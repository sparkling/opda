# OPDA Knowledge Base — UI Kit

High-fidelity restyle of the OPDA Knowledge Base docs site in the warm-canvas,
terracotta-accent, slab-serif editorial system.

## Files

- **`index.html`** — Landing page with hero + seven section cards. Same content
  as upstream `docs/index.html`, restyled.
- **`governance.html`** — Section page: dark sidebar, prose article, card grid,
  right-rail TOC, status table, key callout. Shows the full chrome.
- **`modelling.html`** — Section page with embedded data browser (toolbar +
  zebra table + pagination), overlay catalogue, mermaid-replacement diagram.
- **`design-system.html`** — Inline component showcase. Palette swatches, full
  type scale, every callout, every pill, buttons, tables, cards, pull-quote.

All pages share `../../design-system.css` (which imports `colors_and_type.css`
and the bundled `@font-face` declarations).

## Compatibility

Every class hook the original upstream HTML uses keeps working — no markup
changes required:

| Class                              | Where it shows up                |
|------------------------------------|----------------------------------|
| `.home-hero` `.home-section-card`  | landing page                     |
| `.app-header` `.app-sidebar` `.toc`| chrome on every page             |
| `.prose` `.lead` `.page-meta`      | article body                     |
| `.card` `.card-grid`               | card grids in section overviews  |
| `.callout` (+ `--note/--key/--warn/--success/--danger`) | pull-out boxes |
| `.pill` (+ `--brand/--info/--success/--warn/--accent`)  | tags & badges  |
| `.cta` `.btn` `.btn--ghost`        | buttons                          |
| `.data-browser` `.db-*`            | properties + entities tables     |
| `.overlay-catalogue` `.enum-pill`  | modelling page                   |
| `.diagram` `.mermaid`              | inline diagrams                  |

## Interactive bits

- The theme-toggle button in the header flips `data-theme` between `dark` and
  `light` on `<html>`.
- Section cards link between `index.html` ↔ `governance.html` ↔ `modelling.html`
  ↔ `design-system.html`.
- The data-browser toolbar inputs are live (just not wired to a dataset — this
  is a visual kit, not the production data layer).

## What we deliberately did NOT recreate

- The Mermaid runtime, JSON Crack iframe loader, and 8k-row data backend —
  those are functional concerns. The visual treatments for both surfaces are
  here as static HTML so a designer can iterate without spinning up the live
  site.
- The Astro build wrapper.
- The 25+ topic pages under `docs/pages/`. The four pages in this kit cover
  every distinct layout the rest of the site composes from.
