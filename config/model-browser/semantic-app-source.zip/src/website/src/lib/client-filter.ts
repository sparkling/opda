/**
 * Pure functions for filtering, sorting, and pagination.
 */

// Tier 1 facets (always visible) + Tier 2 (collapsed under "More filters")
export const FACET_TIER1_KEYS = [
  'context', 'subjectArea', 'dataClassification', 'valueChainPosition', 'governanceTier',
] as const;

export const FACET_TIER2_KEYS = [
  'volatility', 'regulatoryRelevance', 'lifecycle', 'sourceSystem', 'stereotype',
] as const;

export const FACET_KEYS = [
  ...FACET_TIER1_KEYS, ...FACET_TIER2_KEYS,
] as const;

export type FacetKey = typeof FACET_KEYS[number];

export const VOCABULARY_FACET_KEYS = ['context', 'schemeType', 'subjectArea'] as const;

export const PROPERTY_FACET_KEYS = ['subjectArea', 'type', 'domain', 'rangeClass', 'datatype', 'characteristics'] as const;

export const SHAPE_FACET_KEYS = ['category', 'context', 'targetType'] as const;

export interface FacetCount {
  value: string;
  count: number;
}

export interface FacetCounts {
  [key: string]: FacetCount[];
}

export interface ActiveFilters {
  [key: string]: string[];
}

export interface PaginationResult<T> {
  pageItems: T[];
  page: number;
  totalCount: number;
  totalPages: number;
}

/** Facets where multiple selected values are AND'ed (item must match all). */
const AND_FACETS = new Set(['characteristics']);

/** Keep items matching ALL active facets (AND across facets, OR within — except AND_FACETS). */
export function applyFilters<T extends Record<string, any>>(
  items: T[],
  filters: ActiveFilters,
): T[] {
  return items.filter(item =>
    Object.entries(filters).every(([key, values]) => {
      if (values.length === 0) return true;
      const v = item[key];
      if (AND_FACETS.has(key)) {
        // AND: item must contain every selected value
        if (Array.isArray(v)) return values.every(sel => v.includes(sel));
        return values.length === 1 && values.includes(v);
      }
      // subjectArea: also match on subjectAreaLocalName for localName-based URLs
      if (key === 'subjectArea' && item.subjectAreaLocalName) {
        return values.includes(v) || values.includes(item.subjectAreaLocalName);
      }
      if (Array.isArray(v)) return v.some((x: string) => values.includes(x));
      return values.includes(v);
    })
  );
}

/**
 * Count occurrences of each facet value using disjunctive faceting.
 * For each facet, counts are computed against items filtered by all OTHER
 * active facets — but NOT by that facet itself. This keeps all options
 * visible for multiselect within a facet.
 */
export function computeFacetCounts<T extends Record<string, any>>(
  items: T[],
  facetKeys: readonly string[],
  activeFilters?: ActiveFilters,
): FacetCounts {
  const facets: FacetCounts = {};
  for (const key of facetKeys) {
    // Filter by all facets EXCEPT this one (disjunctive)
    let pool = items;
    if (activeFilters) {
      const otherFilters: ActiveFilters = {};
      for (const [k, v] of Object.entries(activeFilters)) {
        if (k !== key) otherFilters[k] = v;
      }
      pool = applyFilters(items, otherFilters);
    }

    const counts = new Map<string, number>();
    for (const item of pool) {
      const val = item[key];
      if (Array.isArray(val)) {
        for (const v of val) { if (v) counts.set(v, (counts.get(v) || 0) + 1); }
      } else if (val) {
        counts.set(val, (counts.get(val) || 0) + 1);
      }
    }
    facets[key] = [...counts.entries()]
      .map(([value, count]) => ({ value, count }))
      .sort((a, b) => b.count - a.count);
  }
  return facets;
}

/** Sort items by a string field. */
export function sortItems<T extends Record<string, any>>(
  items: T[],
  field: string,
  direction: 'asc' | 'desc',
): T[] {
  return [...items].sort((a, b) => {
    const av = (a[field] || '').toString().toLowerCase();
    const bv = (b[field] || '').toString().toLowerCase();
    const cmp = av.localeCompare(bv);
    return direction === 'desc' ? -cmp : cmp;
  });
}

/** Paginate items. */
export function paginate<T>(
  items: T[],
  page: number,
  pageSize: number,
): PaginationResult<T> {
  const totalCount = items.length;
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));
  const safePage = Math.min(Math.max(1, page), totalPages);
  return {
    pageItems: items.slice((safePage - 1) * pageSize, safePage * pageSize),
    page: safePage,
    totalCount,
    totalPages,
  };
}

/** Parse filters from URL search params. */
export function parseFiltersFromUrl(url: URL, keys: readonly string[]): ActiveFilters {
  const filters: ActiveFilters = {};
  for (const key of keys) {
    const val = url.searchParams.get(key);
    if (val) {
      const parts = val.split(',').filter(Boolean);
      filters[key] = parts;
    }
    else filters[key] = [];
  }
  return filters;
}

/** Sync current state to URL. */
export function syncUrl(state: {
  filters: ActiveFilters;
  sort: string;
  direction: string;
  page: number;
  pageSize?: number;
  defaultSort?: string;
}, rootToggle?: HTMLInputElement | null) {
  const params = new URLSearchParams();
  for (const [key, values] of Object.entries(state.filters)) {
    if (values.length > 0) params.set(key, values.join(','));
  }
  if (state.sort !== (state.defaultSort || 'name')) params.set('sort', state.sort);
  if (state.direction !== 'asc') params.set('direction', state.direction);
  if (state.page > 1) params.set('page', String(state.page));
  if (state.pageSize && state.pageSize !== 25) params.set('pageSize', String(state.pageSize));
  if (rootToggle?.checked) params.set('rootOnly', 'true');
  // Preserve sidebar state across filter changes
  const currentSidebar = new URL(window.location.href).searchParams.get('sidebar');
  if (currentSidebar) params.set('sidebar', currentSidebar);
  const url = params.toString() ? `?${params}` : window.location.pathname;
  history.pushState(null, '', url);
}
