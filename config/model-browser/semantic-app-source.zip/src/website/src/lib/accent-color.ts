const ACCENT_COLORS = ['text-blue-500', 'text-emerald-500', 'text-purple-500', 'text-amber-500', 'text-rose-500', 'text-cyan-500'];

const BADGE_PALETTE = [
  'bg-blue-100 text-blue-700 border-blue-200',
  'bg-emerald-100 text-emerald-700 border-emerald-200',
  'bg-amber-100 text-amber-700 border-amber-200',
  'bg-violet-100 text-violet-700 border-violet-200',
  'bg-red-100 text-red-700 border-red-200',
  'bg-sky-100 text-sky-700 border-sky-200',
  'bg-purple-100 text-purple-700 border-purple-200',
  'bg-rose-100 text-rose-700 border-rose-200',
  'bg-cyan-100 text-cyan-700 border-cyan-200',
  'bg-indigo-100 text-indigo-700 border-indigo-200',
];

export function hashCode(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

export function accentColorForContext(ctxKey: string): string {
  if (!ctxKey) return 'text-gray-400';
  return ACCENT_COLORS[hashCode(ctxKey) % ACCENT_COLORS.length];
}

export function badgeColorForContext(ctxKey: string): string {
  if (!ctxKey) return 'bg-gray-100 text-gray-600 border-gray-200';
  return BADGE_PALETTE[hashCode(ctxKey) % BADGE_PALETTE.length];
}

export function badgeColorForCategory(category: string): string {
  if (!category) return 'bg-gray-100 text-gray-700 border-gray-200';
  return BADGE_PALETTE[hashCode(category) % BADGE_PALETTE.length];
}
