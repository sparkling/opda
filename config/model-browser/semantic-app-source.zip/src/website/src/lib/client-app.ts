/**
 * Main client-side application entry point.
 * Initializes the RDF store, materializes data, and binds UI events.
 */
import { getStore } from './rdf-store';
import { materialize } from './materialize';
import type { MaterializedConcept, MaterializedProperty, MaterializedVocabulary, MaterializedShape, MaterializedData } from './materialize';
import { INTERNAL_BC_NOTATIONS } from './descriptors/boundary';
import { buildSearchIndex } from './client-search';
import {
  applyFilters,
  computeFacetCounts,
  sortItems,
  paginate,
  parseFiltersFromUrl,
  syncUrl,
  FACET_KEYS,
  FACET_TIER2_KEYS,
  VOCABULARY_FACET_KEYS,
  PROPERTY_FACET_KEYS,
  SHAPE_FACET_KEYS,
  type ActiveFilters,
} from './client-filter';
import { buildListingSearch, DEFAULT_PAGE_SIZE } from './listing-nav';
import {
  renderFacetSidebar,
  renderTable,
  renderCards,
  renderPagination,
  renderSearchResults,
  renderStatus,
  renderActiveFilterChips,
  facetTagHtml,
  type TableColumn,
} from './client-render';
import type MiniSearch from 'minisearch';

import {
  FACET_ICONS,
  FACET_COLOURS,
  DEFAULT_FACET_COLOUR,
  FACET_LABELS as _BASE_LABELS,
  CARD_FACET_KEYS,
  DEFAULT_CARD_FACETS,
  getVisibleCardFacets,
  saveVisibleCardFacets,
  isCardFacetsCustomized,
} from './facet-icons';
import { pillClass } from './pill-colours';
import { badgeColorForContext, badgeColorForCategory } from './accent-color';

/** Run-scope prefix — set by SSR listing pages via window.__hmRunScope.basePath */
const runBasePath: string = (window as any).__hmRunScope?.basePath || '';

// Extend shared labels with page-specific facets not in the icon registry
const FACET_LABELS: Record<string, string> = {
  ..._BASE_LABELS,
  context: 'Bounded Context',
  required: 'Required',
  functional: 'Functional',
  inverseFunctional: 'Inverse Functional',
  transitive: 'Transitive',
  characteristics: 'Characteristics',
  category: 'Category',
  targetType: 'Target Type',
};

interface AppState {
  filters: ActiveFilters;
  sort: string;
  direction: 'asc' | 'desc';
  page: number;
  pageSize: number;
}

let data: MaterializedData | null = null;
let searchIndex: MiniSearch | null = null;
let visibleCardFacets: Set<string> = getVisibleCardFacets();
let currentListingSearch = '';

/** Initialize: fetch TTL, parse, materialize, render. */
export async function initApp(pageType: 'concepts' | 'properties' | 'vocabularies' | 'shapes') {
  const store = await getStore();
  data = materialize(store);
  // Hide blacklisted (non-domain) bounded contexts from the shapes/vocab
  // listings, their facets and search — matching the boundaries/mappings
  // exclusion (INTERNAL_BC_NOTATIONS).
  data.shapes = data.shapes.filter((s: any) => !INTERNAL_BC_NOTATIONS.has(s.context));
  data.vocabularies = data.vocabularies.filter((v: any) => !INTERNAL_BC_NOTATIONS.has(v.context));
  contextLabels = data.contextLabels;
  searchIndex = buildSearchIndex(data.concepts, data.properties, data.vocabularies, data.shapes);

  const url = new URL(window.location.href);
  const allFacetKeys = Array.from(new Set([...FACET_KEYS, ...getFacetKeys(pageType)]));
  // Build subjectArea localName → label map for URL resolution
  const saLocalNameToLabel: Record<string, string> = {};
  for (const item of [...data.concepts, ...data.properties, ...data.vocabularies]) {
    if ((item as any).subjectAreaLocalName && (item as any).subjectArea) {
      saLocalNameToLabel[(item as any).subjectAreaLocalName] = (item as any).subjectArea;
    }
  }

  const state: AppState = {
    filters: parseFiltersFromUrl(url, allFacetKeys),
    sort: url.searchParams.get('sort') || 'name',
    direction: (url.searchParams.get('direction') || 'asc') as 'asc' | 'desc',
    page: Math.max(1, parseInt(url.searchParams.get('page') || '1', 10)),
    pageSize: parseInt(url.searchParams.get('pageSize') || String(DEFAULT_PAGE_SIZE), 10),
  };

  // Resolve subjectArea localNames to display labels for sidebar matching
  if (state.filters.subjectArea?.length) {
    state.filters.subjectArea = state.filters.subjectArea.map(
      v => saLocalNameToLabel[v] || v
    );
  }

  // Bind inline search
  const inlineSearch = document.getElementById('inline-search') as HTMLInputElement | null;
  if (inlineSearch) {
    const initialQ = url.searchParams.get('q') || '';
    if (initialQ) inlineSearch.value = initialQ;

    inlineSearch.addEventListener('input', () => {
      state.page = 1;
      renderListing(pageType, state);
    });
  }

  renderListing(pageType, state);

  // ADR-0072: Wire card display settings gear menu (concepts page only)
  if (pageType === 'concepts') {
    initCardSettings(() => renderListing(pageType, state));
  }
  // it pushes URL state and dispatches popstate, which the popstate handler below picks up.

  // Bind shape view segmented control (ADR-0075)
  if (pageType === 'shapes') {
    document.addEventListener('hm:shape-view', () => {
      state.page = 1;
      renderListing(pageType, state);
    });
  }

  // Bind root classes toggle
  const rootToggle = document.getElementById('root-classes-only') as HTMLInputElement | null;
  if (rootToggle) {
    if (url.searchParams.get('rootOnly') === 'true') rootToggle.checked = true;
    rootToggle.addEventListener('change', () => {
      state.page = 1;
      syncUrl(state, rootToggle);
      renderListing(pageType, state);
    });
  }

  window.addEventListener('popstate', () => {
    const u = new URL(window.location.href);
    state.filters = parseFiltersFromUrl(u, allFacetKeys);
    // Resolve subjectArea localNames to display labels
    if (state.filters.subjectArea?.length) {
      state.filters.subjectArea = state.filters.subjectArea.map(
        v => saLocalNameToLabel[v] || v
      );
    }
    state.sort = u.searchParams.get('sort') || 'name';
    state.direction = (u.searchParams.get('direction') || 'asc') as 'asc' | 'desc';
    state.page = Math.max(1, parseInt(u.searchParams.get('page') || '1', 10));
    state.pageSize = parseInt(u.searchParams.get('pageSize') || String(DEFAULT_PAGE_SIZE), 10);
    const inlineEl = document.getElementById('inline-search') as HTMLInputElement | null;
    if (inlineEl) inlineEl.value = u.searchParams.get('q') || '';
    if (rootToggle) rootToggle.checked = u.searchParams.get('rootOnly') === 'true';
    renderListing(pageType, state);
  });
}

function getItems(pageType: string): any[] {
  if (!data) return [];
  if (pageType === 'concepts') return data.concepts;
  if (pageType === 'properties') return data.properties;
  if (pageType === 'vocabularies') return data.vocabularies;
  if (pageType === 'shapes') return data.shapes;
  return [];
}

function getFacetKeys(pageType: string): readonly string[] {
  if (pageType === 'concepts') return FACET_KEYS;
  if (pageType === 'properties') return PROPERTY_FACET_KEYS;
  if (pageType === 'vocabularies') return VOCABULARY_FACET_KEYS;
  if (pageType === 'shapes') return SHAPE_FACET_KEYS;
  return [] as const;
}

function getColumns(pageType: string): TableColumn[] {
  if (pageType === 'concepts') {
    return [
      { key: 'context', label: 'Boundary', sortable: true, renderHtml: (item: MaterializedConcept) =>
        contextLabelHtml(item.context) },
      { key: 'name', label: 'Name', sortable: true, renderHtml: (item: MaterializedConcept) => {
        const stereo = item.stereotype && item.stereotype !== 'Kind'
          ? `<div class="text-xs text-gray-500 mt-0.5">${escapeHtml(item.stereotype)}</div>` : '';
        return `<a href="${runBasePath}/concepts/${item.context}/${item.localName}${currentListingSearch}" class="font-medium text-blue-600 hover:text-blue-800 hover:underline">${escapeHtml(item.name)}</a>${stereo}`;
      }},
      { key: 'subjectArea', label: 'Subject Area', sortable: true, renderHtml: (item: MaterializedConcept) =>
        item.subjectArea ? `<a href="/subject/${encodeURIComponent(item.subjectAreaLocalName || item.subjectArea)}" class="text-blue-600 hover:text-blue-800 hover:underline">${escapeHtml(item.subjectArea)}</a>` : '' },
      { key: 'definition', label: 'Definition', renderHtml: (item: MaterializedConcept) => {
        const text = item.definition || item.comment;
        return text ? `<span class="text-gray-500">${truncate(text, 60)}</span>` : '';
      }},
    ];
  }
  if (pageType === 'properties') {
    return [
      { key: 'name', label: 'Name', sortable: true, renderHtml: (item: MaterializedProperty) => {
        const badge = contextBadgeHtml(item.context);
        return `<a href="${runBasePath}/properties/${item.context}/${item.localName}${currentListingSearch}" class="font-medium text-blue-600 hover:text-blue-800 hover:underline">${escapeHtml(sentenceCase(item.name))}</a> ${badge}`;
      }},
      { key: 'type', label: 'Type', renderHtml: (item: MaterializedProperty) =>
        item.type === 'ObjectProperty'
          ? '<span class="inline-block rounded-full bg-indigo-100 px-2.5 py-0.5 text-xs font-medium text-indigo-700">Object</span>'
          : '<span class="inline-block rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-medium text-amber-700">Datatype</span>' },
      { key: 'domain', label: 'Domain', sortable: true, renderHtml: (item: MaterializedProperty) => {
        const links: { label: string; localName: string; context: string }[] = (item as any).domainLinks || [];
        if (links.length === 0) return '';
        return links.map(d =>
          d.context && d.localName
            ? `<a href="${runBasePath}/concepts/${d.context}/${d.localName}" class="text-blue-600 hover:text-blue-800 hover:underline">${escapeHtml(d.label)}</a>`
            : escapeHtml(d.label)
        ).join(' <span class="text-gray-300">|</span> ');
      }},
      { key: 'range', label: 'Range', sortable: true, renderHtml: (item: MaterializedProperty) => {
        if (!item.range) return '';
        return item.rangeLocalName
          ? `<a href="${runBasePath}/concepts/${item.rangeContext || ''}/${item.rangeLocalName}" class="text-blue-600 hover:text-blue-800 hover:underline">${escapeHtml(item.range)}</a>`
          : `<code class="rounded bg-gray-100 px-1.5 py-0.5 font-mono text-xs">${escapeHtml(item.range)}</code>`;
      }},
      { key: 'usedByCount', label: 'Used By', sortable: true, renderHtml: (item: MaterializedProperty) =>
        `<span class="text-gray-600">${item.usedByCount ?? ''}</span>` },
    ];
  }
  if (pageType === 'vocabularies') {
    return [
      { key: 'name', label: 'Name', sortable: true, renderHtml: (item: MaterializedVocabulary) => {
        const badge = contextBadgeHtml(item.context);
        return `<a href="${runBasePath}/vocabularies/${item.context}/${item.localName}${currentListingSearch}" class="font-medium text-blue-600 hover:text-blue-800 hover:underline">${escapeHtml(item.name)}</a> ${badge}`;
      }},
      { key: 'schemeType', label: 'Type', renderHtml: (item: MaterializedVocabulary) => {
        const t = item.schemeType || 'Closed';
        const cls = badgeColorForCategory(t);
        return `<span class="inline-block rounded-full px-2.5 py-0.5 text-xs font-medium ${cls}">${escapeHtml(t)}</span>`;
      }},
      { key: 'definition', label: 'Description', renderHtml: (item: MaterializedVocabulary) => truncate(item.definition, 60) },
      { key: 'valueCount', label: 'Values', sortable: true, renderHtml: (item: MaterializedVocabulary) => {
        if (item.schemeType === 'Open-ended') return '<span class="text-gray-400" title="Members managed in source systems">\u2014</span>';
        return `<span>${item.valueCount}</span>`;
      }},
    ];
  }
  if (pageType === 'shapes') {
    return [
      { key: 'name', label: 'Name', sortable: true, renderHtml: (item: MaterializedShape) => {
        const badge = contextBadgeHtml(item.context);
        const href = item.isStandalone
          ? `${runBasePath}/shapes/${item.context}/${item.localName}${currentListingSearch}`
          : `${runBasePath}/concepts/${item.context}/${item.localName}${currentListingSearch}`;
        return `<a href="${href}" class="font-medium text-blue-600 hover:text-blue-800 hover:underline">${escapeHtml(item.name)}</a> ${badge}`;
      }},
      { key: 'category', label: 'Category', renderHtml: (item: MaterializedShape) => {
        const cls = badgeColorForCategory(item.category);
        return `<span class="inline-block rounded-full px-2.5 py-0.5 text-xs font-medium ${cls}">${escapeHtml(item.category)}</span>`;
      }},
      { key: 'targetLabel', label: 'Target', renderHtml: (item: MaterializedShape) =>
        item.targetLabel ? `<span class="text-gray-600">${escapeHtml(item.targetLabel)}</span>` : '' },
      { key: 'propertyCount', label: 'Properties', sortable: true, renderHtml: (item: MaterializedShape) =>
        `<span class="text-gray-600">${item.propertyCount || ''}</span>` },
    ];
  }
  // vocabularies (legacy fallback — redirects to vocabularies)
  return [
    { key: 'name', label: 'Name', sortable: true, renderHtml: (item: MaterializedVocabulary) =>
      `<a href="${runBasePath}/vocabularies/${item.context}/${item.localName}${currentListingSearch}" class="font-medium text-blue-600 hover:text-blue-800 hover:underline">${escapeHtml(item.name)}</a>` },
    { key: 'context', label: 'Context', sortable: true, renderHtml: (item: MaterializedVocabulary) => contextBadgeHtml(item.context) },
    { key: 'valueCount', label: 'Value Count', sortable: true },
  ];
}

function renderConceptCard(item: any): string {
  const ctx = item.context || '';

  // Zone 1: Boundary context header (full label from BoundedContextScheme) + URI right-aligned
  const uriHtml = uriRefHtml(item.context || '', item.localName || '');
  const zone1 = `<div class="flex items-center justify-between gap-2">${contextFilterLabelHtml(ctx)}${uriHtml}</div>`;

  // Zone 2: Name + stereotype + alt labels (ODR-0052 R6: abbreviations first, max 3)
  const stereo = item.stereotype && item.stereotype !== 'Kind'
    ? `<span class="ml-auto inline-block shrink-0 rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-600">${escapeHtml(item.stereotype)}</span>` : '';
  let altLabelHtml = '';
  if (item.altLabels?.length) {
    const sorted = [...item.altLabels].sort((a: string, b: string) => {
      const aShort = a.length <= 5 ? 0 : 1;
      const bShort = b.length <= 5 ? 0 : 1;
      return aShort !== bShort ? aShort - bShort : a.localeCompare(b);
    });
    const shown = sorted.slice(0, 3);
    const extra = sorted.length - shown.length;
    const text = shown.map(escapeHtml).join(', ') + (extra > 0 ? ', …' : '');
    altLabelHtml = `<p class="mt-0.5 text-xs text-gray-400 truncate">${text}</p>`;
  }
  const zone2 = `<div class="mt-0.5 flex items-center gap-2">
    <h3 class="min-w-0 truncate text-base font-semibold text-gray-900 group-hover:text-blue-600">${escapeHtml(item.name)}</h3>
    ${stereo}
  </div>${altLabelHtml}`;

  // Zone 3: Definition with comment fallback
  const defText = item.definition || item.comment || '';
  const zone3 = defText
    ? `<p class="mt-2 text-sm text-gray-600 line-clamp-2">${escapeHtml(defText)}</p>`
    : '<p class="mt-2 text-sm italic text-gray-400">No description yet</p>';

  // Zone 4: Classification metadata footer (ODR-0052) — only visible facets (ADR-0072)
  const facets: string[] = [];
  if (visibleCardFacets.has('subjectArea')) facets.push(facetTagHtml('subjectArea', 'Subject Area', item.subjectArea || ''));
  if (visibleCardFacets.has('dataClassification')) facets.push(facetTagHtml('dataClassification', 'Data Classification', item.dataClassification || ''));
  if (visibleCardFacets.has('valueChainPosition') && item.valueChainPosition) facets.push(facetTagHtml('valueChainPosition', 'Value Chain Position', item.valueChainPosition));
  if (visibleCardFacets.has('governanceTier')) facets.push(facetTagHtml('governanceTier', 'Governance Tier', item.governanceTier || ''));
  if (visibleCardFacets.has('volatility')) facets.push(facetTagHtml('volatility', 'Volatility', item.volatility || ''));
  if (visibleCardFacets.has('regulatoryRelevance') && item.regulatoryRelevance) facets.push(facetTagHtml('regulatoryRelevance', 'Regulatory Relevance', item.regulatoryRelevance));
  if (visibleCardFacets.has('lifecycle') && item.lifecycle && item.lifecycle !== 'Run-Time') facets.push(facetTagHtml('lifecycle', 'Lifecycle Stage', item.lifecycle));
  if (visibleCardFacets.has('sourceSystem') && item.sourceSystem) facets.push(facetTagHtml('sourceSystem', 'Source System', item.sourceSystem));
  if (visibleCardFacets.has('stereotype') && item.stereotype) facets.push(facetTagHtml('stereotype', 'Stereotype', item.stereotype));
  const zone4 = facets.length > 0
    ? `<div class="mt-3 -mx-5 -mb-5 border-t border-gray-100 px-5 py-3 flex flex-wrap gap-4">${facets.join('')}</div>`
    : '';

  return `<a href="${runBasePath}/concepts/${item.context || ''}/${item.localName}${currentListingSearch}" class="group block rounded-lg border border-gray-200 bg-white shadow-sm hover:shadow-md hover:border-gray-300 transition-all overflow-hidden">
    <div class="p-5">
      ${zone1}${zone2}${zone3}${zone4}
    </div>
  </a>`;
}

function renderPropertyCard(item: any): string {
  const ctx = item.context || '';

  // Zone 1: Boundary context header + URI right-aligned
  const uriHtml = uriRefHtml(item.context || '', item.localName || '');
  const zone1 = `<div class="flex items-center justify-between gap-2">${contextFilterLabelHtml(ctx)}${uriHtml}</div>`;

  // Characteristic pills row
  const CHAR_PILL_KEY: Record<string, string> = {
    'Required': 'required', 'Derived': 'derived', 'Functional': 'functional',
    'Inverse Functional': 'inverseFunctional', 'Transitive': 'transitive',
  };
  const chars: string[] = item.characteristics || [];
  const pills = chars.map((c: string) =>
    `<span class="${pillClass(CHAR_PILL_KEY[c] || '')}">${escapeHtml(c)}</span>`
  ).filter(Boolean);
  const pillsRow = pills.length > 0 ? `<div class="mt-1.5 flex flex-wrap gap-1.5">${pills.join('')}</div>` : '';

  // Range type
  let typeHtml = '';
  if (item.range) {
    if (item.rangeLocalName) {
      typeHtml = `<span class="text-sm text-right text-blue-600 hover:text-blue-800 hover:underline" onclick="event.preventDefault(); event.stopPropagation(); window.location.href='${runBasePath}/concepts/${item.rangeContext || ''}/${item.rangeLocalName}'">${escapeHtml(item.range)}</span>`;
    } else {
      typeHtml = `<span class="font-mono text-sm text-gray-900">${escapeHtml(item.range)}</span>`;
    }
  }
  const cardinalityHtml = item.cardinality ? `<span class="font-mono text-xs text-gray-400">${escapeHtml(item.cardinality)}</span>` : '';

  const propHref = `${runBasePath}/properties/${item.context || ''}/${item.localName}${currentListingSearch}`;
  const nameHtml = `<h3 class="truncate text-base font-semibold text-gray-900 group-hover:text-blue-600">${escapeHtml(sentenceCase(item.name))}</h3>`;

  // ODR-0052 R6: altLabels sorted abbreviations-first, max 3
  let propAltLabelHtml = '';
  if (item.altLabels?.length) {
    const sorted = [...item.altLabels].sort((a: string, b: string) => {
      const aShort = a.length <= 5 ? 0 : 1;
      const bShort = b.length <= 5 ? 0 : 1;
      return aShort !== bShort ? aShort - bShort : a.localeCompare(b);
    });
    const shown = sorted.slice(0, 3);
    const extra = sorted.length - shown.length;
    const text = shown.map(escapeHtml).join(', ') + (extra > 0 ? ', …' : '');
    propAltLabelHtml = `<p class="mt-0.5 text-xs text-gray-400 truncate">${text}</p>`;
  }

  const defText = item.definition || item.comment || '';
  const defHtml = defText
    ? `<p class="mt-1 text-sm text-gray-600 line-clamp-2">${escapeHtml(defText)}</p>`
    : '<p class="mt-1 text-sm italic text-gray-400">No description yet</p>';

  const domainLinks: { label: string; localName: string; context: string }[] = item.domainLinks || [];
  const domainHtml = domainLinks.length > 0
    ? domainLinks.map(d =>
        d.context && d.localName
          ? `<a href="${runBasePath}/concepts/${d.context}/${d.localName}" class="text-blue-600 hover:text-blue-800 hover:underline" onclick="event.stopPropagation()">${escapeHtml(d.label)}</a>`
          : escapeHtml(d.label)
      ).join(' <span class="text-gray-300">|</span> ')
    : '';
  const domainLabel = domainLinks.length > 0;
  const domainArrow = `<svg class="inline-block h-4 w-4 text-gray-300 ml-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M3 12h18m0 0l-4-4m4 4l-4 4"/></svg>`;

  // Row 1: name + altLabels (left) + type (right)
  const row1 = `<div class="mt-2 flex items-start justify-between gap-2">
    <div class="min-w-0 flex-1">${nameHtml}${propAltLabelHtml}${defHtml}</div>
    ${typeHtml ? `<div class="shrink-0 max-w-[50%] text-right pl-2 flex items-center gap-2">${domainArrow}${typeHtml}</div>` : ''}
  </div>`;

  // Row 2: domain (left) + cardinality (right)
  const row2 = (domainLabel || cardinalityHtml)
    ? `<div class="mt-2 flex items-center justify-between gap-2 text-sm text-gray-500">
        <div class="min-w-0">${domainLabel ? domainHtml + domainArrow : ''}</div>
        ${cardinalityHtml}
      </div>`
    : '';

  return `<div class="group rounded-lg border border-gray-200 bg-white shadow-sm hover:shadow-md hover:border-gray-300 transition-all overflow-hidden cursor-pointer" onclick="window.location.href='${propHref}'">
    <div class="p-5">
      ${zone1}${row1}${row2}${pillsRow}
    </div>
  </div>`;
}

function renderShapeCard(item: any): string {
  const ctx = item.context || '';
  const uriHtml = uriRefHtml(item.context || '', item.localName || '');

  // Zone 1: Context + URI ref
  const zone1 = `<div class="flex items-center justify-between gap-2">${contextFilterLabelHtml(ctx)}${uriHtml}</div>`;

  // Zone 2: Name + category badge
  const badgeCls = badgeColorForCategory(item.category);
  const badgeHtml = `<span class="inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-medium ${badgeCls}">${escapeHtml(item.category)}</span>`;

  const zone2 = `<div class="mt-0.5 flex items-center gap-2">
    <h3 class="min-w-0 truncate text-base font-semibold text-gray-900 group-hover:text-blue-600">${escapeHtml(item.name)}</h3>
    ${badgeHtml}
  </div>`;

  // Zone 3: Definition (line-clamp-2)
  const defText = item.definition || item.comment || '';
  const zone3 = defText
    ? `<p class="mt-2 text-sm text-gray-600 line-clamp-2">${escapeHtml(defText)}</p>`
    : '<p class="mt-2 text-sm italic text-gray-400">No description yet</p>';

  // Zone 4: Target description + property count
  const TARGET_TEMPLATES: Record<string, (label: string) => string> = {
    'Class Shape': () => 'Validates instances',
    'Value Validator': (l) => `Validates values of: ${l}`,
    'Governance': (l) => `Applies to: ${l}`,
    'Quality Gate': (l) => `Enforces: ${l}`,
    'Disjointness': (l) => `Partitions: ${l} subtypes`,
    'Rule': (l) => `Materialises on: ${l}`,
  };
  const targetDesc = (TARGET_TEMPLATES[item.category] || (() => ''))(escapeHtml(item.targetLabel || ''));
  const propChip = item.propertyCount ? `${item.propertyCount} properties` : '';
  const z4Parts = [targetDesc, propChip].filter(Boolean);
  const zone4 = z4Parts.length > 0
    ? `<div class="mt-3 -mx-5 -mb-5 border-t border-gray-100 px-5 py-3 text-xs text-gray-500">${z4Parts.join(' \u00b7 ')}</div>`
    : '';

  const href = item.isStandalone
    ? `${runBasePath}/shapes/${item.context || ''}/${item.localName}${currentListingSearch}`
    : `${runBasePath}/concepts/${item.context || ''}/${item.localName}${currentListingSearch}`;

  return `<a href="${href}" class="group block rounded-lg border border-gray-200 bg-white shadow-sm hover:shadow-md hover:border-gray-300 transition-all overflow-hidden">
    <div class="p-5">
      ${zone1}${zone2}${zone3}${zone4}
    </div>
  </a>`;
}

function renderVocabularyCard(item: any): string {
  const ctx = item.context || '';
  const uriHtml = uriRefHtml(item.context || '', item.localName || '');

  // Zone 1: Context header + URI ref
  const zone1 = `<div class="flex items-center justify-between gap-2">${contextFilterLabelHtml(ctx)}${uriHtml}</div>`;

  // Zone 2: Name + type badge + value count
  const st = item.schemeType || 'Closed';
  const typeCls = badgeColorForCategory(st);
  const typeBadge = `<span class="inline-block rounded-full px-2.5 py-0.5 text-xs font-medium ${typeCls}">${escapeHtml(st)}</span>`;
  const countText = st === 'Open-ended'
    ? `<span class="text-sm text-gray-400" title="Members managed in source systems">\u2014</span>`
    : `<span class="text-sm text-gray-500">${item.valueCount} values</span>`;

  const zone2 = `<div class="mt-1.5 flex items-center gap-2">
    <h3 class="min-w-0 truncate text-base font-semibold text-gray-900 group-hover:text-blue-600">${escapeHtml(item.name)}</h3>
    <div class="ml-auto flex items-center gap-2 shrink-0">${typeBadge} <span class="text-gray-300">\u00b7</span> ${countText}</div>
  </div>`;

  // Zone 3: Definition
  const defText = item.definition || '';
  const zone3 = defText
    ? `<p class="mt-2 text-sm text-gray-600 line-clamp-2">${escapeHtml(defText)}</p>`
    : '<p class="mt-2 text-sm italic text-gray-400">No description yet</p>';

  // Footer: Subject area chip (conditional — Classification schemes exempt per ADR-0029 Gap 6)
  const sa = item.subjectArea || '';
  const footer = sa
    ? `<div class="mt-3 -mx-5 -mb-5 border-t border-gray-100 px-5 py-3 flex flex-wrap gap-4"><span class="inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-medium bg-blue-50 border-blue-200 text-blue-700 cursor-pointer hover:bg-blue-100 transition-colors" data-filter-facet="subjectArea" data-filter-value="${escapeHtml(sa)}">${escapeHtml(sa)}</span></div>`
    : '';

  return `<a href="${runBasePath}/vocabularies/${item.context || ''}/${item.localName}${currentListingSearch}" class="group block rounded-lg border border-gray-200 bg-white shadow-sm hover:shadow-md hover:border-gray-300 transition-all overflow-hidden">
    <div class="p-5">
      ${zone1}${zone2}${zone3}${footer}
    </div>
  </a>`;
}

function renderListing(pageType: string, state: AppState) {
  const items = getItems(pageType);
  const facetKeys = getFacetKeys(pageType);
  const columns = getColumns(pageType);

  // Apply root classes toggle before facet filtering
  const rootToggle = document.getElementById('root-classes-only') as HTMLInputElement | null;
  let preFiltered = items;
  if (rootToggle?.checked && pageType === 'concepts') {
    preFiltered = items.filter((item: any) => item.isRootClass);
  }

  // Apply shape view segmented control (ADR-0075 S152c F3)
  if (pageType === 'shapes') {
    const viewParam = new URL(window.location.href).searchParams.get('view') || 'all';
    if (viewParam === 'standalone') {
      preFiltered = preFiltered.filter((item: any) => item.isStandalone);
    } else if (viewParam === 'class') {
      preFiltered = preFiltered.filter((item: any) => !item.isStandalone);
    }
  }

  // Apply inline search filter
  const inlineSearch = document.getElementById('inline-search') as HTMLInputElement | null;
  const searchQuery = inlineSearch?.value?.trim() || '';

  // Build search params string for detail page back-links
  currentListingSearch = buildListingSearch({
    filters: state.filters,
    sort: state.sort,
    direction: state.direction,
    page: state.page,
    pageSize: state.pageSize,
    rootOnly: rootToggle?.checked || false,
    q: searchQuery,
  });

  if (searchQuery && searchIndex) {
    const results = searchIndex.search(searchQuery, { prefix: true, fuzzy: 0.2 });
    const matchIds = new Set(results.map(r => r.id));
    preFiltered = preFiltered.filter((item: any) => matchIds.has(item.id));
  }

  // Filter → Sort → Paginate
  const filtered = applyFilters(preFiltered, state.filters);

  // Update search count indicator
  const searchCountEl = document.getElementById('search-count');
  if (searchCountEl) {
    searchCountEl.textContent = searchQuery ? `${filtered.length} found` : '';
  }

  const sorted = sortItems(filtered, state.sort, state.direction);

  const result = paginate(sorted, state.page, state.pageSize);
  const facets = computeFacetCounts(preFiltered, facetKeys, state.filters);

  // Render sidebar — target the content container if using CollapsibleSidebar
  const sidebarEl = document.getElementById('facet-sidebar');
  const sidebar = sidebarEl?.querySelector('[data-sidebar-content]') as HTMLElement ?? sidebarEl;
  if (sidebar) {
    const tier2 = pageType === 'concepts' ? FACET_TIER2_KEYS : undefined;
    renderFacetSidebar(sidebar, facets, state.filters, FACET_LABELS,
      (key, value) => {
        const current = state.filters[key] || [];
        if (current.includes(value)) {
          state.filters[key] = current.filter(v => v !== value);
        } else {
          state.filters[key] = [...current, value];
        }
        // rangeClass and datatype are mutually exclusive
        if (key === 'rangeClass' && state.filters[key].length > 0) state.filters['datatype'] = [];
        if (key === 'datatype' && state.filters[key].length > 0) state.filters['rangeClass'] = [];
        state.page = 1;
        syncUrl(state, rootToggle);
        renderListing(pageType, state);
      },
      () => {
        for (const k of Object.keys(state.filters)) state.filters[k] = [];
        state.page = 1;
        syncUrl(state, rootToggle);
        renderListing(pageType, state);
      },
      tier2,
      { context: contextLabels },
    );
  }

  // Render active filter chips
  const chipsContainer = document.getElementById('active-filters');
  if (chipsContainer) {
    renderActiveFilterChips(chipsContainer, state.filters, FACET_LABELS,
      (key, value) => {
        const current = state.filters[key] || [];
        state.filters[key] = current.filter(v => v !== value);
        state.page = 1;
        syncUrl(state);
        renderListing(pageType, state);
      },
      () => {
        for (const k of Object.keys(state.filters)) {
          if (k !== 'context') state.filters[k] = [];
        }
        state.page = 1;
        syncUrl(state);
        renderListing(pageType, state);
      },
    );
  }


  // Render content — cards for concepts/properties/shapes/vocabularies, table for vocabularies legacy
  const tableContainer = document.getElementById('data-table');
  if (tableContainer) {
    if (pageType === 'concepts') {
      renderCards(tableContainer, 'grid grid-cols-1 gap-4', result.pageItems, renderConceptCard);
      // Wire classification value click → filter shortcut (ODR-0052)
      tableContainer.querySelectorAll('[data-filter-facet]').forEach(el => {
        el.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          const facet = (el as HTMLElement).dataset.filterFacet!;
          const value = (el as HTMLElement).dataset.filterValue!;
          const current = state.filters[facet] || [];
          if (!current.includes(value)) {
            state.filters[facet] = [...current, value];
            state.page = 1;
            syncUrl(state, rootToggle);
            renderListing(pageType, state);
          }
        });
      });
    } else if (pageType === 'properties') {
      renderCards(tableContainer, 'grid grid-cols-1 gap-3', result.pageItems, renderPropertyCard);
    } else if (pageType === 'shapes') {
      renderCards(tableContainer, 'grid grid-cols-1 gap-4', result.pageItems, renderShapeCard);
    } else if (pageType === 'vocabularies') {
      renderCards(tableContainer, 'grid grid-cols-1 gap-4', result.pageItems, renderVocabularyCard);
      // Wire subject area chip click → filter shortcut (ADR-0077)
      tableContainer.querySelectorAll('[data-filter-facet]').forEach(el => {
        el.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          const facet = (el as HTMLElement).dataset.filterFacet!;
          const value = (el as HTMLElement).dataset.filterValue!;
          const current = state.filters[facet] || [];
          if (!current.includes(value)) {
            state.filters[facet] = [...current, value];
            state.page = 1;
            syncUrl(state, rootToggle);
            renderListing(pageType, state);
          }
        });
      });
    } else {
      renderTable(tableContainer, columns, result.pageItems, state.sort, state.direction,
        (field) => {
          if (state.sort === field) {
            state.direction = state.direction === 'asc' ? 'desc' : 'asc';
          } else {
            state.sort = field;
            state.direction = 'asc';
          }
          state.page = 1;
          syncUrl(state, rootToggle);
          renderListing(pageType, state);
        },
      );
    }

    // Wire context label click → filter shortcut + open sidebar (concepts + properties + shapes + vocabularies cards)
    if (pageType === 'concepts' || pageType === 'properties' || pageType === 'shapes' || pageType === 'vocabularies') {
      tableContainer.querySelectorAll('[data-filter-context]').forEach(el => {
        el.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          const value = (el as HTMLElement).dataset.filterContext!;
          const current = state.filters['context'] || [];
          if (!current.includes(value)) {
            state.filters['context'] = [...current, value];
            state.page = 1;
            syncUrl(state, rootToggle);
            renderListing(pageType, state);
          }
          // Open sidebar if collapsed
          const sb = document.querySelector('[data-sidebar]') as HTMLElement | null;
          if (sb?.dataset.collapsed === 'true') {
            const btn = document.getElementById('sidebar-toggle-external') as HTMLButtonElement | null;
            btn?.click();
          }
        });
      });
    }
  }

  // Render pagination
  const paginationContainer = document.getElementById('pagination');
  if (paginationContainer) {
    renderPagination(paginationContainer, result, state.pageSize,
      (page) => {
        state.page = page;
        syncUrl(state, rootToggle);
        renderListing(pageType, state);
      },
      (size) => {
        state.pageSize = size;
        state.page = 1;
        syncUrl(state, rootToggle);
        renderListing(pageType, state);
      },
    );
  }

  // Update count on search bar line
  const listingCountEl = document.getElementById('listing-count');
  if (listingCountEl) {
    listingCountEl.textContent = `${result.totalCount.toLocaleString()} ${pageType}`;
  }
  const statusEl = document.getElementById('status-text');
  if (statusEl) {
    renderStatus(statusEl, `Showing ${result.totalCount.toLocaleString()} ${pageType}`);
  }

  // Sync search query to URL
  const currentUrl = new URL(window.location.href);
  if (searchQuery) currentUrl.searchParams.set('q', searchQuery);
  else currentUrl.searchParams.delete('q');
  history.replaceState(null, '', currentUrl.toString());
}

/** Initialize search page. */
export async function initSearch() {
  const store = await getStore();
  data = materialize(store);
  // Hide blacklisted (non-domain) bounded contexts from the shapes/vocab
  // listings, their facets and search — matching the boundaries/mappings
  // exclusion (INTERNAL_BC_NOTATIONS).
  data.shapes = data.shapes.filter((s: any) => !INTERNAL_BC_NOTATIONS.has(s.context));
  data.vocabularies = data.vocabularies.filter((v: any) => !INTERNAL_BC_NOTATIONS.has(v.context));
  contextLabels = data.contextLabels;
  searchIndex = buildSearchIndex(data.concepts, data.properties, data.vocabularies, data.shapes);

  const input = document.getElementById('search-input') as HTMLInputElement | null;
  const resultsContainer = document.getElementById('search-results');
  if (!input || !resultsContainer) return;

  let typeFilter = '';
  const url = new URL(window.location.href);
  const initialQuery = url.searchParams.get('q') || '';
  typeFilter = url.searchParams.get('type') || '';

  if (initialQuery) {
    input.value = initialQuery;
    doSearch(initialQuery, typeFilter, resultsContainer);
  } else {
    // Replace loading placeholder with ready state
    const totalCount = data.concepts.length + data.properties.length + data.vocabularies.length + data.shapes.length;
    resultsContainer.innerHTML =
      '<div class="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-gray-200 bg-white px-6 py-16 text-center">' +
        '<svg class="h-12 w-12 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">' +
          '<path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />' +
        '</svg>' +
        '<p class="mt-4 text-lg font-medium text-gray-500">Start typing to search</p>' +
        '<p class="mt-1 text-sm text-gray-400">' + totalCount + ' items indexed</p>' +
      '</div>';
  }

  input.addEventListener('input', () => {
    const q = input.value.trim();
    doSearch(q, typeFilter, resultsContainer);
    const params = new URLSearchParams();
    if (q) params.set('q', q);
    if (typeFilter) params.set('type', typeFilter);
    const u = params.toString() ? `?${params}` : window.location.pathname;
    history.replaceState(null, '', u);
  });
}

function doSearch(query: string, typeFilter: string, container: HTMLElement) {
  if (!searchIndex) return;
  const results = query ? searchIndex.search(query, { prefix: true, fuzzy: 0.2 }) : [];
  renderSearchResults(container, results, query, typeFilter,
    (type) => {
      typeFilter = type;
      doSearch(query, typeFilter, container);
    },
  );
}

// --- ADR-0072: Card Display Settings (right sidebar) ---

function initCardSettings(onUpdate: () => void) {
  const wrapper = document.getElementById('card-settings-wrapper');
  const btn = document.getElementById('card-settings-btn');
  const sidebar = document.getElementById('card-settings-sidebar');
  const checks = document.getElementById('card-settings-checks');
  const defaultsBtn = document.getElementById('card-settings-defaults');
  const allBtn = document.getElementById('card-settings-all');
  if (!wrapper || !btn || !sidebar || !checks || !defaultsBtn || !allBtn) return;

  // Show the gear icon (hidden by default for non-concepts pages)
  wrapper.style.display = '';

  const header = sidebar.querySelector('[data-settings-header]') as HTMLElement | null;
  const content = sidebar.querySelector('[data-settings-content]') as HTMLElement | null;
  if (!content) return;

  const WIDTH_OPEN = '18rem';
  const WIDTH_COLLAPSED = '0';
  const WRAPPER_PULL = '-13rem';
  const sidebarWrapper = sidebar.closest('[data-sidebar-wrapper]') as HTMLElement | null;

  function renderCheckboxes() {
    let html = '';
    for (const key of CARD_FACET_KEYS) {
      const icon = FACET_ICONS[key];
      if (!icon) continue;
      const checked = visibleCardFacets.has(key) ? 'checked' : '';
      const c = FACET_COLOURS[key] || DEFAULT_FACET_COLOUR;
      const opacity = visibleCardFacets.has(key) ? '' : 'opacity-50';
      html += `<label class="group flex h-11 min-h-[44px] cursor-pointer items-center gap-3 rounded-md px-2 transition-colors hover:bg-gray-50">
        <input type="checkbox" name="card-facet" value="${key}" ${checked} class="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
        <svg width="16" height="16" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="shrink-0 text-gray-500" aria-hidden="true">${icon.svg}</svg>
        <span class="inline-flex items-center rounded border px-2 py-1 text-[10px] font-semibold uppercase tracking-wider ${c.bg} ${c.text} ${c.border} ${opacity} transition-opacity">${icon.label}</span>
      </label>`;
    }
    checks!.innerHTML = html;
  }

  function applyChange() {
    saveVisibleCardFacets(visibleCardFacets);
    onUpdate();
  }

  function isCollapsed(): boolean {
    return sidebar!.dataset.collapsed === 'true';
  }

  function expand() {
    sidebar!.dataset.collapsed = 'false';
    sidebar!.style.width = WIDTH_OPEN;
    sidebar!.style.marginRight = '';
    sidebar!.style.overflow = '';
    if (sidebarWrapper) sidebarWrapper.style.marginLeft = WRAPPER_PULL;
    content!.style.opacity = '1';
    content!.style.pointerEvents = '';
    if (header) header.style.display = '';
    btn!.setAttribute('aria-expanded', 'true');
    btn!.classList.remove('bg-white', 'border-gray-200', 'text-gray-400');
    btn!.classList.add('bg-blue-50', 'border-blue-200', 'text-blue-600');
    renderCheckboxes();
    // Exclusive: close other sidebars
    document.dispatchEvent(new CustomEvent('sidebar-exclusive', { detail: { id: sidebar!.id } }));
  }

  function collapse(resetWrapper = true) {
    sidebar!.dataset.collapsed = 'true';
    sidebar!.style.width = WIDTH_COLLAPSED;
    sidebar!.style.marginRight = '0';
    sidebar!.style.overflow = 'hidden';
    if (resetWrapper && sidebarWrapper) sidebarWrapper.style.marginLeft = '';
    content!.style.opacity = '0';
    content!.style.pointerEvents = 'none';
    if (header) header.style.display = 'none';
    btn!.setAttribute('aria-expanded', 'false');
    btn!.classList.remove('bg-blue-50', 'border-blue-200', 'text-blue-600');
    btn!.classList.add('bg-white', 'border-gray-200', 'text-gray-400');
  }

  renderCheckboxes();

  // Checkbox toggle
  checks.addEventListener('change', (e) => {
    const target = e.target as HTMLInputElement;
    if (target.name !== 'card-facet') return;
    if (target.checked) {
      visibleCardFacets.add(target.value);
    } else {
      visibleCardFacets.delete(target.value);
    }
    renderCheckboxes();
    applyChange();
  });

  btn.addEventListener('click', () => {
    if (isCollapsed()) expand(); else collapse();
  });

  defaultsBtn.addEventListener('click', () => {
    visibleCardFacets = new Set(DEFAULT_CARD_FACETS);
    renderCheckboxes();
    applyChange();
  });

  allBtn.addEventListener('click', () => {
    visibleCardFacets = new Set(CARD_FACET_KEYS);
    renderCheckboxes();
    applyChange();
  });

  // Escape collapses when focus is inside sidebar
  sidebar.addEventListener('keydown', (e: KeyboardEvent) => {
    if (e.key === 'Escape' && !isCollapsed()) {
      collapse();
      btn!.focus();
    }
  });

  // Exclusive sidebar: collapse when another sidebar opens (don't reset wrapper — opener handles it)
  document.addEventListener('sidebar-exclusive', ((e: CustomEvent) => {
    if (e.detail?.id !== sidebar!.id && !isCollapsed()) {
      collapse(false);
    }
  }) as EventListener);
}

// Helpers
function escapeHtml(str: string): string {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** Sentence-case: capitalise first letter, preserve rest (incl. acronyms). */
function sentenceCase(s: string): string {
  if (!s) return s;
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/**
 * Render a prefixed URI with copy-to-clipboard icon.
 * Client-side mirror of UriRef.astro — keep both in sync.
 */
const URI_MONO_CLS = 'font-mono text-xs text-gray-500';
const URI_BTN_CLS = 'copy-uri inline-flex items-center gap-1 shrink-0 rounded px-1.5 py-0.5 -mr-1.5 cursor-pointer hover:bg-gray-100 transition-colors';
const URI_COPY_ICON = '<svg class="copy-icon h-3.5 w-3.5 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>';
const URI_OK_ICON = '<svg class="copy-ok hidden h-3.5 w-3.5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>';

function uriRefHtml(prefix: string, localName: string): string {
  const uri = `${escapeHtml(prefix)}:${escapeHtml(localName)}`;
  return `<button type="button" class="${URI_BTN_CLS}" `
    + `data-uri="${uri}" title="Copy URI" `
    + `onclick="event.preventDefault();event.stopPropagation();navigator.clipboard.writeText(this.dataset.uri);`
    + `this.querySelector('.copy-ok').classList.remove('hidden');this.querySelector('.copy-icon').classList.add('hidden');`
    + `setTimeout(()=>{this.querySelector('.copy-ok').classList.add('hidden');this.querySelector('.copy-icon').classList.remove('hidden')},1200)">`
    + `<span class="${URI_MONO_CLS}">${uri}</span>`
    + URI_COPY_ICON + URI_OK_ICON
    + `</button>`;
}

/** Derived from BoundedContextScheme at materialization time — never hardcoded. */
let contextLabels: Record<string, string> = {};

/** Uppercase context label used in card zone-1 headers (mirrors ContextLabel.astro) */
const CTX_LABEL_CLS = 'text-[11px] font-semibold uppercase tracking-wider text-gray-400 cursor-pointer hover:text-blue-600 transition-colors';
function contextFilterLabelHtml(context: string): string {
  const label = contextLabels[context] || context;
  return `<span class="${CTX_LABEL_CLS}" data-filter-context="${escapeHtml(context)}">${escapeHtml(label)}</span>`;
}

function contextLabelHtml(context: string): string {
  const c = context;
  const label = contextLabels[c] || c;
  return `<span class="text-sm text-gray-700">${escapeHtml(label)}</span>`;
}

function contextBadgeHtml(context: string): string {
  const c = context;
  const cls = badgeColorForContext(c);
  return `<span class="inline-block rounded-full px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide ${cls}">${c}</span>`;
}

function truncate(str: string, max = 60): string {
  if (!str) return '';
  return str.length > max ? escapeHtml(str.slice(0, max)) + '...' : escapeHtml(str);
}
