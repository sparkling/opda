/**
 * SPARQL Playground: lazy-loads Comunica and executes queries against N3Store.
 * Also supports proxying queries to the live API endpoint.
 */
import type { Store } from 'n3';

interface SparqlResult {
  vars: string[];
  bindings: Record<string, { type: string; value: string }>[];
  elapsed: number;
}

let engine: any = null;

/** Lazy-load Comunica and execute a SPARQL query against the N3Store. */
export async function executeClientSparql(query: string, store: Store): Promise<SparqlResult> {
  const start = performance.now();

  if (!engine) {
    const { QueryEngine } = await import('@comunica/query-sparql-rdfjs-lite');
    engine = new QueryEngine();
  }

  // Detect query type
  const trimmed = query.trim().replace(/^(PREFIX\s+\S+\s*:\s*<[^>]+>\s*)+/i, '').trim();
  const isAsk = /^ASK\b/i.test(trimmed);
  const isConstruct = /^CONSTRUCT\b/i.test(trimmed);

  if (isAsk) {
    const result = await engine.queryBoolean(query, { sources: [store] });
    return {
      vars: ['result'],
      bindings: [{ result: { type: 'literal', value: String(result) } }],
      elapsed: Math.round(performance.now() - start),
    };
  }

  if (isConstruct) {
    const quadsStream = await engine.queryQuads(query, { sources: [store] });
    const quads = await quadsStream.toArray();
    return {
      vars: ['subject', 'predicate', 'object'],
      bindings: quads.map((q: any) => ({
        subject: { type: q.subject.termType === 'NamedNode' ? 'uri' : 'literal', value: q.subject.value },
        predicate: { type: 'uri', value: q.predicate.value },
        object: { type: q.object.termType === 'NamedNode' ? 'uri' : 'literal', value: q.object.value },
      })),
      elapsed: Math.round(performance.now() - start),
    };
  }

  // SELECT
  const bindingsStream = await engine.queryBindings(query, { sources: [store] });
  const bindings = await bindingsStream.toArray();

  const vars: string[] = [];
  if (bindings.length > 0) {
    for (const [key] of bindings[0]) {
      vars.push(key.value);
    }
  }

  const rows = bindings.map((binding: any) => {
    const row: Record<string, { type: string; value: string }> = {};
    for (const v of vars) {
      const term = binding.get(v);
      if (term) {
        row[v] = {
          type: term.termType === 'NamedNode' ? 'uri' : 'literal',
          value: term.value,
        };
      } else {
        row[v] = { type: 'literal', value: '' };
      }
    }
    return row;
  });

  return {
    vars,
    bindings: rows,
    elapsed: Math.round(performance.now() - start),
  };
}

/** Execute a query via the API proxy (Jena/Fuseki). */
export async function executeServerSparql(query: string, apiBase: string): Promise<SparqlResult> {
  const start = performance.now();
  const res = await fetch(`${apiBase}/sparql`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/sparql-query',
      'Accept': 'application/sparql-results+json',
    },
    body: query,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`SPARQL endpoint returned ${res.status}: ${text.slice(0, 200)}`);
  }

  const result = await res.json();
  const elapsed = Math.round(performance.now() - start);

  if (result.results?.bindings) {
    return {
      vars: result.head?.vars || [],
      bindings: result.results.bindings,
      elapsed,
    };
  }

  if (typeof result.boolean === 'boolean') {
    return {
      vars: ['result'],
      bindings: [{ result: { type: 'literal', value: String(result.boolean) } }],
      elapsed,
    };
  }

  return { vars: [], bindings: [], elapsed };
}
