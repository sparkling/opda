/**
 * Builds a Mermaid `flowchart LR` ontology diagram for a single subject area,
 * styled after the semantic-modelling "Schema sample" template (ADR-0076):
 *   - local concepts      → `cls`  (solid)
 *   - cross-section concepts (another subject area) → `xsec` (dashed, tagged with home area)
 *   - external vocabulary terms → `ext`  (dashed)
 * Edges are solid when both endpoints are local, dashed when one crosses out.
 * Relation kind is carried by the edge label ("is a" for rdfs:subClassOf,
 * the SHACL sh:name for object relationships).
 *
 * Palette + layout come from the template; the interaction shell (zoom, 2-phase
 * navigate/explore, fullscreen, theme sync) is supplied by the client engine in
 * scripts/ontology-diagram.ts. Light classDefs are baked into the source; the
 * engine swaps to DARK_CLASSDEFS on theme change, so the strings must match.
 */
import { Store, DataFactory } from 'n3';
import type { MaterializedData, MaterializedConcept } from './materialize';

const { namedNode } = DataFactory;

const RDFS_SUBCLASS = namedNode('http://www.w3.org/2000/01/rdf-schema#subClassOf');
const SH_PROPERTY = namedNode('http://www.w3.org/ns/shacl#property');
const SH_PATH = namedNode('http://www.w3.org/ns/shacl#path');
const SH_CLASS = namedNode('http://www.w3.org/ns/shacl#class');
const SH_NODE = namedNode('http://www.w3.org/ns/shacl#node');
const SH_NAME = namedNode('http://www.w3.org/ns/shacl#name');
const SKOS_BROADER = namedNode('http://www.w3.org/2004/02/skos/core#broader');

/** Subject-area concepts live at https://hm.com/ns/subject/<localName>. */
const SUBJECT_AREA_NS = 'https://hm.com/ns/subject/';

/* ── Template palette (DIA_THEME from the Schema sample) ─────────────── */

export const LIGHT_CLASSDEFS = [
  'classDef cls fill:#f3e9ff,stroke:#7b1fa2,stroke-width:1.5px,color:#4a148c',
  'classDef xsec fill:#eef1f5,stroke:#a6b0bd,stroke-width:1px,stroke-dasharray:4 3,color:#6a7686',
  'classDef ext fill:#e3f2fd,stroke:#1565c0,stroke-width:1px,stroke-dasharray:4 3,color:#0d47a1',
];

export const DARK_CLASSDEFS = [
  'classDef cls fill:#241b33,stroke:#c9a0ff,stroke-width:1.5px,color:#efe6ff',
  'classDef xsec fill:#1b1f27,stroke:#5b6677,stroke-width:1px,stroke-dasharray:4 3,color:#9aa6b6',
  'classDef ext fill:#15212e,stroke:#5aa9ff,stroke-width:1px,stroke-dasharray:4 3,color:#d4e8ff',
];

export const LIGHT_THEMEVARS = {
  background: '#ffffff',
  primaryColor: '#f3e9ff',
  primaryBorderColor: '#7b1fa2',
  primaryTextColor: '#4a148c',
  lineColor: '#00897b',
  fontSize: '14px',
  fontFamily: '-apple-system,Segoe UI,Roboto,sans-serif',
};

export const DARK_THEMEVARS = {
  background: '#161a21',
  primaryColor: '#241b33',
  primaryBorderColor: '#c9a0ff',
  primaryTextColor: '#efe6ff',
  lineColor: '#7ad1c0',
  fontSize: '14px',
  fontFamily: '-apple-system,Segoe UI,Roboto,sans-serif',
};

/* ── helpers ─────────────────────────────────────────────────────────── */

const HM_NS = 'https://hm.com/ns/';

/** Local-name from a full IRI (after last # or /). */
function localName(iri: string): string {
  const hash = iri.lastIndexOf('#');
  if (hash >= 0) return iri.slice(hash + 1);
  const slash = iri.lastIndexOf('/');
  return slash >= 0 ? iri.slice(slash + 1) : iri;
}

/** Best-effort prefix for an external (non-domain) IRI, for `prefix:Name` labels. */
const WELL_KNOWN: Record<string, string> = {
  'http://www.w3.org/2004/02/skos/core#': 'skos',
  'http://www.w3.org/2002/07/owl#': 'owl',
  'http://www.w3.org/2000/01/rdf-schema#': 'rdfs',
  'http://www.w3.org/1999/02/22-rdf-syntax-ns#': 'rdf',
  'http://purl.org/dc/terms/': 'dcterms',
};
function externalPrefix(iri: string): string {
  for (const [ns, p] of Object.entries(WELL_KNOWN)) if (iri.startsWith(ns)) return p;
  // hm sub-namespace: https://hm.com/ns/<seg>/Name → seg
  if (iri.startsWith(HM_NS)) {
    const rest = iri.slice(HM_NS.length);
    const seg = rest.split('/')[0];
    if (seg && rest.includes('/')) return seg;
    return 'hm';
  }
  return '';
}

/** Sanitize an id fragment to a Mermaid-safe node id. */
const safe = (s: string) => s.replace(/[^A-Za-z0-9]/g, '_');

/** Escape dynamic text for a quoted Mermaid label (preserve none of HTML). */
const esc = (s: string) =>
  (s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/\|/g, '&#124;').trim();

type NodeKind = 'cls' | 'xsec' | 'ext';
interface DiaNode { id: string; label: string; kind: NodeKind; click?: string; }
interface DiaEdge { from: string; to: string; label: string; dashed: boolean; }

export interface SubjectGraph {
  conceptCount: number;
  nodeCount: number;
  edgeCount: number;
  source: string;
}

/**
 * Build the diagram for `saLocalName`. Returns null when the area has no
 * local concepts (caller should then render nothing).
 */
export function buildSubjectDiagramSource(
  store: Store,
  data: MaterializedData,
  saLocalName: string,
  theme: 'light' | 'dark' = 'light',
): SubjectGraph | null {
  const byUri = new Map<string, MaterializedConcept>();
  for (const c of data.concepts) byUri.set(c.uri, c);

  // Member areas = this area + its direct subdivisions (skos:broader children),
  // mirroring the API's concept-membership rule (get-subject-area.rq: conceptSa
  // = area OR conceptSa skos:broader area). A leaf subdivision has no children,
  // so this is a no-op there; a parent subject gains its subdivisions' concepts.
  const memberAreas = new Set<string>([saLocalName]);
  for (const q of store.getQuads(null, SKOS_BROADER, namedNode(SUBJECT_AREA_NS + saLocalName), null)) {
    if (q.subject.termType === 'NamedNode') memberAreas.add(localName(q.subject.value));
  }
  const local = data.concepts.filter((c) => memberAreas.has(c.subjectAreaLocalName));
  if (local.length === 0) return null;
  const localUris = new Set(local.map((c) => c.uri));

  // When a parent subject aggregates subdivisions, tag each box with its own
  // (sub)domain so Currency vs Pricing vs Tax vs Finance concepts are tellable.
  const tagAreas = memberAreas.size > 1;

  const nodes = new Map<string, DiaNode>();
  const edges = new Map<string, DiaEdge>();

  const nid = (uri: string) => 'n_' + safe(byUri.get(uri)?.id || localName(uri));
  const xid = (uri: string) => 'x_' + safe(byUri.get(uri)?.id || externalPrefix(uri) + '_' + localName(uri));

  /** Register a node for a target IRI, classifying it; returns its node id. */
  function ref(uri: string): string {
    if (localUris.has(uri)) {
      const c = byUri.get(uri)!;
      const id = nid(uri);
      if (!nodes.has(id)) {
        const tag = tagAreas ? `<br/>(${esc(c.subjectArea || c.subjectAreaLocalName)})` : '';
        nodes.set(id, { id, label: esc(c.name) + tag, kind: 'cls', click: `/concepts/${c.context}/${c.localName}` });
      }
      return id;
    }
    const known = byUri.get(uri);
    const id = xid(uri);
    if (!nodes.has(id)) {
      if (known) {
        const area = known.subjectArea || known.context || 'other';
        nodes.set(id, {
          id,
          label: `${esc(known.name)}<br/>(${esc(area)})`,
          kind: 'xsec',
          click: `/concepts/${known.context}/${known.localName}`,
        });
      } else {
        const pfx = externalPrefix(uri);
        const ln = localName(uri);
        nodes.set(id, { id, label: pfx ? `${esc(pfx)}:${esc(ln)}` : esc(ln), kind: 'ext' });
      }
    }
    return id;
  }

  function addEdge(fromUri: string, toUri: string, label: string) {
    const from = localUris.has(fromUri) ? nid(fromUri) : xid(fromUri);
    const to = localUris.has(toUri) ? nid(toUri) : xid(toUri);
    const dashed = !(localUris.has(fromUri) && localUris.has(toUri));
    const key = `${from}|${label}|${to}`;
    if (!edges.has(key)) edges.set(key, { from, to, label: esc(label), dashed });
  }

  // Ensure all local concepts appear as nodes even if unconnected.
  for (const c of local) ref(c.uri);

  for (const c of local) {
    const subj = namedNode(c.uri);

    // rdfs:subClassOf → "is a" (only hm-entity superclasses; skip owl:Thing etc.)
    for (const q of store.getQuads(subj, RDFS_SUBCLASS, null, null)) {
      if (q.object.termType !== 'NamedNode') continue;
      if (!q.object.value.startsWith(HM_NS)) continue;
      ref(q.object.value);
      addEdge(c.uri, q.object.value, 'is a');
    }

    // outgoing object relationships: sh:property [ sh:class T ; sh:name L ]
    for (const pq of store.getQuads(subj, SH_PROPERTY, null, null)) {
      const shape = pq.object;
      const targetQ =
        store.getQuads(shape, SH_CLASS, null, null)[0] || store.getQuads(shape, SH_NODE, null, null)[0];
      if (!targetQ || targetQ.object.termType !== 'NamedNode') continue;
      const targetUri = targetQ.object.value;
      const nameQ = store.getQuads(shape, SH_NAME, null, null)[0];
      const pathQ = store.getQuads(shape, SH_PATH, null, null)[0];
      const label = nameQ?.object.value || (pathQ ? localName(pathQ.object.value) : 'related to');
      ref(targetUri);
      addEdge(c.uri, targetUri, label);
    }
  }

  // incoming relationships: classes in OTHER areas that point at a local class.
  for (const c of local) {
    const target = namedNode(c.uri);
    // incoming subClassOf (a non-local subclass of this local class)
    for (const q of store.getQuads(null, RDFS_SUBCLASS, target, null)) {
      const src = q.subject;
      if (src.termType !== 'NamedNode' || localUris.has(src.value)) continue;
      if (!byUri.has(src.value)) continue; // only domain concepts
      ref(src.value);
      addEdge(src.value, c.uri, 'is a');
    }
    // incoming object relationships (sh:class points at this local class)
    for (const tq of store.getQuads(null, SH_CLASS, target, null)) {
      const shape = tq.subject;
      const owner = store.getQuads(null, SH_PROPERTY, shape, null)[0];
      if (!owner) continue;
      const srcUri = owner.subject.value;
      if (localUris.has(srcUri) || !byUri.has(srcUri)) continue; // local handled above; only domain concepts
      const nameQ = store.getQuads(shape, SH_NAME, null, null)[0];
      const pathQ = store.getQuads(shape, SH_PATH, null, null)[0];
      const label = nameQ?.object.value || (pathQ ? localName(pathQ.object.value) : 'related to');
      ref(srcUri);
      addEdge(srcUri, c.uri, label);
    }
  }

  // ── emit ──
  const classDefs = theme === 'dark' ? DARK_CLASSDEFS : LIGHT_CLASSDEFS;
  const lines: string[] = [];
  lines.push('---', 'config:', '  layout: elk', '  elk:', '    mergeEdges: false', '    nodePlacementStrategy: BRANDES_KOEPF', '---');
  lines.push('flowchart LR');
  lines.push(`  accTitle: ${saLocalName} ontology model`);
  lines.push(`  accDescr: Concepts in the ${saLocalName} subject area and their relationships`);
  for (const cd of classDefs) lines.push('  ' + cd);
  for (const n of nodes.values()) lines.push(`  ${n.id}["${n.label}"]:::${n.kind}`);
  for (const e of edges.values()) lines.push(`  ${e.from} ${e.dashed ? '-.->' : '-->'}|"${e.label}"| ${e.to}`);
  for (const n of nodes.values()) if (n.click) lines.push(`  click ${n.id} "${n.click}"`);

  return { conceptCount: local.length, nodeCount: nodes.size, edgeCount: edges.size, source: lines.join('\n') };
}
