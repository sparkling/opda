/**
 * Shared facet icon definitions (ADR-0072).
 * Single source of truth for facet SVG icons (18x18 viewBox, stroke-based) —
 * used by CollapsibleSidebar (client-side collapsed strip),
 * the card display settings panel, and concept detail Metadata section
 * (server-side inline icons).
 */

export interface FacetIcon {
  svg: string;
  label: string;
}

/** Colour config per facet key for button-group tags — single source of truth. */
export interface FacetColour { bg: string; text: string; border: string }
export const FACET_COLOURS: Record<string, FacetColour> = {
  subjectArea:        { bg: 'bg-teal-100',    text: 'text-teal-700',    border: 'border-teal-200' },
  dataClassification: { bg: 'bg-amber-50',    text: 'text-amber-800',   border: 'border-amber-200' },
  governanceTier:     { bg: 'bg-violet-100',  text: 'text-violet-700',  border: 'border-violet-200' },
  volatility:         { bg: 'bg-rose-100',    text: 'text-rose-700',    border: 'border-rose-200' },
  lifecycle:          { bg: 'bg-orange-100',   text: 'text-orange-700',  border: 'border-orange-200' },
  regulatoryRelevance:{ bg: 'bg-sky-100',     text: 'text-sky-700',     border: 'border-sky-200' },
  sourceSystem:       { bg: 'bg-indigo-100',  text: 'text-indigo-700',  border: 'border-indigo-200' },
  stereotype:         { bg: 'bg-cyan-100',    text: 'text-cyan-700',    border: 'border-cyan-200' },
  valueChainPosition: { bg: 'bg-emerald-100', text: 'text-emerald-700', border: 'border-emerald-200' },
};
export const DEFAULT_FACET_COLOUR: FacetColour = { bg: 'bg-gray-100', text: 'text-gray-600', border: 'border-gray-200' };

export const FACET_ICONS: Record<string, FacetIcon> = {
  subjectArea: {
    label: 'Subject Area',
    svg: '<circle cx="9" cy="9" r="7" /><line x1="9" y1="5" x2="9" y2="13" /><line x1="5" y1="9" x2="13" y2="9" />',
  },
  dataClassification: {
    label: 'Data Classification',
    svg: '<rect x="3" y="3" rx="1" width="5" height="5" /><rect x="10" y="3" rx="1" width="5" height="5" /><rect x="3" y="10" rx="1" width="5" height="5" /><rect x="10" y="10" rx="1" width="5" height="5" />',
  },
  valueChainPosition: {
    label: 'Value Chain Position',
    svg: '<polyline points="2,14 5,6 9,10 13,4 16,8" /><line x1="2" y1="14" x2="16" y2="14" />',
  },
  governanceTier: {
    label: 'Governance Tier',
    svg: '<path d="M9 2 L16 6 L16 12 L9 16 L2 12 L2 6 Z" />',
  },
  volatility: {
    label: 'Volatility',
    svg: '<polyline points="2,12 5,4 8,10 11,6 14,9 16,3" />',
  },
  regulatoryRelevance: {
    label: 'Regulatory Relevance',
    svg: '<rect x="4" y="2" rx="1" width="10" height="14" /><line x1="6" y1="5" x2="12" y2="5" /><line x1="6" y1="8" x2="12" y2="8" /><line x1="6" y1="11" x2="10" y2="11" />',
  },
  lifecycle: {
    label: 'Lifecycle',
    svg: '<circle cx="9" cy="9" r="6" /><polyline points="9,5 9,9 12,11" />',
  },
  sourceSystem: {
    label: 'Source System',
    svg: '<rect x="2" y="6" rx="1" width="14" height="8" /><line x1="2" y1="10" x2="16" y2="10" /><circle cx="5" cy="8" r="0.7" fill="currentColor" /><circle cx="5" cy="12" r="0.7" fill="currentColor" />',
  },
  stereotype: {
    label: 'Stereotype',
    svg: '<polygon points="9,2 11,7 16,7 12,10 13,15 9,12 5,15 6,10 2,7 7,7" />',
  },
  schemeType: {
    label: 'Scheme Type',
    svg: '<line x1="3" y1="4" x2="15" y2="4" /><line x1="3" y1="8" x2="15" y2="8" /><line x1="3" y1="12" x2="11" y2="12" />',
  },
  type: {
    label: 'Property Type',
    svg: '<polyline points="4,2 4,16" /><polyline points="4,5 10,5 10,9 4,9" /><line x1="4" y1="12" x2="8" y2="12" />',
  },
  domain: {
    label: 'Domain Class',
    svg: '<circle cx="9" cy="4" r="2.5" /><line x1="9" y1="6.5" x2="9" y2="9" /><line x1="9" y1="9" x2="4" y2="13" /><line x1="9" y1="9" x2="14" y2="13" /><circle cx="4" cy="14.5" r="1.5" /><circle cx="14" cy="14.5" r="1.5" />',
  },
  rangeClass: {
    label: 'Range Class',
    svg: '<circle cx="9" cy="14" r="2.5" /><line x1="9" y1="11.5" x2="9" y2="9" /><line x1="9" y1="9" x2="4" y2="5" /><line x1="9" y1="9" x2="14" y2="5" /><circle cx="4" cy="3.5" r="1.5" /><circle cx="14" cy="3.5" r="1.5" />',
  },
  datatype: {
    label: 'Datatype',
    svg: '<rect x="3" y="3" rx="1.5" width="12" height="12" /><text x="9" y="12" text-anchor="middle" font-size="8" font-weight="bold" fill="currentColor" stroke="none">T</text>',
  },
};

/** The 9 facet keys available for card display customization (excludes 'context'). */
export const CARD_FACET_KEYS = [
  'subjectArea', 'dataClassification', 'valueChainPosition', 'governanceTier',
  'volatility', 'regulatoryRelevance', 'lifecycle', 'sourceSystem', 'stereotype',
] as const;

/** Derived facet labels — single source of truth from FACET_ICONS. */
export const FACET_LABELS: Record<string, string> = Object.fromEntries(
  Object.entries(FACET_ICONS).map(([k, v]) => [k, v.label])
);

/** Default facets shown on concept cards. */
export const DEFAULT_CARD_FACETS = new Set([
  'subjectArea', 'dataClassification', 'governanceTier', 'volatility',
]);

/** localStorage key for persisted card facet preferences. */
export const CARD_FACETS_STORAGE_KEY = 'hm-card-facets';

/**
 * Read visible card facets from localStorage.
 * Returns the default set if nothing is persisted or if stored keys are invalid.
 */
export function getVisibleCardFacets(): Set<string> {
  try {
    const stored = localStorage.getItem(CARD_FACETS_STORAGE_KEY);
    if (stored === null) return new Set(DEFAULT_CARD_FACETS);
    if (stored === '') return new Set();
    const keys = stored.split(',').filter(k => CARD_FACET_KEYS.includes(k as any));
    return new Set(keys);
  } catch {
    return new Set(DEFAULT_CARD_FACETS);
  }
}

/**
 * Persist visible card facets to localStorage.
 */
export function saveVisibleCardFacets(facets: Set<string>): void {
  try {
    localStorage.setItem(CARD_FACETS_STORAGE_KEY, Array.from(facets).join(','));
  } catch { /* silently ignore quota errors */ }
}

/**
 * Check whether the current selection differs from defaults.
 */
export function isCardFacetsCustomized(facets: Set<string>): boolean {
  if (facets.size !== DEFAULT_CARD_FACETS.size) return true;
  for (const k of Array.from(DEFAULT_CARD_FACETS)) {
    if (!facets.has(k)) return true;
  }
  return false;
}
