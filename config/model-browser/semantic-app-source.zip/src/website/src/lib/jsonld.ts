/**
 * JSON-LD response parsing helpers for the ontology API.
 *
 * The API compacts JSON-LD responses using the project @context, so keys
 * are short names like `name`, `definition`, `property`. These helpers
 * also handle JSON-LD value forms: language-tagged, typed, IRI refs, and
 * blank node references resolved from `@graph`.
 *
 * The `hm:` fallback in get() handles uncompacted responses from Jena.
 */

/** Unwrap a JSON-LD value to a plain string. */
export function val(v: any): string {
  if (v == null) return '';
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  if (v['@value'] !== undefined) return String(v['@value']);
  // ODR-0041: IRI refs ideally resolved to rdfs:label; localName used as DQ fallback
  if (v['@id'] !== undefined) return localName(v['@id']);
  if (Array.isArray(v)) return v.length > 0 ? val(v[0]) : '';
  return '';
}

/** Extract local name from an IRI: "hm:pf/Article" → "Article", "http://...#string" → "string" */
export function localName(iri: string): string {
  if (!iri) return '';
  const hash = iri.lastIndexOf('#');
  if (hash >= 0) return iri.substring(hash + 1);
  const slash = iri.lastIndexOf('/');
  if (slash >= 0) return iri.substring(slash + 1);
  const colon = iri.lastIndexOf(':');
  if (colon >= 0) return iri.substring(colon + 1);
  return iri;
}

/**
 * Read a field as a raw IRI ref string (prefixed like "pf:Role" or a full IRI),
 * WITHOUT reducing it to a local name the way val() does. Returns '' when the
 * field is absent or is a plain literal rather than an @id reference.
 */
export function iriRef(obj: any, key: string): string {
  const v = get(obj, key);
  if (!v) return '';
  if (typeof v === 'string') return v;
  if (Array.isArray(v)) return v.length > 0 ? (v[0]?.['@id'] ?? (typeof v[0] === 'string' ? v[0] : '')) : '';
  return v['@id'] ?? '';
}

/** Get a raw field from a JSON-LD node, checking plain and hm: prefixed keys. */
export function get(obj: any, key: string): any {
  if (!obj) return null;
  return obj[key] ?? obj[`hm:${key}`] ?? null;
}

/** Get a field and unwrap it to a string. */
export function field(obj: any, key: string): string {
  return val(get(obj, key));
}

/** Find the main resource node by @type suffix match. */
export function findByType(graph: any[], ...types: string[]): any {
  return graph.find((node: any) => {
    const nodeTypes = Array.isArray(node['@type']) ? node['@type'] : [node['@type']];
    return nodeTypes.some((t: string) =>
      t != null && types.some(target => t === target || t.endsWith(`/${target}`) || t.endsWith(`#${target}`) || t.endsWith(`:${target}`))
    );
  });
}

/** Resolve blank node references from @graph into their full objects. */
export function resolveRefs(refs: any, graph: any[]): any[] {
  if (!refs) return [];
  const list = Array.isArray(refs) ? refs : [refs];
  const nodeMap = new Map<string, any>();
  for (const node of graph) {
    if (node['@id']) nodeMap.set(node['@id'], node);
  }
  return list
    .map((ref: any) => {
      if (!ref) return null;
      const id = typeof ref === 'string' ? ref : ref['@id'];
      if (id && nodeMap.has(id)) return nodeMap.get(id);
      if (typeof ref === 'object') return ref;  // keep inline objects AND unresolved refs with @id
      return null;
    })
    .filter(Boolean);
}

/** Sentence-case a label: capitalise first letter, preserve rest (incl. acronyms).
 *  "article name" → "Article name", "GBC fiscal country" → "GBC fiscal country" (no-op). */
export function sentenceCase(s: string): string {
  if (!s) return s;
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/** Extract local names from an array of IRI refs. */
export function iriList(refs: any): string[] {
  if (!refs) return [];
  const list = Array.isArray(refs) ? refs : [refs];
  return list.map((ref: any) => {
    if (typeof ref === 'string') return ref;
    // ODR-0041: IRI refs ideally resolved to rdfs:label; localName used as DQ fallback
    if (ref?.['@id']) return localName(ref['@id']);
    return val(ref);
  }).filter(Boolean);
}
