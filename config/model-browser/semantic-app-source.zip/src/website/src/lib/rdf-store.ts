/**
 * Fetches and parses the entailed TTL file into an N3 Store.
 * The store is a singleton — initialized once and reused.
 */
import { Parser, Store } from 'n3';

let storeUrl: string = import.meta.env.PUBLIC_ENTAILED_TTL_URL || '/ontology-entailed.ttl';

let storePromise: Promise<Store> | null = null;

export function setStoreUrl(url: string): void {
  storeUrl = url;
  storePromise = null;
}

export function getStore(): Promise<Store> {
  if (!storePromise) {
    storePromise = loadStore();
  }
  return storePromise;
}

async function loadStore(): Promise<Store> {
  const res = await fetch(storeUrl);
  if (!res.ok) throw new Error(`Failed to fetch entailed TTL: ${res.status}`);
  const ttl = await res.text();
  const store = new Store();
  const parser = new Parser();
  const quads = parser.parse(ttl);
  store.addQuads(quads);
  return store;
}
