/**
 * Parse a Mermaid `flowchart` source string into a `{ nodes, links }` graph for
 * the 3D force-directed view (ADR-0190). The Mermaid source is the single source
 * of truth shared by both the Diagram (Mermaid) and 3D views — node colours are
 * derived from the source's own `classDef`s and edge colours from `linkStyle`
 * lines (or solid/dotted convention), so the two views stay visually consistent.
 *
 * Handles all three diagram dialects in the app: the relationship graph
 * (concept-graph.ts), the subject/subdivision diagrams (ontology-diagram-source.ts),
 * and the hand-authored boundary diagrams (ConceptModelDiagram) — including
 * `subgraph`/`end` clusters, which are skipped (clusters aren't graph nodes).
 */

export interface ParsedNode {
  id: string;
  label: string;
  cls: string;
  color: string;
  href: string;
  focus: boolean;
}

export interface ParsedLink {
  source: string;
  target: string;
  label: string;
  dotted: boolean;
  color: string;
}

export interface ParsedGraph {
  nodes: ParsedNode[];
  links: ParsedLink[];
}

const DEFAULT_NODE = '#64748b';
const DEFAULT_LINK = '#94a3b8';
const ISA_LINK = '#f59e0b';

/** Decode the handful of HTML entities the source generators emit, and flatten <br/>. */
function decodeLabel(s: string): string {
  return (s || '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/&#124;/g, '|')
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .trim();
}

/** Pull `fill:` / `stroke:` hex colours out of a classDef body. */
function classColors(body: string): { fill: string; stroke: string } {
  const fill = body.match(/fill:\s*(#[0-9a-fA-F]{3,8})/);
  const stroke = body.match(/stroke:\s*(#[0-9a-fA-F]{3,8})/);
  return { fill: fill ? fill[1] : '', stroke: stroke ? stroke[1] : '' };
}

const NODE_RE = /^([A-Za-z0-9_]+)\s*\[\s*"?([\s\S]*?)"?\s*\](?::::([A-Za-z0-9_]+))?/;
const EDGE_LABELLED_RE = /^([A-Za-z0-9_]+)\s*(-\.?->)\s*\|\s*"?([^|]*?)"?\s*\|\s*([A-Za-z0-9_]+)/;
const EDGE_PLAIN_RE = /^([A-Za-z0-9_]+)\s*(-\.?->)\s*([A-Za-z0-9_]+)\s*$/;
const CLICK_RE = /^click\s+([A-Za-z0-9_]+)\s+"([^"]+)"/;
const CLASSDEF_RE = /^classDef\s+([A-Za-z0-9_]+)\s+(.+)$/;
const LINKSTYLE_RE = /^linkStyle\s+(\d+)\s+(.+)$/;
const SKIP_PREFIX = /^(subgraph\b|end\b|flowchart\b|graph\b|accTitle\b|accDescr\b|config:|layout:|elk:|mergeEdges|nodePlacementStrategy|direction\b|%%|---)/;

/** Parse a Mermaid flowchart source into a node/link graph. */
export function parseMermaidGraph(source: string): ParsedGraph {
  const classColorMap = new Map<string, { fill: string; stroke: string }>();
  const linkStyleColor = new Map<number, string>();
  const rawNodes = new Map<string, { label: string; cls: string }>();
  const hrefs = new Map<string, string>();
  const edges: { source: string; target: string; label: string; dotted: boolean }[] = [];

  for (const rawLine of source.split('\n')) {
    const line = rawLine.trim();
    if (!line) continue;

    const cd = line.match(CLASSDEF_RE);
    if (cd) { classColorMap.set(cd[1], classColors(cd[2])); continue; }

    const ls = line.match(LINKSTYLE_RE);
    if (ls) {
      const c = ls[2].match(/stroke:\s*(#[0-9a-fA-F]{3,8})/);
      if (c) linkStyleColor.set(parseInt(ls[1], 10), c[1]);
      continue;
    }

    const ck = line.match(CLICK_RE);
    if (ck) { hrefs.set(ck[1], ck[2]); continue; }

    if (SKIP_PREFIX.test(line)) continue;

    const el = line.match(EDGE_LABELLED_RE) || line.match(EDGE_PLAIN_RE);
    if (el) {
      const labelled = el.length > 4;
      edges.push({
        source: el[1],
        target: labelled ? el[4] : el[3],
        label: labelled ? decodeLabel(el[3]) : '',
        dotted: el[2].includes('.'),
      });
      continue;
    }

    const nm = line.match(NODE_RE);
    if (nm) {
      if (!rawNodes.has(nm[1])) rawNodes.set(nm[1], { label: decodeLabel(nm[2]) || nm[1], cls: nm[3] || '' });
    }
  }

  // Ensure edge endpoints exist as nodes even if never declared on their own line.
  for (const e of edges) {
    if (!rawNodes.has(e.source)) rawNodes.set(e.source, { label: e.source, cls: '' });
    if (!rawNodes.has(e.target)) rawNodes.set(e.target, { label: e.target, cls: '' });
  }

  const nodes: ParsedNode[] = [];
  for (const [id, n] of rawNodes) {
    const focus = /focus/i.test(n.cls);
    const col = classColorMap.get(n.cls);
    const color = col ? (focus ? col.fill || col.stroke : col.stroke || col.fill) || DEFAULT_NODE : DEFAULT_NODE;
    nodes.push({ id, label: n.label, cls: n.cls, color, href: hrefs.get(id) || '', focus });
  }

  const links: ParsedLink[] = edges.map((e, i) => ({
    source: e.source,
    target: e.target,
    label: e.label,
    dotted: e.dotted,
    color: linkStyleColor.get(i) || (e.dotted ? ISA_LINK : DEFAULT_LINK),
  }));

  return { nodes, links };
}
