/**
 * Shared listing ↔ detail navigation — DRY query-parameter keys and
 * reusable API fetch for record navigation on detail pages.
 *
 * The listing page uses buildListingSearch() to encode filter/sort state
 * into query parameters on detail-page links.  The detail page uses
 * fetchNavItems() with those same parameters to reconstruct the ordered
 * result set from the API for prev/next navigation.
 */
export const DEFAULT_PAGE_SIZE = 25;

/**
 * Build the query string carried on detail-page links from listing state.
 * Also used by the detail page to preserve params during prev/next navigation.
 */
export function buildListingSearch(opts: {
  filters: Record<string, string[]>;
  sort: string;
  direction: string;
  page: number;
  pageSize: number;
  rootOnly: boolean;
  q: string;
}): string {
  const p = new URLSearchParams();
  for (const [key, values] of Object.entries(opts.filters)) {
    if (values?.length) p.set(key, values.join(','));
  }
  if (opts.sort !== 'name') p.set('sort', opts.sort);
  if (opts.direction !== 'asc') p.set('direction', opts.direction);
  if (opts.page > 1) p.set('page', String(opts.page));
  if (opts.pageSize !== DEFAULT_PAGE_SIZE) p.set('pageSize', String(opts.pageSize));
  if (opts.rootOnly) p.set('rootOnly', 'true');
  if (opts.q) p.set('q', opts.q);
  return p.toString() ? `?${p}` : '';
}

/** Filter keys the /concepts API supports (subset of FACET_KEYS). */
const CONCEPT_API_FILTER_KEYS = [
  'context', 'subjectArea', 'dataClassification', 'lifecycle',
  'volatility', 'regulatoryRelevance', 'governanceTier', 'sourceSystem',
] as const;

/** Filter keys the /properties API supports. */
const PROPERTY_API_FILTER_KEYS = [
  'context',
] as const;

/**
 * Fetch an ordered list of "context/localName" keys from a paginated API.
 * Shared implementation for both concepts and properties.
 */
function fetchNavItemsFrom(
  endpoint: string,
  filterKeys: readonly string[],
  searchParams: URLSearchParams,
): Promise<string[]> {
  const apiParams = new URLSearchParams();
  for (const key of filterKeys) {
    const v = searchParams.get(key);
    if (v) apiParams.set(key, v);
  }
  const q = searchParams.get('q');
  if (q) apiParams.set('q', q);
  const sort = searchParams.get('sort');
  if (sort) apiParams.set('sort', sort);
  const direction = searchParams.get('direction');
  if (direction) apiParams.set('direction', direction);
  apiParams.set('pageSize', '100');
  apiParams.set('includeFacets', 'false');

  const all: string[] = [];
  const seen = new Set<string>();

  async function fetchAll() {
    let page = 1;
    let totalPages = 1;
    while (page <= totalPages && page <= 20) {
      apiParams.set('page', String(page));
      const res = await fetch(`${endpoint}?${apiParams}`, {
        headers: { Accept: 'application/json' },
      });
      if (!res.ok) return [];
      const data = await res.json();
      for (const item of data.items || []) {
        if (item.context && item.localName) {
          const key = `${item.context}/${item.localName}`;
          if (!seen.has(key)) {
            seen.add(key);
            all.push(key);
          }
        }
      }
      totalPages = data.totalPages || 1;
      page++;
    }
    return all;
  }
  return fetchAll();
}

/**
 * Fetch the ordered list of concept keys ("context/localName") from the
 * /concepts API using the filter/sort/search params from the URL.
 */
export function fetchNavItems(
  searchParams: URLSearchParams,
): Promise<string[]> {
  return fetchNavItemsFrom('/ontology-api/concepts', CONCEPT_API_FILTER_KEYS, searchParams);
}

/**
 * Fetch the ordered list of property keys ("context/localName") from the
 * /properties API using the filter/sort/search params from the URL.
 */
export function fetchPropertyNavItems(
  searchParams: URLSearchParams,
): Promise<string[]> {
  return fetchNavItemsFrom('/ontology-api/properties', PROPERTY_API_FILTER_KEYS, searchParams);
}
