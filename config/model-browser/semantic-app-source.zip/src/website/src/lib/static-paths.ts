import { apiFetch, fetchContextLabels } from './api';

/** Base shape for items returned by paginated API endpoints. */
export interface PaginatedItem {
  localName?: string;
  context?: string;
  [key: string]: unknown;
}

export async function fetchAllPaginated<T extends PaginatedItem = PaginatedItem>(
  endpoint: string,
  pageSize = 100,
  maxPages = 10,
): Promise<T[]> {
  const allItems: T[] = [];
  let page = 1;
  while (true) {
    const data = await apiFetch(`${endpoint}?page=${page}&pageSize=${pageSize}`);
    const items: T[] = data.items || [];
    allItems.push(...items);
    if (items.length < pageSize || (data.totalCount != null && allItems.length >= data.totalCount)) break;
    page++;
    if (page > maxPages) break;
  }
  return allItems;
}

interface BuildPaginatedPathsOptions<T extends PaginatedItem = PaginatedItem> {
  filter?: (item: T) => boolean;
  localNameFn?: (item: T) => string;
  propsFactory?: (items: T[], contextLabels: Record<string, string>) => Record<string, unknown>;
  pageSize?: number;
  maxPages?: number;
}

export async function buildPaginatedPaths<T extends PaginatedItem = PaginatedItem>(
  endpoint: string,
  options: BuildPaginatedPathsOptions<T> = {},
) {
  const { filter, localNameFn, propsFactory, pageSize, maxPages } = options;
  const extractLocalName = localNameFn ?? ((item: T) => item.localName as string);

  const [contextLabels, allItems] = await Promise.all([
    fetchContextLabels(),
    fetchAllPaginated<T>(endpoint, pageSize, maxPages),
  ]);

  const seen = new Set<string>();
  const deduped = allItems.filter((item) => {
    const ln = extractLocalName(item);
    if (!ln || !item.context || ln.includes('/')) return false;
    const key = `${item.context}/${ln}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  const filtered = filter ? deduped.filter(filter) : deduped;
  const extraProps = propsFactory ? propsFactory(filtered, contextLabels) : {};

  return filtered.map((item) => ({
    params: { slug: `${item.context}/${extractLocalName(item)}` },
    props: { contextLabels, context: item.context as string, name: extractLocalName(item), ...extraProps },
  }));
}
