/**
 * Shared helpers for Astro SSG export endpoints.
 * Fetches from the internal API at build time and formats the response.
 */
import { fetchAllPaginated } from './static-paths';
import yaml from 'js-yaml';

// ── Static paths builders ───────────────────────────────────────────────────

export async function getPropertyPaths() {
  const allItems = await fetchAllPaginated('/properties');
  const seen = new Set<string>();
  return allItems.filter((item: any) => {
    if (!item.localName || !item.context || item.localName.includes('/')) return false;
    const key = `${item.context}/${item.localName}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).map((item: any) => ({
    params: { slug: `${item.context}/${item.localName}` },
    props: { context: item.context, name: item.localName },
  }));
}

export async function getConceptPaths() {
  const allItems = await fetchAllPaginated('/concepts');
  const seen = new Set<string>();
  return allItems.filter((item: any) => {
    if (!item.localName || !item.context || item.localName.includes('/')) return false;
    const key = `${item.context}/${item.localName}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).map((item: any) => ({
    params: { slug: `${item.context}/${item.localName}` },
    props: { context: item.context, name: item.localName },
  }));
}

// ── Format converters ───────────────────────────────────────────────────────

/** Convert JSON-LD object to a flat key-value CSV string. */
export function toCSV(data: Record<string, any>): string {
  const rows: string[][] = [['field', 'value']];
  for (const [key, val] of Object.entries(data)) {
    if (key.startsWith('@')) continue;
    const flat = Array.isArray(val) ? val.map(v => typeof v === 'object' ? JSON.stringify(v) : String(v)).join('; ') : String(val ?? '');
    rows.push([key, flat]);
  }
  return rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
}

/** Convert JSON-LD object to YAML string. */
export function toYAML(data: any): string {
  return yaml.dump(data, { lineWidth: 120, noRefs: true });
}

/** Convert JSON-LD object to a simple XML string. */
export function toXML(data: Record<string, any>, rootTag: string): string {
  const esc = (s: string) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const lines: string[] = ['<?xml version="1.0" encoding="UTF-8"?>', `<${rootTag}>`];

  function emit(obj: any, indent: string) {
    if (obj == null) return;
    if (Array.isArray(obj)) {
      for (const item of obj) emit(item, indent);
      return;
    }
    if (typeof obj === 'object') {
      for (const [key, val] of Object.entries(obj)) {
        if (key.startsWith('@')) continue;
        const tag = key.replace(/[^a-zA-Z0-9_-]/g, '_');
        if (Array.isArray(val)) {
          for (const item of val) {
            if (typeof item === 'object' && item !== null) {
              lines.push(`${indent}<${tag}>`);
              emit(item, indent + '  ');
              lines.push(`${indent}</${tag}>`);
            } else {
              lines.push(`${indent}<${tag}>${esc(String(item ?? ''))}</${tag}>`);
            }
          }
        } else if (typeof val === 'object' && val !== null) {
          lines.push(`${indent}<${tag}>`);
          emit(val, indent + '  ');
          lines.push(`${indent}</${tag}>`);
        } else {
          lines.push(`${indent}<${tag}>${esc(String(val ?? ''))}</${tag}>`);
        }
      }
    }
  }

  emit(data, '  ');
  lines.push(`</${rootTag}>`);
  return lines.join('\n');
}
