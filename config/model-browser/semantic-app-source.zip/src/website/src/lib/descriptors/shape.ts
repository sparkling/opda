import type { Badge, NavTab, ExportLink, PageDescriptor } from '../page-descriptor';
import { val, field, get, findByType, resolveRefs } from '../jsonld';
import { accentColorForContext, badgeColorForCategory } from '../accent-color';

export const shapeDescriptor: PageDescriptor = {
  entityType: 'shape',
  entitySingular: 'Shape',
  listEndpoint: '/shapes',
  sectionClass: 'shape-section',
  breadcrumbBase: { label: 'Shapes', href: '/shapes' },
};

/* ── Constraint types (matching ConstraintSection.astro Props) ── */

export interface ConstraintProp {
  pathName: string;
  path: string;
  datatype: string;
  className: string;
  minCount: string;
  maxCount: string;
  pattern: string;
  severity: string;
  message: string;
  editor: string;
  viewer: string;
  nodeKind: string;
  hasValue: string;
  equals: string;
  disjoint: string;
  lessThan: string;
  lessThanOrEquals: string;
  uniqueLang: string;
  uniqueValueForClass: string;
  singleLine: string;
  suggestion: string;
  inValues: string[];
  order: number;
  group: string;
}

export interface LogicalRules {
  hasAnd: boolean;
  hasOr: boolean;
  hasXone: boolean;
  hasNot: boolean;
  nodeRefUri: string;
  nodeRefName: string;
}

export interface SparqlConstraint {
  message: string;
  select: string;
  ask: string;
  severity: string;
}

/**
 * ADR-0171 §G1-7 — sh:PropertyGroup reachable via sh:property/sh:group on the shape.
 * `iri` is the full group IRI (e.g. `https://hm.com/ns/Cat01ClassificationGroup`);
 * `label` is rdfs:label; `order` is sh:order (defaulting to 999 when absent).
 * Sorted ascending by `order` in ShapeData.propertyGroups.
 */
export interface PropertyGroupItem {
  iri: string;
  label: string;
  order: number;
}

/* ── Shape data returned by extract function ── */

export interface ShapeData {
  shapeName: string;
  uri: string;
  comment: string;
  definition: string;
  editorialNote: string;
  purposeSubtitle: string;
  categoryKey: string;
  badges: Badge[];
  targetClasses: any[];
  targetObjOf: any[];
  targetSubjOf: any[];
  targetNodes: any[];
  allTargets: any[];
  hasMultipleTargets: boolean;
  singleTargetName: string;
  constraints: ConstraintProp[];
  logicalRules: LogicalRules;
  sparqlConstraints: SparqlConstraint[];
  /** ADR-0171 §G1-7 — sorted list of sh:PropertyGroup instances on this shape. */
  propertyGroups: PropertyGroupItem[];
  sourceModule: string;
  accentColor: string;
  sectionTabs: NavTab[];
  exportLinks: ExportLink[];
}

/* ── Internal constants ── */

const QUALITY_GATE_TARGETS = [
  'owl:Class', 'owl:ObjectProperty', 'owl:DatatypeProperty', 'owl:Ontology',
  'http://www.w3.org/2002/07/owl#Class', 'http://www.w3.org/2002/07/owl#ObjectProperty',
  'http://www.w3.org/2002/07/owl#DatatypeProperty', 'http://www.w3.org/2002/07/owl#Ontology',
];

/* ── Helpers ── */

function determineCategory(
  shape: any,
  targetClasses: any[],
  targetObjOf: any[],
): string {
  // Prefer API-provided category if available
  const apiCategory = field(shape, 'shapeCategory') || field(shape, 'category') || '';
  if (apiCategory) return apiCategory;
  // Heuristic fallback
  if (targetObjOf.length > 0) return 'Value Validator';
  if (get(shape, 'rule')) return 'Rule';
  if (get(shape, 'xone')) return 'Disjointness';
  if (targetClasses.length > 0) {
    const tcUri = targetClasses[0]?.['@id'] || field(targetClasses[0], 'uri') || '';
    if (QUALITY_GATE_TARGETS.includes(tcUri)) return 'Quality Gate';
  }
  return 'Governance';
}

function buildConstraints(properties: any[]): ConstraintProp[] {
  return properties.map((prop: any) => ({
    pathName: field(prop, 'pathName') || '',
    path: field(prop, 'path') || '',
    datatype: field(prop, 'datatype') || '',
    className: field(prop, 'className') || '',
    minCount: field(prop, 'minCount') || '',
    maxCount: field(prop, 'maxCount') || '',
    pattern: field(prop, 'pattern') || '',
    severity: field(prop, 'severity') || '',
    message: field(prop, 'message') || '',
    editor: field(prop, 'editor') || val(prop['dash:editor']) || '',
    viewer: field(prop, 'viewer') || val(prop['dash:viewer']) || '',
    nodeKind: field(prop, 'nodeKind') || '',
    hasValue: field(prop, 'hasValue') || '',
    equals: field(prop, 'equals') || '',
    disjoint: field(prop, 'disjoint') || '',
    lessThan: field(prop, 'lessThan') || '',
    lessThanOrEquals: field(prop, 'lessThanOrEquals') || '',
    uniqueLang: field(prop, 'uniqueLang') || '',
    uniqueValueForClass: val(prop['dash:uniqueValueForClass']) || field(prop, 'uniqueValueForClass') || '',
    singleLine: val(prop['dash:singleLine']) || field(prop, 'singleLine') || '',
    suggestion: field(prop, 'suggestion') || val(prop['dash:suggestion']) || '',
    inValues: Array.isArray(get(prop, 'inValue'))
      ? get(prop, 'inValue').map((v: any) => val(v)).filter(Boolean)
      : (field(prop, 'inValue') ? [field(prop, 'inValue')] : []),
    order: parseInt(field(prop, 'order') || '999', 10),
    group: field(prop, 'group') || 'Ungrouped',
  }));
}

function buildSparqlConstraints(sparqlRefs: any[]): SparqlConstraint[] {
  return sparqlRefs.map((sc: any) => ({
    message: field(sc, 'message') || 'SPARQL constraint',
    select: field(sc, 'select') || '',
    ask: field(sc, 'ask') || '',
    severity: field(sc, 'severity') || '',
  }));
}

/* ── Main extract function ── */

export function extractShapeData(
  data: any,
  context: string,
  name: string,
  usageItems: any[] = [],
): ShapeData | null {
  const graph = data?.['@graph'] || (data ? [data] : []);
  const shape =
    findByType(graph, 'ShapeDetail') ||
    graph.find((n: any) => n['@id'] && !n['@id'].startsWith('_:')) ||
    graph[0] ||
    null;

  if (!shape) return null;

  // Core identity
  const shapeName = field(shape, 'name') || name || '';
  const uri = shape['@id'] || field(shape, 'uri') || '';

  // Documentation (ODR-0011 four-tier)
  const comment = field(shape, 'comment') || '';
  const definition = field(shape, 'definition') || '';
  const editorialNote = field(shape, 'editorialNote') || '';
  const message = field(shape, 'message') || '';
  const purposeSubtitle = message || comment || definition || '';

  // Targets
  const targetClasses = resolveRefs(get(shape, 'targetClass'), graph);
  const targetObjOf = resolveRefs(get(shape, 'targetObjectsOf'), graph);
  const targetSubjOf = resolveRefs(get(shape, 'targetSubjectsOf'), graph);
  const targetNodes = resolveRefs(get(shape, 'targetNode'), graph);
  const allTargets = [...targetClasses, ...targetObjOf, ...targetSubjOf, ...targetNodes];
  const hasMultipleTargets = allTargets.length > 1;
  const singleTargetName = allTargets.length === 1 ? (field(allTargets[0], 'name') || '') : '';

  // Category + badge
  const categoryKey = determineCategory(shape, targetClasses, targetObjOf);
  const badges: Badge[] = [{ label: categoryKey, class: badgeColorForCategory(categoryKey) }];

  // Constraints
  const properties = resolveRefs(get(shape, 'property'), graph);
  const constraints = buildConstraints(properties);

  // ADR-0171 §G1-7 — sh:PropertyGroup aggregation.
  // Primary source: hm:propertyGroup blank-node refs from the new SPARQL block
  // (`sh:property/sh:group` walk). Each ref carries hm:iri / hm:label / hm:order.
  // Fallback (until the API-side SPARQL is redeployed): derive a label-only entry
  // per distinct constraint group with empty iri + order=999 so the section still
  // renders a sorted list of groups, just without IRI/order data.
  const groupRefs = get(shape, 'propertyGroup');
  const groupNodes = groupRefs ? resolveRefs(groupRefs, graph) : [];
  const propertyGroupsFromGraph: PropertyGroupItem[] = groupNodes
    .map((g: any) => ({
      iri: field(g, 'iri') || (g['@id'] && !String(g['@id']).startsWith('_:') ? String(g['@id']) : ''),
      label: field(g, 'label') || '',
      order: parseInt(field(g, 'order') || '999', 10),
    }))
    .filter((g) => g.label || g.iri);
  let propertyGroups: PropertyGroupItem[];
  if (propertyGroupsFromGraph.length > 0) {
    propertyGroups = propertyGroupsFromGraph;
  } else {
    const seen = new Set<string>();
    const fallback: PropertyGroupItem[] = [];
    for (const c of constraints) {
      const lbl = c.group;
      if (!lbl || lbl === 'Ungrouped' || seen.has(lbl)) continue;
      seen.add(lbl);
      fallback.push({ iri: '', label: lbl, order: 999 });
    }
    propertyGroups = fallback;
  }
  // Stable sort: by order asc, then by label.
  propertyGroups.sort((a, b) => (a.order - b.order) || a.label.localeCompare(b.label));

  // Logical rules
  const logicalRules: LogicalRules = {
    hasAnd: field(shape, 'hasAnd') === 'true',
    hasOr: field(shape, 'hasOr') === 'true',
    hasXone: field(shape, 'hasXone') === 'true',
    hasNot: field(shape, 'hasNot') === 'true',
    nodeRefUri: field(shape, 'nodeRef') || '',
    nodeRefName: field(shape, 'nodeRefName') || '',
  };

  // SPARQL constraints
  const sparqlRefs = resolveRefs(get(shape, 'sparqlConstraint'), graph);
  const sparqlConstraints = buildSparqlConstraints(sparqlRefs);

  // Provenance
  const sourceModule = field(shape, 'sourceModule') || '';

  // Accent color
  const accentColor = accentColorForContext(context);

  // Section tabs
  const hasDoc = !!(comment || definition || editorialNote);
  const hasTarget = hasMultipleTargets;
  const hasConstraintData = constraints.length > 0;
  const hasLogical = logicalRules.hasAnd || logicalRules.hasOr || logicalRules.hasXone || logicalRules.hasNot || !!logicalRules.nodeRefUri;
  const hasSparql = sparqlConstraints.length > 0;
  const hasUsage = usageItems.length > 0;

  const sectionTabs: NavTab[] = [
    ...(hasDoc ? [{ id: 'documentation', label: 'Documentation', href: '#section-documentation', hasData: true }] : []),
    ...(hasTarget ? [{ id: 'target', label: `Target (${allTargets.length})`, href: '#section-target', hasData: true }] : []),
    ...(hasConstraintData || hasLogical || hasSparql ? [{ id: 'constraints', label: 'Constraints', href: '#section-constraints', hasData: true }] : []),
    // ADR-0171 G1-7: Shape Groups tab is conditional on the shape carrying any sh:PropertyGroup
    ...(propertyGroups.length > 0 ? [{ id: 'shape-groups', label: 'Shape Groups', href: '#section-shape-groups', count: propertyGroups.length, hasData: true }] : []),
    ...(hasUsage ? [{ id: 'usage', label: `Usage (${usageItems.length})`, href: '#section-usage', hasData: true }] : []),
    { id: 'provenance', label: 'Provenance', href: '#section-provenance', hasData: true },
    { id: 'discussion', label: 'Discussion', href: '#section-discussion', hasData: true },
  ];

  // Export links
  const exportLinks: ExportLink[] = [];

  return {
    shapeName,
    uri,
    comment,
    definition,
    editorialNote,
    purposeSubtitle,
    categoryKey,
    badges,
    targetClasses,
    targetObjOf,
    targetSubjOf,
    targetNodes,
    allTargets,
    hasMultipleTargets,
    singleTargetName,
    constraints,
    logicalRules,
    sparqlConstraints,
    propertyGroups,
    sourceModule,
    accentColor,
    sectionTabs,
    exportLinks,
  };
}
