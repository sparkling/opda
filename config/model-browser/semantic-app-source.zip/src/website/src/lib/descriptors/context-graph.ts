/**
 * Whole-boundary relationship-graph builder.
 *
 * The client-side, context-wide counterpart of `buildConceptGraph` (which is
 * per concept). Produces the SAME `ConceptGraph` shape so the boundary diagram
 * renders through the identical `conceptGraphToMermaid` path as the concept
 * detail Relationship Graph — filter toggles, typed/coloured edges,
 * cardinalities and clickable property links all come for free.
 *
 * Edges, from the materialized store:
 *   • object properties (domain in this context) → 'outgoing'
 *   • subClassOf hierarchy                        → 'parent' (child → parent)
 *   • datatype properties (domain in this context)→ 'datatype' (duplicated literal node)
 *
 * There is no single focus concept (pass focusId '' to the renderer); every
 * concept node is a peer. Concepts with no included edge are dropped by the
 * renderer, so the wall of unrelated boxes the hand-authored diagram produced
 * never appears.
 */
import type { MaterializedData } from '../materialize';
import type { ConceptGraph, GraphNode, GraphLink } from './concept-graph';

const idOf = (ctx: string, ln: string) => `${ctx}:${ln}`;
const hrefOf = (ctx: string, ln: string) => `/concepts/${ctx}/${ln}`;

export function buildContextGraph(data: MaterializedData, context: string): ConceptGraph {
  const nodes = new Map<string, GraphNode>();
  const links: GraphLink[] = [];
  const seenLinks = new Set<string>();

  // Display-name lookup across ALL contexts (for external range/parent nodes).
  const nameByKey = new Map<string, string>();
  for (const c of data.concepts) nameByKey.set(idOf(c.context, c.localName), c.name || c.localName);

  const ensureNode = (ctx: string, ln: string, label = ''): string => {
    const id = idOf(ctx, ln);
    if (!nodes.has(id)) {
      nodes.set(id, {
        id, name: nameByKey.get(id) || label || ln,
        context: ctx, localName: ln, href: hrefOf(ctx, ln), group: 'related',
      });
    }
    return id;
  };

  const addLink = (source: string, target: string, label: string, kind: GraphLink['kind'], card = '', propHref = '') => {
    if (source === target) return; // skip self-loops
    const key = `${source} ${target} ${label} ${kind}`;
    if (seenLinks.has(key)) return;
    seenLinks.add(key);
    links.push({ source, target, label, kind, card, propHref });
  };

  // 1. Every concept in this context is a node (no focus — all peers).
  for (const c of data.concepts) {
    if (c.context !== context) continue;
    nodes.set(idOf(c.context, c.localName), {
      id: idOf(c.context, c.localName), name: c.name || c.localName,
      context: c.context, localName: c.localName, href: hrefOf(c.context, c.localName), group: 'related',
    });
  }

  // 2. Properties whose domain is anchored in this context.
  let litSeq = 0;
  for (const p of data.properties) {
    const domains = (p.domainLinks && p.domainLinks.length)
      ? p.domainLinks.map((d) => ({ ctx: d.context, ln: d.localName }))
      : (p.domainContext && p.domainLocalName ? [{ ctx: p.domainContext, ln: p.domainLocalName }] : []);
    const propHref = p.localName ? `/properties/${p.context}/${p.localName}` : '';
    for (const dom of domains) {
      if (dom.ctx !== context || !dom.ln) continue;
      const srcId = ensureNode(dom.ctx, dom.ln);
      if (p.type === 'ObjectProperty') {
        if (p.rangeContext && p.rangeLocalName) {
          const tgtId = ensureNode(p.rangeContext, p.rangeLocalName);
          addLink(srcId, tgtId, p.name || p.localName, 'outgoing', p.cardinality, propHref);
        }
      } else {
        // Datatype property → its OWN duplicated literal node (never shared).
        const litId = `lit:${srcId}:${p.localName}:${litSeq++}`;
        nodes.set(litId, { id: litId, name: p.datatype || 'value', context: '', localName: '', href: '', group: 'literal' });
        addLink(srcId, litId, p.name || p.localName, 'datatype', p.cardinality, propHref);
      }
    }
  }

  // 3. subClassOf hierarchy — always emitted as child → parent ('parent' kind),
  //    deduped so an edge captured from both endpoints appears once.
  for (const c of data.concepts) {
    if (c.context !== context) continue;
    const det = data.conceptDetails.get(c.id);
    if (!det) continue;
    const selfId = idOf(c.context, c.localName);
    for (const par of det.parents || []) {
      if (!par.localName) continue;
      const pid = ensureNode(par.context || context, par.localName, par.name);
      addLink(selfId, pid, 'is a', 'parent');
    }
    for (const ch of det.children || []) {
      if (!ch.localName) continue;
      const cid = ensureNode(ch.context || context, ch.localName, ch.name);
      addLink(cid, selfId, 'is a', 'parent');
    }
  }

  return { nodes: Array.from(nodes.values()), links };
}
