/**
 * ADR-0182 Cat 12 — Capability & Intent descriptor.
 *
 * Type contracts + per-concept extractor logic, extracted from concept.ts
 * during slice 4 to keep the parent file under the 500-line ceiling.
 */
import { field, get, resolveRefs, localName } from '../jsonld';

/** ADR-0182 G12-2 / G12-8: realization or influence target with direction. */
export interface RealizationLink {
  iri: string;
  label: string;
  /** "out" = this concept realises/influences target; "in" = target realises/influences this. */
  direction: 'in' | 'out';
}

/** ADR-0182 G12-3: KPI card (linked from Goal/Outcome via hm:measuredBy). */
export interface KpiItem {
  iri: string;
  label: string;
  target: string;
  unit: string;
  percentile: string;
}

/** ADR-0182 G12-4: stakeholder concern or addressedBy target. */
export interface ConcernLink {
  iri: string;
  label: string;
}

/** ADR-0182 G12-2 / G12-8 — bidirectional realization/influence links via bnode resolution. */
export function extractRelationLinks(concept: any, graph: any[], refKey: string): RealizationLink[] {
  const refs = get(concept, refKey) || [];
  const nodes = resolveRefs(Array.isArray(refs) ? refs : [refs], graph);
  return nodes.map((n: any) => ({
    iri: field(n, 'iri'),
    label: field(n, 'label') || localName(field(n, 'iri')),
    direction: (field(n, 'direction') || 'out') as 'in' | 'out',
  })).filter((r: RealizationLink) => r.iri);
}

/** ADR-0182 G12-3 — KPI cards from hm:measuredBy bnodes. */
export function extractKpis(concept: any, graph: any[]): KpiItem[] {
  const kpiRefs = get(concept, 'kpi') || [];
  const kpiNodes = resolveRefs(Array.isArray(kpiRefs) ? kpiRefs : [kpiRefs], graph);
  return kpiNodes.map((n: any) => ({
    iri: field(n, 'iri'),
    label: field(n, 'label') || localName(field(n, 'iri')),
    target: field(n, 'target'),
    unit: field(n, 'unit'),
    percentile: field(n, 'percentile'),
  })).filter((k: KpiItem) => k.iri);
}

/** ADR-0182 G12-4 — stakeholder concern / addressedBy links. */
export function extractConcernLinks(concept: any, graph: any[], refKey: string): ConcernLink[] {
  const refs = get(concept, refKey) || [];
  const nodes = resolveRefs(Array.isArray(refs) ? refs : [refs], graph);
  return nodes.map((n: any) => ({
    iri: field(n, 'iri'),
    label: field(n, 'label') || localName(field(n, 'iri')),
  })).filter((c: ConcernLink) => c.iri);
}
