import type { PageDescriptor, NavTab, ExportLink } from '../page-descriptor';
import { val, field, get, findByType, resolveRefs, localName, sentenceCase } from '../jsonld';
import { editorLabel, viewerLabel } from '../dash-labels';
import { isExternalIri, curieFor } from '../iri-helpers';
import type { SensitivityInfo, PrivacyData, UriLabel } from './concept';

export const propertyDescriptor: PageDescriptor = {
  entityType: 'property',
  entitySingular: 'Property',
  listEndpoint: '/properties',
  sectionClass: 'property-section',
  breadcrumbBase: { label: 'Properties', href: '/properties' },
  filterSelector: '[data-prop-card]',
};

export interface CommonConstraints {
  pattern: string;
  flags: string;
  maxLength: string;
  minLength: string;
  minInclusive: string;
  maxInclusive: string;
  minExclusive: string;
  maxExclusive: string;
  languageIn: string;
  uniqueLang: string;
  totalUsages: number;
}

export interface Aggregates {
  totalUsages: number;
  requiredCount: number;
  severityCounts: Record<string, number>;
}

/** A concept item from the concept listing API (used for domain/target/usedBy lookups). */
export interface ConceptRef {
  name?: string;
  localName?: string;
  context?: string;
  definition?: string;
  comment?: string;
  stereotype?: string;
  altLabels?: string[];
  subjectArea?: string;
  dataClassification?: string;
  governanceTier?: string;
  volatility?: string;
  lifecycle?: string;
  regulatoryRelevance?: string;
  sourceSystem?: string;
  valueChainPosition?: string;
  [key: string]: unknown;
}

export interface TargetConceptRef extends ConceptRef {
  cardinality?: string;
}

export interface DashInfo {
  editorInfo: { label: string; icon: string } | null;
  viewerInfo: { label: string; icon: string } | null;
  uniqueValue: string;
  singleLine: string;
}

export interface SubPropertyItem {
  uri: string;
  localName: string;
  name: string;
  data: Record<string, any> | null;
}

export interface UsedByEntry {
  name: string;
  conceptLocal: string;
  cardinality: string;
  severity: string;
  severityLabelCls: string;
  severityValueCls: string;
  message: string;
  required: string;
  conceptData: Record<string, unknown> | undefined;
  context: string;
  contextLabel: string;
  hasPerClass: boolean;
}

export interface HierarchyCard {
  href: string;
  propData: Record<string, any> | null;
  displayName: string;
  rangeCtx: string;
  rangeCtxLabel: string;
  ctxLabel: string;
}

export interface OrTypeEntry {
  label: string;
  href: string;
}

/**
 * ADR-0171 G1-5: relationship-type item for `hm:relationshipType` rendering
 * on property pages. Single-scheme (hm:RelationshipTypeScheme), so the href
 * is constructed by hardcoding the scheme path per the ADR.
 */
export interface RelationshipTypeItem {
  /** Display label (skos:prefLabel of the scheme concept; falls back to local name). */
  label: string;
  /** Scheme-relative href: `/vocabularies/hm/RelationshipTypeScheme/<localName>`. */
  href: string;
}

/**
 * ADR-0173 G3-7 / ADR-0174 G4-6: domain / range entries that point at
 * external-namespace classes (e.g. bbo:ServiceTask, prov:Activity, rdfs:Class).
 * These have no concept page until XC-5 stub pages exist, so the renderer
 * emits the CURIE as unlinked text rather than a 404-producing anchor.
 */
export interface ExternalIriEntry {
  /** Display label — typically the CURIE (e.g. "bbo:ServiceTask"). */
  label: string;
  /** Full IRI for tooltip / future link. */
  iri: string;
}

export interface SuggestionItem {
  name: string;
  category: string;
  sparqlUpdate: string;
}

export interface PropertyData {
  propName: string;
  technicalName: string;
  definition: string;
  summary: string;
  shDescription: string;
  altLabelList: string[];
  rangeList: string[];
  range: string;
  shDatatype: string;
  nodeKind: string;
  isObjectProp: boolean;
  cc: CommonConstraints;
  aggregates: Aggregates;
  pattern: string;
  maxLength: string;
  minInclusive: string;
  maxInclusive: string;
  isDerived: boolean;
  hasCommonConstraints: boolean;
  allowedValues: string[];
  avSchemeHref: string;
  dash: DashInfo;
  hasDash: boolean;
  groupName: string;
  groupOrder: string;
  usedByEntries: UsedByEntry[];
  suggestions: SuggestionItem[];
  domainConcepts: ConceptRef[];
  /** External-namespace domain entries (e.g. `bbo:ServiceTask`) — render as CURIE text, no link. */
  externalDomainEntries: ExternalIriEntry[];
  targetConcepts: TargetConceptRef[];
  /** External-namespace range entries — render as CURIE text, no link. */
  externalRangeEntries: ExternalIriEntry[];
  distinctCard: string;
  orTypeEntries: OrTypeEntry[];
  isFunctional: string;
  isInverseFunctional: string;
  isTransitive: string;
  inversePropUri: string;
  inversePropName: string;
  inversePropLocalName: string;
  inversePropData: Record<string, any> | null;
  superPropUri: string;
  superPropName: string;
  superPropLocalName: string;
  superPropData: Record<string, any> | null;
  subPropertyItems: SubPropertyItem[];
  hasSubProperties: boolean;
  parentCard: HierarchyCard | null;
  childCards: HierarchyCard[];
  /** ADR-0174 G4-4 / XC-3: editorial note on this property. Empty when absent. */
  editorialNote: string;
  /** ADR-0174 G4-5 / XC-2: rdfs:seeAlso URLs. Empty array when absent. */
  seeAlsoLinks: string[];
  /** ADR-0181 G11-1 (property-page sensitivity per ODR R3). Null when absent. */
  sensitivity: SensitivityInfo | null;
  /** ADR-0181 G11-2..G11-7 (property-page Privacy section per ODR R3). Null when absent. */
  privacy: PrivacyData | null;
  /** ADR-0181 G11-3 processing purpose paired with PrivacySection. */
  processingPurpose: string;
  /** ADR-0171 G1-5: relationship-type item rendered on PropertyDocumentationSection. Null when absent. */
  relationshipType: RelationshipTypeItem | null;
  sectionTabs: NavTab[];
  exportLinks: ExportLink[];
}

export function extractPropertyData(
  data: any,
  context: string,
  name: string,
  conceptLookup: Record<string, any>,
  propertyLookup: Record<string, any>,
  contextLabels: Record<string, string>,
): PropertyData | null {
  const graph = data?.['@graph'] || (data ? [data] : []);
  const property =
    graph.find((n: any) => n['@id'] === `hm:${context}/${name}` || n['@id']?.endsWith(`/${context}/${name}`)) ||
    findByType(graph, 'PropertyDetail', 'ObjectProperty', 'DatatypeProperty') ||
    graph.find((n: any) => n['@id'] && !n['@id'].startsWith('_:')) ||
    graph[0] || null;

  if (!property) return null;

  // -- Identity --
  const propName = sentenceCase(field(property, 'name') || property?.['rdfs:label'] || name || '');
  const technicalName = field(property, 'technicalName') || '';

  // -- ODR-0011 / ODR-0042 documentation layers --
  const definition = field(property, 'definition') || property?.['skos:definition'] || '';
  const summary = field(property, 'summary') || '';
  const shDescription = field(property, 'description') || '';

  // -- Alt labels (ODR-0052 R6: abbreviations <= 5 chars sorted first) --
  const altLabels = get(property, 'altLabel') || get(property, 'synonyms') || [];
  const altLabelList: string[] = (Array.isArray(altLabels) ? altLabels : [altLabels])
    .map((l: any) => val(l)).filter(Boolean)
    .sort((a: string, b: string) => {
      const aShort = a.length <= 5 ? 0 : 1;
      const bShort = b.length <= 5 ? 0 : 1;
      return aShort - bShort || a.localeCompare(b);
    });

  // -- Domain / Range --
  // ADR-0173 G3-7 / ADR-0174 G4-6: keep raw IRIs alongside local names so we can
  // detect external-namespace items (bbo:, prov:, rdfs:Class, etc.) and route them
  // through the broken-link guard rather than letting them silently disappear.
  // For each domain/range item we keep:
  //   - `local`: the display string used by existing rendering (preserved as-is for
  //     literal strings like "xsd:string" — only stripped to local name for full IRIs).
  //   - `iri` : the full IRI when the source carried one, used only by the
  //     external-namespace guard in domainConcepts/targetConcepts resolution
  //     (ADR-0173 G3-7 / ADR-0174 G4-6). Empty when the source was a literal.
  function pairFor(v: any): { local: string; iri: string } {
    if (typeof v === 'object' && v?.['@id']) {
      return { local: localName(v['@id']), iri: v['@id'] };
    }
    const s = val(v);
    // Full IRI: strip to local name AND remember the IRI for the guard.
    if (s.startsWith('http://') || s.startsWith('https://')) {
      return { local: localName(s), iri: s };
    }
    // Literal display string (e.g. "xsd:string", "Country") — preserve verbatim,
    // no IRI to guard against.
    return { local: s, iri: '' };
  }

  const domainRaw = get(property, 'domainInformative') || get(property, 'domain') || property?.['rdfs:domain'] || '';
  const domainPairs: Array<{ local: string; iri: string }> = (Array.isArray(domainRaw) ? domainRaw : [domainRaw])
    .map(pairFor)
    .filter((p) => p.local);
  const rangeRaw = get(property, 'rangeInformative') || get(property, 'range') || property?.['rdfs:range'] || '';
  const rangePairs: Array<{ local: string; iri: string }> = (Array.isArray(rangeRaw) ? rangeRaw : [rangeRaw])
    .map(pairFor)
    .filter((p) => p.local);
  const rangeList: string[] = rangePairs.map((p) => p.local);
  const range = rangeList.join(', ');

  // -- SHACL datatype (ODR-0056 R2: priority sh:datatype > rdfs:range) --
  const shDatatypeRaw = field(property, 'shDatatype') || '';
  const shDatatype = localName(shDatatypeRaw);

  // -- Node kind (sh:nodeKind - ODR-0056 R3) --
  const nodeKind = field(property, 'nodeKind') || '';

  // -- Type inference --
  const propType = property?.['@type'] || '';
  const typeArray = Array.isArray(propType) ? propType : [propType];
  const explicitOwlType = typeArray.find((t: string) => t && (t.includes('ObjectProperty') || t.includes('DatatypeProperty'))) || '';
  const xsdTypePattern = /^(string|boolean|integer|decimal|float|double|date|dateTime|int|long|short|byte|nonNegativeInteger|positiveInteger|anyURI|token)$/i;
  const isDatatypeRange = rangeList.some(r => xsdTypePattern.test(localName(r)));
  const inferredType = explicitOwlType
    ? (explicitOwlType.includes('ObjectProperty') ? 'ObjectProperty' : 'DatatypeProperty')
    : (isDatatypeRange ? 'DatatypeProperty' : 'ObjectProperty');
  const isObjectProp = inferredType === 'ObjectProperty';

  // -- ADR-0074: Three-tier constraint model --
  const commonConstraints = property?.['hm:commonConstraints'] || property?.commonConstraints || {};
  const cc: CommonConstraints = {
    pattern: commonConstraints.pattern || '',
    flags: commonConstraints.flags || '',
    maxLength: commonConstraints.maxLength || '',
    minLength: commonConstraints.minLength || '',
    minInclusive: commonConstraints.minInclusive || '',
    maxInclusive: commonConstraints.maxInclusive || '',
    minExclusive: commonConstraints.minExclusive || '',
    maxExclusive: commonConstraints.maxExclusive || '',
    languageIn: commonConstraints.languageIn || '',
    uniqueLang: commonConstraints.uniqueLang || '',
    totalUsages: commonConstraints._totalUsages || 0,
  };

  // Aggregate summaries
  const aggRaw = property?.['hm:aggregates'] || property?.aggregates || {};
  const aggregates: Aggregates = {
    totalUsages: aggRaw.totalUsages || 0,
    requiredCount: aggRaw.requiredCount || 0,
    severityCounts: aggRaw.severityCounts || {},
  };

  // Legacy: check for old-style constraints bnode (backward compat with Turtle fallback)
  const constraintsRef = get(property, 'constraints');
  const constraintsNodes = constraintsRef ? resolveRefs(constraintsRef, graph) : [];
  const legacyConstraints = constraintsNodes[0] || {};
  const pattern = cc.pattern || field(legacyConstraints, 'pattern') || '';
  const maxLength = cc.maxLength || field(legacyConstraints, 'maxLength') || '';
  const minInclusive = cc.minInclusive || field(legacyConstraints, 'minInclusive') || '';
  const maxInclusive = cc.maxInclusive || field(legacyConstraints, 'maxInclusive') || '';

  const isDerived = val(get(property, 'derived')) === 'true' || val(get(legacyConstraints, 'derived')) === 'true';

  // -- Allowed values (sh:in - ODR-0056 R4) --
  const allowedValuesRaw = get(property, 'allowedValue') || [];
  const allowedValues: string[] = (Array.isArray(allowedValuesRaw) ? allowedValuesRaw : [allowedValuesRaw])
    .map((v: any) => val(v)).filter(Boolean);
  const avSchemeContext = field(property, 'allowedValueSchemeContext') || '';
  const avSchemeName = field(property, 'allowedValueSchemeName') || '';
  const avSchemeHref = avSchemeContext && avSchemeName ? `/vocabularies/${avSchemeContext}/${avSchemeName}` : '';

  const hasCommonConstraints = !!(pattern || maxLength || minInclusive || maxInclusive
    || cc.minLength || cc.minExclusive || cc.maxExclusive || cc.flags || cc.languageIn || cc.uniqueLang
    || allowedValues.length > 0);

  // -- ODR-0060: sh:or union types (Tier 1 - range definition) --
  const orTypesRaw = get(property, 'orTypes') || property?.['hm:orTypes'] || [];
  const orTypes: string[] = (Array.isArray(orTypesRaw) ? orTypesRaw : [orTypesRaw])
    .map((v: any) => val(v)).filter(Boolean);

  // -- DASH UI annotations --
  const editorRaw = field(property, 'editorWidget') || field(property, 'editor') || '';
  const viewerRaw = field(property, 'viewerWidget') || field(property, 'viewer') || '';
  const uniqueValue = val(get(property, 'unique') ?? get(property, 'uniqueValueForClass'));
  const singleLine = val(get(property, 'singleLine'));
  const editorInfo = editorRaw ? editorLabel(editorRaw) : null;
  const viewerInfo = viewerRaw ? viewerLabel(viewerRaw) : null;
  const hasDash = !!(editorInfo || viewerInfo || uniqueValue || singleLine);
  const dash: DashInfo = { editorInfo, viewerInfo, uniqueValue, singleLine };

  // -- Property Group --
  const groupRef = get(property, 'propertyGroup');
  const groupNodes = groupRef ? resolveRefs(groupRef, graph) : [];
  const groupNode = groupNodes[0] || null;
  const groupName = groupNode ? field(groupNode, 'name') : (typeof groupRef === 'string' ? groupRef : '');
  const groupOrder = groupNode ? field(groupNode, 'order') : '';

  // -- Used By --
  const usedByRef = get(property, 'usedBy');
  const usedByList = usedByRef ? resolveRefs(usedByRef, graph) : [];

  // -- Suggestions --
  const suggRef = get(property, 'suggestions');
  const suggList = suggRef ? resolveRefs(suggRef, graph) : [];
  const suggestions: SuggestionItem[] = suggList.map((s: any) => ({
    name: field(s, 'name') || '',
    category: field(s, 'category') || '',
    sparqlUpdate: field(s, 'sparqlUpdate') || '',
  }));

  // -- Domain concepts (for ConceptCard display) --
  // Resolved entries become ConceptRefs; unresolved + external-namespace IRIs
  // surface separately so the section renders them as unlinked CURIE text
  // (ADR-0173 G3-7).
  const domainConcepts: ConceptRef[] = [];
  const externalDomainEntries: ExternalIriEntry[] = [];
  for (const { local, iri } of domainPairs) {
    const match = Object.values(conceptLookup).find((c: any) => c.localName === local || c.name === local);
    if (match) {
      domainConcepts.push(match);
    } else if (iri && isExternalIri(iri)) {
      externalDomainEntries.push({ label: curieFor(iri), iri });
    }
  }

  // -- Target Object / Range concepts --
  const cardinalities = usedByList.map((ub: any) => field(ub, 'cardinality') || '').filter(Boolean);
  const distinctCard = Array.from(new Set(cardinalities)).join(' / ');
  const targetConcepts: TargetConceptRef[] = [];
  const externalRangeEntries: ExternalIriEntry[] = [];
  if (isObjectProp) {
    for (const { local, iri } of rangePairs) {
      const match = Object.values(conceptLookup).find((c: any) => c.localName === local || c.name === local);
      if (match) {
        targetConcepts.push({ ...match, cardinality: distinctCard });
      } else if (iri && isExternalIri(iri)) {
        externalRangeEntries.push({ label: curieFor(iri), iri });
      }
    }
  }

  // -- OWL Property Characteristics (ADR-0064) --
  const isFunctional = val(get(property, 'isFunctional'));
  const isInverseFunctional = val(get(property, 'isInverseFunctional'));
  const isTransitive = val(get(property, 'isTransitive'));
  const inversePropUri = field(property, 'inverseProperty') || '';
  const inversePropName = field(property, 'inversePropertyName') || '';
  const superPropUri = field(property, 'superProperty') || '';
  const superPropName = field(property, 'superPropertyName') || '';

  // -- Inverse / Super property lookups (for PropertyCard rendering) --
  const inversePropLocalName = inversePropUri ? localName(inversePropUri) : '';
  const inversePropData = inversePropLocalName
    ? Object.values(propertyLookup).find((p: any) => p.localName === inversePropLocalName) || null
    : null;
  const superPropLocalName = superPropUri ? localName(superPropUri) : '';
  const superPropData = superPropLocalName
    ? Object.values(propertyLookup).find((p: any) => p.localName === superPropLocalName) || null
    : null;

  // -- Sub-properties (children - properties that declare rdfs:subPropertyOf this property) --
  const subPropRefs = get(property, 'subProperty') || [];
  const subPropRefList: string[] = (Array.isArray(subPropRefs) ? subPropRefs : [subPropRefs])
    .map((s: any) => typeof s === 'object' && s?.['@id'] ? s['@id'] : val(s))
    .filter(Boolean);
  const subPropNames = get(property, 'subPropertyName') || [];
  const subPropNameList: string[] = (Array.isArray(subPropNames) ? subPropNames : [subPropNames])
    .map((s: any) => val(s)).filter(Boolean);
  const subPropertyItems: SubPropertyItem[] = subPropRefList.map((spUri, i) => {
    const ln = localName(spUri);
    const spData = ln ? Object.values(propertyLookup).find((p: any) => p.localName === ln) || null : null;
    return { uri: spUri, localName: ln, name: subPropNameList[i] || '', data: spData };
  });
  const hasSubProperties = subPropertyItems.length > 0;

  // -- Pre-process usedBy entries (ADR-0074 Tier 3) --
  const usedByEntries: UsedByEntry[] = usedByList.map((ub: any) => {
    const ubName = field(ub, 'name') || '';
    const ubConceptUri = field(ub, 'concept') || '';
    const conceptLocal = ubConceptUri ? localName(ubConceptUri) : '';
    const ubPattern = field(ub, 'pattern') || '';
    const ubMaxLength = field(ub, 'maxLength') || '';
    const ubMinLength = field(ub, 'minLength') || '';
    const severity = field(ub, 'severity') || '';
    const message = field(ub, 'message') || '';
    const required = val(get(ub, 'required'));
    const hasValue = field(ub, 'hasValue') || '';
    const conceptData = Object.values(conceptLookup).find((c: any) => c.localName === conceptLocal || c.name === ubName);
    const ubCtx = conceptData?.context || '';
    const hasPerClass = !!(severity || message
      || (ubPattern && ubPattern !== cc.pattern)
      || (ubMaxLength && ubMaxLength !== cc.maxLength)
      || (ubMinLength && ubMinLength !== cc.minLength)
      || hasValue);
    const sevLbl = severity === 'Violation' ? 'bg-red-100 text-red-700 border-red-200'
      : severity === 'Warning' ? 'bg-amber-100 text-amber-700 border-amber-200'
      : 'bg-blue-100 text-blue-700 border-blue-200';
    const sevVal = severity === 'Violation' ? 'border-red-200'
      : severity === 'Warning' ? 'border-amber-200' : 'border-blue-200';
    return {
      name: ubName, conceptLocal, cardinality: field(ub, 'cardinality') || '',
      severity, severityLabelCls: sevLbl, severityValueCls: sevVal,
      message, required, conceptData,
      context: ubCtx, contextLabel: contextLabels[ubCtx] || ubCtx, hasPerClass,
    };
  });

  // -- Resolve hierarchy cards (parent + children) --
  function buildHierarchyCard(propData: any, fallbackName: string, fallbackCtx: string): HierarchyCard {
    const ctx = propData?.context || fallbackCtx;
    const ln = propData?.localName || fallbackName;
    const rangeMatch = propData?.range ? Object.values(conceptLookup).find((c: any) => c.localName === propData.range || c.name === propData.range) : null;
    const rCtx = rangeMatch?.context || '';
    return {
      href: `/properties/${ctx}/${ln}`,
      propData,
      displayName: sentenceCase(propData?.name || fallbackName),
      rangeCtx: rCtx,
      rangeCtxLabel: rCtx ? (contextLabels[rCtx] || rCtx) : '',
      ctxLabel: contextLabels[ctx] || ctx,
    };
  }
  const parentCard: HierarchyCard | null = superPropUri
    ? buildHierarchyCard(superPropData, superPropName || superPropLocalName, context)
    : null;
  const childCards: HierarchyCard[] = subPropertyItems.map(sp =>
    buildHierarchyCard(sp.data, sp.name || sp.localName, context),
  );

  // -- Resolve or-type entries --
  const orTypeEntries: OrTypeEntry[] = orTypes.map(t => {
    const tLocal = localName(t);
    const tMatch = Object.values(conceptLookup).find((c: any) => c.localName === tLocal || c.name === t);
    const tCtx = tMatch?.context || '';
    return { label: t, href: tCtx && tLocal ? `/concepts/${tCtx}/${tLocal}` : '' };
  });

  // -- ADR-0174 G4-4 (XC-3): skos:editorialNote on the property itself --
  const editorialNote = field(property, 'editorialNote') || '';

  // -- ADR-0174 G4-5 (XC-2): rdfs:seeAlso URLs on the property --
  const seeAlsoRaw = get(property, 'seeAlso') || [];
  const seeAlsoLinks: string[] = (Array.isArray(seeAlsoRaw) ? seeAlsoRaw : [seeAlsoRaw])
    .map((s: any) => {
      if (typeof s === 'object' && s?.['@id']) return s['@id'];
      return val(s);
    })
    .filter(Boolean);

  // -- ADR-0171 G1-5: relationship-type item (single-scheme RelationshipTypeScheme) --
  // The mapper now emits scheme IRIs (e.g. `hm:rel-Composition`) and the SPARQL
  // OPTIONAL projects `?relTypeLabel` + `?relTypeLocal`. Scheme name is hardcoded
  // per the ADR's single-scheme note.
  const relationshipType: RelationshipTypeItem | null = (() => {
    const local = field(property, 'relationshipTypeLocal');
    const label = field(property, 'relationshipType');
    if (!local || !label) return null;
    return { label, href: `/vocabularies/hm/RelationshipTypeScheme/${local}` };
  })();

  // -- ADR-0181 G11-1 (property-page sensitivity per ODR R3) --
  const sensitivity: SensitivityInfo | null = (() => {
    const iri = field(property, 'dataSensitivity');
    if (!iri) return null;
    const label = field(property, 'dataSensitivityLabel') || localName(iri);
    const level = field(property, 'dataSensitivityLevel') || label.toLowerCase();
    return { iri, label, level };
  })();

  // -- ADR-0181 G11-2..G11-7 (property-page Privacy section per ODR R3) --
  function uriLabelOne(uriKey: string, labelKey: string): UriLabel | null {
    const iri = field(property, uriKey);
    if (!iri) return null;
    const label = field(property, labelKey) || localName(iri);
    return { iri, label };
  }
  const processingPurpose = field(property, 'processingPurpose') || '';
  const privacy: PrivacyData | null = (() => {
    const flagRaw = (field(property, 'personalDataFlag') || '').toLowerCase();
    const personalDataFlag = flagRaw === 'true';
    const personalDataCategory = uriLabelOne('personalDataCategory', 'personalDataCategoryLabel');
    const accessRole = uriLabelOne('accessRole', 'accessRoleLabel');
    const hasAny = personalDataFlag || !!personalDataCategory;
    if (!hasAny) return null;
    return { personalDataFlag, personalDataCategory, accessRole, hasAny };
  })();

  // -- Section navbar tabs (conditional on data presence) --
  const hasSuggestions = suggestions.length > 0;
  const hasDocs = !!(definition || summary || shDescription || hasSuggestions || editorialNote || seeAlsoLinks.length > 0);
  const hasDomain = domainConcepts.length > 0;
  const hasRange = targetConcepts.length > 0 || rangeList.length > 0 || !!shDatatype || !!nodeKind || orTypes.length > 0;
  const sectionTabs: NavTab[] = [
    { id: 'documentation',  label: 'Doc',         href: '#section-documentation',  hasData: hasDocs },
    { id: 'domain',         label: 'Domain',      href: '#section-domain',         count: domainConcepts.length, hasData: true },
    { id: 'range',          label: 'Range',       href: '#section-range',          count: targetConcepts.length || undefined, hasData: hasRange },
    { id: 'inverse-of',     label: 'Inverse',     href: '#section-inverse-of',     hasData: !!inversePropUri },
    { id: 'hierarchy',      label: 'Hierarchy',   href: '#section-hierarchy',      hasData: hasSubProperties || !!superPropUri },
    { id: 'constraints',    label: 'Constraints', href: '#section-constraints',    hasData: hasCommonConstraints },
    { id: 'used-by',        label: 'Used By',     href: '#section-used-by',        count: usedByEntries.length, hasData: usedByEntries.length > 0 },
    { id: 'privacy',        label: 'Privacy',     href: '#section-privacy',        hasData: !!privacy || !!sensitivity },
    { id: 'user-interface', label: 'UI',          href: '#section-user-interface', hasData: hasDash, expert: true },
    { id: 'discussion',     label: 'Discussion',  href: '#section-discussion',     hasData: true },
  ];

  // -- Export links --
  const exportLinks: ExportLink[] = [
    { format: 'JSON-LD', href: `/export/properties/${context}/${name}.jsonld` },
    { format: 'JSON',    href: `/export/properties/${context}/${name}.json` },
    { format: 'CSV',     href: `/export/properties/${context}/${name}.csv` },
    { format: 'YAML',    href: `/export/properties/${context}/${name}.yaml` },
    { format: 'XML',     href: `/export/properties/${context}/${name}.xml` },
  ];

  return {
    propName,
    technicalName,
    definition,
    summary,
    shDescription,
    altLabelList,
    rangeList,
    range,
    shDatatype,
    nodeKind,
    isObjectProp,
    cc,
    aggregates,
    pattern,
    maxLength,
    minInclusive,
    maxInclusive,
    isDerived,
    hasCommonConstraints,
    allowedValues,
    avSchemeHref,
    dash,
    hasDash,
    groupName,
    groupOrder,
    usedByEntries,
    suggestions,
    domainConcepts,
    externalDomainEntries,
    targetConcepts,
    externalRangeEntries,
    distinctCard,
    orTypeEntries,
    isFunctional,
    isInverseFunctional,
    isTransitive,
    inversePropUri,
    inversePropName,
    inversePropLocalName,
    inversePropData,
    superPropUri,
    superPropName,
    superPropLocalName,
    superPropData,
    subPropertyItems,
    hasSubProperties,
    parentCard,
    childCards,
    editorialNote,
    seeAlsoLinks,
    sensitivity,
    privacy,
    processingPurpose,
    relationshipType,
    sectionTabs,
    exportLinks,
  };
}
