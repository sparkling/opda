import type { Badge, PageDescriptor } from '../page-descriptor';
import { val, field, get, findByType, resolveRefs } from '../jsonld';

export const vocabularyDescriptor: PageDescriptor = {
  entityType: 'vocabulary',
  entitySingular: 'Vocabulary',
  listEndpoint: '/vocabularies',
  sectionClass: 'vocab-section',
  breadcrumbBase: { label: 'Vocabularies', href: '/vocabularies' },
};

export interface VocabularyData {
  vocabName: string;
  docText: string;
  closureBadges: Badge[];
  memberList: Record<string, unknown>[];
  hasHierarchy: boolean;
  usedByList: Record<string, unknown>[];
  schemeScopeNote: string;
  schemeEditorialNote: string;
}

function isNumericTyped(raw: any): boolean {
  if (raw == null) return false;
  const t = raw['@type'] || '';
  if (t.includes('integer') || t.includes('decimal') || t.includes('int')) return true;
  const v = val(raw);
  return /^\d+$/.test(v);
}

export function extractVocabularyData(
  data: any,
  context: string,
  name: string,
): VocabularyData | null {
  const graph = data?.['@graph'] || (data ? [data] : []);
  const vocabulary =
    graph.find(
      (n: any) =>
        n['@id'] &&
        (n['@id'] === `${context}:${name}` ||
          n['@id'].endsWith(`/${name}`) ||
          n['@id'].endsWith(`#${name}`)),
    ) ||
    findByType(graph, 'VocabularyDetail', 'ConceptScheme') ||
    graph.find((n: any) => n['@id'] && !n['@id'].startsWith('_:')) ||
    graph[0] ||
    null;

  if (!vocabulary) return null;

  const vocabName =
    field(vocabulary, 'name') || vocabulary?.['rdfs:label'] || name || '';
  const definition =
    field(vocabulary, 'definition') || vocabulary?.['skos:definition'] || '';
  const description =
    field(vocabulary, 'description') ||
    field(vocabulary, 'comment') ||
    vocabulary?.['rdfs:comment'] ||
    '';
  const docText = definition || description;

  const closureType = field(vocabulary, 'closureType') || '';
  const schemeScopeNote = field(vocabulary, 'scopeNote') || '';
  const schemeEditorialNote = field(vocabulary, 'editorialNote') || '';

  const memberRefs =
    get(vocabulary, 'values') ||
    get(vocabulary, 'members') ||
    get(vocabulary, 'hasTopConcept') ||
    [];
  const memberList = resolveRefs(memberRefs, graph);

  function displayAbbr(m: Record<string, unknown>): string {
    const abbrRaw = get(m, 'abbreviation');
    if (abbrRaw != null && isNumericTyped(abbrRaw)) return '';
    const abbrVal = val(abbrRaw);
    if (abbrVal) return abbrVal;
    const alt = val(m['skos:altLabel']) || '';
    if (alt) return alt;
    return '';
  }

  // ADR-0175 G5-7: governance requirements (mandatory + recommended) may be
  // multi-valued — JSON-LD renders these as either a single string or an array.
  function multiVal(node: any, key: string): string[] {
    const raw = get(node, key);
    if (raw == null) return [];
    return (Array.isArray(raw) ? raw : [raw]).map((v: any) => val(v)).filter(Boolean);
  }

  const enrichedMembers = memberList.map((m: Record<string, unknown>) => ({
    ...m,
    _abbr: displayAbbr(m),
    _owner: field(m, 'owner'),
    _scopeNote: field(m, 'scopeNote'),
    _deprecated: field(m, 'deprecated') === 'true',
    _depth: parseInt(field(m, 'depth') || '0', 10) || 0,
    _mandatoryProperties: multiVal(m, 'mandatoryProperty'),
    _recommendedProperties: multiVal(m, 'recommendedProperty'),
  }));

  const hasHierarchy = memberList.some(
    (m: any) => get(m, 'broader') != null || get(m, 'depth') != null,
  );

  const usedByRefs = get(vocabulary, 'usedBy') || [];
  const usedByList = resolveRefs(
    Array.isArray(usedByRefs) ? usedByRefs : [usedByRefs],
    graph,
  );

  // ADR-0175 G5-6 colour map: Closed → amber, OpenEnded → green, Classification → blue.
  // Accept both label-style ("Open-ended") and concept-style ("OpenEnded") spellings
  // so the badge renders correctly whether the SPARQL OPTIONAL coalesced from a
  // concept localName or fell through to a legacy literal.
  const closureBadgeClass: Record<string, string> = {
    Closed: 'bg-amber-100 text-amber-700',
    'Open-ended': 'bg-green-100 text-green-700',
    OpenEnded: 'bg-green-100 text-green-700',
    Classification: 'bg-blue-100 text-blue-700',
  };
  const badgeCls =
    closureBadgeClass[closureType] || 'bg-gray-100 text-gray-700';
  const closureBadges: Badge[] = closureType
    ? [{ label: closureType, class: badgeCls }]
    : [];

  return {
    vocabName,
    docText,
    closureBadges,
    memberList: enrichedMembers,
    hasHierarchy,
    usedByList,
    schemeScopeNote,
    schemeEditorialNote,
  };
}
