import type { PageDescriptor } from '../page-descriptor';
import { val, field, get, findByType, resolveRefs } from '../jsonld';

export const moduleDescriptor: PageDescriptor = {
  entityType: 'module',
  entitySingular: 'Module',
  listEndpoint: '/modules',
  sectionClass: 'module-section',
  breadcrumbBase: { label: 'Modules', href: '/modules' },
};

export interface ModuleData {
  modName: string;
  description: string;
  classList: Record<string, unknown>[];
  modPropList: Record<string, unknown>[];
  modContext: string;
}

export function extractModuleData(
  data: any,
  context: string,
  name: string,
): ModuleData | null {
  const graph = data?.['@graph'] || (data ? [data] : []);
  const mod =
    findByType(graph, 'ModuleDetail', 'Module', 'Ontology') ||
    (data?.['@type'] && !data?.['@graph'] ? data : null) ||
    graph.find((n: any) => n['@id'] && !n['@id'].startsWith('_:')) ||
    graph[0] ||
    null;

  if (!mod) return null;

  const modName = field(mod, 'name') || val(mod?.['rdfs:label']) || name || '';
  const modContext = field(mod, 'context') || context || '';
  const description =
    field(mod, 'description') ||
    field(mod, 'comment') ||
    val(mod?.['rdfs:comment']) ||
    '';

  const classRefs =
    get(mod, 'classes') || get(mod, 'class') || get(mod, 'concepts') || [];
  const classList = resolveRefs(
    Array.isArray(classRefs) ? classRefs : [classRefs],
    graph,
  );

  const propRefs = get(mod, 'properties') || get(mod, 'property') || [];
  const modPropList = resolveRefs(
    Array.isArray(propRefs) ? propRefs : [propRefs],
    graph,
  );

  return {
    modName,
    description,
    classList,
    modPropList,
    modContext,
  };
}
