/**
 * DASH ResourceActions + Incoming Properties pipelines.
 *
 * Extracted from concept.ts (slice 5) to keep concept.ts under the 500-line
 * ceiling. Public API preserved via re-exports in concept.ts.
 */
import { val, field, get, iriRef, resolveRefs } from '../jsonld';

/** A single DASH ResourceAction row. */
export interface ActionRow {
  name: string;
  description: string;
  group: string;
  groupOrder: number;
}

/** A single incoming-property row (where this concept is a target of another property). */
export interface InPropRow {
  name: string;
  techName: string;
  desc: string;
  group: string;
  card: string;
  required: boolean;
  severity: string;
  context: string;
  /** Source-class IRI ref (e.g. "pf:Role") that owns this property — for the graph view. */
  fromIri: string;
  /** Source-class display label. */
  fromName: string;
}

export interface ActionsData {
  rawActions: ActionRow[];
  actionGroupMap: Map<string, ActionRow[]>;
  actionGroupNames: string[];
}

export interface IncomingPropsData {
  inProps: InPropRow[];
  inGroupMap: Map<string, InPropRow[]>;
  inGroupNames: string[];
}

/** Extract DASH ResourceActions grouped by actionGroup + groupOrder. */
export function extractActions(concept: any, graph: any[]): ActionsData {
  const actionRefs = get(concept, 'action') || [];
  const actionList = resolveRefs(Array.isArray(actionRefs) ? actionRefs : [actionRefs], graph);

  const rawActions: ActionRow[] = actionList.map((a: any) => ({
    name: field(a, 'name') || '',
    description: field(a, 'description') || '',
    group: field(a, 'actionGroup') || 'Other',
    groupOrder: parseInt(field(a, 'groupOrder') || '999', 10),
  })).filter((a) => a.name);

  const actionGroupMap = new Map<string, ActionRow[]>();
  for (const a of rawActions) {
    if (!actionGroupMap.has(a.group)) actionGroupMap.set(a.group, []);
    actionGroupMap.get(a.group)!.push(a);
  }
  const actionGroupNames = Array.from(actionGroupMap.keys()).sort((a, b) => {
    const aOrder = actionGroupMap.get(a)![0].groupOrder;
    const bOrder = actionGroupMap.get(b)![0].groupOrder;
    return aOrder - bOrder;
  });
  return { rawActions, actionGroupMap, actionGroupNames };
}

/** Extract incoming-property rows (deduped by techName/name) grouped by propertyGroup. */
export function extractIncomingProps(concept: any, graph: any[]): IncomingPropsData {
  const inPropRefs = get(concept, 'incomingProperty') || [];
  const inPropList = resolveRefs(Array.isArray(inPropRefs) ? inPropRefs : [inPropRefs], graph);

  const rawInProps: InPropRow[] = inPropList.map((p: any) => ({
    name: field(p, 'name') || '',
    techName: field(p, 'technicalName') || '',
    desc: field(p, 'description') || '',
    group: field(p, 'propertyGroup') || field(p, 'group') || '',
    card: field(p, 'cardinality') || '',
    required: val(get(p, 'required')) === 'true',
    severity: field(p, 'severity') || '',
    context: field(p, 'context') || '',
    fromIri: iriRef(p, 'fromClass'),
    fromName: field(p, 'fromName') || '',
  })).filter((p) => p.name || p.techName);

  const inPropMap = new Map<string, InPropRow>();
  for (const p of rawInProps) {
    const key = p.techName || p.name;
    if (!inPropMap.has(key)) inPropMap.set(key, p);
  }
  const inProps = Array.from(inPropMap.values()).sort((a, b) => a.name.localeCompare(b.name));

  const inGroupMap = new Map<string, InPropRow[]>();
  for (const p of inProps) {
    const g = p.group || 'Other';
    if (!inGroupMap.has(g)) inGroupMap.set(g, []);
    inGroupMap.get(g)!.push(p);
  }
  const inGroupNames = Array.from(inGroupMap.keys()).sort((a, b) => {
    if (a === 'Other') return 1;
    if (b === 'Other') return -1;
    return a.localeCompare(b);
  });
  return { inProps, inGroupMap, inGroupNames };
}
