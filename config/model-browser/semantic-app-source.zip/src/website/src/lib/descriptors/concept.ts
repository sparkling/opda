import type { PageDescriptor, NavTab, ExportLink } from '../page-descriptor';
import { val, field, get, findByType } from '../jsonld';
import { accentColorForContext } from '../accent-color';

export const conceptDescriptor: PageDescriptor = {
  entityType: 'concept',
  entitySingular: 'Concept',
  listEndpoint: '/concepts',
  sectionClass: 'concept-section',
  breadcrumbBase: { label: 'Concepts', href: '/concepts' },
  showNavFilter: true,
  filterSelector: '[data-prop-card]',
};

// ── Interfaces ──

// PropRow + extractProperties moved to concept-properties.ts (slice 5).
export type { PropRow } from './concept-properties';
import type { PropRow } from './concept-properties';
import { extractProperties } from './concept-properties';

export interface PairConstraint {
  sourceName: string; sourceTech: string;
  pairType: string;
  targetName: string; targetTech: string;
}

// ActionRow + InPropRow + extractors moved to concept-actions-incoming.ts (slice 5).
export type { ActionRow, InPropRow } from './concept-actions-incoming';
import type { ActionRow, InPropRow } from './concept-actions-incoming';
import { extractActions, extractIncomingProps } from './concept-actions-incoming';

// HierarchyItem + MappingItem + extractors moved to concept-relations.ts (slice 5).
export type { HierarchyItem, MappingItem } from './concept-relations';
import type { HierarchyItem, MappingItem } from './concept-relations';
import { extractHierarchy, extractMappings } from './concept-relations';

// Relationship graph (ADR-0190): object-property + subClassOf edges → { nodes, links }.
export type { ConceptGraph, GraphNode, GraphLink } from './concept-graph';
import type { ConceptGraph } from './concept-graph';
import { buildConceptGraph } from './concept-graph';

export interface FacetItem {
  label: string; values: string[]; href?: string; filter?: string; iconKey?: string;
}

/** ADR-0181 G11-1: data sensitivity classification (CLOSED scheme — 4 levels). */
// ADR-0181 Cat 11 — Sensitivity / Privacy / Regulatory types + extractors
// (extracted slice 4).
export type { SensitivityInfo, UriLabel, RegulatoryData, PrivacyData } from './concept-cat11';
import type { SensitivityInfo, RegulatoryData, PrivacyData } from './concept-cat11';
import { extractSensitivity, extractRegulatory, extractPrivacy } from './concept-cat11';

// ADR-0183 Cat 13 + ADR-0182 G12-1 / G12-8 — lifecycle status + coverage types
// + extractors (extracted slice 4).
export type { LifecycleStatus, CoverageData } from './concept-cat13';
import type { LifecycleStatus, CoverageData } from './concept-cat13';
import { extractLifecycleStatus, extractCoverage } from './concept-cat13';

// ADR-0182 Cat 12 — Realization / KPI / Concern types + extractors (extracted slice 4).
export type { RealizationLink, KpiItem, ConcernLink } from './concept-cat12';
import type { RealizationLink, KpiItem, ConcernLink } from './concept-cat12';
import { extractRelationLinks, extractKpis, extractConcernLinks } from './concept-cat12';

// ADR-0171 G1-4 — Ontological Profile types + extractor (extracted slice 5).
export type { OntologicalProfileItem } from './concept-cat01';
import type { OntologicalProfileItem } from './concept-cat01';
import { extractOntologicalProfile } from './concept-cat01';

// ADR-0179 G9-5 — Extraction Provenance type + extractor (extracted slice 5).
export type { ExtractionProvenance } from './concept-cat09';
import type { ExtractionProvenance } from './concept-cat09';
import { extractExtractionProvenance } from './concept-cat09';

// ADR-0176 Cat 6 — Governance & Compliance type + extractor (extracted slice 4).
export type { GovernanceData } from './concept-cat06';
import type { GovernanceData } from './concept-cat06';
import { extractGovernance } from './concept-cat06';

export interface ConceptData {
  // Identity
  conceptName: string;

  // Context
  ctxLabel: string;
  accentColor: string;

  // Documentation
  summary: string;
  definition: string;
  usage: string;
  altLabelList: string[];

  // Stereotype
  stereotype: string;
  stereotypeKind: string;

  // Governance / editorial
  sourceSystems: string[];
  notesList: string[];
  temporalValidity: string;

  // Classification
  facets: FacetItem[];
  statusList: string[];

  // Ontological profile (ADR-0171 G1-4)
  dddStereotype: OntologicalProfileItem | null;
  ontologicalType: OntologicalProfileItem | null;
  rigidity: OntologicalProfileItem | null;
  identityPrinciple: OntologicalProfileItem | null;
  hasOntologicalProfile: boolean;

  // Lifecycle / sensitivity badges (ADR-0181 G11-1, ADR-0183 G13-1 / G13-2, ADR-0182 G12-1 / G12-8)
  sensitivity: SensitivityInfo | null;
  promotionStatus: LifecycleStatus | null;
  reviewStatus: LifecycleStatus | null;
  reviewedBy: string;
  capabilityStatus: LifecycleStatus | null;
  priority: LifecycleStatus | null;

  // Governance (ADR-0176 G6-1 + G6-3) — null when no governance annotations
  governance: GovernanceData | null;

  // Cat 5 G5-4/G5-10 + G5-8
  ufoStereotype: { label: string; href: string } | null;
  businessKey: string;

  // Cat 9 extraction provenance (ADR-0179 G9-5)
  extractionProvenance: ExtractionProvenance | null;

  // Regulatory + privacy (ADR-0181 G11-2..G11-7)
  regulatory: RegulatoryData | null;
  privacy: PrivacyData | null;

  // Cat 13 coverage (ADR-0183 G13-3) — null when no ConformanceSummary targets this concept
  coverage: CoverageData | null;

  // Cat 12 (ADR-0182 G12-2 / G12-8): realizations + influences (multi-valued)
  realizations: RealizationLink[];
  influences: RealizationLink[];

  // Cat 12 (ADR-0182 G12-3): KPI cards from hm:measuredBy
  kpis: KpiItem[];

  // Cat 12 (ADR-0182 G12-4): stakeholder concerns + addressedBy
  concerns: ConcernLink[];
  addressedBy: ConcernLink[];

  // Properties (SHACL)
  props: PropRow[];
  groupMap: Map<string, PropRow[]>;
  groupNames: string[];

  // Pair constraints
  pairConstraints: PairConstraint[];

  // Actions (DASH ResourceActions)
  rawActions: ActionRow[];
  actionGroupMap: Map<string, ActionRow[]>;
  actionGroupNames: string[];

  // Incoming properties
  inProps: InPropRow[];
  inGroupMap: Map<string, InPropRow[]>;
  inGroupNames: string[];

  // Hierarchy
  parentList: HierarchyItem[];
  childList: HierarchyItem[];
  roleOfList: HierarchyItem[];
  disjointList: HierarchyItem[];

  // Mappings
  mappings: MappingItem[];

  // Relationship graph (ADR-0190): object-property + subClassOf edges for the 3D view.
  propertyGraph: ConceptGraph;

  // Technical
  isAbstract: boolean;
  labelProp: string;

  // Section tabs
  sectionTabs: NavTab[];

  // Export links
  exportLinks: ExportLink[];
}

// ── Helpers ──

function classValues(concept: any, key: string): string[] {
  const raw = get(concept, key);
  if (!raw) return [];
  return (Array.isArray(raw) ? raw : [raw]).map((v: any) => val(v)).filter(Boolean);
}

// ── Main extraction ──

export function extractConceptData(
  data: any,
  context: string,
  name: string,
  conceptLookup: Record<string, any>,
  contextLabels: Record<string, string>,
): ConceptData | null {
  if (!data) return null;
  const graph = data['@graph'] || [data];
  const concept = findByType(graph, 'ConceptDetail')
    || graph.find((n: any) => n['@id'] && !n['@id'].startsWith('_:'))
    || graph[0] || null;
  if (!concept) return null;

  // ── Core identity ──
  const conceptName = field(concept, 'name') || val(concept['rdfs:label']) || name;

  // ── Bounded context ──
  const ctxKey = context || '';
  const ctxLabel = contextLabels[ctxKey] || ctxKey;
  const accentColor = accentColorForContext(ctxKey);

  // ── ONT-0011 four-tier documentation ──
  const summary = field(concept, 'summary') || '';
  const definition = field(concept, 'definition') || '';
  const usageNotes = field(concept, 'usageNotes') || '';
  const scopeNote = field(concept, 'scopeNote') || '';
  const usage = usageNotes || scopeNote;

  const altLabels = get(concept, 'altLabel') || get(concept, 'synonyms') || [];
  const altLabelList: string[] = (Array.isArray(altLabels) ? altLabels : [altLabels])
    .map((l: any) => val(l)).filter(Boolean)
    .sort((a: string, b: string) => {
      const aShort = a.length <= 5 ? 0 : 1;
      const bShort = b.length <= 5 ? 0 : 1;
      return aShort - bShort || a.localeCompare(b);
    });

  // Stereotype
  const stereotype = field(concept, 'stereotype') || '';
  const stereotypeKind = field(concept, 'stereotypeKind') || '';

  // ── Governance / editorial ──
  const governance = get(concept, 'governance') || {};
  const sourceSystemRefs = governance.sourceSystem || get(concept, 'sourceSystem') || [];
  const sourceSystems: string[] = (Array.isArray(sourceSystemRefs) ? sourceSystemRefs : [sourceSystemRefs])
    .map((s: any) => val(s)).filter(Boolean);
  const editorialNotesRaw = governance.editorialNotes || get(concept, 'editorialNotes') || [];
  const notesList = Array.isArray(editorialNotesRaw)
    ? editorialNotesRaw.map((n: any) => val(n)).filter(Boolean)
    : [val(editorialNotesRaw)].filter(Boolean);
  const temporalValidity = field(concept, 'temporalValidity') || '';

  // ── Cat 9 extraction provenance (ADR-0179 G9-5) ──
  const extractionProvenance: ExtractionProvenance | null = extractExtractionProvenance(concept);

  // ── Cat 5 G5-4/G5-10 ufoStereotype + G5-8 businessKey ──
  // ufoStereotype links to /vocabularies/hm/UFOStereotypeScheme/<localName>
  // (the scheme is well-known; ADR-0175 §G5-4 hardcodes this scheme name).
  const ufoStereotype = (() => {
    const local = field(concept, 'ufoStereotypeLocal');
    const label = field(concept, 'ufoStereotypeLabel');
    if (!local || !label) return null;
    return { label, href: `/vocabularies/hm/UFOStereotypeScheme/${local}` };
  })();
  const businessKey = field(concept, 'businessKey');

  // ── Cat 11 regulatory + privacy (ADR-0181 G11-2..G11-7) ──
  // Helper to read multi-valued URI+label pairs (applicableRegulation).
  // ── Cat 11 G11-2..G11-7 regulatory + privacy ──
  const regulatory = extractRegulatory(concept);
  const privacy = extractPrivacy(concept);

  // ── Cat 13 G13-3 coverage (latest ConformanceRun via testedClass + runRef sub-select). ──
  const coverage = extractCoverage(concept);

  // ── Cat 12 G12-2 / G12-8 realizations + influences (bidirectional bnode resolution). ──
  const realizations = extractRelationLinks(concept, graph, 'realization');
  const influences = extractRelationLinks(concept, graph, 'influence');

  // ── Cat 12 G12-3 KPIs from hm:measuredBy bnodes. ──
  const kpis = extractKpis(concept, graph);

  // ── Cat 12 G12-4 concerns + addressedBy. ──
  const concerns = extractConcernLinks(concept, graph, 'concern');
  const addressedBy = extractConcernLinks(concept, graph, 'addressedBy');

  // ── Classification (ONT-0010 seven facets) ──
  const subjectArea = field(concept, 'subjectArea') || '';
  const subjectAreaLocalName = field(concept, 'subjectAreaLocalName') || '';
  const dataClassification = classValues(concept, 'dataClassification');
  const lifecycle = classValues(concept, 'lifecycle');
  const volatility = classValues(concept, 'volatility');
  const regulatoryRelevance = classValues(concept, 'regulatoryRelevance');
  const governanceTierRaw = val(governance?.tier) || field(concept, 'governanceTier') || '';
  const governanceTier = governanceTierRaw ? [governanceTierRaw] : [];
  const valueChainPositions = classValues(concept, 'valueChainPositions');

  const statusRaw = get(concept, 'status') || field(concept, 'status') || '';
  const statusList: string[] = statusRaw
    ? (Array.isArray(statusRaw) ? statusRaw : [statusRaw]).map((s: any) => val(s)).filter(Boolean)
    : [];

  // ── Ontological profile (ADR-0171 G1-4) ──
  // Slice 4 mapper update lifted dddStereotype + rigidity from BLOCKED to
  // PASS by emitting scheme IRIs; the OPTIONAL skos:inScheme joins now
  // resolve for all four predicates once Fuseki reloads.
  const { dddStereotype, ontologicalType, rigidity, identityPrinciple, hasOntologicalProfile } =
    extractOntologicalProfile(concept);

  // ── Lifecycle / sensitivity (ADR-0181 G11-1, ADR-0183 G13-1/G13-2, ADR-0182 G12-1/G12-8) ──
  // The CONSTRUCT in get-concept-core.rq emits both an IRI and a label/level
  // for each so the descriptor can render the badge colour without re-deriving
  // anything from raw IRIs (CLOSED-scheme carve-out per ADR-0181 acceptance).
  const sensitivity = extractSensitivity(concept);
  const promotionStatus = extractLifecycleStatus(concept, 'promotionStatus', 'promotionStatusLabel', 'promotionStatusLocal');
  const reviewStatus = extractLifecycleStatus(concept, 'reviewStatus', 'reviewStatusLabel', 'reviewStatusLocal');
  const reviewedBy = field(concept, 'reviewedBy');
  const capabilityStatus = extractLifecycleStatus(concept, 'capabilityStatus', 'capabilityStatusLabel', 'capabilityStatusLocal');
  const priority = extractLifecycleStatus(concept, 'priority', 'priorityLabel', 'priorityLocal');

  // ── Cat 6 governance (ADR-0176 G6-1 + G6-3) — null when no annotations. ──
  const cat6Governance = extractGovernance(concept);

  const facets: FacetItem[] = [
    { label: 'Subject Area', values: subjectArea ? [subjectArea] : [], href: subjectAreaLocalName ? `/subject/${encodeURIComponent(subjectAreaLocalName)}` : '', iconKey: 'subjectArea' },
    { label: 'Data Classification', values: dataClassification, filter: 'dataClassification', iconKey: 'dataClassification' },
    { label: 'Lifecycle', values: lifecycle, filter: 'lifecycle', iconKey: 'lifecycle' },
    { label: 'Volatility', values: volatility, filter: 'volatility', iconKey: 'volatility' },
    { label: 'Regulatory', values: regulatoryRelevance, filter: 'regulatoryRelevance', iconKey: 'regulatoryRelevance' },
    { label: 'Governance', values: governanceTier, filter: 'governanceTier', iconKey: 'governanceTier' },
    { label: 'Value Chain', values: valueChainPositions, filter: 'valueChain', iconKey: 'valueChainPosition' },
    // ADR-0175 G5-10: hm:ufoStereotype rendered alongside facets.
    ...(ufoStereotype ? [{ label: 'UFO Stereotype', values: [ufoStereotype.label], href: ufoStereotype.href }] : []),
  ].filter(f => f.values.length > 0);

  // ── Properties (SHACL, grouped by sh:group + sh:order — extracted slice 5) ──
  const { props, groupMap, groupNames } = extractProperties(concept, graph);

  // ── Pair Constraints (ADR-0074 Phase 4) ──
  const pairConstraints: PairConstraint[] = props
    .filter((p) => p.pairType)
    .map((p) => ({
      sourceName: p.name,
      sourceTech: p.techName,
      pairType: p.pairType,
      targetName: p.pairPropertyName || p.pairProperty,
      targetTech: p.pairProperty,
    }));

  // ── Actions + Incoming Properties (extracted slice 5) ──
  const { rawActions, actionGroupMap, actionGroupNames } = extractActions(concept, graph);
  const { inProps, inGroupMap, inGroupNames } = extractIncomingProps(concept, graph);

  // ── Hierarchy + Mappings (extracted to concept-relations.ts slice 5) ──
  const { parentList, childList, roleOfList, disjointList } = extractHierarchy(concept, graph, context);
  const mappings: MappingItem[] = extractMappings(concept, graph, conceptLookup);

  // ── Relationship graph (ADR-0190): object-property + subClassOf edges. ──
  const propertyGraph = buildConceptGraph({
    context, localName: name, conceptName, props, inProps, parentList, childList,
  });

  // ── Technical ──
  const isAbstract = val(get(concept, 'abstract')) === 'true' || val(get(concept, 'dash:abstract')) === 'true';
  const labelPropRaw = field(concept, 'labelProperty') || '';
  const labelProp = labelPropRaw && labelPropRaw !== 'label' ? labelPropRaw : '';

  // ── Section tabs ──
  const hasClassification = facets.length > 0 || statusList.length > 0 || hasOntologicalProfile;
  const hasDocs = !!(definition || usage || notesList.length > 0);
  const hasProps = props.length > 0;
  const hasIncoming = inProps.length > 0;
  const hasMappings = mappings.length > 0;
  const hasProvenance = sourceSystems.length > 0 || !!temporalValidity || !!businessKey;
  const hasActions = rawActions.length > 0;
  const hasPairConstraints = pairConstraints.length > 0;
  const hasHierarchy = parentList.length > 0 || childList.length > 0 || roleOfList.length > 0 || disjointList.length > 0;
  const hasGraph = propertyGraph.links.length > 0;

  const sectionTabs: NavTab[] = [
    { id: 'relationship-graph', label: 'Graph',    href: '#section-relationship-graph', count: propertyGraph.links.length, hasData: hasGraph },
    { id: 'documentation',    label: 'Doc',        href: '#section-documentation',    hasData: hasDocs },
    { id: 'classification',   label: 'Meta',       href: '#section-classification',   hasData: hasClassification },
    { id: 'properties',       label: 'Properties', href: '#section-properties',       count: props.length,            hasData: hasProps },
    { id: 'pair-constraints', label: 'Pairs',      href: '#section-pair-constraints', count: pairConstraints.length,  hasData: hasPairConstraints, expert: true },
    { id: 'incoming',         label: 'Incoming',   href: '#section-incoming',         count: inProps.length,          hasData: hasIncoming },
    { id: 'hierarchy',        label: 'Hierarchy',  href: '#section-hierarchy',        hasData: hasHierarchy },
    { id: 'mappings',         label: 'Map',        href: '#section-mappings',         count: mappings.length,         hasData: hasMappings, expert: true },
    { id: 'provenance',       label: 'Prov',       href: '#section-provenance',       hasData: hasProvenance },
    { id: 'extraction-provenance', label: 'Extract',    href: '#section-extraction-provenance', hasData: !!extractionProvenance, expert: true },
    { id: 'coverage',         label: 'Coverage',   href: '#section-coverage',         hasData: !!coverage },
    { id: 'realizations',     label: 'Realizations', href: '#section-realizations',   hasData: realizations.length > 0 || influences.length > 0 },
    { id: 'measurement',      label: 'Measurement',  href: '#section-measurement',    hasData: kpis.length > 0 },
    { id: 'concerns',         label: 'Concerns',   href: '#section-concerns',         hasData: concerns.length > 0 || addressedBy.length > 0 },
    { id: 'privacy',          label: 'Privacy',    href: '#section-privacy',          hasData: !!privacy },
    { id: 'regulatory',       label: 'Regulatory', href: '#section-regulatory',       hasData: !!regulatory },
    { id: 'governance',       label: 'Govern',     href: '#section-governance',       hasData: !!cat6Governance },
    { id: 'operations',       label: 'Ops',        href: '#section-operations',       count: rawActions.length,       hasData: hasActions },
    { id: 'discussion',       label: 'Discuss',    href: '#section-discussion',       hasData: true },
  ];

  // ── Export links ──
  const exportLinks: ExportLink[] = [
    { format: 'JSON-LD', href: `/export/concepts/${context}/${name}.jsonld` },
    { format: 'JSON',    href: `/export/concepts/${context}/${name}.json` },
    { format: 'CSV',     href: `/export/concepts/${context}/${name}.csv` },
    { format: 'YAML',    href: `/export/concepts/${context}/${name}.yaml` },
    { format: 'XML',     href: `/export/concepts/${context}/${name}.xml` },
  ];

  return {
    conceptName,
    ctxLabel,
    accentColor,
    summary,
    definition,
    usage,
    altLabelList,
    stereotype,
    stereotypeKind,
    sourceSystems,
    notesList,
    temporalValidity,
    facets,
    statusList,
    dddStereotype,
    ontologicalType,
    rigidity,
    identityPrinciple,
    hasOntologicalProfile,
    sensitivity,
    promotionStatus,
    reviewStatus,
    reviewedBy,
    capabilityStatus,
    priority,
    governance: cat6Governance,
    ufoStereotype,
    businessKey,
    extractionProvenance,
    regulatory,
    privacy,
    coverage,
    realizations,
    influences,
    kpis,
    concerns,
    addressedBy,
    props,
    groupMap,
    groupNames,
    pairConstraints,
    rawActions,
    actionGroupMap,
    actionGroupNames,
    inProps,
    inGroupMap,
    inGroupNames,
    parentList,
    childList,
    roleOfList,
    disjointList,
    mappings,
    propertyGraph,
    isAbstract,
    labelProp,
    sectionTabs,
    exportLinks,
  };
}
