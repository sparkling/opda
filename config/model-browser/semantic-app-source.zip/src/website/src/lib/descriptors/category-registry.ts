import type { PageDescriptor } from '../page-descriptor';
import { apiFetch } from '../api';

/* ------------------------------------------------------------------ */
/*  Descriptor                                                        */
/* ------------------------------------------------------------------ */

export const categoryDescriptor: PageDescriptor = {
  entityType: 'category',
  entitySingular: 'Category',
  listEndpoint: '/categories',
  sectionClass: 'category-section',
  breadcrumbBase: { label: 'Categories', href: '/categories' },
};

/* ------------------------------------------------------------------ */
/*  Data interfaces                                                   */
/* ------------------------------------------------------------------ */

export interface CategoryRootClass {
  id: string;
  abstract: string;
}

export interface CategoryPropertyGroup {
  id: string;
  label: string;
  order: number;
}

export interface CategoryData {
  number: string;
  name: string;
  slug: string;
  description: string;
  rootClass: CategoryRootClass | null;
  propertyGroups: CategoryPropertyGroup[];
}

/* ------------------------------------------------------------------ */
/*  Mapping helpers                                                   */
/* ------------------------------------------------------------------ */

function mapRootClass(raw: Record<string, unknown> | null | undefined): CategoryRootClass | null {
  if (!raw || typeof raw !== 'object') return null;
  return {
    id: (raw['@id'] as string) || '',
    abstract: (raw['abstract'] as string) || '',
  };
}

function mapPropertyGroup(raw: Record<string, unknown>): CategoryPropertyGroup {
  return {
    id: (raw['@id'] as string) || '',
    label: (raw['label'] as string) || '',
    order: typeof raw['order'] === 'number' ? raw['order'] : 0,
  };
}

function mapItem(item: Record<string, unknown>): CategoryData {
  const groups = Array.isArray(item.propertyGroups) ? item.propertyGroups : [];
  return {
    number: (item.number as string) || '',
    name: (item.name as string) || '',
    slug: (item.slug as string) || '',
    description: (item.description as string) || '',
    rootClass: mapRootClass(item.rootClass as Record<string, unknown> | null),
    propertyGroups: groups.map((g: Record<string, unknown>) => mapPropertyGroup(g)),
  };
}

/* ------------------------------------------------------------------ */
/*  Fetch functions                                                   */
/* ------------------------------------------------------------------ */

/**
 * Fetch all categories from the API, sorted by number.
 * Returns an empty array on failure so the SSG build never crashes.
 */
export async function fetchCategories(): Promise<CategoryData[]> {
  try {
    const data = await apiFetch('/categories');
    const items: Record<string, unknown>[] = data?.items ?? [];
    return items.map(mapItem).sort((a, b) => a.number.localeCompare(b.number));
  } catch (err) {
    console.warn('[category-registry] Failed to fetch categories:', err);
    return [];
  }
}

/**
 * Fetch a single category by its URL slug.
 * Returns null when the slug is not found or the API is unreachable.
 */
export async function fetchCategoryBySlug(slug: string): Promise<CategoryData | null> {
  const categories = await fetchCategories();
  return categories.find((c) => c.slug === slug) ?? null;
}
