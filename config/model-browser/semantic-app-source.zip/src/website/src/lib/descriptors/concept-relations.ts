/**
 * Hierarchy + Mappings extraction (parent / child / roleOf / disjoint plus
 * cross-domain mappings).
 *
 * Extracted from concept.ts (slice 5) to keep concept.ts under the 500-line
 * ceiling. Public API preserved via re-exports in concept.ts.
 */
import { val, field, get, resolveRefs, localName } from '../jsonld';

/** A single hierarchy entry (parent / child / roleOf / disjointWith). */
export interface HierarchyItem {
  name: string;
  localName: string;
  ctx: string;
}

/** A single cross-domain mapping entry rendered in the Mappings section. */
export interface MappingItem {
  matchType: string;
  verb: string;
  otherName: string;
  otherLocal: string;
  otherCtx: string;
  subjectArea: string;
  subjectAreaLocal: string;
  comment: string;
}

/** Aggregate of the four hierarchy lists exposed by ConceptData. */
export interface HierarchyLists {
  parentList: HierarchyItem[];
  childList: HierarchyItem[];
  roleOfList: HierarchyItem[];
  disjointList: HierarchyItem[];
}

/** Resolve a single hierarchy edge (parent/child/roleOf/disjoint) to a HierarchyItem[]. */
function resolveHierarchy(
  concept: any,
  graph: any[],
  context: string,
  ...keys: string[]
): HierarchyItem[] {
  let refs: any = [];
  for (const k of keys) {
    const v = get(concept, k);
    if (v) { refs = v; break; }
  }
  const nodes = resolveRefs(Array.isArray(refs) ? refs : [refs], graph);
  return nodes.map((n: any) => ({
    name: field(n, 'name') || val(n['rdfs:label']) || '',
    localName: field(n, 'localName') || '',
    ctx: field(n, 'context') || context || '',
  })).filter((h) => h.name);
}

/** Build the four hierarchy lists from a concept node + JSON-LD graph. */
export function extractHierarchy(concept: any, graph: any[], context: string): HierarchyLists {
  return {
    parentList: resolveHierarchy(concept, graph, context, 'parent', 'superClass'),
    childList: resolveHierarchy(concept, graph, context, 'child'),
    roleOfList: resolveHierarchy(concept, graph, context, 'roleOf'),
    disjointList: resolveHierarchy(concept, graph, context, 'disjointWith'),
  };
}

function otherContext(m: any): string {
  return field(m, 'otherContext') || field(m, 'context') || '';
}

/**
 * Extract cross-domain mappings from a concept, joining each entry against
 * `conceptLookup` to resolve subjectArea / subjectAreaLocal / comment from
 * the other concept (used for Mapping section card metadata).
 */
export function extractMappings(
  concept: any,
  graph: any[],
  conceptLookup: Record<string, any>,
): MappingItem[] {
  const mappingRefs = get(concept, 'mappings') || get(concept, 'crossDomainMappings') || [];
  const mappingList = resolveRefs(Array.isArray(mappingRefs) ? mappingRefs : [mappingRefs], graph);
  return mappingList.map((m: any) => {
    const matchType = field(m, 'matchType') || '';
    const otherRaw = get(m, 'other');
    const otherName = field(m, 'otherName') || '';
    const otherLocal = otherRaw
      ? localName(typeof otherRaw === 'object' && otherRaw?.['@id'] ? otherRaw['@id'] : String(otherRaw))
      : '';
    const otherCtx = otherContext(m) || '';
    const verb = field(m, 'matchVerb') || matchType;
    const otherData = conceptLookup[`${otherCtx}/${otherLocal}`] || {};
    const subjectArea = otherData.subjectArea || '';
    const subjectAreaLocal = otherData.subjectAreaLocalName || '';
    const comment = otherData.comment || otherData.definition || '';
    return { matchType, verb, otherName, otherLocal, otherCtx, subjectArea, subjectAreaLocal, comment };
  });
}
