/**
 * ADR-0179 G9-5 — extraction provenance fields (PROV-O + hm: per-resource).
 *
 * Extracted from concept.ts (slice 5) to keep concept.ts under the 500-line
 * ceiling. Public API preserved via re-exports in concept.ts.
 */
import { field, localName } from '../jsonld';

/** PROV-O + hm: per-concept extraction provenance (ADR-0179 G9-5). */
export interface ExtractionProvenance {
  /** 0..1 confidence score; null when absent. */
  confidence: number | null;
  /** Source line number in the originating file. */
  lineNumber: string;
  /** Source file path or URL. */
  sourceFile: string;
  /** prov:wasGeneratedBy IRI (the extraction run). */
  generatedByIri: string;
  /** Display label for the run (rdfs:label or fallback to local-name). */
  generatedByLabel: string;
  /** prov:wasAttributedTo IRI (the agent). */
  attributedToIri: string;
  /** Display label for the agent. */
  attributedToLabel: string;
  hasAny: boolean;
}

/**
 * Extract extraction-provenance fields from a concept node. Returns null
 * when none of the PROV-O / hm: predicates are present so the caller can
 * conditionally suppress the section.
 *
 * SPARQL emits prov:wasGeneratedBy / prov:wasAttributedTo as URI+label
 * pairs; literal-typed annotation properties (confidence, lineNumber,
 * sourceFile) are passed through as strings (confidence parsed to number).
 */
export function extractExtractionProvenance(concept: any): ExtractionProvenance | null {
  const confidenceStr = field(concept, 'confidence');
  const confidence = confidenceStr ? Number(confidenceStr) : null;
  const lineNumber = field(concept, 'lineNumber');
  const sourceFile = field(concept, 'sourceFile');
  const generatedByIri = field(concept, 'wasGeneratedBy');
  const generatedByLabel = field(concept, 'wasGeneratedByLabel') || (generatedByIri ? localName(generatedByIri) : '');
  const attributedToIri = field(concept, 'wasAttributedTo');
  const attributedToLabel = field(concept, 'wasAttributedToLabel') || (attributedToIri ? localName(attributedToIri) : '');
  const hasAny = confidence !== null || !!lineNumber || !!sourceFile || !!generatedByIri || !!attributedToIri;
  if (!hasAny) return null;
  return {
    confidence: confidence !== null && !Number.isNaN(confidence) ? confidence : null,
    lineNumber,
    sourceFile,
    generatedByIri,
    generatedByLabel,
    attributedToIri,
    attributedToLabel,
    hasAny,
  };
}
