/**
 * ADR-0183 Cat 13 — Test Coverage & Verification descriptor.
 *
 * Type contracts + per-concept extractor logic, extracted from concept.ts
 * during slice 4 to keep the parent file under the 500-line ceiling.
 *
 * Also covers ADR-0182 G12-1 / G12-8 lifecycle status badges (which use the
 * same shape as Cat 13 promotion / review badges — a CLOSED-scheme tag with
 * a sub-namespace local-path keying the colour map).
 */
import { field, localName } from '../jsonld';

/** ADR-0183 G13-1 / G13-2 + ADR-0182 G12-1 / G12-8: lifecycle / status badges (CLOSED schemes). */
export interface LifecycleStatus {
  /** Full IRI of the status concept. */
  iri: string;
  /** Display label (e.g. "Validated", "In Review", "Gap", "High"). */
  label: string;
  /** Local name including sub-namespace (e.g. "promotion/Validated", "capstatus/Gap", "priority/High") — drives colour map. */
  localPath: string;
}

/** ADR-0183 G13-3: coverage section data (latest ConformanceRun for the concept). */
export interface CoverageData {
  /** /shapes/[ctx]/[localName] — when known. */
  shapeHref: string;
  shapeLabel: string;
  /** 0..1 conformance rate; null when absent. */
  rate: number | null;
  /** ISO date of the run; empty when absent. */
  runDate: string;
  /** prov:wasGeneratedBy value (IRI) on the ConformanceRun. */
  agentIri: string;
  agentLabel: string;
  /** ConformanceRun IRI for follow-up navigation. */
  runIri: string;
  hasAny: boolean;
}

/**
 * Generic CLOSED-scheme status extractor used by promotion / review /
 * capability / priority badges. Returns null when the iri field is absent.
 */
export function extractLifecycleStatus(
  concept: any,
  iriKey: string,
  labelKey: string,
  localPathKey: string,
): LifecycleStatus | null {
  const iri = field(concept, iriKey);
  if (!iri) return null;
  const label = field(concept, labelKey) || localName(iri);
  const localPath = field(concept, localPathKey) || localName(iri);
  return { iri, label, localPath };
}

/** ADR-0183 G13-3 coverage extractor — null when no ConformanceSummary targets the concept. */
export function extractCoverage(concept: any): CoverageData | null {
  const shapeIri = field(concept, 'coverageShape');
  const shapeLabel = field(concept, 'coverageShapeLabel') || (shapeIri ? localName(shapeIri) : '');
  const rateStr = field(concept, 'coverageRate');
  const rate = rateStr ? Number(rateStr) : null;
  const runDate = field(concept, 'coverageRunDate');
  const runIri = field(concept, 'coverageRunIri');
  const agentIri = field(concept, 'coverageAgentIri');
  const agentLabel = field(concept, 'coverageAgentLabel') || (agentIri ? localName(agentIri) : '');
  const hasAny = !!shapeIri || rate !== null || !!runDate || !!runIri;
  if (!hasAny) return null;
  // shapeHref: only build /shapes/[ctx]/[local] for hm.com/ns/ IRIs.
  let shapeHref = '';
  if (shapeIri && shapeIri.startsWith('https://hm.com/ns/')) {
    const rest = shapeIri.replace('https://hm.com/ns/', '');
    const parts = rest.split('/');
    if (parts.length === 1) shapeHref = `/shapes/hm/${parts[0]}`;
    else if (parts.length >= 2) shapeHref = `/shapes/${parts[0]}/${parts[parts.length - 1]}`;
  }
  return {
    shapeHref,
    shapeLabel,
    rate: rate !== null && !Number.isNaN(rate) ? rate : null,
    runDate,
    agentIri,
    agentLabel,
    runIri,
    hasAny,
  };
}
