import type { PageDescriptor } from '../page-descriptor';
import { val, field, get, findByType, resolveRefs } from '../jsonld';

/**
 * Dedupe resolved concept refs by URI. The get-subject-area query emits one
 * concept bnode per (concept × subdivision) row, so a parent area comes back
 * with duplicated concept refs (e.g. Finance: 66 rows = 22 distinct × 3).
 */
function dedupeByUri(nodes: any[]): any[] {
  const seen = new Set<string>();
  return nodes.filter((c) => {
    const key = field(c, 'uri') || field(c, 'localName') || field(c, 'name');
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

export const subjectDescriptor: PageDescriptor = {
  entityType: 'subject',
  entitySingular: 'Subject',
  listEndpoint: '/subjects',
  sectionClass: 'subject-section',
  breadcrumbBase: { label: 'Subjects', href: '/subjects' },
};

export interface SubjectData {
  saName: string;
  definition: string;
  owner: string;
  editorialNote: string;
  scopeNote: string;
  conceptCount: number;
  propertyCount: number;
  vocabCount: number;
  contextCounts: Record<string, number>;
  subdivisionList: Record<string, unknown>[];
  saContext: string;
}

export function extractSubjectData(
  data: any,
  saLocalName: string,
): SubjectData | null {
  const graph = data?.['@graph'] || (data ? [data] : []);
  const subjectArea =
    findByType(graph, 'SubjectAreaDetail', 'SubjectArea') ||
    graph.find((n: any) => n['@id'] && !n['@id'].startsWith('_:')) ||
    graph[0] ||
    null;

  if (!subjectArea) return null;

  const saName =
    field(subjectArea, 'name') ||
    val(subjectArea?.['rdfs:label']) ||
    saLocalName ||
    '';
  const definition =
    field(subjectArea, 'definition') ||
    val(subjectArea?.['skos:definition']) ||
    '';
  const owner =
    field(subjectArea, 'owner') ||
    val(subjectArea?.['hm:dataDomainOwner']) ||
    '';
  const editorialNote =
    field(subjectArea, 'editorialNote') ||
    val(subjectArea?.['skos:editorialNote']) ||
    val(subjectArea?.['hm:editorialNote']) ||
    '';
  const scopeNote =
    field(subjectArea, 'scopeNote') ||
    val(subjectArea?.['skos:scopeNote']) ||
    val(subjectArea?.['hm:scopeNote']) ||
    '';

  // Concepts -- count only (ADR-0078: no inline tables)
  const conceptRefs =
    get(subjectArea, 'concept') || get(subjectArea, 'concepts') || [];
  const conceptList = dedupeByUri(resolveRefs(conceptRefs, graph));
  const conceptCount = conceptList.length;

  // ADR-0079: Per-context concept breakdown
  const contextCounts: Record<string, number> = {};
  for (const c of conceptList) {
    const ctx = field(c, 'context') || '';
    if (ctx) contextCounts[ctx] = (contextCounts[ctx] || 0) + 1;
  }

  // Properties -- count only (ADR-0078: link to filtered listing)
  const propertyRefs =
    get(subjectArea, 'properties') || get(subjectArea, 'property') || [];
  const propertyList = resolveRefs(propertyRefs, graph);
  const propertyCount = propertyList.length;

  // Vocabularies -- count only
  const vocabRefs =
    get(subjectArea, 'vocabularies') || get(subjectArea, 'vocabulary') || [];
  const vocabList = resolveRefs(vocabRefs, graph);
  const vocabCount = vocabList.length;

  // Subdivisions
  const subRefs =
    get(subjectArea, 'subdivisions') || get(subjectArea, 'narrower') || [];
  const subdivisionList = resolveRefs(subRefs, graph);

  const saContext = field(subjectArea, 'context') || '';

  return {
    saName,
    definition,
    owner,
    editorialNote,
    scopeNote,
    conceptCount,
    propertyCount,
    vocabCount,
    contextCounts,
    subdivisionList,
    saContext,
  };
}
