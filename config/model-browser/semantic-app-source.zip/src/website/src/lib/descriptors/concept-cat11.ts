/**
 * ADR-0181 Cat 11 — Access Control & Data Sensitivity descriptor.
 *
 * Type contracts + per-concept extractor logic, extracted from concept.ts
 * during slice 4 to keep the parent file under the 500-line ceiling.
 */
import { val, field, get, localName } from '../jsonld';

/** ADR-0181 G11-1: sensitivity badge metadata (CLOSED scheme of 4 values). */
export interface SensitivityInfo {
  /** Full IRI of the sensitivity concept (e.g. `https://hm.com/ns/Confidential`). */
  iri: string;
  /** Display label (e.g. "Confidential"). */
  label: string;
  /** Lower-cased level: 'public' | 'internal' | 'confidential' | 'restricted' — drives badge colour. */
  level: string;
}

/** ADR-0181 reusable URI+label pair for SKOS-linked annotation values. */
export interface UriLabel {
  iri: string;
  label: string;
}

/** ADR-0181 G11-3..G11-7: regulatory section data (concept pages). */
export interface RegulatoryData {
  applicableRegulations: Array<{ iri: string; label: string; localName: string }>;
  processingPurpose: string;
  consentBasis: UriLabel | null;
  dataResidency: UriLabel | null;
  accessRole: UriLabel | null;
  hasAny: boolean;
}

/** ADR-0181 G11-2 + IA extension: privacy section data (concept pages and properties). */
export interface PrivacyData {
  personalDataFlag: boolean;
  personalDataCategory: UriLabel | null;
  /** Mirrored on property pages per ODR R3; on concept pages provides additional context. */
  accessRole: UriLabel | null;
  hasAny: boolean;
}

/** Read multi-valued URI+label+localName triples from a concept JSON-LD node. */
export function uriLabelList(
  concept: any,
  uriKey: string,
  labelKey: string,
  localKey?: string,
): Array<{ iri: string; label: string; localName: string }> {
  const uris = get(concept, uriKey);
  const labels = get(concept, labelKey);
  const locals = localKey ? get(concept, localKey) : null;
  if (!uris) return [];
  const uriArr = Array.isArray(uris) ? uris : [uris];
  const labelArr = Array.isArray(labels) ? labels : (labels ? [labels] : []);
  const localArr = locals ? (Array.isArray(locals) ? locals : [locals]) : [];
  return uriArr.map((u: any, i: number) => {
    const iri = val(u);
    const label = val(labelArr[i]) || val(labelArr[0]) || iri.replace(/^.*[/#]/, '');
    const local = val(localArr[i]) || val(localArr[0]) || iri.replace(/^.*[/#]/, '');
    return { iri, label, localName: local };
  }).filter((e: { iri: string }) => e.iri);
}

/** Read a single URI+label pair (UriLabel) from a concept JSON-LD node. */
export function uriLabelOne(concept: any, uriKey: string, labelKey: string): UriLabel | null {
  const iri = field(concept, uriKey);
  if (!iri) return null;
  const label = field(concept, labelKey) || localName(iri);
  return { iri, label };
}

/** ADR-0181 G11-1 sensitivity extractor — null when no hm:dataSensitivity is set. */
export function extractSensitivity(concept: any): SensitivityInfo | null {
  const iri = field(concept, 'dataSensitivity');
  if (!iri) return null;
  const label = field(concept, 'dataSensitivityLabel') || localName(iri);
  const level = field(concept, 'dataSensitivityLevel') || label.toLowerCase();
  return { iri, label, level };
}

/** ADR-0181 G11-3..G11-7 regulatory extractor — null when no regulatory annotations. */
export function extractRegulatory(concept: any): RegulatoryData | null {
  const applicableRegulations = uriLabelList(concept, 'applicableRegulation', 'applicableRegulationLabel', 'applicableRegulationLocal');
  const processingPurpose = field(concept, 'processingPurpose');
  const consentBasis = uriLabelOne(concept, 'consentBasis', 'consentBasisLabel');
  const dataResidency = uriLabelOne(concept, 'dataResidency', 'dataResidencyLabel');
  const accessRole = uriLabelOne(concept, 'accessRole', 'accessRoleLabel');
  const hasAny = applicableRegulations.length > 0 || !!processingPurpose || !!consentBasis || !!dataResidency || !!accessRole;
  if (!hasAny) return null;
  return { applicableRegulations, processingPurpose, consentBasis, dataResidency, accessRole, hasAny };
}

/** ADR-0181 G11-2 privacy extractor — null when no personal-data flag/category. */
export function extractPrivacy(concept: any): PrivacyData | null {
  const flagRaw = field(concept, 'personalDataFlag').toLowerCase();
  const personalDataFlag = flagRaw === 'true';
  const personalDataCategory = uriLabelOne(concept, 'personalDataCategory', 'personalDataCategoryLabel');
  const accessRole = uriLabelOne(concept, 'accessRole', 'accessRoleLabel');
  const hasAny = personalDataFlag || !!personalDataCategory;
  if (!hasAny) return null;
  return { personalDataFlag, personalDataCategory, accessRole, hasAny };
}
