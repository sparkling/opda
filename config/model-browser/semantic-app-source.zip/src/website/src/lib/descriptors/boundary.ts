import type { PageDescriptor } from '../page-descriptor';
import { localName as extractLocalName } from '../jsonld';

export const boundaryDescriptor: PageDescriptor = {
  entityType: 'boundary',
  entitySingular: 'Boundary',
  listEndpoint: '/bounded-contexts',
  sectionClass: 'boundary-section',
  breadcrumbBase: { label: 'Boundaries', href: '/boundaries' },
};

export interface BoundaryContext {
  name: string;
  fullName: string;
  description: string;
  namespace: string;
  badge: string;
}

export interface BoundaryPair {
  from: string;
  to: string;
  count: number;
  summary: string;
}

export interface BoundaryListData {
  contexts: BoundaryContext[];
  contextStats: Record<string, { concepts: number; properties: number; vocabs: number }>;
  pairs: BoundaryPair[];
  totalMappings: number;
  ctxFullName: Record<string, string>;
}

// SKOS match types are a closed W3C vocabulary (5 values); labels are static, not derived.
const MATCH_LABELS: Record<string, string> = {
  exactMatch: 'exact match',
  closeMatch: 'close match',
  broadMatch: 'broad match',
  narrowMatch: 'narrow match',
  relatedMatch: 'related match',
};

function matchLabel(mt: string): string {
  const ln = extractLocalName(mt || '');
  return MATCH_LABELS[ln] || ln;
}

// Non-domain bounded contexts excluded from the boundaries listing:
// the ArchiMate layers (ODR-0071d: service/capability/process/state/archimate)
// plus infrastructure/cross-cutting contexts — hm (Enterprise), meta (Governance
// Infrastructure) and pplan (Production Plan).
export const INTERNAL_BC_NOTATIONS = new Set(['archimate', 'service', 'capability', 'process', 'state', 'hm', 'meta', 'pplan']);

export function extractBoundaryListData(bcData: any, mappingsData: any): BoundaryListData {
  const bcItems = (bcData?.items || []).filter((bc: any) => !INTERNAL_BC_NOTATIONS.has(bc.notation || ''));
  const mappingItems = mappingsData?.items || [];

  const contexts: BoundaryContext[] = bcItems.map((bc: any) => ({
    name: bc.notation || '',
    fullName: bc.name || '',
    description: bc.definition || '',
    namespace: (bc.namespace || '').replace(/^Namespace:\s*/, ''),
    badge: bc.notation || '',
  }));

  const contextStats: Record<string, { concepts: number; properties: number; vocabs: number }> = {};
  for (const bc of bcItems) {
    const key = bc.notation || '';
    if (key) contextStats[key] = {
      concepts: bc.conceptCount || 0,
      properties: bc.propertyCount || 0,
      vocabs: bc.vocabCount || 0,
    };
  }

  const ctxFullName: Record<string, string> = {};
  for (const ctx of contexts) ctxFullName[ctx.name] = ctx.fullName;

  const totalMappings = mappingItems.length;
  const pairMap = new Map<string, { from: string; to: string; count: number; types: Record<string, number> }>();
  for (const item of mappingItems) {
    const src = typeof item.source === 'object' ? item.source : {};
    const tgt = typeof item.target === 'object' ? item.target : {};
    const sCtx = src.context || '';
    const tCtx = tgt.context || '';
    if (!sCtx || !tCtx) continue;
    const key = [sCtx, tCtx].sort().join('|');
    if (!pairMap.has(key)) {
      pairMap.set(key, { from: sCtx, to: tCtx, count: 0, types: {} });
    }
    const pair = pairMap.get(key)!;
    pair.count++;
    const mt = matchLabel(item.matchType || item.type || '');
    pair.types[mt] = (pair.types[mt] || 0) + 1;
  }

  const pairs: BoundaryPair[] = Array.from(pairMap.values()).map(p => ({
    from: p.from,
    to: p.to,
    count: p.count,
    summary: Object.entries(p.types).map(([t, c]) => c + ' ' + t.toLowerCase()).join(' \u00b7 '),
  }));

  return { contexts, contextStats, pairs, totalMappings, ctxFullName };
}

/* ------------------------------------------------------------------ */
/*  Boundary Detail — extract function (ADR-0160 Wave 5)              */
/* ------------------------------------------------------------------ */

export interface BoundaryDetailData {
  name: string;
  definition: string;
  namespace: string;
  prefix: string;
  conceptCount: number;
  propertyCount: number;
  vocabCount: number;
  conceptHref: string;
  propertyHref: string;
  vocabHref: string;
  /** Mappings filtered to this context, enriched with subject areas. */
  mappings: any[];
  /** JSON string for client-side mapping card rendering (ADR-0082). */
  mappingClientData: string;
  altLabels: string[];
  scopeNote: string;
  isDefinedBy: string;
  topConceptOf: string;
}

/**
 * Pure data-transformation function: takes pre-fetched API responses
 * and returns the typed data the boundary detail template needs.
 *
 * @param bc           Bounded-context object from `/bounded-contexts`
 * @param prefix       Context notation (e.g. "sds")
 * @param ctxLabels    Map of notation → display name for all contexts
 * @param counts       Pre-computed entity counts from the bounded-context API
 * @param allMappings  All mapping items from `/mappings`
 * @param conceptsData All concept items (paginated) for subject-area lookup
 */
export function extractBoundaryDetailData(
  bc: any,
  prefix: string,
  ctxLabels: Record<string, string>,
  counts: { conceptCount: number; propertyCount: number; vocabCount: number },
  allMappings: any[],
  conceptsData: any[],
): BoundaryDetailData | null {
  if (!bc) return null;

  const name = bc.name || prefix || '';
  const definition = bc.definition || '';
  const namespace = (bc.namespace || '').replace(/^Namespace:\s*/, '');

  const altLabel = bc.altLabel || '';
  const altLabels = altLabel ? [altLabel] : [];
  const scopeNote = bc.namespace || '';
  const isDefinedBy = bc.isDefinedBy || '';
  const topConceptOf = bc.topConceptOf || '';

  // Read counts directly from bounded-context API data
  const conceptCount = counts.conceptCount;
  const propertyCount = counts.propertyCount;
  const vocabCount = counts.vocabCount;

  // Filter mappings to this context
  const mappings = (allMappings || []).filter((m: any) => {
    const src = typeof m.source === 'object' ? m.source : {};
    const tgt = typeof m.target === 'object' ? m.target : {};
    return (src.context || '') === prefix || (tgt.context || '') === prefix;
  });

  // Build subject-area lookup from concept data
  const conceptSAMap: Record<string, string> = {};
  for (const c of conceptsData || []) {
    if (c.localName && c.subjectArea) {
      conceptSAMap[c.localName] = c.subjectArea;
    }
  }

  // Enrich mappings with subject area
  for (const m of mappings) {
    const src = typeof m.source === 'object' ? { ...m.source } : {};
    const tgt = typeof m.target === 'object' ? { ...m.target } : {};
    const srcLocal = src.localName || (src.uri ? extractLocalName(src.uri) : '');
    const tgtLocal = tgt.localName || (tgt.uri ? extractLocalName(tgt.uri) : '');
    if (srcLocal && conceptSAMap[srcLocal]) src.subjectArea = conceptSAMap[srcLocal];
    if (tgtLocal && conceptSAMap[tgtLocal]) tgt.subjectArea = conceptSAMap[tgtLocal];
    m.source = src;
    m.target = tgt;
  }

  // Serialize mapping data for client-side rendering
  const mappingClientData = serializeMappingClientData(mappings, ctxLabels);

  // Browse card hrefs
  const conceptHref = '/concepts?context=' + encodeURIComponent(prefix);
  const propertyHref = '/properties?context=' + encodeURIComponent(prefix);
  const vocabHref = '/vocabularies?context=' + encodeURIComponent(prefix);

  return {
    name,
    definition,
    namespace,
    prefix,
    conceptCount,
    propertyCount,
    vocabCount,
    conceptHref,
    propertyHref,
    vocabHref,
    mappings,
    mappingClientData,
    altLabels,
    scopeNote,
    isDefinedBy,
    topConceptOf,
  };
}

export interface MappingClientRecord {
  srcName: string;
  srcLocalName: string;
  srcCtx: string;
  srcSubjectArea: string;
  tgtName: string;
  tgtLocalName: string;
  tgtCtx: string;
  tgtSubjectArea: string;
  matchType: string;
  entailed: boolean;
}

/**
 * Serialize mapping data for client-side card rendering (ADR-0082).
 * Extracts source/target fields, local names, subject areas, and match type
 * into a flat JSON string that the client script parses at runtime.
 */
export function serializeMappingClientData(
  mappings: any[],
  ctxLabels: Record<string, string>,
): string {
  return JSON.stringify({
    ctxLabels: ctxLabels || {},
    mappings: mappings.map((m: any) => {
      const src = typeof m.source === 'object' ? m.source : {};
      const tgt = typeof m.target === 'object' ? m.target : {};
      const srcLocal = src.localName || (src.uri ? extractLocalName(src.uri) : '');
      const tgtLocal = tgt.localName || (tgt.uri ? extractLocalName(tgt.uri) : '');
      return {
        srcName: src.name || src.label || srcLocal,
        srcLocalName: srcLocal,
        srcCtx: src.context || '',
        srcSubjectArea: src.subjectArea || '',
        tgtName: tgt.name || tgt.label || tgtLocal,
        tgtLocalName: tgtLocal,
        tgtCtx: tgt.context || '',
        tgtSubjectArea: tgt.subjectArea || '',
        matchType: m.matchType || m.type || '',
        entailed: !!m.entailed,
      } satisfies MappingClientRecord;
    }),
  });
}
