/**
 * SHACL property extraction + grouping pipeline (sh:property → sh:group +
 * sh:order). Implements XC-11 IRI-keyed group map with label-collision
 * disambiguation per ADR-0171 §G1-8.
 *
 * Extracted from concept.ts (slice 5) to keep concept.ts under the 500-line
 * ceiling. Public API preserved via re-exports in concept.ts.
 */
import { val, field, get, iriRef, resolveRefs, localName } from '../jsonld';

const XSD_TYPES = new Set([
  'string', 'boolean', 'integer', 'decimal', 'float', 'double', 'date',
  'dateTime', 'time', 'duration', 'anyURI', 'base64Binary', 'hexBinary',
  'long', 'int', 'short', 'byte', 'nonNegativeInteger', 'positiveInteger', 'untyped',
]);

/** A single SHACL property row (post-dedupe, post-grouping). */
export interface PropRow {
  name: string; techName: string; type: string; card: string;
  required: boolean; group: string; groupIri: string; order: number; desc: string;
  editor: string; viewer: string; derived: boolean; id: string;
  isObject: boolean; severity: string;
  /** Target-class IRI ref(s) for object properties (graph view). Multiple sh:or ranges joined by '|'. Empty for datatype properties. */
  typeIri: string;
  pairType: string; pairProperty: string; pairPropertyName: string;
}

/** Aggregated property pipeline output: deduped + sorted props plus group map. */
export interface PropertiesData {
  props: PropRow[];
  groupMap: Map<string, PropRow[]>;
  groupNames: string[];
}

/** Map a raw JSON-LD property node to a PropRow. */
function rowFor(prop: any): PropRow {
  return {
    name: field(prop, 'name') || val(prop['rdfs:label']) || prop['@id'] || '',
    techName: field(prop, 'technicalName') || '',
    id: prop['@id'] || '',
    type: field(prop, 'type') || '',
    card: field(prop, 'cardinality') || '',
    required: val(get(prop, 'required')) === 'true',
    group: field(prop, 'propertyGroup') || field(prop, 'group') || '',
    groupIri: field(prop, 'propertyGroupIri') || '',
    order: parseInt(field(prop, 'order') || '999', 10),
    desc: field(prop, 'description') || '',
    editor: field(prop, 'editorWidget') || field(prop, 'editor') || '',
    viewer: field(prop, 'viewerWidget') || field(prop, 'viewer') || '',
    derived: val(get(prop, 'derived')) === 'true',
    isObject: !XSD_TYPES.has(field(prop, 'type') || ''),
    typeIri: iriRef(prop, 'typeIri'),
    severity: field(prop, 'severity') || '',
    pairType: field(prop, 'pairType') || '',
    pairProperty: field(prop, 'pairProperty') || '',
    pairPropertyName: field(prop, 'pairPropertyName') || '',
  };
}

/** Deduplicate raw props by techName/name/id, merging multi-class ranges into a `|`-joined type. */
function dedupe(rawProps: PropRow[]): PropRow[] {
  const propMap = new Map<string, PropRow & { _types: Set<string>; _typeIris: Set<string> }>();
  for (const p of rawProps) {
    const key = p.techName || p.name || p.id;
    if (propMap.has(key)) {
      const existing = propMap.get(key)!;
      if (p.type && !existing._types.has(p.type)) {
        existing._types.add(p.type);
        existing.type = Array.from(existing._types).join(' | ');
      }
      if (p.typeIri && !existing._typeIris.has(p.typeIri)) {
        existing._typeIris.add(p.typeIri);
        existing.typeIri = Array.from(existing._typeIris).join('|');
      }
      if (!existing.required && p.required) existing.required = true;
      if (!existing.desc && p.desc) existing.desc = p.desc;
      if (!existing.editor && p.editor) existing.editor = p.editor;
      if (!existing.viewer && p.viewer) existing.viewer = p.viewer;
      if (!existing.severity && p.severity) existing.severity = p.severity;
    } else {
      propMap.set(key, {
        ...p,
        _types: new Set(p.type ? [p.type] : []),
        _typeIris: new Set(p.typeIri ? [p.typeIri] : []),
      });
    }
  }
  return Array.from(propMap.values())
    .map(({ _types, _typeIris, ...rest }) => rest)
    .sort((a, b) => a.order - b.order);
}

/**
 * Build the IRI-keyed group map (XC-11): two distinct sh:groups sharing the
 * same rdfs:label do NOT collapse into one bucket. Collisions are
 * disambiguated by suffixing with the IRI's local-name fragment. Display key
 * (the label) is preserved as the map key for GroupedPropertySection
 * rendering compatibility.
 */
function groupProps(props: PropRow[]): { groupMap: Map<string, PropRow[]>; groupNames: string[] } {
  const groupMap = new Map<string, PropRow[]>();
  const iriToKey = new Map<string, string>();
  const labelToFirstIri = new Map<string, string>();
  for (const p of props) {
    const baseLabel = p.group || 'Other';
    let displayKey = baseLabel;
    if (p.groupIri) {
      if (iriToKey.has(p.groupIri)) {
        displayKey = iriToKey.get(p.groupIri)!;
      } else {
        const firstIriForLabel = labelToFirstIri.get(baseLabel);
        if (firstIriForLabel && firstIriForLabel !== p.groupIri) {
          displayKey = `${baseLabel} (${localName(p.groupIri)})`;
        } else {
          labelToFirstIri.set(baseLabel, p.groupIri);
        }
        iriToKey.set(p.groupIri, displayKey);
      }
    }
    if (!groupMap.has(displayKey)) groupMap.set(displayKey, []);
    groupMap.get(displayKey)!.push(p);
  }
  const groupNames = Array.from(groupMap.keys()).sort((a, b) => {
    if (a === 'Other') return 1;
    if (b === 'Other') return -1;
    return a.localeCompare(b);
  });
  return { groupMap, groupNames };
}

/** Extract the full SHACL-property pipeline for a concept node. */
export function extractProperties(concept: any, graph: any[]): PropertiesData {
  const propRefs = get(concept, 'property') || [];
  const propList = resolveRefs(propRefs, graph);
  const rawProps: PropRow[] = propList.map(rowFor);
  const props = dedupe(rawProps);
  const { groupMap, groupNames } = groupProps(props);
  return { props, groupMap, groupNames };
}
