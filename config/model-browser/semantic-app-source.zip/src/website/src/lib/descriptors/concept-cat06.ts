/**
 * ADR-0176 Cat 6 — Governance & Compliance descriptor.
 *
 * Type contract + per-concept governance extractor (14 G6-1 governance
 * properties + 2 G6-3 mandatory/recommended), extracted from concept.ts
 * during slice 4 to keep the parent file under the 500-line ceiling.
 */
import { field, localName } from '../jsonld';

/** ADR-0176 G6-1 + G6-3 governance annotations (14 + 2 properties). */
export interface GovernanceData {
  // Identity sub-group
  dataOwner: string;
  complianceContact: string;
  dataProtectionOfficer: string;
  // Lineage sub-group
  goldenSource: string;
  lineageSource: string;
  derivationLogic: string;
  dataQualityRules: string;
  // Compliance sub-group
  retentionPeriod: string;
  auditRetentionYears: string;
  legalBasis: string;
  traceabilityRequirement: string;
  // Schema Control sub-group
  changeApprovalIri: string;
  changeApprovalLabel: string;
  schemaChangeNotify: string;
  dppReadinessIri: string;
  dppReadinessLabel: string;
  /** Lower-cased local-name fragment (notassessed | inprogress | ready | approved) — drives badge colour. */
  dppReadinessLevel: string;
  mandatoryProperty: string;
  recommendedProperty: string;
  // Derived flags driving sub-group conditional rendering.
  hasIdentity: boolean;
  hasLineage: boolean;
  hasCompliance: boolean;
  hasSchemaControl: boolean;
  hasAny: boolean;
}

/**
 * ADR-0176 Cat 6 governance extractor.
 *
 * The CONSTRUCT in get-concept-core.rq emits literal-string values for the
 * 14 plain annotations, plus IRI + label pairs for the two SKOS-linked ones
 * (changeApprovalProcess, dppReadinessStatus). The boolean-ish 2 G6-3 props
 * are kept as strings so callers can distinguish absent (`""`) from
 * explicitly-false (`"false"`) without coercion ambiguity. Returns null when
 * no governance annotations are present.
 */
export function extractGovernance(concept: any): GovernanceData | null {
  const dataOwner = field(concept, 'dataOwner');
  const complianceContact = field(concept, 'complianceContact');
  const dataProtectionOfficer = field(concept, 'dataProtectionOfficer');
  const goldenSource = field(concept, 'goldenSource');
  const lineageSource = field(concept, 'lineageSource');
  const derivationLogic = field(concept, 'derivationLogic');
  const dataQualityRules = field(concept, 'dataQualityRules');
  const retentionPeriod = field(concept, 'retentionPeriod');
  const auditRetentionYears = field(concept, 'auditRetentionYears');
  const legalBasis = field(concept, 'legalBasis');
  const traceabilityRequirement = field(concept, 'traceabilityRequirement');
  const changeApprovalIri = field(concept, 'changeApprovalProcess');
  const changeApprovalLabel = field(concept, 'changeApprovalLabel') || (changeApprovalIri ? localName(changeApprovalIri) : '');
  const schemaChangeNotify = field(concept, 'schemaChangeNotify');
  const dppReadinessIri = field(concept, 'dppReadinessStatus');
  const dppReadinessLabel = field(concept, 'dppReadinessLabel') || (dppReadinessIri ? localName(dppReadinessIri) : '');
  const dppReadinessLevel = (field(concept, 'dppReadinessLocal') || dppReadinessLabel).toLowerCase();
  const mandatoryProperty = field(concept, 'mandatoryProperty');
  const recommendedProperty = field(concept, 'recommendedProperty');

  const hasIdentity = !!(dataOwner || complianceContact || dataProtectionOfficer);
  const hasLineage = !!(goldenSource || lineageSource || derivationLogic || dataQualityRules);
  const hasCompliance = !!(retentionPeriod || auditRetentionYears || legalBasis || traceabilityRequirement);
  const hasSchemaControl = !!(changeApprovalIri || schemaChangeNotify || dppReadinessIri || mandatoryProperty || recommendedProperty);
  const hasAny = hasIdentity || hasLineage || hasCompliance || hasSchemaControl;
  if (!hasAny) return null;
  return {
    dataOwner, complianceContact, dataProtectionOfficer,
    goldenSource, lineageSource, derivationLogic, dataQualityRules,
    retentionPeriod, auditRetentionYears, legalBasis, traceabilityRequirement,
    changeApprovalIri, changeApprovalLabel, schemaChangeNotify,
    dppReadinessIri, dppReadinessLabel, dppReadinessLevel,
    mandatoryProperty, recommendedProperty,
    hasIdentity, hasLineage, hasCompliance, hasSchemaControl, hasAny,
  };
}
