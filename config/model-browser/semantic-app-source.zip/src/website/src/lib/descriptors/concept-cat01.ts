/**
 * ADR-0171 G1-4 — Ontological Profile sub-block (DDD stereotype, ontological
 * type, rigidity, identity principle).
 *
 * Extracted from concept.ts (slice 5) to keep concept.ts under the 500-line
 * ceiling. Public API preserved via re-exports in concept.ts.
 */
import { field } from '../jsonld';

/** A single ontological-profile entry rendered in ClassificationSection. */
export interface OntologicalProfileItem {
  label: string;
  /** /vocabularies/hm/<SchemeName>/<localName> per ODR §R7. Empty when no scheme link is available. */
  href: string;
  /** BFO super-category for UFO-fine sortals (per ODR §R7 skos:broader walk); null otherwise. */
  broader: { label: string; href: string } | null;
}

/** Aggregate of the four ontological-profile predicates surfaced on a concept. */
export interface OntologicalProfile {
  dddStereotype: OntologicalProfileItem | null;
  ontologicalType: OntologicalProfileItem | null;
  rigidity: OntologicalProfileItem | null;
  identityPrinciple: OntologicalProfileItem | null;
  hasOntologicalProfile: boolean;
}

/**
 * Build a single OntologicalProfileItem from a labelKey + localKey + schemeKey
 * triple of CONSTRUCT bindings. Each predicate has its own scheme; href is
 * built from `?<key>SchemeLocal` + `?<key>Local` projections per ADR-0171
 * §G1-4 (no string-manipulation of predicate IRIs).
 *
 * Returns null when the OPTIONAL skos:inScheme join did not resolve — for
 * example when the mapper still emits literals (now resolved per slice 4
 * Phase A for dddStereotype + rigidity).
 */
function ontProfileItem(
  concept: any,
  labelKey: string,
  localKey: string,
  schemeKey: string,
): OntologicalProfileItem | null {
  const label = field(concept, labelKey);
  const local = field(concept, localKey);
  const scheme = field(concept, schemeKey);
  if (!label || !local || !scheme) return null;
  return {
    label,
    href: `/vocabularies/hm/${scheme}/${local}`,
    broader: null,
  };
}

/**
 * Extract the full ontological profile from a concept node. Walks the four
 * G1-4 predicates and (for ontologicalType) the BFO `skos:broader` chain
 * per ODR §R7.
 */
export function extractOntologicalProfile(concept: any): OntologicalProfile {
  const ontologicalType = (() => {
    const item = ontProfileItem(concept, 'ontologicalType', 'ontologicalTypeLocal', 'ontologicalTypeScheme');
    if (!item) return null;
    const broaderLabel = field(concept, 'ontologicalTypeBroader');
    const broaderLocal = field(concept, 'ontologicalTypeBroaderLocal');
    const broaderScheme = field(concept, 'ontologicalTypeBroaderScheme');
    if (broaderLabel && broaderLocal && broaderScheme) {
      item.broader = { label: broaderLabel, href: `/vocabularies/hm/${broaderScheme}/${broaderLocal}` };
    }
    return item;
  })();
  const dddStereotype = ontProfileItem(concept, 'dddStereotype', 'dddStereotypeLocal', 'dddStereotypeScheme');
  const rigidity = ontProfileItem(concept, 'rigidity', 'rigidityLocal', 'rigidityScheme');
  const identityPrinciple = ontProfileItem(concept, 'identityPrinciple', 'identityPrincipleLocal', 'identityPrincipleScheme');
  const hasOntologicalProfile = !!(dddStereotype || ontologicalType || rigidity || identityPrinciple);
  return { dddStereotype, ontologicalType, rigidity, identityPrinciple, hasOntologicalProfile };
}
