export interface Badge {
  label: string;
  class: string;
}

export interface BreadcrumbSegment {
  label: string;
  href?: string;
}

export interface NavTab {
  id: string;
  label: string;
  href: string;
  count?: number;
  hasData: boolean;
  expert?: boolean;
}

export interface ExportLink {
  format: string;
  href: string;
}

export interface PageDescriptor {
  entityType: string;
  entitySingular: string;
  listEndpoint: string;
  sectionClass: string;
  breadcrumbBase: BreadcrumbSegment;
  showNavFilter?: boolean;
  filterSelector?: string;
}
