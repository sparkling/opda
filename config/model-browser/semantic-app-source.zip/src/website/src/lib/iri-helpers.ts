/**
 * IRI routing helpers for broken-link prevention.
 *
 * ADR-0173 §G3-6 / §G3-7 (and ADR-0174 §G4-6) require that domain/range/target
 * sections render external-namespace IRIs without producing broken concept-page
 * or property-page links. Until XC-5 stub pages exist for non-`hm:` namespaces,
 * external IRIs render as unlinked CURIEs.
 *
 * Local namespaces are HM-controlled and have first-class browser pages:
 *   - `hm:` (https://hm.com/ns/)
 *   - `pf:`, `sds:`, `common:`, `pplan:`, `meta:`, etc. — all sub-paths of hm:
 *   - `archimate:` per ONT-0071d (Cat 4 — first-class browser surface)
 *
 * External namespaces (return null route, render as text):
 *   - `bbo:` (BPMN-Based Ontology — Cat 3)
 *   - `prov:`, `time:`, `dpv:`, `dcterms:`/`dct:`, `dcat:`, `odrl:`, `semapv:`, etc.
 *   - `rdfs:`, `owl:`, `rdf:`, `xsd:`, `sh:`, `dash:`, `skos:` — vocabularies, no class pages
 */

const HM_BASE = 'https://hm.com/ns/';

/**
 * Local IRI prefixes that resolve to first-class concept/property pages.
 * - HM_BASE prefix covers hm:, pf:, sds:, common:, pplan:, meta:, etc.
 * - archimate: is local per ONT-0071d (Cat 4 ratification).
 */
const LOCAL_PREFIXES = [
  HM_BASE,
  'http://www.opengroup.org/xsd/archimate/3.0/', // archimate:
];

const COMMON_PREFIX_TO_FULL: Record<string, string> = {
  hm: HM_BASE,
  pf: HM_BASE + 'pf/',
  sds: HM_BASE + 'sds/',
  common: HM_BASE + 'common/',
  pplan: HM_BASE + 'pplan/',
  meta: HM_BASE + 'meta/',
  laika: HM_BASE + 'laika/',
  archimate: 'http://www.opengroup.org/xsd/archimate/3.0/',
  bbo: 'http://bbo.com/bbo#',
  prov: 'http://www.w3.org/ns/prov#',
  time: 'http://www.w3.org/2006/time#',
  dpv: 'https://w3id.org/dpv#',
  dct: 'http://purl.org/dc/terms/',
  dcterms: 'http://purl.org/dc/terms/',
  dcat: 'http://www.w3.org/ns/dcat#',
  odrl: 'http://www.w3.org/ns/odrl/2/',
  semapv: 'https://w3id.org/semapv/vocab/',
  sssom: 'https://w3id.org/sssom/',
  rdfs: 'http://www.w3.org/2000/01/rdf-schema#',
  owl: 'http://www.w3.org/2002/07/owl#',
  rdf: 'http://www.w3.org/1999/02/22-rdf-syntax-ns#',
  xsd: 'http://www.w3.org/2001/XMLSchema#',
  sh: 'http://www.w3.org/ns/shacl#',
  dash: 'http://datashapes.org/dash#',
  skos: 'http://www.w3.org/2004/02/skos/core#',
};

/** Expand a CURIE (`pf:Article`) to a full IRI when prefix is known; pass through full IRIs. */
export function expandCurie(iriOrCurie: string): string {
  if (!iriOrCurie) return '';
  if (iriOrCurie.startsWith('http://') || iriOrCurie.startsWith('https://')) return iriOrCurie;
  const colonIdx = iriOrCurie.indexOf(':');
  if (colonIdx <= 0) return iriOrCurie;
  const prefix = iriOrCurie.slice(0, colonIdx);
  const rest = iriOrCurie.slice(colonIdx + 1);
  const base = COMMON_PREFIX_TO_FULL[prefix];
  return base ? base + rest : iriOrCurie;
}

/** True when the IRI (full or CURIE) belongs to a local browser namespace. */
export function isLocalIri(iriOrCurie: string): boolean {
  const full = expandCurie(iriOrCurie);
  return LOCAL_PREFIXES.some(p => full.startsWith(p));
}

/** True when the IRI belongs to an external (non-browser) namespace. */
export function isExternalIri(iriOrCurie: string): boolean {
  if (!iriOrCurie) return false;
  return !isLocalIri(iriOrCurie);
}

/**
 * Compute a CURIE display form for an IRI when the prefix is known.
 * Falls back to the local-name only when no known prefix matches.
 */
export function curieFor(iriOrCurie: string): string {
  if (!iriOrCurie) return '';
  // Already CURIE-shaped (no scheme): return as-is when prefix is known.
  if (!iriOrCurie.startsWith('http://') && !iriOrCurie.startsWith('https://')) {
    const colonIdx = iriOrCurie.indexOf(':');
    if (colonIdx > 0 && COMMON_PREFIX_TO_FULL[iriOrCurie.slice(0, colonIdx)]) {
      return iriOrCurie;
    }
  }
  const full = iriOrCurie.startsWith('http') ? iriOrCurie : expandCurie(iriOrCurie);
  // Find the longest matching prefix.
  let best: { prefix: string; base: string } | null = null;
  for (const [prefix, base] of Object.entries(COMMON_PREFIX_TO_FULL)) {
    if (full.startsWith(base) && (!best || base.length > best.base.length)) {
      best = { prefix, base };
    }
  }
  if (!best) {
    // Fallback to local name without a prefix (legacy display behaviour).
    const hash = full.lastIndexOf('#');
    if (hash >= 0) return full.slice(hash + 1);
    const slash = full.lastIndexOf('/');
    if (slash >= 0) return full.slice(slash + 1);
    return full;
  }
  return `${best.prefix}:${full.slice(best.base.length)}`;
}

/**
 * Resolve a class IRI to its concept-page route, or `null` for external IRIs.
 *
 * Local IRIs return `/concepts/{context}/{localName}` where context is the
 * sub-namespace path component (e.g. `pf` for `pf:Article`).
 * External IRIs return `null` — callers must render text, not a link.
 *
 * Used by ShapeTargetSection (sh:targetClass), PropertyConstraintSection
 * (sh:class value restrictions), and PropertyDomainSection / PropertyRangeSection.
 */
export function resolveClassRoute(iriOrCurie: string): string | null {
  if (!iriOrCurie) return null;
  const full = expandCurie(iriOrCurie);
  if (!isLocalIri(full)) return null;
  // Strip the longest matching local base.
  for (const base of LOCAL_PREFIXES) {
    if (full.startsWith(base)) {
      const rest = full.slice(base.length);
      // archimate: namespace has no sub-context (rest is just the local name).
      if (base !== HM_BASE) {
        // Treat as a single-segment route with context = base prefix label.
        const ctx = base.includes('archimate') ? 'archimate' : '';
        return ctx && rest ? `/concepts/${ctx}/${rest}` : null;
      }
      // hm:-derived routes use the first path component as the context.
      const slash = rest.indexOf('/');
      if (slash < 0) {
        // Bare hm:LocalName — the canonical browser route uses the implicit
        // hm context. Surface as /concepts/hm/LocalName so static-paths can
        // resolve it; the existing route pattern accepts this form.
        return `/concepts/hm/${rest}`;
      }
      const ctx = rest.slice(0, slash);
      const local = rest.slice(slash + 1);
      return ctx && local ? `/concepts/${ctx}/${local}` : null;
    }
  }
  return null;
}

/**
 * Resolve a property IRI to its property-page route, or `null` for external IRIs.
 * Mirrors `resolveClassRoute` semantics for `/properties/...` instead of `/concepts/...`.
 *
 * Used by PropertyConstraintSection (sh:path BBO property references).
 */
export function resolvePropertyRoute(iriOrCurie: string): string | null {
  if (!iriOrCurie) return null;
  const full = expandCurie(iriOrCurie);
  if (!isLocalIri(full)) return null;
  for (const base of LOCAL_PREFIXES) {
    if (full.startsWith(base)) {
      const rest = full.slice(base.length);
      if (base !== HM_BASE) {
        const ctx = base.includes('archimate') ? 'archimate' : '';
        return ctx && rest ? `/properties/${ctx}/${rest}` : null;
      }
      const slash = rest.indexOf('/');
      if (slash < 0) {
        return `/properties/hm/${rest}`;
      }
      const ctx = rest.slice(0, slash);
      const local = rest.slice(slash + 1);
      return ctx && local ? `/properties/${ctx}/${local}` : null;
    }
  }
  return null;
}
