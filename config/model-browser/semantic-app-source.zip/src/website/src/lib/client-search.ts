/**
 * MiniSearch initialization from materialized arrays.
 */
import MiniSearch from 'minisearch';
import type { MaterializedConcept, MaterializedProperty, MaterializedVocabulary, MaterializedShape } from './materialize';

export interface SearchableItem {
  id: string;
  name: string;
  context: string;
  type: 'concept' | 'property' | 'vocabulary' | 'shape';
  definition: string;
  comment: string;
  altLabels: string;
  uri: string;
  subjectArea?: string;
}

export function buildSearchIndex(
  concepts: MaterializedConcept[],
  properties: MaterializedProperty[],
  vocabularies: MaterializedVocabulary[],
  shapes: MaterializedShape[],
): MiniSearch<SearchableItem> {
  const index = new MiniSearch<SearchableItem>({
    fields: ['name', 'definition', 'altLabels', 'comment'],
    storeFields: ['name', 'context', 'subjectArea', 'type', 'definition', 'uri', 'id'],
    searchOptions: {
      boost: { name: 3, altLabels: 2, definition: 1, comment: 0.5 },
      prefix: true,
      fuzzy: 0.2,
    },
  });

  const items: SearchableItem[] = [
    ...concepts.map(c => ({
      id: c.id,
      name: c.name,
      context: c.context,
      type: 'concept' as const,
      definition: c.definition,
      comment: c.comment,
      altLabels: c.altLabels.join(' '),
      uri: c.uri,
      subjectArea: c.subjectArea,
    })),
    ...properties.map(p => ({
      id: p.id,
      name: p.name,
      context: p.context,
      type: 'property' as const,
      definition: p.definition,
      comment: p.comment,
      altLabels: p.altLabels.join(' '),
      uri: p.uri,
      subjectArea: p.subjectArea,
    })),
    ...vocabularies.map(e => ({
      id: e.id,
      name: e.name,
      context: e.context,
      type: 'vocabulary' as const,
      definition: e.definition,
      comment: '',
      altLabels: '',
      uri: e.uri,
      subjectArea: e.subjectArea,
    })),
    ...shapes.map(s => ({
      id: s.id,
      name: s.name,
      context: s.context,
      type: 'shape' as const,
      definition: s.definition,
      comment: s.comment,
      altLabels: '',
      uri: s.uri,
    })),
  ];

  // Deduplicate: learning pipeline TTL can produce entities that appear in
  // multiple categories (e.g. owl:Class + sh:NodeShape) sharing the same id.
  const seen = new Set<string>();
  const unique = items.filter(item => {
    if (seen.has(item.id)) return false;
    seen.add(item.id);
    return true;
  });

  index.addAll(unique);
  return index;
}
