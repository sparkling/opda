/**
 * Client-side detail page rendering for run-scoped entities.
 * Counterpart to client-app.ts (listings) — renders concept/property/vocabulary
 * detail pages from the N3 RDF store.
 */
import { getStore } from './rdf-store';
import { materialize } from './materialize';
import type { ConceptDetail, MaterializedProperty, MaterializedVocabulary, MaterializedData } from './materialize';
import { facetTagHtml } from './client-render';
import { pillClass } from './pill-colours';
import { badgeColorForCategory } from './accent-color';
import { Store, DataFactory } from 'n3';

const { namedNode } = DataFactory;
const skosIri = {
  prefLabel: namedNode('http://www.w3.org/2004/02/skos/core#prefLabel'),
  definition: namedNode('http://www.w3.org/2004/02/skos/core#definition'),
  hasTopConcept: namedNode('http://www.w3.org/2004/02/skos/core#hasTopConcept'),
  notation: namedNode('http://www.w3.org/2004/02/skos/core#notation'),
  inScheme: namedNode('http://www.w3.org/2004/02/skos/core#inScheme'),
};

const runBasePath: string = (window as any).__hmRunScope?.basePath || '';
const SINGULAR: Record<string, string> = {
  concepts: 'concept', properties: 'property', vocabularies: 'vocabulary',
};

let data: MaterializedData | null = null;
let rdfStore: Store | null = null;

/**
 * Initialise a detail page: fetch store, materialise, render into #detail-content.
 * @param path — the full catch-all path, e.g. "hm/pplan-planproductdomain/SomeClass".
 *               This directly matches the entity `id` in materialized data.
 */
export async function initDetail(
  entityType: 'concepts' | 'properties' | 'vocabularies',
  path: string,
): Promise<void> {
  const container = document.getElementById('detail-content');
  if (!container) return;

  rdfStore = await getStore();
  data = materialize(rdfStore);

  let html: string;
  if (entityType === 'concepts') {
    const detail = data.conceptDetails.get(path);
    html = detail ? renderConceptDetail(detail, data) : notFoundHtml(entityType, path);
  } else if (entityType === 'properties') {
    const prop = data.properties.find(p => p.id === path);
    html = prop ? renderPropertyDetail(prop, data) : notFoundHtml(entityType, path);
  } else {
    const vocab = data.vocabularies.find(e => e.id === path);
    html = vocab ? renderVocabularyDetail(vocab) : notFoundHtml(entityType, path);
  }

  container.innerHTML = html;
}

// ── Concept Detail ──────────────────────────────────────────────────────────

function renderConceptDetail(detail: ConceptDetail, data: MaterializedData): string {
  const parts: string[] = [];

  // Back link
  parts.push(backLink('concepts'));

  // Hero
  const ctxLabel = data.contextLabels[detail.context] || detail.context;
  const stereo = detail.stereotype && detail.stereotype !== 'Kind'
    ? `<span class="inline-block rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-600">${esc(detail.stereotype)}</span>` : '';
  const altLabels = detail.altLabels.length > 0
    ? `<p class="mt-1 text-sm text-gray-500">${detail.altLabels.map(esc).join(', ')}</p>` : '';

  parts.push(`<div class="mb-8">
    <div class="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-gray-400">${esc(ctxLabel)}</div>
    <div class="mt-1 flex items-center gap-3">
      <h1 class="text-2xl font-bold tracking-tight text-gray-900 sm:text-3xl">${esc(detail.name)}</h1>
      ${stereo}
    </div>
    ${altLabels}
    <div class="mt-2">${uriRefHtml(detail.context, detail.localName)}</div>
  </div>`);

  // Documentation (ODR-0011 four-tier)
  const docItems: string[] = [];
  if (detail.definition) {
    docItems.push(`<div class="rounded-lg border-l-4 border-blue-400 bg-blue-50/50 p-4">
      <p class="text-sm font-medium text-blue-900">Definition</p>
      <p class="mt-1 text-sm text-blue-800">${esc(detail.definition)}</p>
    </div>`);
  }
  if (detail.comment && detail.comment !== detail.definition) {
    docItems.push(`<div class="rounded-lg border-l-4 border-gray-300 bg-gray-50 p-4">
      <p class="text-sm font-medium text-gray-700">Comment</p>
      <p class="mt-1 text-sm text-gray-600">${esc(detail.comment)}</p>
    </div>`);
  }
  for (const n of detail.scopeNotes) {
    docItems.push(`<div class="rounded-lg border-l-4 border-amber-400 bg-amber-50/50 p-4">
      <p class="text-sm font-medium text-amber-900">Usage Note</p>
      <p class="mt-1 text-sm text-amber-800">${esc(n)}</p>
    </div>`);
  }
  if (detail.editorialNotes.length > 0) {
    docItems.push(`<details class="rounded-lg border border-gray-200 bg-white">
      <summary class="cursor-pointer px-4 py-3 text-sm font-medium text-gray-700">Editorial Notes (${detail.editorialNotes.length})</summary>
      <div class="border-t border-gray-100 px-4 py-3 space-y-2">
        ${detail.editorialNotes.map(n => `<p class="text-sm text-gray-600">${esc(n)}</p>`).join('')}
      </div>
    </details>`);
  }
  if (docItems.length === 0) {
    docItems.push('<p class="text-sm italic text-gray-400">No documentation available</p>');
  }
  parts.push(sectionCard('Documentation', docItems.join('<div class="mt-3"></div>')));

  // Classification (ODR-0010 seven facets)
  const facets = [
    { key: 'subjectArea', label: 'Subject Area', value: detail.subjectArea },
    { key: 'dataClassification', label: 'Data Classification', value: detail.dataClassification },
    { key: 'lifecycle', label: 'Lifecycle Stage', value: detail.lifecycle },
    { key: 'volatility', label: 'Volatility', value: detail.volatility },
    { key: 'regulatoryRelevance', label: 'Regulatory Relevance', value: detail.regulatoryRelevance },
    { key: 'governanceTier', label: 'Governance Tier', value: detail.governanceTier },
    { key: 'valueChainPosition', label: 'Value Chain', value: detail.valueChainPosition },
  ];
  const facetHtml = facets.map(f => facetTagHtml(f.key, f.label, f.value, { filterable: false })).join('');
  parts.push(sectionCard('Classification', `<div class="flex flex-wrap gap-3">${facetHtml}</div>`));

  // Properties (filtered by rdfs:domain pointing to this concept)
  const conceptProps = data.properties.filter(p =>
    p.domainLinks.some(d => d.context === detail.context && d.localName === detail.localName)
  );
  if (conceptProps.length > 0) {
    const propCards = conceptProps
      .sort((a, b) => a.name.localeCompare(b.name))
      .map(p => propertyRow(p))
      .join('');
    parts.push(sectionCard('Properties', `<div class="space-y-2">${propCards}</div>`, `${conceptProps.length}`));
  }

  // Hierarchy (parents + children)
  if (detail.parents.length > 0 || detail.children.length > 0) {
    const hierParts: string[] = [];
    if (detail.parents.length > 0) {
      hierParts.push(`<div>
        <h4 class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">Parent classes</h4>
        <div class="flex flex-wrap gap-2">${detail.parents.map(conceptChip).join('')}</div>
      </div>`);
    }
    if (detail.children.length > 0) {
      const shown = detail.children.slice(0, 12);
      const extra = detail.children.length - shown.length;
      let childHtml = `<div class="flex flex-wrap gap-2">${shown.map(conceptChip).join('')}</div>`;
      if (extra > 0) {
        childHtml = `<details>
          <summary class="cursor-pointer text-sm text-blue-600 hover:text-blue-800 mb-2">Show all ${detail.children.length} subclasses</summary>
          <div class="flex flex-wrap gap-2">${detail.children.map(conceptChip).join('')}</div>
        </details>`;
      }
      hierParts.push(`<div>
        <h4 class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">Subclasses</h4>
        ${childHtml}
      </div>`);
    }
    parts.push(sectionCard('Hierarchy', hierParts.join('<div class="mt-4"></div>')));
  }

  return `<div class="space-y-6">${parts.join('')}</div>`;
}

// ── Property Detail ─────────────────────────────────────────────────────────

function renderPropertyDetail(prop: MaterializedProperty, _data: MaterializedData): string {
  const parts: string[] = [];

  parts.push(backLink('properties'));

  // Hero
  const typeBadge = prop.type === 'ObjectProperty'
    ? '<span class="inline-block rounded-full bg-indigo-100 px-2.5 py-0.5 text-xs font-medium text-indigo-700">Object Property</span>'
    : '<span class="inline-block rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-medium text-amber-700">Datatype Property</span>';
  const altLabels = prop.altLabels.length > 0
    ? `<p class="mt-1 text-sm text-gray-500">${prop.altLabels.map(esc).join(', ')}</p>` : '';

  parts.push(`<div class="mb-8">
    <div class="mt-1 flex items-center gap-3">
      <h1 class="text-2xl font-bold tracking-tight text-gray-900 sm:text-3xl">${esc(sentenceCase(prop.name))}</h1>
      ${typeBadge}
    </div>
    ${altLabels}
    <div class="mt-2">${uriRefHtml(prop.context, prop.localName)}</div>
  </div>`);

  // Documentation
  const docItems: string[] = [];
  if (prop.definition) {
    docItems.push(`<div class="rounded-lg border-l-4 border-blue-400 bg-blue-50/50 p-4">
      <p class="text-sm font-medium text-blue-900">Definition</p>
      <p class="mt-1 text-sm text-blue-800">${esc(prop.definition)}</p>
    </div>`);
  }
  if (prop.comment && prop.comment !== prop.definition) {
    docItems.push(`<div class="rounded-lg border-l-4 border-gray-300 bg-gray-50 p-4">
      <p class="text-sm font-medium text-gray-700">Comment</p>
      <p class="mt-1 text-sm text-gray-600">${esc(prop.comment)}</p>
    </div>`);
  }
  if (docItems.length === 0) {
    docItems.push('<p class="text-sm italic text-gray-400">No documentation available</p>');
  }
  parts.push(sectionCard('Documentation', docItems.join('<div class="mt-3"></div>')));

  // Type Signature
  const sigItems: string[] = [];
  if (prop.domainLinks.length > 0) {
    const domHtml = prop.domainLinks.map(d =>
      d.context && d.localName
        ? `<a href="${runBasePath}/concepts/${d.context}/${d.localName}" class="text-blue-600 hover:text-blue-800 hover:underline font-medium">${esc(d.label)}</a>`
        : esc(d.label)
    ).join(' <span class="text-gray-300">|</span> ');
    sigItems.push(sigRow('Domain', domHtml));
  }
  if (prop.range) {
    const rangeHtml = prop.rangeLocalName
      ? `<a href="${runBasePath}/concepts/${prop.rangeContext || ''}/${prop.rangeLocalName}" class="text-blue-600 hover:text-blue-800 hover:underline font-medium">${esc(prop.range)}</a>`
      : `<code class="rounded bg-gray-100 px-1.5 py-0.5 font-mono text-sm">${esc(prop.range)}</code>`;
    sigItems.push(sigRow('Range', rangeHtml));
  }
  if (prop.cardinality) {
    sigItems.push(sigRow('Card.', `<code class="rounded bg-gray-100 px-1.5 py-0.5 font-mono text-sm">${esc(prop.cardinality)}</code>`));
  }
  if (sigItems.length > 0) {
    parts.push(sectionCard('Type Signature', `<div class="space-y-3">${sigItems.join('')}</div>`));
  }

  // Characteristics
  if (prop.characteristics.length > 0) {
    const CHAR_KEY: Record<string, string> = {
      'Required': 'required', 'Derived': 'derived', 'Functional': 'functional',
      'Inverse Functional': 'inverseFunctional', 'Transitive': 'transitive',
    };
    const pills = prop.characteristics.map(c =>
      `<span class="${pillClass(CHAR_KEY[c] || '')}">${esc(c)}</span>`
    ).join('');
    parts.push(sectionCard('Characteristics', `<div class="flex flex-wrap gap-2">${pills}</div>`));
  }

  return `<div class="space-y-6">${parts.join('')}</div>`;
}

// ── Vocabulary Detail ───────────────────────────────────────────────────────

function renderVocabularyDetail(vocab: MaterializedVocabulary): string {
  const parts: string[] = [];

  parts.push(backLink('vocabularies'));

  // Hero
  const st = vocab.schemeType || 'Closed';
  const typeBadge = `<span class="inline-block rounded-full px-2.5 py-0.5 text-xs font-medium ${badgeColorForCategory(st)}">${esc(st)}</span>`;
  const countText = st === 'Open-ended' ? '' : `<span class="text-sm text-gray-500">${vocab.valueCount} values</span>`;

  parts.push(`<div class="mb-8">
    <div class="mt-1 flex items-center gap-3">
      <h1 class="text-2xl font-bold tracking-tight text-gray-900 sm:text-3xl">${esc(vocab.name)}</h1>
      ${typeBadge}
      ${countText}
    </div>
    <div class="mt-2">${uriRefHtml(vocab.context, vocab.localName)}</div>
  </div>`);

  // Documentation
  if (vocab.definition) {
    parts.push(sectionCard('Documentation', `<div class="rounded-lg border-l-4 border-blue-400 bg-blue-50/50 p-4">
      <p class="text-sm font-medium text-blue-900">Definition</p>
      <p class="mt-1 text-sm text-blue-800">${esc(vocab.definition)}</p>
    </div>`));
  }

  // Members from N3 store
  if (rdfStore) {
    const schemeNode = namedNode(vocab.uri);
    const memberUris = new Set<string>();
    for (const q of rdfStore.getQuads(schemeNode, skosIri.hasTopConcept, null, null)) memberUris.add(q.object.value);
    for (const q of rdfStore.getQuads(null, skosIri.inScheme, schemeNode, null)) memberUris.add(q.subject.value);

    if (memberUris.size > 0) {
      const members = Array.from(memberUris).map(uri => {
        const node = namedNode(uri);
        const label = rdfStore!.getQuads(node, skosIri.prefLabel, null, null);
        const def = rdfStore!.getQuads(node, skosIri.definition, null, null);
        const notation = rdfStore!.getQuads(node, skosIri.notation, null, null);
        return {
          label: label.length > 0 ? label[0].object.value : extractLocalName(uri),
          definition: def.length > 0 ? def[0].object.value : '',
          notation: notation.length > 0 ? notation[0].object.value : '',
        };
      }).sort((a, b) => a.label.localeCompare(b.label));

      const hasNotation = members.some(m => m.notation);
      const rows = members.map(m => `<tr class="border-t border-gray-100">
        <td class="py-2 pr-4 text-sm font-medium text-gray-900">${esc(m.label)}</td>
        ${hasNotation ? `<td class="py-2 pr-4 text-sm text-gray-500 font-mono">${esc(m.notation)}</td>` : ''}
        <td class="py-2 text-sm text-gray-500">${esc(m.definition)}</td>
      </tr>`).join('');

      parts.push(sectionCard('Members', `<div class="overflow-x-auto">
        <table class="min-w-full">
          <thead><tr class="text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
            <th class="pb-2 pr-4">Name</th>
            ${hasNotation ? '<th class="pb-2 pr-4">Code</th>' : ''}
            <th class="pb-2">Definition</th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>`, `${members.length}`));
    }
  }

  return `<div class="space-y-6">${parts.join('')}</div>`;
}

// ── Shared rendering helpers ────────────────────────────────────────────────

function backLink(entityType: string): string {
  return `<a href="${runBasePath}/${entityType}" class="inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-blue-600 transition-colors mb-2">
    <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
      <path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
    </svg>
    Back to ${entityType}
  </a>`;
}

function notFoundHtml(entityType: string, path: string): string {
  const singular = SINGULAR[entityType] || entityType;
  return `<div class="rounded-lg border border-red-200 bg-red-50 px-6 py-16 text-center">
    <p class="text-sm font-medium text-red-800">${esc(sentenceCase(singular))} not found</p>
    <p class="mt-1 text-xs text-red-600">No ${singular} with identifier "${esc(path)}" exists in this run.</p>
    <a href="${runBasePath}/${entityType}" class="mt-4 inline-flex text-sm text-blue-600 hover:text-blue-800">Back to listing</a>
  </div>`;
}

function sectionCard(title: string, content: string, badge?: string): string {
  const badgeHtml = badge ? ` <span class="ml-2 text-xs font-normal text-gray-400">${esc(badge)}</span>` : '';
  return `<div class="rounded-lg border border-gray-200 bg-white p-6">
    <h2 class="text-lg font-semibold text-gray-900 mb-4">${esc(title)}${badgeHtml}</h2>
    ${content}
  </div>`;
}

function sigRow(label: string, valueHtml: string): string {
  return `<div class="flex items-center gap-2">
    <span class="text-xs font-semibold uppercase tracking-wider text-gray-400 w-16">${esc(label)}</span>
    <div>${valueHtml}</div>
  </div>`;
}

function propertyRow(p: MaterializedProperty): string {
  const typeBadge = p.type === 'ObjectProperty'
    ? '<span class="rounded-full bg-indigo-100 px-2 py-0.5 text-[10px] font-medium text-indigo-700">Obj</span>'
    : '<span class="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-medium text-amber-700">Data</span>';
  const rangeHtml = p.rangeLocalName
    ? `<a href="${runBasePath}/concepts/${p.rangeContext || ''}/${p.rangeLocalName}" class="text-blue-600 hover:text-blue-800 hover:underline text-sm" onclick="event.stopPropagation()">${esc(p.range)}</a>`
    : p.range ? `<code class="rounded bg-gray-100 px-1.5 py-0.5 font-mono text-xs">${esc(p.range)}</code>` : '';
  const cardHtml = p.cardinality ? `<span class="font-mono text-xs text-gray-400">${esc(p.cardinality)}</span>` : '';
  const CHAR_KEY: Record<string, string> = {
    'Required': 'required', 'Derived': 'derived', 'Functional': 'functional',
    'Inverse Functional': 'inverseFunctional', 'Transitive': 'transitive',
  };
  const chars = p.characteristics.length > 0
    ? `<div class="flex gap-1">${p.characteristics.map(c => `<span class="${pillClass(CHAR_KEY[c] || '')}">${esc(c)}</span>`).join('')}</div>` : '';

  return `<a href="${runBasePath}/properties/${p.context}/${p.localName}" class="flex items-center justify-between gap-3 rounded-lg border border-gray-100 bg-gray-50 px-4 py-3 hover:bg-white hover:border-gray-200 hover:shadow-sm transition-all">
    <div class="flex items-center gap-2 min-w-0">
      ${typeBadge}
      <span class="font-medium text-sm text-gray-900 truncate">${esc(sentenceCase(p.name))}</span>
      ${chars}
    </div>
    <div class="flex items-center gap-3 shrink-0">
      ${rangeHtml}
      ${cardHtml}
    </div>
  </a>`;
}

function conceptChip(c: { name: string; context: string; localName: string }): string {
  return `<a href="${runBasePath}/concepts/${c.context}/${c.localName}" class="inline-flex items-center gap-1.5 rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-sm font-medium text-blue-600 hover:text-blue-800 hover:border-gray-300 hover:shadow-sm transition-all">
    <span class="text-[10px] font-semibold uppercase tracking-wider text-gray-400">${esc(c.context)}</span>
    ${esc(c.name)}
  </a>`;
}

// ── Private utilities (duplicated from client-app.ts to avoid coupling) ─────

function esc(str: string): string {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function sentenceCase(s: string): string {
  if (!s) return s;
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function extractLocalName(iri: string): string {
  const hash = iri.lastIndexOf('#');
  if (hash >= 0) return iri.substring(hash + 1);
  const slash = iri.lastIndexOf('/');
  return slash >= 0 ? iri.substring(slash + 1) : iri;
}

const URI_MONO_CLS = 'font-mono text-xs text-gray-500';
const URI_BTN_CLS = 'copy-uri inline-flex items-center gap-1 shrink-0 rounded px-1.5 py-0.5 -mr-1.5 cursor-pointer hover:bg-gray-100 transition-colors';
const URI_COPY_ICON = '<svg class="copy-icon h-3.5 w-3.5 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>';
const URI_OK_ICON = '<svg class="copy-ok hidden h-3.5 w-3.5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>';

function uriRefHtml(prefix: string, localName: string): string {
  const uri = `${esc(prefix)}:${esc(localName)}`;
  return `<button type="button" class="${URI_BTN_CLS}" `
    + `data-uri="${uri}" title="Copy URI" `
    + `onclick="event.preventDefault();event.stopPropagation();navigator.clipboard.writeText(this.dataset.uri);`
    + `this.querySelector('.copy-ok').classList.remove('hidden');this.querySelector('.copy-icon').classList.add('hidden');`
    + `setTimeout(()=>{this.querySelector('.copy-ok').classList.add('hidden');this.querySelector('.copy-icon').classList.remove('hidden')},1200)">`
    + `<span class="${URI_MONO_CLS}">${uri}</span>`
    + URI_COPY_ICON + URI_OK_ICON
    + `</button>`;
}
