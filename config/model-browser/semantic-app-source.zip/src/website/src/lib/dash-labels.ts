/**
 * DASH vocabulary URI → human-readable label/icon mapping.
 * Council S110 Q3: humanize DASH widget references in property displays.
 */

const EDITOR_LABELS: Record<string, { label: string; icon: string }> = {
  'dash:TextFieldEditor':        { label: 'Text Field',     icon: 'text' },
  'dash:TextAreaEditor':         { label: 'Text Area',      icon: 'textarea' },
  'dash:TextFieldWithLangEditor':{ label: 'Text (i18n)',    icon: 'lang' },
  'dash:EnumSelectEditor':       { label: 'Enum Select',    icon: 'enum' },
  'dash:AutoCompleteEditor':     { label: 'Auto Complete',  icon: 'search' },
  'dash:BooleanSelectEditor':    { label: 'Boolean',        icon: 'toggle' },
  'dash:DatePickerEditor':       { label: 'Date Picker',    icon: 'date' },
  'dash:DateTimePickerEditor':   { label: 'DateTime Picker',icon: 'date' },
  'dash:URIEditor':              { label: 'URI',            icon: 'link' },
  'dash:InstancesSelectEditor':  { label: 'Instance Select',icon: 'search' },
  'dash:BlankNodeEditor':        { label: 'Blank Node',     icon: 'node' },
  'dash:SubClassEditor':         { label: 'SubClass',       icon: 'hierarchy' },
  'dash:RichTextEditor':         { label: 'Rich Text',      icon: 'textarea' },
};

const VIEWER_LABELS: Record<string, { label: string; icon: string }> = {
  'dash:LabelViewer':      { label: 'Label',     icon: 'label' },
  'dash:LiteralViewer':    { label: 'Literal',   icon: 'text' },
  'dash:LangStringViewer': { label: 'Lang String',icon: 'lang' },
  'dash:URIViewer':        { label: 'URI',        icon: 'link' },
  'dash:HTMLViewer':       { label: 'HTML',        icon: 'code' },
  'dash:ImageViewer':      { label: 'Image',      icon: 'image' },
  'dash:HyperlinkViewer':  { label: 'Hyperlink',  icon: 'link' },
  'dash:ValueTableViewer': { label: 'Value Table', icon: 'table' },
};

function normalize(uri: string): string {
  if (!uri) return '';
  if (uri.startsWith('dash:')) return uri;
  // Handle full URI: http://datashapes.org/dash#TextFieldEditor → dash:TextFieldEditor
  const hash = uri.lastIndexOf('#');
  if (hash >= 0) return `dash:${uri.substring(hash + 1)}`;
  const slash = uri.lastIndexOf('/');
  if (slash >= 0) return `dash:${uri.substring(slash + 1)}`;
  return uri;
}

export function editorLabel(uri: string): { label: string; icon: string } {
  const key = normalize(uri);
  return EDITOR_LABELS[key] || { label: key, icon: 'text' };
}

export function viewerLabel(uri: string): { label: string; icon: string } {
  const key = normalize(uri);
  return VIEWER_LABELS[key] || { label: key, icon: 'text' };
}
