/**
 * DOM rendering functions for listing pages, facets, pagination, and search results.
 */
import type { FacetCounts, ActiveFilters, PaginationResult } from './client-filter';
import { FACET_ICONS, FACET_COLOURS, DEFAULT_FACET_COLOUR } from './facet-icons';
import { badgeColorForContext, badgeColorForCategory } from './accent-color';

const MAX_DEF = 60;

// --- Facet Tag (button-group key/value) ---

/**
 * Renders a button-group tag: coloured key | grey value.
 * If value is empty, renders a muted "missing" state in the same colour family.
 * Optional `removable` adds an × button for active filter chips.
 */
export function facetTagHtml(
  facetKey: string,
  facetLabel: string,
  value: string,
  opts: { removable?: boolean; filterable?: boolean } = {},
): string {
  const c = FACET_COLOURS[facetKey] || DEFAULT_FACET_COLOUR;
  const fi = FACET_ICONS[facetKey];
  const iconSvg = fi ? `<svg width="10" height="10" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="shrink-0" aria-hidden="true">${fi.svg}</svg>` : '';

  // Missing/empty state — muted version of the same colour
  if (!value) {
    const kCls = `inline-flex items-center gap-1 px-2 py-1 text-[10px] font-semibold uppercase tracking-wider rounded-l border border-r-0 opacity-40 ${c.bg} ${c.text} ${c.border}`;
    const vCls = 'inline-flex items-center px-2 py-1 text-[11px] text-gray-400 italic bg-gray-50 rounded-r border border-gray-200 opacity-60';
    return `<span class="inline-flex rounded"><span class="${kCls}">${iconSvg}${escapeHtml(facetLabel)}</span><span class="${vCls}">—</span></span>`;
  }

  const kCls = `inline-flex items-center gap-1 px-2 py-1 text-[10px] font-semibold uppercase tracking-wider rounded-l border border-r-0 ${c.bg} ${c.text} ${c.border}`;
  const vCls = 'inline-flex items-center px-2 py-1 text-[11px] bg-gray-100 text-gray-700 rounded-r border border-gray-200';
  const filterAttrs = opts.filterable !== false
    ? ` data-filter-facet="${escapeHtml(facetKey)}" data-filter-value="${escapeHtml(value)}"`
    : '';
  const gCls = opts.filterable !== false
    ? 'inline-flex cursor-pointer rounded transition-all hover:shadow-sm hover:brightness-95'
    : 'inline-flex rounded';

  const removeBtn = opts.removable
    ? ` <button type="button" data-chip-key="${escapeHtml(facetKey)}" data-chip-value="${escapeHtml(value)}" class="inline-flex items-center px-1.5 py-1 text-gray-300 hover:text-gray-500 hover:bg-gray-200 rounded-r border border-l-0 border-gray-200 transition-colors" aria-label="Remove filter"><svg class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg></button>`
    : '';

  const vClsFinal = opts.removable
    ? 'inline-flex items-center px-2 py-1 text-[11px] bg-gray-100 text-gray-700 border-y border-gray-200'
    : vCls;

  return `<span class="${gCls}"${filterAttrs}><span class="${kCls}">${iconSvg}${escapeHtml(facetLabel)}</span><span class="${vClsFinal}">${escapeHtml(value)}</span>${removeBtn}</span>`;
}

// --- Facet Sidebar ---

/** Persistent page index per facet key (survives re-renders). */
const facetPageState = new Map<string, number>();

export function renderFacetSidebar(
  container: HTMLElement,
  facets: FacetCounts,
  activeFilters: ActiveFilters,
  facetLabels: Record<string, string>,
  onToggle: (key: string, value: string) => void,
  onClear: () => void,
  tier2Keys?: readonly string[],
  /** Per-facet value→label maps (e.g. context: { SDS: 'Shared Data Services' }) */
  valueLabelMaps?: Record<string, Record<string, string>>,
) {
  const hasAny = Object.values(activeFilters).some(v => v.length > 0);

  // Preserve facet search query across re-renders
  const prevInput = container.querySelector('#facet-search') as HTMLInputElement | null;
  const prevQuery = prevInput?.value || '';

  // Filter funnel icon + search input
  let html = `<div class="mb-4">
    <div class="relative">
      <svg class="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
        <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
      </svg>
      <input type="search" id="facet-search" placeholder="Filter options\u2026" class="w-full rounded-lg border border-gray-200 bg-white py-2.5 pl-10 pr-4 text-sm text-gray-900 shadow-sm placeholder-transparent focus-visible:border-blue-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 transition-shadow" />
    </div>
  </div>`;

  for (const [key, values] of Object.entries(facets)) {
    if (!values || values.length === 0) continue;
    const valueMap = valueLabelMaps?.[key];
    html += renderFacetSection(key, values, activeFilters, facetLabels, valueMap, facetPageState.get(key) || 0, !!prevQuery);
  }

  if (hasAny) {
    html += `<div class="mt-5 border-t border-gray-200 pt-4">
      <button type="button" data-action="clear-filters" class="inline-flex w-full items-center justify-center gap-1.5 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 transition-colors">
        <svg class="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
        Clear all filters
      </button>
    </div>`;
  }

  // Snapshot which facet sections the user has manually opened/closed
  const openState = new Map<string, boolean>();
  container.querySelectorAll('[data-facet-key]').forEach(div => {
    const key = (div as HTMLElement).dataset.facetKey!;
    const det = div.querySelector('details');
    if (det) openState.set(key, det.open);
  });

  container.innerHTML = html;

  // Restore user's open/closed state, but force-open facets with active filters
  container.querySelectorAll('[data-facet-key]').forEach(div => {
    const key = (div as HTMLElement).dataset.facetKey!;
    const det = div.querySelector('details');
    if (!det) return;
    const hasActive = (activeFilters[key] || []).length > 0;
    if (hasActive) {
      det.open = true;
    } else if (openState.has(key)) {
      det.open = openState.get(key)!;
    }
  });

  // Bind checkbox events
  container.querySelectorAll('input[type="checkbox"]').forEach(cb => {
    cb.addEventListener('change', () => {
      const input = cb as HTMLInputElement;
      onToggle(input.name, input.value);
    });
  });

  // Bind +/- toggle on details elements
  container.querySelectorAll('details').forEach(det => {
    const icon = det.querySelector('.facet-plus') as HTMLElement | null;
    if (!icon) return;
    const update = () => { icon.textContent = det.open ? '−' : '+'; };
    update();
    det.addEventListener('toggle', update);
  });

  const clearBtn = container.querySelector('[data-action="clear-filters"]');
  if (clearBtn) clearBtn.addEventListener('click', onClear);

  // Bind facet pager buttons — re-render just the affected section in place
  container.querySelectorAll('[data-facet-pager]').forEach(pager => {
    const section = pager.closest('[data-facet-key]') as HTMLElement;
    if (!section) return;
    const key = section.dataset.facetKey!;
    pager.querySelectorAll('button[data-pager-action]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const cur = parseInt(section.dataset.facetPage || '0', 10);
        const total = parseInt(section.dataset.facetTotal || '1', 10);
        const action = (btn as HTMLElement).dataset.pagerAction;
        let next = cur;
        if (action === 'first') next = 0;
        else if (action === 'prev') next = Math.max(0, cur - 1);
        else if (action === 'next') next = Math.min(total - 1, cur + 1);
        else if (action === 'last') next = total - 1;
        if (next !== cur) {
          facetPageState.set(key, next);
          // Re-render entire sidebar to apply new page
          renderFacetSidebar(container, facets, activeFilters, facetLabels, onToggle, onClear, tier2Keys, valueLabelMaps);
        }
      });
    });
  });

  // Facet search: filter visible options within each category
  const facetSearch = container.querySelector('#facet-search') as HTMLInputElement | null;
  if (facetSearch) {
    // Restore previous query
    if (prevQuery) facetSearch.value = prevQuery;

    const applyFacetFilter = () => {
      const q = facetSearch.value.trim().toLowerCase();
      container.querySelectorAll('[data-facet-key]').forEach(section => {
        const labels = section.querySelectorAll('label');
        let visibleCount = 0;
        labels.forEach(label => {
          const text = label.querySelector('.min-w-0')?.textContent?.toLowerCase() || '';
          const match = !q || text.includes(q);
          (label as HTMLElement).style.display = match ? '' : 'none';
          if (match) visibleCount++;
        });
        // Hide entire section if no options match
        (section as HTMLElement).style.display = visibleCount === 0 && q ? 'none' : '';
        // Hide pager when search is active
        const pager = section.querySelector('[data-facet-pager]') as HTMLElement | null;
        if (pager) pager.style.display = q ? 'none' : '';
      });
    };

    facetSearch.addEventListener('input', applyFacetFilter);
    // Apply immediately if restoring a previous query
    if (prevQuery) applyFacetFilter();
  }
}

const FACET_PAGE_SIZE = 10;

function renderFacetSection(
  key: string,
  values: { value: string; count: number }[],
  activeFilters: ActiveFilters,
  facetLabels: Record<string, string>,
  valueLabels?: Record<string, string>,
  page: number = 0,
  searchActive: boolean = false,
): string {
  const activeCount = (activeFilters[key] || []).filter(v => values.some(fv => fv.value === v)).length;
  const badge = activeCount > 0 ? `<span class="ml-auto rounded-full bg-blue-100 px-1.5 py-0.5 text-xs font-medium text-blue-700">${activeCount}</span>` : '';

  // Open by default if any value is active, or if it's a tier-1 facet (caller controls via details open)
  const hasActive = activeCount > 0;

  const totalPages = Math.ceil(values.length / FACET_PAGE_SIZE);
  const needsPaging = values.length > FACET_PAGE_SIZE && !searchActive;
  const safePage = needsPaging ? Math.min(Math.max(0, page), totalPages - 1) : 0;
  const pageStart = safePage * FACET_PAGE_SIZE;
  const pageEnd = pageStart + FACET_PAGE_SIZE;
  const pageValues = needsPaging ? values.slice(pageStart, pageEnd) : values;

  let html = `<div class="mt-4 first:mt-0" data-facet-key="${key}" data-facet-page="${safePage}" data-facet-total="${totalPages}">
    <details${hasActive ? ' open' : ''}>
      <summary class="group mb-1.5 flex cursor-pointer select-none items-center gap-1 text-sm font-semibold text-gray-900 hover:text-gray-900 list-none [&::-webkit-details-marker]:hidden">
        <span class="facet-plus text-gray-400 text-xs font-mono w-3.5 shrink-0 text-center" aria-hidden="true"></span>
        <span>${facetLabels[key] || key}</span>${badge}
      </summary>
      <div class="space-y-0.5 pl-3.5">`;

  for (const fv of pageValues) {
    const isActive = (activeFilters[key] || []).includes(fv.value);
    const checkedAttr = isActive ? 'checked' : '';
    const rowClass = isActive
      ? 'bg-blue-50 text-blue-900'
      : 'text-gray-700 hover:bg-gray-50';
    const boxClass = isActive
      ? 'border-blue-600 bg-blue-600'
      : 'border-gray-300 bg-white group-hover:border-gray-400';
    const checkSvg = isActive
      ? '<svg class="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>'
      : '';

    html += `<label class="group flex items-center gap-2.5 rounded-md px-2 py-1.5 text-sm cursor-pointer transition-colors ${rowClass}">
      <input type="checkbox" name="${key}" value="${escapeHtml(fv.value)}" ${checkedAttr} class="sr-only" />
      <span class="flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors ${boxClass}">${checkSvg}</span>
      <span class="min-w-0 truncate">${valueLabels?.[fv.value] || fv.value}</span>
      <span class="ml-auto shrink-0 tabular-nums text-xs text-gray-400">${fv.count}</span>
    </label>`;
  }

  // Compact pagination controls
  if (needsPaging) {
    const btnBase = 'inline-flex items-center justify-center h-5 w-5 rounded text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors disabled:opacity-30 disabled:cursor-default disabled:hover:bg-transparent disabled:hover:text-gray-400';
    const isFirst = safePage === 0;
    const isLast = safePage >= totalPages - 1;
    const chevL = '<svg class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg>';
    const chevR = '<svg class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>';
    const chevLL = '<svg class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M11 19l-7-7 7-7M18 19l-7-7 7-7"/></svg>';
    const chevRR = '<svg class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M13 5l7 7-7 7M6 5l7 7-7 7"/></svg>';

    html += `<div class="mt-1.5 flex items-center justify-center gap-0.5" data-facet-pager>
      <button type="button" class="${btnBase}" data-pager-action="first" ${isFirst ? 'disabled' : ''} title="First page">${chevLL}</button>
      <button type="button" class="${btnBase}" data-pager-action="prev" ${isFirst ? 'disabled' : ''} title="Previous page">${chevL}</button>
      <span class="px-1.5 text-[10px] tabular-nums text-gray-500">${safePage + 1}/${totalPages}</span>
      <button type="button" class="${btnBase}" data-pager-action="next" ${isLast ? 'disabled' : ''} title="Next page">${chevR}</button>
      <button type="button" class="${btnBase}" data-pager-action="last" ${isLast ? 'disabled' : ''} title="Last page">${chevRR}</button>
    </div>`;
  }

  html += '</div></details></div>';
  return html;
}

// --- Data Table ---

export interface TableColumn {
  key: string;
  label: string;
  sortable?: boolean;
  renderHtml?: (item: any) => string;
}

export function renderTable(
  container: HTMLElement,
  columns: TableColumn[],
  items: any[],
  currentSort: string,
  currentDirection: string,
  onSort: (field: string) => void,
) {
  const headerCells = columns.map(col => {
    const isCurrent = currentSort === col.key;
    const indicator = isCurrent ? (currentDirection === 'asc' ? '\u25B2' : '\u25BC') : '\u25B3';
    const indicatorClass = isCurrent ? 'text-blue-600 font-bold' : 'text-gray-300 group-hover:text-gray-400';

    if (col.sortable) {
      return `<th scope="col" class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
        <button type="button" data-sort="${col.key}" class="group inline-flex cursor-pointer items-center gap-1 hover:text-gray-900">
          ${col.label}
          <span class="text-xs ${indicatorClass}">${indicator}</span>
        </button>
      </th>`;
    }
    return `<th scope="col" class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500"><span>${col.label}</span></th>`;
  }).join('');

  let bodyHtml: string;
  if (items.length === 0) {
    bodyHtml = `<tr><td colspan="${columns.length}" class="px-6 py-16 text-center">
  <svg class="mx-auto h-10 w-10 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
    <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"/>
  </svg>
  <p class="mt-3 text-sm font-medium text-gray-900">No results found</p>
  <p class="mt-1 text-sm text-gray-500">Try adjusting your search or filters</p>
</td></tr>`;
  } else {
    bodyHtml = items.map(item => {
      const cells = columns.map(col => {
        const value = col.renderHtml ? col.renderHtml(item) : escapeHtml(String(item[col.key] ?? ''));
        return `<td class="whitespace-nowrap px-4 py-3 text-sm text-gray-700">${value}</td>`;
      }).join('');
      return `<tr class="transition-colors hover:bg-blue-50/40">${cells}</tr>`;
    }).join('');
  }

  container.innerHTML = `<table class="min-w-full divide-y divide-gray-200">
    <thead class="sticky top-0 z-10 bg-gray-50/95 backdrop-blur"><tr>${headerCells}</tr></thead>
    <tbody class="divide-y divide-gray-100 bg-white">${bodyHtml}</tbody>
  </table>`;

  // Bind sort events
  container.querySelectorAll('[data-sort]').forEach(btn => {
    btn.addEventListener('click', () => onSort((btn as HTMLElement).dataset.sort!));
  });
}

// --- Pagination ---

export function renderPagination(
  container: HTMLElement,
  result: PaginationResult<any>,
  pageSize: number,
  onPage: (page: number) => void,
  onPageSizeChange?: (size: number) => void,
) {
  const { page, totalCount, totalPages } = result;
  const from = totalCount === 0 ? 0 : (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, totalCount);

  if (totalCount === 0) {
    container.innerHTML = '';
    return;
  }

  // Page size selector (hide if total fits in smallest page size)
  const sizes = [10, 25, 50, 100];
  const sizeSelector = totalCount > sizes[0] ? (() => {
    const sizeOptions = sizes.map(s =>
      `<option value="${s}"${s === pageSize ? ' selected' : ''}>${s}</option>`
    ).join('');
    return `<div class="flex items-center gap-2">
      <label for="page-size-select" class="text-sm text-gray-500">Show</label>
      <select id="page-size-select" class="rounded-md border border-gray-300 bg-white py-1 pl-2 pr-7 text-sm text-gray-700 focus-visible:border-blue-500 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-blue-500">
        ${sizeOptions}
      </select>
    </div>`;
  })() : '';

  const pages = visiblePages(page, totalPages);
  const pageButtons = pages.map(p => {
    if (p === null) return '<span class="px-2 text-sm text-gray-500">&hellip;</span>';
    if (p === page) return `<span class="rounded-md bg-blue-600 px-3 py-1.5 text-sm font-medium text-white">${p}</span>`;
    return `<button type="button" data-page="${p}" class="rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-50">${p}</button>`;
  }).join('');

  const prevBtn = page > 1
    ? `<button type="button" data-page="${page - 1}" class="rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-50">Previous</button>`
    : '<span class="cursor-not-allowed rounded-md border border-gray-200 bg-gray-50 px-3 py-1.5 text-sm font-medium text-gray-500" aria-disabled="true">Previous</span>';

  const nextBtn = page < totalPages
    ? `<button type="button" data-page="${page + 1}" class="rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-50">Next</button>`
    : '<span class="cursor-not-allowed rounded-md border border-gray-200 bg-gray-50 px-3 py-1.5 text-sm font-medium text-gray-500" aria-disabled="true">Next</span>';

  const pageNav = totalPages > 1
    ? `<div class="flex items-center gap-1">${prevBtn}${pageButtons}${nextBtn}</div>`
    : '';

  container.innerHTML = `<nav class="flex flex-col gap-3 border-t border-gray-200 px-1 pt-4 sm:flex-row sm:items-center sm:justify-between" aria-label="Pagination">
    ${sizeSelector}
    ${totalCount > sizes[0] ? `<p class="text-sm text-gray-500">Showing <span class="font-medium">${from}</span>–<span class="font-medium">${to}</span> of <span class="font-medium">${totalCount.toLocaleString()}</span></p>` : ''}
    ${pageNav}
  </nav>`;

  // Bind page events
  container.querySelectorAll('[data-page]').forEach(btn => {
    btn.addEventListener('click', () => onPage(parseInt((btn as HTMLElement).dataset.page!, 10)));
  });

  // Bind page size
  const sizeSelect = document.getElementById('page-size-select') as HTMLSelectElement | null;
  if (sizeSelect && onPageSizeChange) {
    sizeSelect.addEventListener('change', () => {
      onPageSizeChange(parseInt(sizeSelect.value, 10));
    });
  }
}

function visiblePages(page: number, totalPages: number): (number | null)[] {
  const pages: (number | null)[] = [];
  const w = 2;
  const start = Math.max(2, page - w);
  const end = Math.min(totalPages - 1, page + w);
  pages.push(1);
  if (start > 2) pages.push(null);
  for (let i = start; i <= end; i++) pages.push(i);
  if (end < totalPages - 1) pages.push(null);
  if (totalPages > 1) pages.push(totalPages);
  return pages;
}

// --- Search Results ---

export function renderSearchResults(
  container: HTMLElement,
  results: any[],
  query: string,
  typeFilter: string,
  onTypeFilter: (type: string) => void,
) {
  if (!query) {
    container.innerHTML = `<div class="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-gray-200 bg-white px-6 py-16 text-center">
      <svg class="h-12 w-12 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
      <p class="mt-4 text-lg font-medium text-gray-500">Enter a search term to explore the ontology</p>
      <p class="mt-1 text-sm text-gray-500">Search by name, definition, or URI across all bounded contexts</p>
    </div>`;
    return;
  }

  if (results.length === 0) {
    container.innerHTML = `<p class="mb-4 text-sm text-gray-600"><span class="font-semibold">0</span> results for <span class="font-semibold">&lsquo;${escapeHtml(query)}&rsquo;</span></p>
    <div class="rounded-lg border border-gray-200 bg-white px-6 py-12 text-center"><p class="text-sm font-medium text-gray-500">No results found</p></div>`;
    return;
  }

  // Type counts
  const typeCounts: Record<string, number> = { concept: 0, property: 0, vocabulary: 0, shape: 0 };
  for (const r of results) typeCounts[r.type] = (typeCounts[r.type] || 0) + 1;
  const allCount = results.length;

  const filtered = typeFilter ? results.filter(r => r.type === typeFilter) : results;

  const tabs = [
    { key: '', label: 'All', count: allCount },
    { key: 'concept', label: 'Concepts', count: typeCounts.concept },
    { key: 'property', label: 'Properties', count: typeCounts.property },
    { key: 'vocabulary', label: 'Vocabularies', count: typeCounts.vocabulary },
    { key: 'shape', label: 'Shapes', count: typeCounts.shape },
  ];

  const tabsHtml = tabs.map(t => {
    const isActive = typeFilter === t.key;
    const cls = isActive
      ? 'border-blue-600 text-blue-600'
      : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-900';
    const countCls = isActive ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600';
    return `<button type="button" data-type-filter="${t.key}" class="flex items-center gap-2 whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium transition-colors ${cls}">
      ${t.label} <span class="rounded-full px-2 py-0.5 text-xs ${countCls}">${t.count}</span>
    </button>`;
  }).join('');

  const cardsHtml = filtered.map(r => {
    const badge = typeBadge(r.type);
    const href = detailHref(r);
    const ctxBadge = contextBadge(r.context);
    return `<a href="${href}" class="group block rounded-lg border border-gray-200 bg-white px-5 py-4 shadow-sm transition-shadow hover:shadow-md">
      <div class="flex items-start justify-between gap-3"><div class="min-w-0 flex-1">
        <div class="flex items-center gap-2">
          <h3 class="truncate text-base font-semibold text-gray-900 group-hover:text-blue-600">${escapeHtml(r.type === 'property' ? sentenceCase(r.name || '') : (r.name || ''))}</h3>
          <span class="inline-block shrink-0 rounded-full px-2.5 py-0.5 text-xs font-medium ${badge.color}">${badge.label}</span>
          ${ctxBadge}
        </div>
        ${r.definition ? `<p class="mt-1.5 line-clamp-2 text-sm text-gray-600">${escapeHtml(r.definition)}</p>` : ''}
      </div></div>
    </a>`;
  }).join('');

  container.innerHTML = `<p class="mb-4 text-sm text-gray-600"><span class="font-semibold">${allCount}</span> result${allCount !== 1 ? 's' : ''} for <span class="font-semibold">&lsquo;${escapeHtml(query)}&rsquo;</span></p>
    <div class="mb-6 flex gap-1 overflow-x-auto border-b border-gray-200">${tabsHtml}</div>
    <div class="space-y-3">${cardsHtml}</div>`;

  container.querySelectorAll('[data-type-filter]').forEach(btn => {
    btn.addEventListener('click', () => onTypeFilter((btn as HTMLElement).dataset.typeFilter!));
  });
}

// --- Status / Loading ---

export function renderStatus(container: HTMLElement, message: string) {
  container.setAttribute('aria-live', 'polite');
  container.textContent = message;
}

// --- Active Filter Chips ---

/** Render active filter chips above the table. */
export function renderActiveFilterChips(
  container: HTMLElement,
  activeFilters: ActiveFilters,
  facetLabels: Record<string, string>,
  onRemove: (key: string, value: string) => void,
  onClearAll: () => void,
) {
  // Collect all active filter entries (excluding context — handled by toggle)
  const chips: { key: string; value: string; label: string }[] = [];
  for (const [key, values] of Object.entries(activeFilters)) {
    if (key === 'context') continue;
    for (const value of values) {
      chips.push({ key, value, label: facetLabels[key] || key });
    }
  }

  if (chips.length === 0) {
    container.innerHTML = '';
    return;
  }

  const chipHtml = chips.map(c =>
    facetTagHtml(c.key, c.label, c.value, { removable: true, filterable: false })
  ).join('');

  const clearAll = chips.length >= 2
    ? `<button type="button" data-action="clear-all-chips" class="text-sm font-medium text-gray-500 hover:text-gray-900 transition-colors">Clear all</button>`
    : '';

  container.innerHTML = `<div class="flex flex-wrap items-center gap-4">${chipHtml}${clearAll}</div>`;

  // Bind chip remove
  container.querySelectorAll('[data-chip-key]').forEach(btn => {
    btn.addEventListener('click', () => {
      const el = btn as HTMLElement;
      onRemove(el.dataset.chipKey!, el.dataset.chipValue!);
    });
  });

  // Bind clear all
  const clearBtn = container.querySelector('[data-action="clear-all-chips"]');
  if (clearBtn) clearBtn.addEventListener('click', onClearAll);
}

// --- Sort Controls (pill-style) ---

export function renderSortControls(
  container: HTMLElement,
  sortFields: { key: string; label: string }[],
  currentSort: string,
  currentDirection: string,
  onSort: (field: string) => void,
  onDirection: () => void,
) {
  const pills = sortFields.map(f => {
    const isActive = currentSort === f.key;
    const cls = isActive
      ? 'rounded-full bg-blue-100 text-blue-700 font-medium'
      : 'rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200';
    return `<button type="button" data-sort-pill="${f.key}" class="px-3 py-1.5 text-sm transition-colors ${cls}">${escapeHtml(f.label)}</button>`;
  }).join('');

  const arrow = currentDirection === 'asc' ? '\u25B2' : '\u25BC';
  const dirBtn = `<button type="button" data-sort-direction class="rounded-full bg-gray-100 px-2.5 py-1.5 text-sm text-gray-600 hover:bg-gray-200 transition-colors">${arrow}</button>`;

  container.innerHTML = `<div class="flex flex-wrap items-center gap-2"><span class="text-sm text-gray-500">Sort by</span>${pills}${dirBtn}</div>`;

  container.querySelectorAll('[data-sort-pill]').forEach(btn => {
    btn.addEventListener('click', () => onSort((btn as HTMLElement).dataset.sortPill!));
  });
  const dirEl = container.querySelector('[data-sort-direction]');
  if (dirEl) dirEl.addEventListener('click', onDirection);
}

// --- Card Grid ---

export function renderCards(
  container: HTMLElement,
  gridClass: string,
  items: any[],
  renderCard: (item: any) => string,
) {
  if (items.length === 0) {
    container.innerHTML = `<div class="px-6 py-16 text-center">
  <svg class="mx-auto h-10 w-10 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
    <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"/>
  </svg>
  <p class="mt-3 text-sm font-medium text-gray-900">No results found</p>
  <p class="mt-1 text-sm text-gray-500">Try adjusting your search or filters</p>
</div>`;
    return;
  }
  container.innerHTML = `<div class="${gridClass}">${items.map(renderCard).join('')}</div>`;
}

// --- Helpers ---

function escapeHtml(str: string): string {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function sentenceCase(s: string): string {
  if (!s) return s;
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function typeBadge(type: string): { label: string; color: string } {
  if (type === 'property') return { label: 'Property', color: 'bg-emerald-100 text-emerald-700' };
  if (type === 'vocabulary') return { label: 'Vocabulary', color: 'bg-purple-100 text-purple-700' };
  return { label: 'Concept', color: 'bg-blue-100 text-blue-700' };
}

function contextBadge(context: string): string {
  if (!context) return '';
  const c = context;
  const cls = badgeColorForContext(c);
  return `<span class="inline-block shrink-0 rounded-full px-2.5 py-0.5 text-xs font-medium uppercase ${cls}">${escapeHtml(c)}</span>`;
}

function detailHref(item: any): string {
  const ctx = item.context || '';
  const ln = item.localName || '';
  if (item.type === 'property') return `/properties/${ctx}/${ln}`;
  if (item.type === 'vocabulary') return `/vocabularies/${ctx}/${ln}`;
  if (item.type === 'shape') return `/shapes/${ctx}/${ln}`;
  return `/concepts/${ctx}/${ln}`;
}
