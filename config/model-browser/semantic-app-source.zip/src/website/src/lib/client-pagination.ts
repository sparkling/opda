/**
 * Reusable client-side pagination renderer.
 * Material Data Table pattern: page size selector, status, page buttons.
 */

export interface PaginationState {
  page: number;
  pageSize: number;
  totalCount: number;
}

export interface PaginationCallbacks {
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
}

const PAGE_SIZES = [5, 10, 25, 50];

const BTN_BASE = 'rounded-md px-3 py-1.5 text-sm font-medium';
const BTN_ACTIVE = BTN_BASE + ' bg-blue-600 text-white';
const BTN_NORMAL = BTN_BASE + ' border border-gray-300 bg-white text-gray-700 hover:bg-gray-50';
const BTN_DISABLED = BTN_BASE + ' cursor-not-allowed border border-gray-200 bg-gray-50 text-gray-400';

/**
 * Renders pagination HTML and binds events on the given container.
 * Call this after rendering table rows.
 */
export function renderPaginationBar(
  container: HTMLElement,
  state: PaginationState,
  callbacks: PaginationCallbacks,
  id = 'pagination',
): void {
  const { page, pageSize, totalCount } = state;
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));
  const from = totalCount === 0 ? 0 : (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, totalCount);

  if (totalCount === 0) {
    container.innerHTML = '';
    return;
  }

  // Page size options
  const sizeOptions = PAGE_SIZES.map(s =>
    `<option value="${s}"${s === pageSize ? ' selected' : ''}>${s}</option>`
  ).join('');

  // Page buttons (only if > 1 page)
  let pageButtons = '';
  if (totalPages > 1) {
    const prevCls = page <= 1 ? BTN_DISABLED : BTN_NORMAL;
    const nextCls = page >= totalPages ? BTN_DISABLED : BTN_NORMAL;

    let numButtons = '';
    // Show window of pages: first, ..., window, ..., last
    const w = 2;
    const start = Math.max(2, page - w);
    const end = Math.min(totalPages - 1, page + w);
    numButtons += page === 1
      ? `<button type="button" data-pg="1" class="${BTN_ACTIVE}" aria-current="page">1</button>`
      : `<button type="button" data-pg="1" class="${BTN_NORMAL}">1</button>`;
    if (start > 2) numButtons += '<span class="px-1 text-sm text-gray-400">&hellip;</span>';
    for (let i = start; i <= end; i++) {
      numButtons += i === page
        ? `<button type="button" data-pg="${i}" class="${BTN_ACTIVE}" aria-current="page">${i}</button>`
        : `<button type="button" data-pg="${i}" class="${BTN_NORMAL}">${i}</button>`;
    }
    if (end < totalPages - 1) numButtons += '<span class="px-1 text-sm text-gray-400">&hellip;</span>';
    if (totalPages > 1) {
      numButtons += page === totalPages
        ? `<button type="button" data-pg="${totalPages}" class="${BTN_ACTIVE}" aria-current="page">${totalPages}</button>`
        : `<button type="button" data-pg="${totalPages}" class="${BTN_NORMAL}">${totalPages}</button>`;
    }

    pageButtons = '<div class="flex items-center gap-1">' +
      `<button type="button" data-pg="prev" class="${prevCls}"${page <= 1 ? ' aria-disabled="true"' : ''}>Previous</button>` +
      numButtons +
      `<button type="button" data-pg="next" class="${nextCls}"${page >= totalPages ? ' aria-disabled="true"' : ''}>Next</button>` +
      '</div>';
  }

  container.innerHTML = `<nav class="flex flex-col gap-3 border-t border-gray-200 px-1 pt-4 sm:flex-row sm:items-center sm:justify-between" aria-label="Table pagination">
    <div class="flex items-center gap-2">
      <label for="${id}-size" class="text-sm text-gray-500">Rows per page</label>
      <select id="${id}-size" class="rounded-md border border-gray-300 bg-white py-1 pl-2 pr-7 text-sm text-gray-700 focus-visible:border-blue-500 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-blue-500">
        ${sizeOptions}
      </select>
    </div>
    <p class="text-sm text-gray-500" aria-live="polite">
      Showing <span class="font-medium">${from}</span>\u2013<span class="font-medium">${to}</span> of <span class="font-medium">${totalCount}</span>
    </p>
    ${pageButtons}
  </nav>`;

  // Bind page clicks
  container.querySelectorAll('[data-pg]').forEach(btn => {
    btn.addEventListener('click', () => {
      const val = (btn as HTMLElement).dataset.pg!;
      if (val === 'prev' && page > 1) callbacks.onPageChange(page - 1);
      else if (val === 'next' && page < totalPages) callbacks.onPageChange(page + 1);
      else if (val !== 'prev' && val !== 'next') callbacks.onPageChange(parseInt(val, 10));
    });
  });

  // Bind page size
  const sizeSelect = document.getElementById(`${id}-size`) as HTMLSelectElement | null;
  if (sizeSelect) {
    sizeSelect.addEventListener('change', () => {
      callbacks.onPageSizeChange(parseInt(sizeSelect.value, 10));
    });
  }
}
