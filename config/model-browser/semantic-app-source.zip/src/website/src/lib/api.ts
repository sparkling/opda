const API_BASE = import.meta.env.API_URL || 'http://localhost:3000';

export async function apiFetch(path: string, init?: RequestInit) {
  const url = `${API_BASE}${path}`;
  const res = await fetch(url, {
    ...init,
    headers: { Accept: 'application/ld+json', ...init?.headers },
  });
  if (!res.ok) throw new Error(`API ${res.status}: ${url}`);
  return res.json();
}

export async function apiText(path: string, accept = 'text/turtle') {
  const url = `${API_BASE}${path}`;
  const res = await fetch(url, { headers: { Accept: accept } });
  if (!res.ok) throw new Error(`API ${res.status}: ${url}`);
  return res.text();
}

export async function sparqlJson(query: string): Promise<any> {
  const url = `${API_BASE}/sparql`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/sparql-query', 'Accept': 'application/sparql-results+json' },
    body: query,
  });
  if (!res.ok) throw new Error(`SPARQL ${res.status}: ${url}`);
  return res.json();
}

/**
 * Fetch shape metadata for a SHACL ShapeClass, optionally with action visibility.
 * When instanceUri is provided, applicableWhen ASK queries are evaluated server-side
 * and the response includes an `actionVisibility` map (action URI → boolean).
 * Without instanceUri, returns cached shape metadata only.
 */
export async function fetchShapeMeta(className: string, instanceUri?: string) {
  const params = instanceUri ? `?instance=${encodeURIComponent(instanceUri)}` : '';
  return apiFetch(`/api/learn/meta/${className}${params}`);
}

/** Fetch bounded context notation→label map from BoundedContextScheme (build time). */
export async function fetchContextLabels(): Promise<Record<string, string>> {
  // All BoundedContextScheme members, not just skos:hasTopConcept ones: bc:HM,
  // bc:Meta, and the category sub-namespace members (service/capability/process/
  // state, ODR-0071d amendment) carry a notation but are deliberately not top
  // concepts (they are not DDD bounded contexts). Including skos:inScheme members
  // gives every context a display label instead of a bare notation.
  const result = await sparqlJson(`
    PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
    PREFIX hm: <https://hm.com/ns/>
    SELECT ?label ?notation WHERE {
      { hm:BoundedContextScheme skos:hasTopConcept ?bc } UNION { ?bc skos:inScheme hm:BoundedContextScheme }
      ?bc skos:prefLabel ?label .
      ?bc skos:notation ?notation .
    }`);
  const labels: Record<string, string> = {};
  for (const b of result?.results?.bindings ?? []) {
    const notation = b.notation?.value;
    const label = b.label?.value;
    if (notation && label) labels[notation] = label;
  }
  return labels;
}
