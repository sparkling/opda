/**
 * Materializes flat arrays and detail Maps from the N3Store.
 * Includes entailed triples (subclass hierarchy, inverse properties, etc.).
 */
import { Store, DataFactory } from 'n3';

const { namedNode } = DataFactory;

// Well-known IRIs
const rdf = {
  type: namedNode('http://www.w3.org/1999/02/22-rdf-syntax-ns#type'),
};
const rdfs = {
  label: namedNode('http://www.w3.org/2000/01/rdf-schema#label'),
  comment: namedNode('http://www.w3.org/2000/01/rdf-schema#comment'),
  subClassOf: namedNode('http://www.w3.org/2000/01/rdf-schema#subClassOf'),
  isDefinedBy: namedNode('http://www.w3.org/2000/01/rdf-schema#isDefinedBy'),
  domain: namedNode('http://www.w3.org/2000/01/rdf-schema#domain'),
  range: namedNode('http://www.w3.org/2000/01/rdf-schema#range'),
};
const owl = {
  Class: namedNode('http://www.w3.org/2002/07/owl#Class'),
  ObjectProperty: namedNode('http://www.w3.org/2002/07/owl#ObjectProperty'),
  DatatypeProperty: namedNode('http://www.w3.org/2002/07/owl#DatatypeProperty'),
  FunctionalProperty: namedNode('http://www.w3.org/2002/07/owl#FunctionalProperty'),
  InverseFunctionalProperty: namedNode('http://www.w3.org/2002/07/owl#InverseFunctionalProperty'),
  TransitiveProperty: namedNode('http://www.w3.org/2002/07/owl#TransitiveProperty'),
};
const sh = {
  NodeShape: namedNode('http://www.w3.org/ns/shacl#NodeShape'),
  property: namedNode('http://www.w3.org/ns/shacl#property'),
  path: namedNode('http://www.w3.org/ns/shacl#path'),
  minCount: namedNode('http://www.w3.org/ns/shacl#minCount'),
  maxCount: namedNode('http://www.w3.org/ns/shacl#maxCount'),
  targetClass: namedNode('http://www.w3.org/ns/shacl#targetClass'),
  targetObjectsOf: namedNode('http://www.w3.org/ns/shacl#targetObjectsOf'),
  targetSubjectsOf: namedNode('http://www.w3.org/ns/shacl#targetSubjectsOf'),
  rule: namedNode('http://www.w3.org/ns/shacl#rule'),
  xone: namedNode('http://www.w3.org/ns/shacl#xone'),
  message: namedNode('http://www.w3.org/ns/shacl#message'),
  severity: namedNode('http://www.w3.org/ns/shacl#severity'),
  closed: namedNode('http://www.w3.org/ns/shacl#closed'),
};
const shx = {
  ShapeClass: namedNode('http://www.w3.org/ns/shacl#ShapeClass'),
};
const dash = {
  derived: namedNode('http://datashapes.org/dash#derived'),
};
const skos = {
  prefLabel: namedNode('http://www.w3.org/2004/02/skos/core#prefLabel'),
  definition: namedNode('http://www.w3.org/2004/02/skos/core#definition'),
  altLabel: namedNode('http://www.w3.org/2004/02/skos/core#altLabel'),
  scopeNote: namedNode('http://www.w3.org/2004/02/skos/core#scopeNote'),
  editorialNote: namedNode('http://www.w3.org/2004/02/skos/core#editorialNote'),
  ConceptScheme: namedNode('http://www.w3.org/2004/02/skos/core#ConceptScheme'),
  hasTopConcept: namedNode('http://www.w3.org/2004/02/skos/core#hasTopConcept'),
  notation: namedNode('http://www.w3.org/2004/02/skos/core#notation'),
  exactMatch: namedNode('http://www.w3.org/2004/02/skos/core#exactMatch'),
  closeMatch: namedNode('http://www.w3.org/2004/02/skos/core#closeMatch'),
  broadMatch: namedNode('http://www.w3.org/2004/02/skos/core#broadMatch'),
  narrowMatch: namedNode('http://www.w3.org/2004/02/skos/core#narrowMatch'),
  relatedMatch: namedNode('http://www.w3.org/2004/02/skos/core#relatedMatch'),
};
const vann = {
  preferredNamespacePrefix: namedNode('http://purl.org/vocab/vann/preferredNamespacePrefix'),
  preferredNamespaceUri: namedNode('http://purl.org/vocab/vann/preferredNamespaceUri'),
};

const HM_NS = 'https://hm.com/ns/';
// ODR-0041 R5 (Council S109): metaclasses live in the meta: namespace.
// Any owl:Class in https://hm.com/ns/meta/ is infrastructure, not a domain concept.
const META_NS = 'https://hm.com/ns/meta/';
// Laika learn-pipeline infrastructure namespaces — not domain concepts.
const LEARN_NS = 'https://hm.com/ns/learn/';
const LAIKA_NS = 'https://hm.com/ns/laika/';
// Bare hm: classes with no bounded-context sub-namespace segment, e.g.
// https://hm.com/ns/AcceptanceGate — governance/learn infra, not domain concepts.
const BARE_HM_CLASS = /^https:\/\/hm\.com\/ns\/[^/]+$/;
// Internal modelling bounded contexts (ODR-0071d) — archimate, service, capability,
// process, state describe internal structure, not domain data. Excluded from concept
// and property search, mirroring the API (src/api/queries/list-concepts.rq).
const INTERNAL_BC = /^https:\/\/hm\.com\/ns\/(archimate|service|capability|process|state|learn)\//;
// The internal bounded contexts' governing ontologies. Some governance shapes for
// these contexts live in the bare hm: namespace (so they default to "HM") but are
// rdfs:isDefinedBy one of these ontologies — that reveals their true (blacklisted)
// context. Non-blacklisted governance shapes (cross-domain, access-control, …) are
// defined by other ontologies and are kept.
const INTERNAL_BC_ONTOLOGY = /\/ns\/(archimate|service-architecture|capability-intent|process-modelling|temporal-state-history)/;
const hm = {
  subjectArea: namedNode(`${HM_NS}subjectArea`),
  dataClassification: namedNode(`${HM_NS}dataClassification`),
  lifecycleStage: namedNode(`${HM_NS}lifecycleStage`),
  volatility: namedNode(`${HM_NS}volatility`),
  regulatoryRelevance: namedNode(`${HM_NS}regulatoryRelevance`),
  sourceSystem: namedNode(`${HM_NS}sourceSystem`),
  valueChainPosition: namedNode(`${HM_NS}valueChainPosition`),
  stereotype: namedNode(`${HM_NS}stereotype`),
  governanceTier: namedNode(`${HM_NS}governanceTier`),
  schemeType: namedNode(`${HM_NS}schemeType`),
};

export interface MaterializedConcept {
  id: string;
  name: string;
  context: string;
  localName: string;
  definition: string;
  comment: string;
  altLabels: string[];
  subjectArea: string;
  subjectAreaLocalName: string;
  dataClassification: string;
  lifecycle: string;
  volatility: string;
  regulatoryRelevance: string;
  sourceSystem: string;
  stereotype: string;
  valueChainPosition: string;
  governanceTier: string;
  isRootClass: boolean;
  uri: string;
}

export interface ConceptDetail extends MaterializedConcept {
  scopeNotes: string[];
  editorialNotes: string[];
  valueChainPositions: string[];
  parents: { name: string; context: string; localName: string }[];
  children: { name: string; context: string; localName: string }[];
}

export interface MaterializedProperty {
  id: string;
  name: string;
  context: string;
  localName: string;
  type: 'ObjectProperty' | 'DatatypeProperty';
  domain: string[];
  domainLocalName: string;
  domainContext: string;
  /** Per-domain link info for multi-domain properties */
  domainLinks: { label: string; localName: string; context: string }[];
  range: string;
  rangeLocalName: string;
  rangeContext: string;
  rangeClass: string;
  datatype: string;
  cardinality: string;
  derived: boolean;
  definition: string;
  comment: string;
  altLabels: string[];
  subjectArea: string;
  subjectAreaLocalName: string;
  usedByCount: number;
  required: string;
  functional: string;
  inverseFunctional: string;
  transitive: string;
  characteristics: string[];
  uri: string;
}

export interface MaterializedVocabulary {
  id: string;
  name: string;
  context: string;
  localName: string;
  definition: string;
  schemeType: string;
  subjectArea: string;
  subjectAreaLocalName: string;
  valueCount: number;
  uri: string;
}

export type ShapeCategory = 'Class Shape' | 'Value Validator' | 'Governance' | 'Quality Gate' | 'Disjointness' | 'Rule';

export interface MaterializedShape {
  id: string;
  name: string;
  context: string;
  localName: string;
  category: ShapeCategory;
  targetType: string;
  targetLabel: string;
  definition: string;
  comment: string;
  message: string;
  propertyCount: number;
  isStandalone: boolean;
  uri: string;
}

export interface MaterializedData {
  concepts: MaterializedConcept[];
  properties: MaterializedProperty[];
  vocabularies: MaterializedVocabulary[];
  shapes: MaterializedShape[];
  conceptDetails: Map<string, ConceptDetail>;
  /** Notation (lowercase) → skos:prefLabel for bounded contexts */
  contextLabels: Record<string, string>;
}

function localName(iri: string): string {
  const hash = iri.lastIndexOf('#');
  if (hash >= 0) return iri.substring(hash + 1);
  const slash = iri.lastIndexOf('/');
  return slash >= 0 ? iri.substring(slash + 1) : iri;
}

/** Split CamelCase/PascalCase into space-separated words for fallback display. */
function splitCamelCase(s: string): string {
  return s.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2');
}

type PrefixEntry = [string, string]; // [prefix, namespaceUri]

/** Build sorted prefix map from vann: declarations in the store. Longest namespace first. */
function buildPrefixMap(store: Store): PrefixEntry[] {
  const ontQuads = store.getQuads(null, rdf.type, namedNode('http://www.w3.org/2002/07/owl#Ontology'), null);
  const map = new Map<string, string>();
  for (const q of ontQuads) {
    const prefix = literal(store, q.subject, vann.preferredNamespacePrefix);
    const ns = literal(store, q.subject, vann.preferredNamespaceUri);
    if (prefix && ns) map.set(prefix, ns);
  }
  // Add hm: base namespace (not declared via vann: on an owl:Ontology node)
  if (!map.has('hm')) map.set('hm', HM_NS);
  return Array.from(map.entries()).sort((a, b) => b[1].length - a[1].length);
}

/** Resolve a full URI to {context, localName} using the prefix map. */
function resolveUri(prefixMap: PrefixEntry[], uri: string): { context: string; localName: string } | null {
  for (const [prefix, ns] of prefixMap) {
    if (uri.startsWith(ns)) return { context: prefix, localName: uri.slice(ns.length) };
  }
  return null;
}

function literal(store: Store, subject: any, predicate: any): string {
  const quads = store.getQuads(subject, predicate, null, null);
  return quads.length > 0 ? quads[0].object.value : '';
}

/** S137→strategic: prefer skos:prefLabel, then rdfs:label NOT entailed from skos:altLabel */
function displayLabel(store: Store, subject: any): string {
  // ODR-0041 R1: skos:prefLabel is the canonical display label
  const prefLabels = store.getQuads(subject, skos.prefLabel, null, null);
  if (prefLabels.length > 0) return prefLabels[0].object.value;
  // Fallback: rdfs:label with S137 altLabel disambiguation
  const labels = store.getQuads(subject, rdfs.label, null, null);
  if (labels.length === 0) return '';
  if (labels.length === 1) return labels[0].object.value;
  const altLabels = new Set(
    store.getQuads(subject, skos.altLabel, null, null).map(q => q.object.value)
  );
  const primary = labels.find(q => !altLabels.has(q.object.value));
  return primary ? primary.object.value : labels[0].object.value;
}

function literals(store: Store, subject: any, predicate: any): string[] {
  return store.getQuads(subject, predicate, null, null).map(q => q.object.value);
}

function facetLabel(store: Store, subject: any, predicate: any): string {
  const refs = store.getQuads(subject, predicate, null, null);
  if (refs.length === 0) return '';
  const target = refs[0].object;
  // ODR-0041 R1: skos:prefLabel (SKOS concepts) → rdfs:label fallback → empty (DQ issue)
  const prefLabel = store.getQuads(target, skos.prefLabel, null, null);
  if (prefLabel.length > 0) return prefLabel[0].object.value;
  // S137: use displayLabel to avoid entailed altLabel duplicates
  return displayLabel(store, target);
}

function facetLocalName(store: Store, subject: any, predicate: any): string {
  const refs = store.getQuads(subject, predicate, null, null);
  if (refs.length === 0) return '';
  const uri = refs[0].object.value;
  return localName(uri);
}

function isHmEntity(iri: string): boolean {
  return iri.startsWith(HM_NS) && !iri.includes('/ia/');
}

// Scope the concept listing to the same domain-concept set the live API serves
// (src/api/queries/list-concepts.rq): an hm: owl:Class under a bounded-context
// sub-namespace (pf/sds/archimate/common/…), excluding infrastructure —
// meta: metaclasses (ODR-0041 R5, Council S109), the learn/laika Laika pipeline
// namespaces, and bare hm:<ClassName> classes with no sub-namespace segment
// (governance/learn infra). Without this, those infra classes appear in the
// browser listing but have no API-backed detail page and 404 on click.
function isDomainConcept(_store: Store, subject: any): boolean {
  const iri = subject.value;
  if (iri.startsWith(META_NS)) return false;
  if (iri.startsWith(LEARN_NS) || iri.startsWith(LAIKA_NS)) return false;
  if (BARE_HM_CLASS.test(iri)) return false;
  if (INTERNAL_BC.test(iri)) return false;
  return true;
}

export function materialize(store: Store): MaterializedData {
  const prefixMap = buildPrefixMap(store);

  // --- Concepts ---
  const conceptQuads = store.getQuads(null, rdf.type, owl.Class, null);
  const seenConcepts = new Set<string>();
  const concepts: MaterializedConcept[] = [];

  for (const q of conceptQuads) {
    const uri = q.subject.value;
    if (!isHmEntity(uri) || seenConcepts.has(uri)) continue;
    if (!isDomainConcept(store, q.subject)) continue;
    seenConcepts.add(uri);

    const resolved = resolveUri(prefixMap, uri);
    const ctx = resolved?.context || '';
    const ln = resolved?.localName || localName(uri);
    concepts.push({
      id: `${ctx}/${ln}`,
      name: displayLabel(store, q.subject) || `[${splitCamelCase(ln)}]`,
      context: ctx,
      localName: ln,
      definition: literal(store, q.subject, skos.definition),
      comment: literal(store, q.subject, rdfs.comment),
      altLabels: literals(store, q.subject, skos.altLabel),
      subjectArea: facetLabel(store, q.subject, hm.subjectArea),
      subjectAreaLocalName: facetLocalName(store, q.subject, hm.subjectArea),
      dataClassification: facetLabel(store, q.subject, hm.dataClassification),
      lifecycle: facetLabel(store, q.subject, hm.lifecycleStage),
      volatility: facetLabel(store, q.subject, hm.volatility),
      regulatoryRelevance: facetLabel(store, q.subject, hm.regulatoryRelevance),
      sourceSystem: facetLabel(store, q.subject, hm.sourceSystem),
      stereotype: facetLabel(store, q.subject, hm.stereotype),
      valueChainPosition: facetLabel(store, q.subject, hm.valueChainPosition),
      governanceTier: facetLabel(store, q.subject, hm.governanceTier),
      isRootClass: store.getQuads(q.subject, rdfs.subClassOf, null, null)
        .filter(pq => pq.object.termType === 'NamedNode' && isHmEntity(pq.object.value))
        .length === 0,
      uri,
    });
  }

  // --- Concept Details (hierarchy uses entailed rdfs:subClassOf) ---
  const conceptDetails = new Map<string, ConceptDetail>();
  for (const c of concepts) {
    const subj = namedNode(c.uri);
    const parents = store.getQuads(subj, rdfs.subClassOf, null, null)
      .filter(q => q.object.termType === 'NamedNode' && isHmEntity(q.object.value))
      .map(q => ({
        name: displayLabel(store, q.object) || `[${splitCamelCase(localName(q.object.value))}]`,
        context: resolveUri(prefixMap, q.object.value)?.context || '',
        localName: localName(q.object.value),
      }));
    const children = store.getQuads(null, rdfs.subClassOf, subj, null)
      .filter(q => q.subject.termType === 'NamedNode' && isHmEntity(q.subject.value))
      .map(q => ({
        name: displayLabel(store, q.subject) || `[${splitCamelCase(localName(q.subject.value))}]`,
        context: resolveUri(prefixMap, q.subject.value)?.context || '',
        localName: localName(q.subject.value),
      }));

    conceptDetails.set(c.id, {
      ...c,
      scopeNotes: literals(store, subj, skos.scopeNote),
      editorialNotes: literals(store, subj, skos.editorialNote),
      valueChainPositions: store.getQuads(subj, hm.valueChainPosition, null, null)
        .map(q => {
          const pref = store.getQuads(q.object, skos.prefLabel, null, null);
          if (pref.length > 0) return pref[0].object.value;
          // S137: use displayLabel for rdfs:label fallback
          return displayLabel(store, q.object) || localName(q.object.value);
        }),
      parents,
      children,
    });
  }

  // --- Properties ---
  const seenProps = new Set<string>();
  const properties: MaterializedProperty[] = [];

  for (const owlType of [owl.ObjectProperty, owl.DatatypeProperty]) {
    const propQuads = store.getQuads(null, rdf.type, owlType, null);
    for (const q of propQuads) {
      const uri = q.subject.value;
      if (!isHmEntity(uri) || seenProps.has(uri)) continue;
      seenProps.add(uri);

      const resolved = resolveUri(prefixMap, uri);
      const ctx = resolved?.context || '';
      const ln = resolved?.localName || localName(uri);
      const domainQuads = store.getQuads(q.subject, rdfs.domain, null, null);
      // Exclude internal modelling bounded contexts (ODR-0071d), mirroring the API
      // (src/api/queries/list-properties.rq): a property whose own namespace is internal,
      // or whose rdfs:domain is *exclusively* an internal-context class (e.g. hm:httpMethod
      // → archimate, hm:kpiTarget → capability). Mixed/shared and domain-less props stay.
      if (INTERNAL_BC.test(uri)) continue;
      if (domainQuads.length > 0 && domainQuads.every(dq => INTERNAL_BC.test(dq.object.value))) continue;
      const rangeQuads = store.getQuads(q.subject, rdfs.range, null, null);

      // Aggregate cardinality and derived from SHACL shapes referencing this property
      const shapeQuads = store.getQuads(null, sh.path, q.subject, null);
      let minCard = Infinity;
      let maxCard = 0;
      let hasMax = false;
      let isDerived = false;
      for (const sq of shapeQuads) {
        const minQ = store.getQuads(sq.subject, sh.minCount, null, null);
        const maxQ = store.getQuads(sq.subject, sh.maxCount, null, null);
        if (minQ.length > 0) {
          const v = parseInt(minQ[0].object.value, 10);
          if (v < minCard) minCard = v;
        }
        if (maxQ.length > 0) {
          const v = parseInt(maxQ[0].object.value, 10);
          if (v > maxCard) { maxCard = v; hasMax = true; }
        }
        const derivedQ = store.getQuads(sq.subject, dash.derived, null, null);
        if (derivedQ.length > 0 && derivedQ[0].object.value === 'true') isDerived = true;
      }
      const mn = minCard === Infinity ? '0' : String(minCard);
      const mx = hasMax ? String(maxCard) : '*';
      const cardinality = shapeQuads.length > 0 ? `${mn}..${mx}` : '';
      const isRequired = minCard !== Infinity && minCard >= 1;
      const isFunctional = store.getQuads(q.subject, rdf.type, owl.FunctionalProperty, null).length > 0;
      const isInverseFunctional = store.getQuads(q.subject, rdf.type, owl.InverseFunctionalProperty, null).length > 0;
      const isTransitive = store.getQuads(q.subject, rdf.type, owl.TransitiveProperty, null).length > 0;

      // Collect all unique ranges (handles multi-range from sh:or / rdfs:range)
      const rangeNames = new Set<string>();
      for (const rq of rangeQuads) {
        const name = displayLabel(store, rq.object) || localName(rq.object.value);
        if (name) rangeNames.add(name);
      }
      const range = [...rangeNames].join(' | ');

      const domUri = domainQuads.length > 0 ? domainQuads[0].object.value : '';
      const ranUri = rangeQuads.length > 0 ? rangeQuads[0].object.value : '';
      const ranIsHm = ranUri ? isHmEntity(ranUri) : false;
      const isObj = owlType === owl.ObjectProperty;
      properties.push({
        id: `${ctx}/${ln}`,
        name: displayLabel(store, q.subject) || `[${splitCamelCase(ln)}]`,
        context: ctx,
        localName: ln,
        type: isObj ? 'ObjectProperty' : 'DatatypeProperty',
        domain: domainQuads.map(dq => displayLabel(store, dq.object) || localName(dq.object.value)).filter(Boolean),
        domainLocalName: domUri ? localName(domUri) : '',
        domainContext: domUri ? (resolveUri(prefixMap, domUri)?.context || '') : '',
        domainLinks: domainQuads.map(dq => {
          const u = dq.object.value;
          const resolved = resolveUri(prefixMap, u);
          return {
            label: displayLabel(store, dq.object) || localName(u),
            localName: resolved?.localName || localName(u),
            context: resolved?.context || '',
          };
        }).filter(d => d.label),
        range,
        rangeLocalName: ranIsHm ? localName(ranUri) : '',
        rangeContext: ranIsHm ? (resolveUri(prefixMap, ranUri)?.context || '') : '',
        rangeClass: isObj && range ? range : '',
        datatype: !isObj && ranUri ? localName(ranUri) : '',
        cardinality,
        derived: isDerived,
        definition: literal(store, q.subject, skos.definition),
        comment: literal(store, q.subject, rdfs.comment),
        altLabels: literals(store, q.subject, skos.altLabel),
        subjectArea: facetLabel(store, q.subject, hm.subjectArea),
        subjectAreaLocalName: facetLocalName(store, q.subject, hm.subjectArea),
        usedByCount: shapeQuads.length,
        required: isRequired ? 'Required' : '',
        functional: isFunctional ? 'Functional' : '',
        inverseFunctional: isInverseFunctional ? 'Inverse Functional' : '',
        transitive: isTransitive ? 'Transitive' : '',
        characteristics: [
          ...(isRequired ? ['Required'] : []),
          ...(isDerived ? ['Derived'] : []),
          ...(isFunctional ? ['Functional'] : []),
          ...(isInverseFunctional ? ['Inverse Functional'] : []),
          ...(isTransitive ? ['Transitive'] : []),
        ],
        uri,
      });
    }
  }

  // --- Vocabularies (SKOS ConceptSchemes) ---
  const enumQuads = store.getQuads(null, rdf.type, skos.ConceptScheme, null);
  const seenEnums = new Set<string>();
  const vocabularies: MaterializedVocabulary[] = [];

  for (const q of enumQuads) {
    const uri = q.subject.value;
    if (!isHmEntity(uri) || seenEnums.has(uri) || INTERNAL_BC.test(uri)) continue;
    seenEnums.add(uri);

    const resolved = resolveUri(prefixMap, uri);
    const ctx = resolved?.context || '';
    const ln = resolved?.localName || localName(uri);
    const members = store.getQuads(q.subject, skos.hasTopConcept, null, null);

    const st = facetLabel(store, q.subject, hm.schemeType);
    // Gap 6 (ADR-0029): Classification schemes are cross-cutting — exempt from subject area
    const sa = st === 'Classification' ? '' : facetLabel(store, q.subject, hm.subjectArea);
    const saLN = st === 'Classification' ? '' : facetLocalName(store, q.subject, hm.subjectArea);
    // Gap 5 (ADR-0029): Ideally subject area is inferred from consuming OWL classes;
    // direct annotation on the ConceptScheme is functionally equivalent when ontology is correct.

    vocabularies.push({
      id: `${ctx}/${ln}`,
      name: displayLabel(store, q.subject) || `[${splitCamelCase(ln)}]`,
      context: ctx,
      localName: ln,
      definition: literal(store, q.subject, skos.definition),
      schemeType: st,
      subjectArea: sa,
      subjectAreaLocalName: saLN,
      valueCount: members.length,
      uri,
    });
  }

  // --- Shapes (SHACL NodeShapes) ---
  const shapeQuads = store.getQuads(null, rdf.type, sh.NodeShape, null);
  const seenShapes = new Set<string>();
  const shapes: MaterializedShape[] = [];

  for (const q of shapeQuads) {
    const uri = q.subject.value;
    if (!isHmEntity(uri) || seenShapes.has(uri) || INTERNAL_BC.test(uri)) continue;
    // Bare hm: governance shapes for a blacklisted context (e.g. hm:ArchiMate*Shape
    // isDefinedBy service-architecture-meta-shapes) default to "HM" via resolveUri but
    // belong to an internal bounded context — exclude them. Other bare hm: governance
    // shapes (cross-domain, access-control, …) are defined elsewhere and are kept.
    if (BARE_HM_CLASS.test(uri) &&
        store.getQuads(q.subject, rdfs.isDefinedBy, null, null)
          .some((d) => INTERNAL_BC_ONTOLOGY.test(d.object.value))) continue;
    seenShapes.add(uri);

    const resolved = resolveUri(prefixMap, uri);
    const ctx = resolved?.context || '';
    const ln = resolved?.localName || localName(uri);

    // Detect ShapeClass (dual-typed with owl:Class)
    const isShapeClass = store.getQuads(q.subject, rdf.type, owl.Class, null).length > 0;

    // Count sh:property blocks
    const propCount = store.getQuads(q.subject, sh.property, null, null).length;

    // Target mechanisms
    const targetClassQuads = store.getQuads(q.subject, sh.targetClass, null, null);
    const targetObjOfQuads = store.getQuads(q.subject, sh.targetObjectsOf, null, null);
    const targetSubjOfQuads = store.getQuads(q.subject, sh.targetSubjectsOf, null, null);
    const hasRule = store.getQuads(q.subject, sh.rule, null, null).length > 0;
    const hasXone = store.getQuads(q.subject, sh.xone, null, null).length > 0;

    // Category determination (ADR-0075)
    let category: ShapeCategory;
    if (isShapeClass) {
      category = 'Class Shape';
    } else if (targetObjOfQuads.length > 0) {
      category = 'Value Validator';
    } else if (hasRule) {
      category = 'Rule';
    } else if (hasXone) {
      category = 'Disjointness';
    } else if (targetClassQuads.length > 0) {
      const tcUri = targetClassQuads[0].object.value;
      const qualityGateTargets = [
        'http://www.w3.org/2002/07/owl#Class',
        'http://www.w3.org/2002/07/owl#ObjectProperty',
        'http://www.w3.org/2002/07/owl#DatatypeProperty',
        'http://www.w3.org/2002/07/owl#Ontology',
      ];
      category = qualityGateTargets.includes(tcUri) ? 'Quality Gate' : 'Governance';
    } else {
      category = 'Governance';
    }

    // Target type and label
    let targetType = 'Other';
    let targetLabel = '';
    if (isShapeClass) {
      targetType = 'Implicit (self)';
      targetLabel = 'Validates instances';
    } else if (targetObjOfQuads.length > 0) {
      targetType = 'targetObjectsOf';
      const tgt = targetObjOfQuads[0].object;
      targetLabel = displayLabel(store, tgt) || localName(tgt.value);
    } else if (targetSubjOfQuads.length > 0) {
      targetType = 'targetSubjectsOf';
      const tgt = targetSubjOfQuads[0].object;
      targetLabel = displayLabel(store, tgt) || localName(tgt.value);
    } else if (targetClassQuads.length > 0) {
      targetType = 'targetClass';
      const tgt = targetClassQuads[0].object;
      targetLabel = displayLabel(store, tgt) || localName(tgt.value);
    }

    shapes.push({
      id: `${ctx}/${ln}`,
      name: displayLabel(store, q.subject) || `[${splitCamelCase(ln)}]`,
      context: ctx,
      localName: ln,
      category,
      targetType,
      targetLabel,
      definition: literal(store, q.subject, skos.definition),
      comment: literal(store, q.subject, rdfs.comment),
      message: literal(store, q.subject, sh.message),
      propertyCount: propCount,
      isStandalone: !isShapeClass,
      uri,
    });
  }

  // Extract bounded context labels from BoundedContextScheme.
  // Collect ALL scheme members, not just skos:hasTopConcept ones: bc:HM,
  // bc:Meta, and the category sub-namespace members (service/capability/
  // process/state, ODR-0071d amendment) carry a notation but are deliberately
  // not top concepts (they are not DDD bounded contexts). Reading inScheme
  // members too gives every context a display label instead of a raw notation.
  const skosInScheme = namedNode('http://www.w3.org/2004/02/skos/core#inScheme');
  const bcScheme = namedNode(`${HM_NS}BoundedContextScheme`);
  const memberSet = new Set<string>();
  for (const q of store.getQuads(bcScheme, skos.hasTopConcept, null, null)) memberSet.add(q.object.value);
  for (const q of store.getQuads(null, skosInScheme, bcScheme, null)) memberSet.add(q.subject.value);
  const contextLabels: Record<string, string> = {};
  for (const memberUri of memberSet) {
    const member = namedNode(memberUri);
    const prefLabel = store.getQuads(member, skos.prefLabel, null, null);
    const notation = store.getQuads(member, namedNode('http://www.w3.org/2004/02/skos/core#notation'), null, null);
    const label = prefLabel.length > 0 ? prefLabel[0].object.value : '';
    const notationVal = notation.length > 0 ? notation[0].object.value : '';
    if (notationVal && label) {
      contextLabels[notationVal] = label;
    }
  }

  return { concepts, properties, vocabularies, shapes, conceptDetails, contextLabels };
}
