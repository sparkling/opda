import { readdirSync, readFileSync, existsSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';

const GENERATED_ROOT = resolve(import.meta.dirname, '../../../../generated');
const REPORT_ROOT = join(GENERATED_ROOT, 'report');

export interface ReportManifest {
  slug: string;
  system: string;
  version: string;
  source: { run_id: string };
  documents: Array<{ file: string; type: string }>;
}

export interface ResolvedReport {
  dir: string;
  manifest: ReportManifest;
}

export function resolveReport(runId: string): ResolvedReport | null {
  if (!existsSync(REPORT_ROOT)) return null;
  for (const system of readdirSync(REPORT_ROOT)) {
    const systemDir = join(REPORT_ROOT, system);
    if (!statSync(systemDir).isDirectory()) continue;
    for (const slug of readdirSync(systemDir)) {
      const slugDir = join(systemDir, slug);
      if (!statSync(slugDir).isDirectory()) continue;
      for (const version of readdirSync(slugDir)) {
        const versionDir = join(slugDir, version);
        const manifestPath = join(versionDir, 'REPORT-MANIFEST.yaml');
        if (!existsSync(manifestPath)) continue;
        const text = readFileSync(manifestPath, 'utf8');
        if (text.includes(`run_id: ${runId}`)) {
          const manifest = parseManifest(text);
          if (manifest) return { dir: versionDir, manifest };
        }
      }
    }
  }
  return null;
}

function parseManifest(text: string): ReportManifest | null {
  const get = (key: string) => {
    const m = text.match(new RegExp(`^${key}:\\s*(.+)$`, 'm'));
    return m ? m[1].trim().replace(/^["']|["']$/g, '') : '';
  };
  const runIdMatch = text.match(/run_id:\s*(.+)/);
  return {
    slug: get('slug'),
    system: get('system'),
    version: get('version'),
    source: { run_id: runIdMatch ? runIdMatch[1].trim() : '' },
    documents: [],
  };
}

export function readReportMarkdown(dir: string, page: string): string | null {
  const filename = page.endsWith('.md') ? page : `${page}.md`;
  const filepath = join(dir, filename);
  if (!existsSync(filepath)) return null;
  return readFileSync(filepath, 'utf8');
}

export function listReportPages(dir: string): string[] {
  return readdirSync(dir)
    .filter(f => f.endsWith('.md'))
    .map(f => f.replace(/\.md$/, ''))
    .sort();
}

export function getReportDiagramPath(dir: string): string | null {
  const diagrams = join(dir, 'diagrams');
  return existsSync(diagrams) ? diagrams : null;
}
