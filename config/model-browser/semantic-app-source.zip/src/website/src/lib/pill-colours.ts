/**
 * Shared colour scheme for property characteristic pills.
 * Each key maps to Tailwind classes for bg, text, and border.
 * Used by: client-app.ts (listing cards), PropertyCard.astro, property detail page.
 */
export const PILL_COLOURS: Record<string, { bg: string; text: string; border: string }> = {
  required:          { bg: 'bg-amber-100',  text: 'text-amber-700',  border: 'border-amber-200' },
  functional:        { bg: 'bg-sky-100',    text: 'text-sky-700',    border: 'border-sky-200' },
  inverseFunctional: { bg: 'bg-violet-100', text: 'text-violet-700', border: 'border-violet-200' },
  transitive:        { bg: 'bg-teal-100',   text: 'text-teal-700',   border: 'border-teal-200' },
  derived:           { bg: 'bg-indigo-100', text: 'text-indigo-700', border: 'border-indigo-200' },
};

/** Build the full class string for a characteristic pill. */
export function pillClass(key: string, extra = ''): string {
  const c = PILL_COLOURS[key];
  if (!c) return '';
  const base = `inline-flex items-center rounded px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider border ${c.bg} ${c.text} ${c.border}`;
  return extra ? `${base} ${extra}` : base;
}
