# src

Astro source tree for the HM ontology browser. All pages render ontology data from an N3 triple store loaded from the entailed RDF graph.

## Directories

| Directory | Description |
|-----------|-------------|
| `pages/` | Astro page routes (see below) |
| `components/` | Reusable Astro components: `DataTable`, `FacetSidebar`, `Pagination`, `ContextBadge`, `StatCard` |
| `layouts/` | `Base.astro` — shared HTML shell with Tailwind |
| `lib/` | Client-side TypeScript: RDF store, SPARQL playground, materializer, search, filtering, JSON-LD utils |
| `integrations/` | `export-entailed.ts` — Astro build hook that exports entailed triples from Fuseki to `public/` |
| `styles/` | `global.css` — Tailwind import |
| `partials/` | Reserved for HTMX partial templates (currently empty) |

## Pages

| Route | File | Description |
|-------|------|-------------|
| `/` | `index.astro` | Dashboard with ontology statistics |
| `/concepts/` | `concepts/index.astro` | Paginated concept listing with facet filters |
| `/concepts/[context]/[name]` | `concepts/[context]/[name].astro` | Concept detail (properties, hierarchy, facets) |
| `/properties/` | `properties/index.astro` | Property listing |
| `/properties/[context]/[name]` | `properties/[context]/[name].astro` | Property detail (domain, range, SHACL) |
| `/vocabularies/` | `vocabularies/index.astro` | SKOS vocabulary listing |
| `/vocabularies/[context]/[name]` | `vocabularies/[context]/[name].astro` | Vocabulary detail with members |
| `/subjects/` | `subjects/index.astro` | Subject area listing |
| `/subjects/[name]` | `subjects/[name].astro` | Subject area detail |
| `/modules/` | `modules/index.astro` | Ontology module listing |
| `/modules/[context]/[name]` | `modules/[context]/[name].astro` | Module detail |
| `/mappings/` | `mappings/index.astro` | Cross-domain SKOS mappings |
| `/search` | `search.astro` | Full-text search (MiniSearch) |
| `/sparql` | `sparql.astro` | SPARQL playground |
| `/api-docs` | `api-docs.astro` | REST API documentation |
| `/openapi.yaml` | `openapi.yaml.ts` | OpenAPI spec endpoint |
