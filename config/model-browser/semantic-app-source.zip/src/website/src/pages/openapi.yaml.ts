import type { APIRoute } from 'astro';

export const GET: APIRoute = async () => {
  const API_BASE = import.meta.env.API_URL || 'http://localhost:3000';
  const res = await fetch(`${API_BASE}/openapi.yaml`);
  const body = await res.text();
  return new Response(body, {
    headers: { 'Content-Type': 'text/yaml', 'Cache-Control': 'public, max-age=3600' },
  });
};
