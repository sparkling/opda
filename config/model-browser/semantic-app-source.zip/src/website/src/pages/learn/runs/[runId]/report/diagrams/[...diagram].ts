import type { APIRoute } from 'astro';
import { resolveReport, getReportDiagramPath } from '../../../../../../lib/report-resolver';
import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

export const prerender = false;

const MIME: Record<string, string> = {
  svg: 'image/svg+xml',
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
};

export const GET: APIRoute = ({ params }) => {
  const { runId, diagram } = params;
  if (!runId || !diagram) return new Response('Not found', { status: 404 });

  const report = resolveReport(runId);
  if (!report) return new Response('Not found', { status: 404 });

  const diagramDir = getReportDiagramPath(report.dir);
  if (!diagramDir) return new Response('Not found', { status: 404 });

  if (diagram.includes('..')) return new Response('Forbidden', { status: 403 });
  const filepath = join(diagramDir, diagram);
  if (!existsSync(filepath)) return new Response('Not found', { status: 404 });

  const content = readFileSync(filepath);
  const ext = diagram.split('.').pop()?.toLowerCase() || '';

  return new Response(content, {
    headers: {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': 'public, max-age=3600',
    },
  });
};
