export const prerender = false;
import type { APIRoute } from 'astro';
import { apiFetch } from '../../lib/api';
import { toXML } from '../../lib/export-helpers';

export const GET: APIRoute = async ({ url }) => {
  const page = url.searchParams.get('page') || '1';
  const pageSize = url.searchParams.get('pageSize') || '25';
  const data = await apiFetch(`/properties?page=${page}&pageSize=${pageSize}`);
  const items = data.items || [];
  const xml = ['<?xml version="1.0" encoding="UTF-8"?>', '<properties>'];
  for (const item of items) xml.push(toXML(item, 'property').replace(/^<\?xml[^>]*\?>\n/, ''));
  xml.push('</properties>');
  return new Response(xml.join('\n'), {
    headers: { 'Content-Type': 'application/xml' },
  });
};
