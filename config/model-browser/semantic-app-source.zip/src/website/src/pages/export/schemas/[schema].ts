import type { APIRoute, GetStaticPaths } from 'astro';
import { apiText } from '../../../lib/api';

const SCHEMAS = [
  'concept-detail.schema.json',
  'concept-detail.xsd',
  'concept-listing.schema.json',
  'concept-listing.xsd',
  'property-detail.schema.json',
  'property-detail.xsd',
  'property-listing.schema.json',
  'property-listing.xsd',
];

export const getStaticPaths: GetStaticPaths = async () =>
  SCHEMAS.map(s => ({ params: { schema: s } }));

export const GET: APIRoute = async ({ params }) => {
  const body = await apiText(`/schemas/${params.schema}`, params.schema!.endsWith('.json') ? 'application/json' : 'application/xml');
  const ct = params.schema!.endsWith('.json') ? 'application/json' : 'application/xml';
  return new Response(body, { headers: { 'Content-Type': ct } });
};
