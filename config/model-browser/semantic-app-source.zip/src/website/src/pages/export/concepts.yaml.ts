export const prerender = false;
import type { APIRoute } from 'astro';
import { apiFetch } from '../../lib/api';
import { toYAML } from '../../lib/export-helpers';

export const GET: APIRoute = async ({ url }) => {
  const page = url.searchParams.get('page') || '1';
  const pageSize = url.searchParams.get('pageSize') || '25';
  const data = await apiFetch(`/concepts?page=${page}&pageSize=${pageSize}`);
  return new Response(toYAML(data), {
    headers: { 'Content-Type': 'application/yaml' },
  });
};
