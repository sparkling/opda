export const prerender = false;
import type { APIRoute } from 'astro';
import { apiFetch } from '../../lib/api';

export const GET: APIRoute = async ({ url }) => {
  const page = url.searchParams.get('page') || '1';
  const pageSize = url.searchParams.get('pageSize') || '25';
  const data = await apiFetch(`/properties?page=${page}&pageSize=${pageSize}`);
  return new Response(JSON.stringify(data, null, 2), {
    headers: { 'Content-Type': 'application/json' },
  });
};
