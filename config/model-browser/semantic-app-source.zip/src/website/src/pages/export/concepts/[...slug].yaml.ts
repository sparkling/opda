import type { APIRoute, GetStaticPaths } from 'astro';
import { apiFetch } from '../../../lib/api';
import { getConceptPaths, toYAML } from '../../../lib/export-helpers';

export const getStaticPaths: GetStaticPaths = async () => getConceptPaths();

export const GET: APIRoute = async ({ props }) => {
  const data = await apiFetch(`/concepts/${encodeURIComponent((props as any).context)}/${encodeURIComponent((props as any).name)}`);
  return new Response(toYAML(data), {
    headers: { 'Content-Type': 'application/yaml' },
  });
};
