export const prerender = false;
import type { APIRoute } from 'astro';
import { apiFetch } from '../../lib/api';

export const GET: APIRoute = async ({ url }) => {
  const page = url.searchParams.get('page') || '1';
  const pageSize = url.searchParams.get('pageSize') || '25';
  const data = await apiFetch(`/properties?page=${page}&pageSize=${pageSize}`);
  const items = data.items || [];
  if (items.length === 0) return new Response('', { headers: { 'Content-Type': 'text/csv' } });
  const keys = Object.keys(items[0]);
  const header = keys.map(k => `"${k}"`).join(',');
  const rows = items.map((item: any) => keys.map(k => {
    const v = item[k];
    const s = Array.isArray(v) ? v.join('; ') : String(v ?? '');
    return `"${s.replace(/"/g, '""')}"`;
  }).join(','));
  return new Response([header, ...rows].join('\n'), {
    headers: { 'Content-Type': 'text/csv', 'Content-Disposition': 'attachment; filename="properties.csv"' },
  });
};
