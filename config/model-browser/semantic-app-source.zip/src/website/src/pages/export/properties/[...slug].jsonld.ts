import type { APIRoute, GetStaticPaths } from 'astro';
import { apiFetch } from '../../../lib/api';
import { getPropertyPaths } from '../../../lib/export-helpers';

export const getStaticPaths: GetStaticPaths = async () => getPropertyPaths();

export const GET: APIRoute = async ({ props }) => {
  const data = await apiFetch(`/properties/${encodeURIComponent((props as any).context)}/${encodeURIComponent((props as any).name)}`);
  return new Response(JSON.stringify(data, null, 2), {
    headers: { 'Content-Type': 'application/ld+json' },
  });
};
