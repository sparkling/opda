import type { APIRoute, GetStaticPaths } from 'astro';
import { apiFetch } from '../../../lib/api';
import { getConceptPaths, toXML } from '../../../lib/export-helpers';

export const getStaticPaths: GetStaticPaths = async () => getConceptPaths();

export const GET: APIRoute = async ({ props }) => {
  const data = await apiFetch(`/concepts/${encodeURIComponent((props as any).context)}/${encodeURIComponent((props as any).name)}`);
  const graph = data?.['@graph'] || [data];
  const node = graph.find((n: any) => n['@id'] && !String(n['@id']).startsWith('_:')) || graph[0] || {};
  return new Response(toXML(node, 'concept'), {
    headers: { 'Content-Type': 'application/xml' },
  });
};
