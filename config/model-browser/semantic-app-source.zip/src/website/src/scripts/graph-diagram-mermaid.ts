// @ts-nocheck
/**
 * Mermaid view for the unified GraphDiagram (ADR-0190).
 *
 * The interaction shell — ELK flowchart render, pan/zoom with a live % label,
 * 2-phase Navigate/Explore, hover highlight, strict-CSP click-to-navigate, theme
 * sync — is factored from scripts/ontology-diagram.ts (subjects/subdivision) so
 * boundary diagrams, subject diagrams and the relationship graph all share ONE
 * implementation. The only generalisation: the light Mermaid source and its
 * light/dark classDef + themeVar palettes are supplied by the caller, instead of
 * being TTL-generated and hard-coded.
 */

export interface MermaidViewOpts {
  wrapper: HTMLElement;
  viewport: HTMLElement;        // .diagram-viewport (pan/zoom surface)
  canvas: HTMLElement;          // .diagram-canvas (transformed)
  pre: HTMLElement;             // .gd-mermaid (mermaid renders here)
  getLightSource: () => string; // resolved light-mode mermaid source
  getEdgeMeta?: () => Array<{ kind: string; propHref: string }>; // per-edge, source order
  classDefsLight: string[];
  classDefsDark: string[];
  themeVarsLight: Record<string, string>;
  themeVarsDark: Record<string, string>;
}

export interface MermaidView {
  render: () => void;
  initControls: () => void;
  readonly rendered: boolean;
}

let mermaidMod: any = null;
function loadMermaid() {
  if (mermaidMod) return Promise.resolve(mermaidMod);
  return Promise.all([import('mermaid'), import('@mermaid-js/layout-elk')]).then((mods) => {
    mermaidMod = mods[0].default;
    mermaidMod.registerLayoutLoaders(mods[1].default);
    return mermaidMod;
  });
}

const isDark = () => document.documentElement.getAttribute('data-theme') === 'dark';

export function createMermaidView(opts: MermaidViewOpts): MermaidView {
  const { wrapper, viewport, canvas, pre } = opts;

  let scale = 1, panX = 0, panY = 0;
  const MIN = 0.1, MAX = 5, ZOOM_BTN = 1.2;
  let dragging = false, didDrag = false, dsx = 0, dsy = 0, psx = 0, psy = 0;
  let mode: 'navigate' | 'explore' = 'navigate';
  let lockedNode: string | null = null;
  let didRender = false;

  function applyTransform() {
    canvas.style.transform = `translate(${panX}px,${panY}px) scale(${scale})`;
    const label = wrapper.querySelector('.diagram-zoom-label');
    if (label) label.textContent = Math.round(scale * 100) + '%';
  }
  function resetView() { scale = 1; panX = 0; panY = 0; applyTransform(); }
  function zoom(factor: number, cx?: number, cy?: number) {
    const rect = viewport.getBoundingClientRect();
    const px = cx ?? rect.width / 2;
    const py = cy ?? rect.height / 2;
    const old = scale;
    scale = Math.min(MAX, Math.max(MIN, scale * factor));
    const ratio = scale / old;
    panX = px - ratio * (px - panX);
    panY = py - ratio * (py - panY);
    applyTransform();
  }

  function render() {
    const lightSource = opts.getLightSource();
    if (!lightSource) return;
    loadMermaid().then((mermaid) => {
      const dark = isDark();
      let src = lightSource;
      if (dark) for (let i = 0; i < opts.classDefsLight.length; i++) src = src.replace(opts.classDefsLight[i], opts.classDefsDark[i]);
      pre.removeAttribute('data-processed');
      pre.textContent = src;
      mermaid.initialize({
        startOnLoad: false,
        securityLevel: 'strict',
        theme: 'base',
        themeVariables: dark ? opts.themeVarsDark : opts.themeVarsLight,
        flowchart: { htmlLabels: true, curve: 'basis' },
      });
      mermaid
        .run({ nodes: [pre] })
        .then(() => { wrapper.querySelector('.diagram-loading')?.remove(); didRender = true; initHoverHighlight(); })
        .catch((e: any) => console.error('[graph-diagram] mermaid render', e));
    });
  }

  function initHoverHighlight() {
    const svg = pre.querySelector('svg');
    if (!svg) return;
    const lightSource = opts.getLightSource();

    const edgeList: { source: string; target: string }[] = [];
    const re = /^\s*(\w+)\s+[-.]+->\|?[^|]*\|?\s*(\w+)/gm;
    let m: RegExpExecArray | null;
    while ((m = re.exec(lightSource)) !== null) edgeList.push({ source: m[1], target: m[2] });

    const nodeEdges: Record<string, number[]> = {};
    edgeList.forEach((e, i) => { (nodeEdges[e.source] ||= []).push(i); (nodeEdges[e.target] ||= []).push(i); });

    let edgePaths = svg.querySelectorAll('.edgePaths > path.flowchart-link');
    if (edgePaths.length === 0) edgePaths = svg.querySelectorAll('.edgePaths path.flowchart-link');
    const edgeLabels = svg.querySelectorAll('.edgeLabels > .edgeLabel');
    // Property-edge labels link to the property detail page (concept-graph mode).
    const edgeMeta = opts.getEdgeMeta ? opts.getEdgeMeta() : [];
    edgeLabels.forEach((el, i) => { const href = edgeMeta[i]?.propHref; if (href) { (el as any)._gdHref = href; el.classList.add('gd-prop-link'); } });
    const nodes = svg.querySelectorAll('.node');
    const hi = isDark() ? '#FFA726' : '#F57F17';
    const DIM = '0.08';

    const nameOf = (el: Element) => { const mx = (el.id || '').match(/flowchart-(.+?)-\d+$/); return mx ? mx[1] : el.id || ''; };
    function applyHighlight(name: string) {
      const idx = nodeEdges[name] || [];
      const connected: Record<string, boolean> = { [name]: true };
      idx.forEach((i) => { connected[edgeList[i].source] = true; connected[edgeList[i].target] = true; });
      nodes.forEach((n) => { (n as HTMLElement).style.opacity = connected[nameOf(n)] ? '1' : DIM; });
      edgePaths.forEach((p, i) => {
        const el = p as HTMLElement;
        if (idx.indexOf(i) !== -1) { el.style.opacity = '1'; el.style.stroke = hi; el.style.strokeWidth = '3px'; el.style.filter = `drop-shadow(0 0 3px ${hi})`; }
        else el.style.opacity = DIM;
      });
      edgeLabels.forEach((el, i) => { (el as HTMLElement).style.opacity = idx.indexOf(i) !== -1 ? '1' : DIM; });
    }
    function clearHighlight() {
      nodes.forEach((n) => { (n as HTMLElement).style.opacity = ''; });
      edgePaths.forEach((p) => { const el = p as HTMLElement; el.style.opacity = ''; el.style.stroke = ''; el.style.strokeWidth = ''; el.style.filter = ''; });
      edgeLabels.forEach((el) => { (el as HTMLElement).style.opacity = ''; });
    }

    const urls: Record<string, string> = {};
    const cre = /^\s*click\s+(\w+)\s+"([^"]+)"/gm;
    let cm: RegExpExecArray | null;
    while ((cm = cre.exec(lightSource)) !== null) urls[cm[1]] = cm[2];

    svg.addEventListener('click', (evt) => {
      if (didDrag) { didDrag = false; return; }
      // Mermaid nests a <span class="edgeLabel"> inside the outer <g class="edgeLabel">;
      // match the .gd-prop-link we tagged (which carries _gdHref), not the inner span.
      const labelEl = (evt.target as Element).closest('.gd-prop-link') as any;
      if (labelEl && labelEl._gdHref) { evt.preventDefault(); evt.stopPropagation(); window.location.href = labelEl._gdHref; return; }
      const nodeEl = (evt.target as Element).closest('.node');
      if (mode === 'navigate') {
        if (nodeEl) { const url = urls[nameOf(nodeEl)]; if (url) { evt.preventDefault(); evt.stopPropagation(); window.location.href = url; } }
        return;
      }
      if (nodeEl) {
        evt.preventDefault(); evt.stopPropagation();
        const n = nameOf(nodeEl);
        if (lockedNode === n) { lockedNode = null; clearHighlight(); } else { lockedNode = n; applyHighlight(n); }
      } else if (lockedNode) { lockedNode = null; clearHighlight(); }
    }, true);

    nodes.forEach((node) => {
      (node as HTMLElement).style.cursor = 'pointer';
      node.addEventListener('mouseenter', () => { if (dragging || lockedNode) return; applyHighlight(nameOf(node)); });
      node.addEventListener('mouseleave', () => { if (lockedNode) return; clearHighlight(); });
    });
  }

  function initControls() {
    wrapper.querySelectorAll('[data-diagram-action]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const a = btn.getAttribute('data-diagram-action');
        if (a === 'zoom-in') zoom(ZOOM_BTN);
        else if (a === 'zoom-out') zoom(1 / ZOOM_BTN);
        else if (a === 'reset') resetView();
        else if (a === 'toggle-mode') toggleMode();
      });
    });

    function toggleMode() {
      const label = wrapper.querySelector('.diagram-mode-label');
      const icon = wrapper.querySelector('.diagram-mode-icon');
      const toggle = wrapper.querySelector('.diagram-mode-toggle');
      if (mode === 'navigate') {
        mode = 'explore';
        if (label) label.textContent = 'Explore';
        if (icon) icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />';
        if (toggle) { toggle.classList.add('bg-amber-100', 'text-amber-700'); toggle.classList.remove('text-gray-500'); }
      } else {
        mode = 'navigate'; lockedNode = null;
        if (label) label.textContent = 'Navigate';
        if (icon) icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M13.5 6H5.25A2.25 2.25 0 003 8.25v10.5A2.25 2.25 0 005.25 21h10.5A2.25 2.25 0 0018 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25" />';
        if (toggle) { toggle.classList.remove('bg-amber-100', 'text-amber-700'); toggle.classList.add('text-gray-500'); }
        const svg = pre.querySelector('svg');
        if (svg) {
          svg.querySelectorAll('.node').forEach((n) => { (n as HTMLElement).style.opacity = ''; });
          svg.querySelectorAll('path.flowchart-link').forEach((p) => { const el = p as HTMLElement; el.style.opacity = ''; el.style.stroke = ''; el.style.strokeWidth = ''; el.style.filter = ''; });
          svg.querySelectorAll('.edgeLabel').forEach((el) => { (el as HTMLElement).style.opacity = ''; });
        }
      }
    }

    let nudgeTimer: any = null;
    function nudge() { wrapper.classList.add('zoom-nudge'); if (nudgeTimer) clearTimeout(nudgeTimer); nudgeTimer = setTimeout(() => wrapper.classList.remove('zoom-nudge'), 900); }
    viewport.addEventListener('wheel', (e) => {
      if (!(e.ctrlKey || e.metaKey)) { nudge(); return; }
      e.preventDefault();
      const rect = viewport.getBoundingClientRect();
      const factor = Math.min(1.18, Math.max(0.85, Math.exp(-e.deltaY * 0.0012)));
      zoom(factor, e.clientX - rect.left, e.clientY - rect.top);
    }, { passive: false });

    viewport.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      if ((e.target as Element).closest('.node') && mode === 'navigate') return;
      dragging = true; didDrag = false; dsx = e.clientX; dsy = e.clientY; psx = panX; psy = panY;
      viewport.style.cursor = 'grabbing'; e.preventDefault();
    });
    window.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      const dx = e.clientX - dsx, dy = e.clientY - dsy;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) didDrag = true;
      panX = psx + dx; panY = psy + dy; applyTransform();
    });
    window.addEventListener('mouseup', () => { if (dragging) { dragging = false; viewport.style.cursor = 'grab'; } });

    let lastTouches: TouchList | null = null;
    viewport.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) { dragging = true; dsx = e.touches[0].clientX; dsy = e.touches[0].clientY; psx = panX; psy = panY; }
      lastTouches = e.touches;
    }, { passive: true });
    viewport.addEventListener('touchmove', (e) => {
      if (e.touches.length === 1 && dragging) {
        panX = psx + (e.touches[0].clientX - dsx); panY = psy + (e.touches[0].clientY - dsy); applyTransform(); e.preventDefault();
      } else if (e.touches.length === 2 && lastTouches && lastTouches.length === 2) {
        const od = Math.hypot(lastTouches[0].clientX - lastTouches[1].clientX, lastTouches[0].clientY - lastTouches[1].clientY);
        const nd = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
        const rect = viewport.getBoundingClientRect();
        const cx = (e.touches[0].clientX + e.touches[1].clientX) / 2 - rect.left;
        const cy = (e.touches[0].clientY + e.touches[1].clientY) / 2 - rect.top;
        if (od > 0) zoom(nd / od, cx, cy); lastTouches = e.touches; e.preventDefault();
      }
    }, { passive: false });
    viewport.addEventListener('touchend', () => { dragging = false; lastTouches = null; });

    // Live indicator: light up the Ctrl button while Ctrl/⌘ is held (zoom armed).
    const armZoom = (on: boolean) => {
      wrapper.classList.toggle('zoom-active', on);
      wrapper.querySelector('.gd-ctrl')?.setAttribute('aria-pressed', on ? 'true' : 'false');
    };
    const setZoomArmed = (e: KeyboardEvent) => armZoom(e.ctrlKey || e.metaKey);
    window.addEventListener('keydown', setZoomArmed);
    window.addEventListener('keyup', setZoomArmed);
    window.addEventListener('blur', () => armZoom(false));

    document.addEventListener('hm:theme-change', () => { if (didRender) render(); });
  }

  return { render, initControls, get rendered() { return didRender; } };
}
