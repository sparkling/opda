// @ts-nocheck
/**
 * Diagram engine (ADR-0190): one widget, a single Mermaid diagram
 * (scripts/graph-diagram-mermaid, the subjects/subdivision shell —
 * pan/zoom with % indicator, Navigate/Explore, fullscreen, hover highlight).
 *
 * Source comes either statically (boundary diagrams, relationship graph — embedded
 * as JSON in `.gd-config`) or generated in-browser from the entailed TTL for a
 * subject area (subjects/subdivision). The subject path is dynamically imported so
 * static pages don't bundle the RDF store.
 */
import { createMermaidView } from './graph-diagram-mermaid';

const DEFAULT_TV_LIGHT = { background: '#ffffff', lineColor: '#64748b', textColor: '#1e293b', primaryColor: '#f1f5f9', primaryBorderColor: '#94a3b8', primaryTextColor: '#1e293b', fontSize: '14px', fontFamily: '-apple-system,Segoe UI,Roboto,sans-serif' };
const DEFAULT_TV_DARK = { background: '#0b0f17', lineColor: '#94a3b8', textColor: '#e2e8f0', primaryColor: '#1f2937', primaryBorderColor: '#6b7280', primaryTextColor: '#e2e8f0', fontSize: '14px', fontFamily: '-apple-system,Segoe UI,Roboto,sans-serif' };

export function mountGraphDiagrams() {
  document.querySelectorAll('.graph-diagram-wrapper').forEach((w) => {
    if ((w as any)._gdMounted) return;
    (w as any)._gdMounted = true;
    setupWrapper(w as HTMLElement);
  });
}

function setupWrapper(wrapper: HTMLElement) {
  let config: any = {};
  try { config = JSON.parse(wrapper.querySelector('.gd-config')?.textContent || '{}'); } catch { /* ignore */ }

  const viewportMermaid = wrapper.querySelector('.diagram-viewport') as HTMLElement | null;
  const canvas = wrapper.querySelector('.diagram-canvas') as HTMLElement | null;
  const pre = wrapper.querySelector('.gd-mermaid') as HTMLElement | null;
  if (!viewportMermaid || !canvas || !pre) return;

  let classDefsLight: string[] = config.classDefsLight || [];
  let classDefsDark: string[] = config.classDefsDark || [];
  let themeVarsLight = config.themeVarsLight || DEFAULT_TV_LIGHT;
  let themeVarsDark = config.themeVarsDark || DEFAULT_TV_DARK;

  let mermaidView: any = null;
  let lightSource = '';
  let edgeMeta: Array<{ kind: string; propHref: string }> = [];
  // Edge-category filter, remembered across detail pages (localStorage).
  // Boundary (context) graphs keep their own key and default attributes OFF — a
  // whole bounded context has many datatype properties, so rendering every
  // literal node on first load would overwhelm; per-concept graphs default all-on.
  const isContextGraph = config.mode === 'concept-graph' && !!config.context;
  const FILTER_KEY = isContextGraph ? 'hm-graph-edge-filter-context' : 'hm-graph-edge-filter';
  const loadFilter = () => {
    try {
      const s = JSON.parse(localStorage.getItem(FILTER_KEY) || 'null');
      if (s && typeof s === 'object') return { hierarchy: s.hierarchy !== false, object: s.object !== false, datatype: s.datatype !== false };
    } catch { /* ignore */ }
    return { hierarchy: true, object: true, datatype: !isContextGraph };
  };
  const filter = loadFilter();
  const saveFilter = () => { try { localStorage.setItem(FILTER_KEY, JSON.stringify(filter)); } catch { /* ignore */ } };
  let cg: any = null; // concept-graph module (lazy)
  let graphObj: any = null; // ConceptGraph for concept-graph mode (embedded, or built from the store for a boundary)

  /** Rebuild the concept-graph source for the current filter (sync, after cg + graphObj ready). */
  function buildConceptGraph(): string {
    const built = cg.conceptGraphToMermaid(graphObj, config.focusId || '', filter);
    edgeMeta = built.edges;
    return built.source as string;
  }

  async function resolveSource(): Promise<string> {
    if (config.mode === 'subject') {
      const [rs, mat, src] = await Promise.all([
        import('../lib/rdf-store'),
        import('../lib/materialize'),
        import('../lib/ontology-diagram-source'),
      ]);
      const store = await rs.getStore();
      const data = mat.materialize(store);
      const built = src.buildSubjectDiagramSource(store, data, config.subjectArea || '', 'light');
      classDefsLight = src.LIGHT_CLASSDEFS; classDefsDark = src.DARK_CLASSDEFS;
      themeVarsLight = src.LIGHT_THEMEVARS; themeVarsDark = src.DARK_THEMEVARS;
      return built ? built.source : '';
    }
    if (config.mode === 'concept-graph') {
      cg = await import('../lib/descriptors/concept-graph');
      if (config.context) {
        // Boundary diagram: build the whole-context graph in-browser from the
        // entailed TTL (the same store the subject diagram uses), then render it
        // through the concept-graph path.
        const [rs, mat, ctxg] = await Promise.all([
          import('../lib/rdf-store'),
          import('../lib/materialize'),
          import('../lib/descriptors/context-graph'),
        ]);
        graphObj = ctxg.buildContextGraph(mat.materialize(await rs.getStore()), config.context);
      } else {
        graphObj = config.graph;
      }
      return buildConceptGraph();
    }
    return config.source || '';
  }

  function toggleFullscreen() {
    const full = wrapper.classList.toggle('diagram-fullscreen');
    document.body.style.overflow = full ? 'hidden' : '';
  }

  // Empty state shown INSIDE the diagram box, so the action bar (toggles, zoom,
  // reset, fullscreen) stays available — the only way to re-enable a hidden edge
  // category or reset the view on an otherwise-empty page.
  function showEmpty() {
    wrapper.querySelector('.diagram-loading')?.remove();
    pre.removeAttribute('data-processed');
    const isCg = config.mode === 'concept-graph';
    const allOff = isCg && !filter.hierarchy && !filter.object && !filter.datatype;
    const someOff = isCg && (!filter.hierarchy || !filter.object || !filter.datatype);
    const msg = allOff
      ? 'Select an edge type to display.'
      : someOff
        ? 'No relationships for the selected edge types — enable more above.'
        : 'No relationships available to diagram.';
    pre.innerHTML = `<span class="block px-2 py-10 text-center text-sm text-gray-400">${msg}</span>`;
  }

  async function boot() {
    lightSource = await resolveSource();
    const getSource = () => lightSource;
    const getEdgeMeta = () => edgeMeta;
    mermaidView = createMermaidView({ wrapper, viewport: viewportMermaid, canvas, pre, getLightSource: getSource, getEdgeMeta, classDefsLight, classDefsDark, themeVarsLight, themeVarsDark });

    wrapper.querySelectorAll('[data-diagram-action="fullscreen"]').forEach((b) => b.addEventListener('click', toggleFullscreen));
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && wrapper.classList.contains('diagram-fullscreen')) toggleFullscreen(); });

    // Filter toggles (concept-graph): reflect the persisted state, then flip + save on click.
    wrapper.querySelectorAll('[data-gd-toggle]').forEach((b) => {
      const cat = b.getAttribute('data-gd-toggle') as keyof typeof filter;
      b.setAttribute('aria-pressed', filter[cat] ? 'true' : 'false');
      b.addEventListener('click', () => {
        const next = b.getAttribute('aria-pressed') !== 'true';
        b.setAttribute('aria-pressed', next ? 'true' : 'false');
        filter[cat] = next;
        saveFilter();
        lightSource = buildConceptGraph();
        if (lightSource) mermaidView.render();
        else showEmpty();
      });
    });

    mermaidView.initControls();
    if (lightSource) mermaidView.render();
    else showEmpty();
  }

  // Lazy boot when scrolled near; immediate check + scroll/resize fallback so it
  // still boots when already on screen (and where IntersectionObserver is flaky).
  let booted = false;
  const inView = () => { const r = wrapper.getBoundingClientRect(); return r.top < window.innerHeight + 300 && r.bottom > -300 && r.width > 0; };
  function tryBoot() {
    if (booted || !inView()) return;
    booted = true;
    io.disconnect();
    window.removeEventListener('scroll', tryBoot);
    window.removeEventListener('resize', tryBoot);
    boot().catch((err) => console.error('[graph-diagram] boot failed', err));
  }
  const io = new IntersectionObserver((entries) => { if (entries.some((e) => e.isIntersecting)) tryBoot(); }, { rootMargin: '300px' });
  io.observe(wrapper);
  window.addEventListener('scroll', tryBoot, { passive: true });
  window.addEventListener('resize', tryBoot, { passive: true });
  tryBoot();
}
