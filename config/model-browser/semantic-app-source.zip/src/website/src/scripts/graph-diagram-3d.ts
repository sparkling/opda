// @ts-nocheck
/**
 * 3D force-directed view for the unified GraphDiagram (ADR-0190).
 *
 * Ported from the concept-details relationship graph: `3d-force-graph` (three.js)
 * + `three-spritetext` camera-facing labels, lazy-loaded on first show. The graph
 * is parsed from the SAME Mermaid source the Diagram view renders
 * (parseMermaidGraph), so node/edge colours stay consistent across both views.
 *
 * A single shared three.js instance is enforced via window.THREE (three-forcegraph
 * prefers it) so SpriteText labels render in the force-graph scene.
 */
import { parseMermaidGraph } from '../lib/mermaid-graph';
import type { ParsedGraph } from '../lib/mermaid-graph';

const isDark = () => document.documentElement.getAttribute('data-theme') === 'dark';
const bgColor = () => (isDark() ? '#0b0f17' : '#ffffff');
const labelColor = () => (isDark() ? '#e2e8f0' : '#1e293b');
const dimColor = () => (isDark() ? 'rgba(148,163,184,0.12)' : 'rgba(100,116,139,0.12)');

export interface ForceView {
  mount: () => void;
  fit: () => void;
  resize: () => void;
  retheme: () => void;
  readonly mounted: boolean;
}

/** Create the 3D force view bound to `viewport`; `getSource()` returns the light Mermaid source. */
export function createForceView(viewport: HTMLElement, getSource: () => string): ForceView {
  let fg: any = null;
  let ForceGraph3D: any = null;
  let SpriteText: any = null;
  let mounting = false;
  let hoverId: string | null = null;
  let graph: ParsedGraph = { nodes: [], links: [] };
  const neighbours = new Map<string, Set<string>>();

  const endId = (e: any) => (typeof e === 'object' && e ? e.id : e);
  const nodeVisible = (n: any) => !hoverId || neighbours.get(hoverId)?.has(n.id);
  const linkVisible = (l: any) => !hoverId || endId(l.source) === hoverId || endId(l.target) === hoverId;

  function nodeColor(n: any) { return nodeVisible(n) ? n.color : dimColor(); }
  function linkColor(l: any) { return linkVisible(l) ? l.color : dimColor(); }

  let big = false; // large graph → smaller spheres/labels
  function makeNodeObject(n: any) {
    const s = new SpriteText(n.label || n.id);
    s.color = nodeVisible(n) ? labelColor() : dimColor();
    s.textHeight = big ? 3 : n.focus ? 7 : 5;
    s.fontWeight = n.focus ? '700' : '400';
    return s;
  }

  function repaint() {
    if (!fg) return;
    fg.nodeColor(nodeColor).linkColor(linkColor).nodeThreeObject(makeNodeObject);
  }

  function render() {
    const N = Math.max(graph.nodes.length, 1);
    big = N > 40;
    const R = Math.min(420, 60 + Math.sqrt(N) * 24);
    // Deterministic initial spread (fibonacci sphere) so the layout never starts
    // collapsed (which makes zoomToFit over-zoom and spheres fill the frame).
    graph.nodes.forEach((n: any, i: number) => {
      if (n.focus && N > 1) { n.x = 0; n.y = 0; n.z = 0; return; }
      const k = i + 0.5;
      const phi = Math.acos(Math.max(-1, Math.min(1, 1 - (2 * k) / N)));
      const theta = Math.PI * (1 + Math.sqrt(5)) * k;
      n.x = R * Math.cos(theta) * Math.sin(phi);
      n.y = R * Math.sin(theta) * Math.sin(phi);
      n.z = R * Math.cos(phi);
    });

    fg = new ForceGraph3D(viewport)
      .width(viewport.clientWidth || 800)
      .height(viewport.clientHeight || 480)
      .backgroundColor(bgColor())
      .graphData(graph)
      .nodeId('id')
      .nodeVal((n: any) => (n.focus ? 6 : 2))
      .nodeRelSize(big ? 2 : 3)
      .nodeColor(nodeColor)
      .nodeLabel((n: any) => (n.label || n.id).replace(/\n/g, ' '))
      .nodeThreeObject(makeNodeObject)
      .nodeThreeObjectExtend(true)
      .linkColor(linkColor)
      .linkWidth((l: any) => (linkVisible(l) ? 1.2 : 0.4))
      .linkLabel((l: any) => l.label || '')
      .linkDirectionalArrowLength(3.5)
      .linkDirectionalArrowRelPos(1)
      .onNodeHover((n: any) => {
        const id = n ? n.id : null;
        if (id === hoverId) return;
        hoverId = id;
        viewport.style.cursor = n ? 'pointer' : 'grab';
        repaint();
      })
      .onNodeClick((n: any) => { if (n && n.href) window.location.href = n.href; })
      .onBackgroundClick(() => { if (hoverId) { hoverId = null; repaint(); } });

    try {
      fg.d3Force('charge').strength(big ? -120 : -260);
      const lf = fg.d3Force('link');
      if (lf) lf.distance(big ? 60 : 110);
    } catch { /* forces optional */ }

    fg.cameraPosition({ z: R * 1.8 });
    let fitted = false;
    const fit = () => { if (fg) fg.zoomToFit(600, 90); };
    fg.onEngineStop(() => { if (!fitted) { fitted = true; fit(); } });
    setTimeout(fit, 2000);
  }

  function buildNeighbours() {
    neighbours.clear();
    graph.nodes.forEach((n) => neighbours.set(n.id, new Set([n.id])));
    graph.links.forEach((l) => {
      neighbours.get(l.source as string)?.add(l.target as string);
      neighbours.get(l.target as string)?.add(l.source as string);
    });
  }

  async function mount() {
    if (fg || mounting) return;
    if (!viewport.clientWidth) return; // hidden / zero-size — wait until shown
    const src = getSource();
    if (!src) return;
    mounting = true;
    graph = parseMermaidGraph(src);
    buildNeighbours();
    try {
      const three = await import('three');
      (window as any).THREE = three;
      const [fgMod, stMod] = await Promise.all([import('3d-force-graph'), import('three-spritetext')]);
      ForceGraph3D = fgMod.default;
      SpriteText = stMod.default;
      render();
    } catch (err) {
      mounting = false;
      console.error('[graph-diagram] 3D engine failed to load', err);
    }
  }

  return {
    mount,
    fit() { if (fg) fg.zoomToFit(500, 80); },
    resize() { if (fg) fg.width(viewport.clientWidth || 800).height(viewport.clientHeight || 480); },
    retheme() { if (fg) { fg.backgroundColor(bgColor()); repaint(); } },
    get mounted() { return !!fg; },
  };
}
