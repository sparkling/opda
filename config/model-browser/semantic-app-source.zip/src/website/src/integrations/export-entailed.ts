import type { AstroIntegration } from 'astro';
import { writeFile } from 'node:fs/promises';
import { join } from 'node:path';

export default function exportEntailed(): AstroIntegration {
  return {
    name: 'export-entailed',
    hooks: {
      'astro:build:start': async ({ logger }) => {
        const fusekiUrl = process.env.FUSEKI_URL || 'http://localhost:3030';
        const dataset = process.env.FUSEKI_DATASET || 'hm';
        const output = join(process.cwd(), 'public', 'ontology-entailed.ttl');

        logger.info(`Exporting entailed graph from ${fusekiUrl}/${dataset}...`);

        const query = `
          CONSTRUCT { ?s ?p ?o }
          WHERE {
            {
              ?s ?p ?o .
              FILTER(
                STRSTARTS(STR(?s), "https://hm.com/ns/") ||
                STRSTARTS(STR(?s), "urn:hm:")
              )
              FILTER(!STRSTARTS(STR(?p), "http://jena.hpl.hp.com/"))
            } UNION {
              ?s ?p ?o .
              FILTER(isBlank(?s))
              ?parent <http://www.w3.org/ns/shacl#property> ?s .
              FILTER(STRSTARTS(STR(?parent), "https://hm.com/ns/"))
            }
          }`;

        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 30_000);

        try {
          const res = await fetch(`${fusekiUrl}/${dataset}/sparql`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
              'Accept': 'text/turtle',
            },
            body: new URLSearchParams({ query }),
            signal: controller.signal,
          });

          if (!res.ok) {
            throw new Error(`Fuseki export failed: ${res.status} ${res.statusText}`);
          }

          const contentType = res.headers.get('content-type') || '';
          if (!contentType.includes('turtle') && !contentType.includes('n-triples')) {
            logger.warn(`Unexpected Content-Type: ${contentType} (expected text/turtle)`);
          }

          const ttl = await res.text();
          if (ttl.length < 100) {
            throw new Error(`Fuseki returned near-empty response (${ttl.length} bytes) — check dataset`);
          }

          await writeFile(output, ttl, 'utf-8');
          logger.info(`Wrote ${output} (${(ttl.length / 1024).toFixed(0)} KB)`);
        } finally {
          clearTimeout(timeout);
        }
      },
    },
  };
}
