/**
 * Shared phase rendering module — single source of truth for both
 * Astro SSR and client-side DOM updates (ADR-0142 A21, Abramov).
 *
 * Eliminates SSR/client rendering divergence for duration, entered_at,
 * notes, provenance, sub-steps, and stale detection.
 */

// ── Types ────────────────────────────────────────────────────────────

export interface SubStep {
  slug: string;
  category_number?: number;
  tier?: number;
  state: string;
  entity_count?: number;
  triple_count?: number;
  notes?: string;
  artifact_path?: string;
  duration_ms?: number;
  cost_usd?: number;
  model_id?: string;
  provenance?: string;
}

export interface PhaseData {
  phase: string;
  state: string;
  entered_at?: string;
  completed_at?: string;
  result?: string;
  duration_ms?: number;
  tokens_used?: number;
  entity_count?: number;
  notes?: string;
  error?: string;
  provenance?: string;
  subSteps?: SubStep[];
}

export interface RenderOptions {
  isLast: boolean;
  heartbeatAt?: string | null;
}

// ── Constants ────────────────────────────────────────────────────────

export const PHASE_ORDER = [
  { slug: 'extract', label: 'Extract' },
  { slug: 'split', label: 'Split' },
  { slug: 'enrich', label: 'Enrich' },
  { slug: 'review', label: 'Review' },
  { slug: 'schema-validate', label: 'Schema Validate' },
  { slug: 'map', label: 'Map' },
  { slug: 'validate', label: 'Validate' },
  { slug: 'golden-baseline', label: 'Golden Baseline' },
] as const;

const PHASE_LABELS: Record<string, string> = Object.fromEntries(
  PHASE_ORDER.map(p => [p.slug, p.label]),
);

const STATUS_CONFIG: Record<string, {
  dot: string; border: string; bg: string;
  badgeBg: string; badgeText: string; label: string;
}> = {
  completed: { dot: 'bg-green-500', border: 'border-green-200', bg: 'bg-white', badgeBg: 'bg-green-50', badgeText: 'text-green-700', label: 'Completed' },
  success:   { dot: 'bg-green-500', border: 'border-green-200', bg: 'bg-white', badgeBg: 'bg-green-50', badgeText: 'text-green-700', label: 'Completed' },
  running:   { dot: 'bg-blue-500 animate-pulse', border: 'border-blue-300 ring-1 ring-blue-100', bg: 'bg-blue-50/50', badgeBg: 'bg-blue-50', badgeText: 'text-blue-700', label: 'Running' },
  active:    { dot: 'bg-blue-500 animate-pulse', border: 'border-blue-300 ring-1 ring-blue-100', bg: 'bg-blue-50/50', badgeBg: 'bg-blue-50', badgeText: 'text-blue-700', label: 'Running' },
  partial:   { dot: 'bg-amber-500', border: 'border-amber-200', bg: 'bg-white', badgeBg: 'bg-amber-50', badgeText: 'text-amber-700', label: 'Partial' },
  failed:    { dot: 'bg-red-500', border: 'border-red-200', bg: 'bg-white', badgeBg: 'bg-red-50', badgeText: 'text-red-700', label: 'Failed' },
  error:     { dot: 'bg-red-500', border: 'border-red-200', bg: 'bg-white', badgeBg: 'bg-red-50', badgeText: 'text-red-700', label: 'Failed' },
  skipped:   { dot: 'bg-gray-300', border: 'border-gray-200', bg: 'bg-white', badgeBg: 'bg-gray-50', badgeText: 'text-gray-500', label: 'Skipped' },
  pending:   { dot: 'bg-gray-200', border: 'border-dashed border-gray-200', bg: 'bg-white', badgeBg: 'bg-gray-50', badgeText: 'text-gray-400', label: 'Pending' },
};

const DEFAULT_STATUS = STATUS_CONFIG.pending;

// ── Shared helpers ───────────────────────────────────────────────────

/** Resolve phase slug to human-readable label. */
export function phaseLabel(slug: string): string {
  return PHASE_LABELS[slug]
    ?? slug.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}

/** Compute duration in ms — prefers duration_ms, falls back to timestamps. */
export function computeDurationMs(p: PhaseData): number | null {
  if (p.duration_ms != null && p.duration_ms > 0) return p.duration_ms;
  if (p.entered_at && p.completed_at) {
    const diff = new Date(p.completed_at).getTime() - new Date(p.entered_at).getTime();
    return diff > 0 ? diff : null;
  }
  return null;
}

/** Format ms as human-readable "Xm Ys". */
export function formatDuration(ms: number | null): string {
  if (ms == null || ms <= 0) return '--';
  if (ms < 1000) return `${ms}ms`;
  const secs = Math.floor(ms / 1000);
  if (secs < 60) return `${secs}s`;
  const mins = Math.floor(secs / 60);
  const rem = secs % 60;
  return rem > 0 ? `${mins}m ${rem}s` : `${mins}m`;
}

/** Escape HTML entities. */
export function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/** Detect whether a running phase is stale (>90s since last heartbeat). */
export function isStale(state: string, heartbeatAt?: string | null): boolean {
  if (state !== 'running' && state !== 'active') return false;
  if (!heartbeatAt) return false;
  return Date.now() - new Date(heartbeatAt).getTime() > 90_000;
}

// ── Phase card HTML ──────────────────────────────────────────────────

/** Render a single phase card as an HTML string. */
export function renderPhaseCardHtml(
  slug: string,
  data: PhaseData | null,
  opts: RenderOptions,
): string {
  const state = data?.state || 'pending';
  const isPending = state === 'pending' || state === 'not-started';
  const isFailed = state === 'failed' || state === 'error';
  const cfg = STATUS_CONFIG[state] || DEFAULT_STATUS;

  const label = phaseLabel(slug);
  const durationMs = data ? computeDurationMs(data) : null;
  const duration = formatDuration(durationMs);

  // Stale detection
  const stale = isStale(state, opts.heartbeatAt);
  const dotClass = stale ? 'bg-amber-500 animate-pulse' : cfg.dot;
  const badgeLabel = stale ? 'Stale' : cfg.label;
  const badgeClasses = stale
    ? 'bg-amber-50 text-amber-700'
    : `${cfg.badgeBg} ${cfg.badgeText}`;

  // Provenance badge
  const provenanceBadge = data?.provenance === 'inferred'
    ? '<span class="text-[10px] font-medium text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded ml-2">reconstructed</span>'
    : '';

  // Connecting line
  const lineHtml = !opts.isLast
    ? `<div class="absolute top-3 bottom-0 w-px ${isPending ? 'border-l border-dashed border-gray-200' : 'bg-gray-200'}" style="left: -12px;"></div>`
    : '';

  // Detail section: tokens, entities, started timestamp
  const detailParts: string[] = [];
  if (data?.tokens_used != null) {
    detailParts.push(`<div><span class="text-xs font-medium uppercase tracking-wider text-gray-400">Tokens</span><span class="ml-1.5">${data.tokens_used.toLocaleString()}</span></div>`);
  }
  if (data?.entity_count != null) {
    detailParts.push(`<div><span class="text-xs font-medium uppercase tracking-wider text-gray-400">Entities</span><span class="ml-1.5">${data.entity_count.toLocaleString()}</span></div>`);
  }
  if (data?.entered_at) {
    const ts = new Date(data.entered_at).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' });
    detailParts.push(`<div><span class="text-xs font-medium uppercase tracking-wider text-gray-400">Started</span><span class="ml-1.5 text-xs text-gray-500">${escapeHtml(ts)}</span></div>`);
  }
  let detailHtml = '';
  if (!isPending && detailParts.length > 0) {
    detailHtml = `<div class="border-t border-gray-100 px-4 py-3 text-sm"><div class="flex flex-wrap gap-4 text-gray-600">${detailParts.join('')}</div>`;
    if (data?.notes) {
      detailHtml += `<p class="mt-2 text-gray-600">${escapeHtml(data.notes)}</p>`;
    }
    detailHtml += '</div>';
  } else if (!isPending && data?.notes) {
    detailHtml = `<div class="border-t border-gray-100 px-4 py-3 text-sm"><p class="text-gray-600">${escapeHtml(data.notes)}</p></div>`;
  }

  // Error display
  const errorHtml = isFailed && data?.error
    ? `<div class="border-t border-red-100 bg-red-50/50 px-4 py-3"><p class="text-xs font-medium text-red-700">Error</p><pre class="mt-1 max-h-24 overflow-auto whitespace-pre-wrap text-xs text-red-600 font-mono">${escapeHtml(data.error.slice(0, 500))}</pre></div>`
    : '';

  // Sub-steps disclosure
  const subStepsHtml = data?.subSteps?.length
    ? renderSubStepsHtml(data.subSteps)
    : '';

  return `<div class="relative pb-5 ${isPending ? 'opacity-50' : ''}" role="listitem" data-phase-state="${escapeHtml(state)}">
    ${lineHtml}
    <div class="absolute -left-[18px] top-1.5 h-3 w-3 rounded-full ring-2 ring-white ${dotClass}"></div>
    <div class="rounded-lg border ${cfg.border} ${cfg.bg} shadow-sm ${isPending ? '' : 'hover:shadow-md'} transition-shadow">
      <div class="flex items-center gap-3 px-4 py-3 text-sm">
        <span class="font-medium ${isPending ? 'text-gray-400' : 'text-gray-900'}">${escapeHtml(label)}</span>
        <span class="ml-auto flex items-center gap-3">
          <span class="text-xs ${isPending ? 'text-gray-300' : 'text-gray-400'}">${duration}</span>
          <span class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${badgeClasses}">${badgeLabel}</span>
          ${provenanceBadge}
        </span>
      </div>
      ${detailHtml}
      ${errorHtml}
      ${subStepsHtml}
    </div>
  </div>`;
}

// ── Sub-steps HTML ───────────────────────────────────────────────────

function renderSubStepsHtml(subSteps: SubStep[]): string {
  const hasFailedSub = subSteps.some(s => s.state === 'failed');
  const showToggle = subSteps.length > 5 && hasFailedSub;

  const toggleHtml = showToggle
    ? `<label class="ml-auto flex items-center gap-1.5 text-[10px] text-gray-400 font-normal cursor-pointer" onclick="event.stopPropagation()"><input type="checkbox" class="si-failures-toggle h-3 w-3 rounded border-gray-300 text-red-500 focus:ring-red-400" /><span>failures only</span></label>`
    : '';

  const subRows = subSteps.map(sub => renderSubStepRow(sub)).join('');

  return `<details class="border-t border-gray-100"${hasFailedSub ? ' open' : ''}>
    <summary class="flex cursor-pointer items-center gap-2 px-4 py-2.5 text-xs font-medium text-gray-500 hover:text-gray-700 select-none">
      <svg class="h-3.5 w-3.5 transition-transform details-chevron" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" /></svg>
      ${subSteps.length} categories
      ${toggleHtml}
    </summary>
    <div class="divide-y divide-gray-50 px-4 pb-3 si-substep-list">${subRows}</div>
  </details>`;
}

function renderSubStepRow(sub: SubStep): string {
  const subState = sub.state || 'pending';
  const subDot = subState === 'completed' ? 'bg-green-400'
    : subState === 'failed' ? 'bg-red-400'
    : subState === 'partial' ? 'bg-amber-400'
    : subState === 'running' ? 'bg-blue-400'
    : 'bg-gray-300';
  const subLabel = escapeHtml(
    (sub.slug || '').replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
  );
  const tierBadge = sub.tier != null
    ? `<span class="text-[10px] font-medium text-gray-400 bg-gray-50 px-1.5 py-0.5 rounded">T${sub.tier}</span>`
    : '';
  const entityInfo = sub.entity_count != null
    ? `<span class="text-xs text-gray-400">${sub.entity_count} entities</span>`
    : '';
  const tripleInfo = sub.triple_count != null
    ? `<span class="text-xs text-gray-400">${sub.triple_count} triples</span>`
    : '';
  const costInfo = sub.cost_usd != null
    ? `<span class="text-xs text-gray-400">$${sub.cost_usd.toFixed(2)}</span>`
    : '';
  const modelInfo = sub.model_id
    ? `<span class="text-[10px] text-gray-400">${escapeHtml(sub.model_id)}</span>`
    : '';

  return `<div class="flex items-center gap-3 py-2 text-sm si-substep" data-sub-state="${escapeHtml(subState)}">
    <span class="inline-block h-2 w-2 rounded-full shrink-0 ${subDot}"></span>
    <span class="text-gray-700 min-w-0 truncate">${subLabel}</span>
    ${tierBadge}
    <span class="ml-auto flex items-center gap-2 shrink-0">${entityInfo}${tripleInfo}${costInfo}${modelInfo}</span>
  </div>`;
}

// ── Termination banner (A23) ────────────────────────────────────────

const TERMINATION_LABELS: Record<string, { label: string; detail: string }> = {
  cost_guard: { label: 'Cost Guard', detail: 'Run terminated because the cost guard threshold was exceeded.' },
  timeout: { label: 'Timeout', detail: 'Run terminated due to a timeout.' },
  user_cancelled: { label: 'Cancelled', detail: 'Run was cancelled by the user.' },
  error: { label: 'Error', detail: 'Run terminated due to one or more phase failures.' },
};

/** Render a termination banner if the run was terminated for a non-normal reason. */
export function renderTerminationBanner(reason: string | null | undefined): string {
  if (!reason || reason === 'completed') return '';
  const info = TERMINATION_LABELS[reason] || { label: reason, detail: `Run terminated: ${reason}` };
  return `<div class="mb-4 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm">
    <span class="font-medium text-amber-800">${escapeHtml(info.label)}</span>
    <span class="ml-2 text-amber-700">${escapeHtml(info.detail)}</span>
  </div>`;
}

// ── Timeline rendering ───────────────────────────────────────────────

/** Merge canonical phase order with API data, render full timeline HTML. */
export function renderTimelineHtml(
  phases: PhaseData[],
  heartbeatAt?: string | null,
  terminationReason?: string | null,
): string {
  if (phases.length === 0) {
    return '<p class="py-8 text-center text-sm text-gray-400">No pipeline phases recorded</p>';
  }

  // ADR-0142 A23: termination banner
  const banner = renderTerminationBanner(terminationReason);

  // Merge canonical order with actual data
  const merged: Array<{ slug: string; data: PhaseData | null }> = [];
  const seen = new Set<string>();
  for (const { slug } of PHASE_ORDER) {
    merged.push({ slug, data: phases.find(p => p.phase === slug) ?? null });
    seen.add(slug);
  }
  for (const p of phases) {
    if (!seen.has(p.phase)) {
      merged.push({ slug: p.phase, data: p });
      seen.add(p.phase);
    }
  }

  return banner + merged.map(({ slug, data }, i) =>
    renderPhaseCardHtml(slug, data, {
      isLast: i === merged.length - 1,
      heartbeatAt,
    }),
  ).join('');
}

/** Count completed phases. */
export function countCompleted(phases: PhaseData[]): number {
  return phases.filter(
    p => p.state === 'completed' || p.state === 'success',
  ).length;
}

/** Terminal states — no further transitions possible. */
const TERMINAL_STATES = new Set([
  'completed', 'success', 'failed', 'error', 'skipped', 'partial',
]);

/** Check whether all phases have reached a terminal state. */
export function allPhasesTerminal(phases: PhaseData[]): boolean {
  return phases.length > 0 && phases.every(p => TERMINAL_STATES.has(p.state));
}

/** Check whether any phase is still running or pending. */
export function hasActivePhases(phases: PhaseData[]): boolean {
  return phases.some(p => {
    const st = p.state;
    return st === 'running' || st === 'active' || st === 'pending';
  });
}
