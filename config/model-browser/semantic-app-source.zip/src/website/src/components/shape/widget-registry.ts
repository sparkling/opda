/**
 * Resolve the concrete widget type for a SHACL property shape.
 *
 * Priority order (ADR-0133 section 4.2):
 *   1. sh:in present           → 'select' (or 'readonly-text' in view/readOnly)
 *   2. dash:readOnly           → 'readonly-text' or 'readonly-link'
 *   2.5 dash:viewer explicit   → map from viewer URI (view mode only)
 *   3. dash:editor explicit    → map from editor URI
 *   4. sh:class present        → 'resource-link' (view) or 'select' (edit)
 *   5. sh:datatype             → map from datatype URI
 *   6. fallback                → 'text-input'
 */

import type { PropertyMeta, WidgetType } from './shape-types';

type Mode = 'view' | 'edit';

const EDITOR_MAP: Record<string, WidgetType> = {
  'dash:TextFieldEditor':      'text-input',
  'dash:TextAreaEditor':       'textarea',
  'dash:DatePickerEditor':     'datetime-input',
  'dash:URIEditor':            'resource-link',
  'dash:DateTimePickerEditor': 'datetime-input',
  'dash:BooleanSelectEditor':  'select',
  'dash:EnumSelectEditor':     'select',
};

const VIEWER_MAP: Record<string, WidgetType> = {
  'dash:LiteralViewer':  'readonly-text',
  'dash:LabelViewer':    'readonly-text',
  'dash:URIViewer':      'readonly-link',
  'dash:HTMLViewer':     'readonly-text',
};

const DATATYPE_MAP: Record<string, WidgetType> = {
  'xsd:string':    'text-input',
  'xsd:dateTime':  'datetime-input',
  'xsd:date':      'datetime-input',
  'xsd:integer':   'number-input',
  'xsd:int':       'number-input',
  'xsd:long':      'number-input',
  'xsd:decimal':   'decimal-input',
  'xsd:float':     'decimal-input',
  'xsd:double':    'decimal-input',
  'xsd:boolean':   'checkbox',
  'xsd:anyURI':    'resource-link',
  'rdf:JSON':      'json-editor',
};

export function resolveWidget(prop: PropertyMeta, mode: Mode = 'view'): WidgetType {
  const ro = mode === 'view' || prop.readOnly;

  // 1. sh:in enumeration
  if (prop.values && prop.values.length > 0) {
    return ro ? 'readonly-text' : 'select';
  }

  // 2. dash:readOnly
  if (prop.readOnly) {
    return prop.classRef ? 'readonly-link' : 'readonly-text';
  }

  // 2.5. dash:viewer explicit (view mode only)
  if (ro && prop.viewer) {
    const mapped = VIEWER_MAP[prop.viewer];
    if (mapped) return mapped;
  }

  // 3. dash:editor explicit
  if (prop.editor) {
    const mapped = EDITOR_MAP[prop.editor];
    if (mapped) return ro ? readOnlyFallback(mapped, prop) : mapped;
  }

  // 4. sh:class reference
  if (prop.classRef) {
    return mode === 'view' ? 'resource-link' : 'select';
  }

  // 5. sh:datatype
  if (prop.datatype) {
    const mapped = DATATYPE_MAP[prop.datatype];
    if (mapped) return ro ? readOnlyFallback(mapped, prop) : mapped;
  }

  // 6. fallback
  return ro ? 'readonly-text' : 'text-input';
}

function readOnlyFallback(widget: WidgetType, prop: PropertyMeta): WidgetType {
  if (widget === 'resource-link' || prop.classRef) return 'readonly-link';
  if (widget === 'json-editor') return 'json-viewer';
  return 'readonly-text';
}
