/**
 * Check whether an XSD/SHACL regex pattern is compatible with JavaScript's
 * RegExp engine.  Returns false when the pattern uses XSD-specific features
 * that have no JS equivalent (S325-Hendler):
 *
 *  - Character class subtraction   [a-z-[aeiou]]
 *  - XML name-character escapes    \i  \c
 *  - XSD-specific Unicode blocks   \p{IsBasicLatin}  (the "Is" prefix)
 */
const XSD_CLASS_SUBTRACTION = /\[.*-\[/;
const XSD_NAME_CHARS = /\\[ic]/;
const XSD_UNICODE_BLOCK = /\\p\{Is/;

export function isXsdPatternCompatible(pattern: string): boolean {
  return !(
    XSD_CLASS_SUBTRACTION.test(pattern) ||
    XSD_NAME_CHARS.test(pattern) ||
    XSD_UNICODE_BLOCK.test(pattern)
  );
}

/**
 * Convert a SHACL sh:pattern (full-anchored regex) to an HTML5 pattern
 * attribute value (implicitly anchored — browser wraps with ^…$).
 *
 * Returns undefined when the pattern uses XSD-only regex features that
 * JavaScript cannot represent — the caller should fall back to server-side
 * validation only.
 */
export function shPatternToHtml(shPattern: string | undefined): string | undefined {
  if (!shPattern) return undefined;
  if (!isXsdPatternCompatible(shPattern)) return undefined;
  let p = shPattern;
  if (p.startsWith('^')) p = p.slice(1);
  if (p.endsWith('$')) p = p.slice(0, -1);
  return p;
}
