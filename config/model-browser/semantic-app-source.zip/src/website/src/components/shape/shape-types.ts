/**
 * TypeScript interfaces for the SHACL-to-HTML rendering framework.
 * Mirrors the shape metadata returned by the /api/shapes/:class endpoint.
 */

export interface ShapeMetaResponse {
  classUri: string;
  label?: string;
  comment?: string;
  definition?: string;
  abstract?: boolean;
  deprecated?: boolean;
  labelProperty?: string;
  version?: string;
  boundedContext?: string;
  properties: PropertyMeta[];
  actions: ActionMeta[];
  /** Evaluated action visibility map (action URI → visible). Present when fetched with ?instance=<uri>. */
  actionVisibility?: Record<string, boolean>;
}

export interface PropertyMeta {
  path: string;
  pathLocal: string;
  name: string;
  description?: string;
  datatype?: string;
  classRef?: string;
  minCount?: number;
  maxCount?: number;
  pattern?: string;
  htmlPattern?: string;
  editor?: string;
  viewer?: string;
  singleLine?: boolean;
  readOnly?: boolean;
  /** dash:hidden — property is suppressed from rendering (E5 Session E) */
  hidden?: boolean;
  /** Composition kind for part-whole relationships (S325-Guizzardi UFO analysis) */
  compositionKind?: 'mandatory-component' | 'optional-component' | 'shared-part';
  /** Identity kind: surrogate (system-generated UUID) vs natural (user-provided slug) (S325-Guizzardi) */
  identityKind?: 'surrogate' | 'natural';
  uniqueFor?: string;
  defaultValue?: string;
  minInclusive?: number;
  maxInclusive?: number;
  minExclusive?: number;
  maxExclusive?: number;
  minLength?: number;
  maxLength?: number;
  deprecated?: boolean;
  severity?: string;
  message?: string;
  group?: { uri: string; label: string; order: number };
  order?: number;
  values?: EnumValue[];
  /** Resolved by widget-registry at render time — not sent by the server. */
  widget?: WidgetType;
}

export interface EnumValue {
  value: string;
  label: string;
}

export interface ActionMeta {
  uri: string;
  label: string;
  comment?: string;
  group?: { uri: string; label: string; order: number };
  order?: number;
  applicableWhen?: string;
}

export type WidgetType =
  | 'text-input'
  | 'textarea'
  | 'select'
  | 'datetime-input'
  | 'number-input'
  | 'decimal-input'
  | 'json-editor'
  | 'json-viewer'
  | 'resource-link'
  | 'readonly-text'
  | 'readonly-link'
  | 'checkbox';
