/**
 * Build HTML validation attributes from a SHACL property shape.
 * Returns only the attributes that have values, ready for spreading
 * onto an <input> or <textarea> element.
 */

import type { PropertyMeta } from './shape-types';
import { shPatternToHtml } from './pattern-utils';

export interface ValidationAttrs {
  required?: boolean;
  pattern?: string;
  title?: string;
  min?: number;
  max?: number;
  minlength?: number;
  maxlength?: number;
  step?: string;
  inputmode?: string;
  readonly?: boolean;
}

export function buildValidationAttrs(prop: PropertyMeta): ValidationAttrs {
  const attrs: ValidationAttrs = {};

  if (prop.minCount && prop.minCount > 0) {
    attrs.required = true;
  }

  const htmlPat = prop.htmlPattern ?? shPatternToHtml(prop.pattern);
  if (htmlPat) {
    attrs.pattern = htmlPat;
    attrs.title = prop.message ?? prop.description ?? `Must match ${htmlPat}`;
  }

  if (prop.minInclusive !== undefined) {
    attrs.min = prop.minInclusive;
  }

  if (prop.maxInclusive !== undefined) {
    attrs.max = prop.maxInclusive;
  }

  // sh:minExclusive / sh:maxExclusive — HTML5 min/max are inclusive,
  // so for integer types we adjust by +1 / -1; for decimals we pass
  // the exclusive bound as-is (strict enforcement deferred to JS).
  if (prop.minExclusive !== undefined && attrs.min === undefined) {
    attrs.min = prop.widget === 'number-input'
      ? prop.minExclusive + 1
      : prop.minExclusive;
  }

  if (prop.maxExclusive !== undefined && attrs.max === undefined) {
    attrs.max = prop.widget === 'number-input'
      ? prop.maxExclusive - 1
      : prop.maxExclusive;
  }

  // sh:minLength / sh:maxLength
  if (prop.minLength !== undefined) {
    attrs.minlength = prop.minLength;
  }

  if (prop.maxLength !== undefined) {
    attrs.maxlength = prop.maxLength;
  }

  if (prop.widget === 'decimal-input') {
    attrs.step = 'any';
  } else if (prop.widget === 'number-input') {
    attrs.step = '1';
  }

  // inputmode hints for mobile keyboards and accessibility
  if (prop.widget === 'number-input' || prop.widget === 'decimal-input') {
    attrs.inputmode = 'numeric';
  } else if (prop.widget === 'resource-link' && prop.datatype === 'xsd:anyURI') {
    attrs.inputmode = 'url';
  }

  if (prop.readOnly) {
    attrs.readonly = true;
  }

  return attrs;
}
