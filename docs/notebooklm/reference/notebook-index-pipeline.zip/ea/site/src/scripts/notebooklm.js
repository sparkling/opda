import { initInfographicCarousels } from './notebooklm-carousels.js';
import { initEditorialOverlay } from './notebooklm-editorials.js';
import { deckIdFromPrefix } from '../data/slide-links.mjs';
import { loadDeckThumbnails } from './notebooklm-thumbnails.js';
import { initImageLinks } from './notebooklm-image-links.js';
import { initDeckPreview } from './notebooklm-deck-preview.js';
const THEME_KEY = 'ea-leadership-theme';
const THEME_COLORS = { dark: '#081622', light: '#eef3ef' };

export function initNotebookGallery(doc, win) {
  const subscriptions = [];
  const on = (target, type, listener) => {
    if (!target) return;
    target.addEventListener(type, listener);
    subscriptions.push(() => target.removeEventListener(type, listener));
  };

  const root = doc.documentElement;
  const themeButton = doc.querySelector('#theme-toggle');
  const themeColor = doc.querySelector('meta[name="theme-color"]');
  let storedTheme;
  try { storedTheme = win.localStorage?.getItem(THEME_KEY); } catch { /* Storage may be disabled. */ }
  const theme = storedTheme === 'dark' || storedTheme === 'light'
    ? storedTheme : 'dark';
  const applyTheme = value => {
    root.dataset.theme = value;
    if (themeButton) themeButton.textContent = value === 'dark' ? 'Light mode' : 'Dark mode';
    themeColor?.setAttribute('content', THEME_COLORS[value]);
  };
  applyTheme(theme);
  on(themeButton, 'click', () => {
    const next = root.dataset.theme === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    try { win.localStorage?.setItem(THEME_KEY, next); } catch { /* Theme still works for this page. */ }
  });

  const dialog = doc.querySelector('#notebook-lightbox');
  const title = doc.querySelector('#lightbox-title');
  const description = doc.querySelector('#lightbox-description');
  const image = doc.querySelector('#lightbox-image');
  const original = doc.querySelector('#lightbox-original');
  const closeButton = doc.querySelector('#lightbox-close');
  const galleryNavigation = doc.querySelector('#lightbox-gallery-navigation');
  const galleryThumbnails = doc.querySelector('#lightbox-gallery-thumbnails');
  const galleryPrevious = doc.querySelector('#lightbox-gallery-previous');
  const galleryNext = doc.querySelector('#lightbox-gallery-next');
  const galleryCounter = doc.querySelector('#lightbox-gallery-counter');
  const carousels = initInfographicCarousels(doc, on, win);
  const releaseEditorial = initEditorialOverlay(doc, on);
  let activeGallery = null, galleryIndex = 0, galleryButtons = [];
  let thumbnailSources = [];
  const releaseThumbnailSources = () => { thumbnailSources.forEach(release => release()); thumbnailSources = []; };
  const usableDialog = dialog && title && description && image && original && closeButton
    && typeof dialog.showModal === 'function' && typeof dialog.close === 'function';
  let opener = null;
  const lightboxLinks = [...doc.querySelectorAll('a[data-lightbox]')];
  let imageLinks;

  const releaseImage = () => {
    image?.removeAttribute('src');
    if (image) image.hidden = false;
  };
  const finishClose = () => {
    if (dialog?.open) return;
    imageLinks?.write(null);
    releaseImage();
    const focusTarget = activeGallery?.links[galleryIndex] || opener;
    activeGallery = null;
    galleryButtons = [];
    releaseThumbnailSources();
    galleryThumbnails?.replaceChildren();
    if (galleryNavigation) galleryNavigation.hidden = true;
    if (galleryThumbnails) galleryThumbnails.hidden = true;
    opener = null;
    if (focusTarget?.isConnected !== false) focusTarget?.focus();
  };

  const displayImage = (link, load = true) => {
    const href = link.getAttribute('href');
    title.textContent = link.dataset.title || link.querySelector('img')?.alt || 'Gallery image';
    description.textContent = link.dataset.description || '';
    image.alt = link.querySelector('img')?.alt || title.textContent;
    image.hidden = false;
    original.setAttribute('href', href);
    if (load) image.setAttribute('src', href);
  };
  const showGalleryImage = index => {
    if (!activeGallery) return;
    galleryIndex = Math.max(0, Math.min(activeGallery.links.length - 1, index));
    displayImage(activeGallery.links[galleryIndex]);
    imageLinks?.write(activeGallery.links[galleryIndex]);
    activeGallery.show(galleryIndex);
    galleryCounter.textContent = `${galleryIndex + 1} of ${activeGallery.links.length}`;
    galleryPrevious.disabled = galleryIndex === 0;
    galleryNext.disabled = galleryIndex === activeGallery.links.length - 1;
    galleryButtons.forEach((button, i) => button.setAttribute('aria-current', String(i === galleryIndex)));
  };
  const closeLightbox = () => {
    if (dialog?.open) dialog.close();
    finishClose();
  };

  const openLightbox = (link, push = true) => {
        if (!usableDialog) return false;
        const href = link.getAttribute('href');
        if (!href) return false;
        displayImage(link, false);
        try { if (!dialog.open) dialog.showModal(); } catch { return false; }
        closeDeck();
        pauseAll();
        opener = link;
        imageLinks?.write(link, push);
        displayImage(link);
        activeGallery = galleryNavigation && galleryThumbnails && galleryPrevious && galleryNext && galleryCounter ? carousels.get(link.dataset.gallery) : null;
        if (galleryNavigation) galleryNavigation.hidden = !activeGallery;
        if (galleryThumbnails) galleryThumbnails.hidden = !activeGallery;
        if (activeGallery) {
          releaseThumbnailSources();
          galleryButtons = activeGallery.links.map((entry, index) => {
            const button = doc.createElement('button'), thumbnail = doc.createElement('img');
            button.type = 'button';
            button.dataset.galleryIndex = String(index);
            button.setAttribute('aria-label', `View infographic ${index + 1}: ${entry.dataset.title}`);
            const sourceImage = entry.querySelector('img');
            const copyReadySource = () => {
              const source = sourceImage.getAttribute('src');
              if (source) thumbnail.setAttribute('src', source);
            };
            copyReadySource();
            // Reuse the queued page request; never retain its initial placeholder.
            sourceImage.addEventListener('load', copyReadySource);
            thumbnailSources.push(() => sourceImage.removeEventListener('load', copyReadySource));
            thumbnail.alt = '';
            thumbnail.loading = 'eager';
            button.append(thumbnail);
            return button;
          });
          galleryThumbnails.replaceChildren(...galleryButtons);
          showGalleryImage(activeGallery.links.indexOf(link));
        }
        closeButton.focus();
        return true;
  };
  imageLinks = initImageLinks(win, { links: lightboxLinks, open: link => openLightbox(link, false), close: closeLightbox, isOpen: () => dialog?.open });
  if (usableDialog) {
    for (const link of lightboxLinks) {
      on(link, 'click', event => {
        if (event.defaultPrevented || event.button !== 0 || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
        if (openLightbox(link)) event.preventDefault();
      });
    }
    on(closeButton, 'click', closeLightbox);
    on(dialog, 'close', finishClose);
    on(galleryPrevious, 'click', () => showGalleryImage(galleryIndex - 1));
    on(galleryNext, 'click', () => showGalleryImage(galleryIndex + 1));
    on(galleryThumbnails, 'click', event => {
      const button = event.target.closest('button[data-gallery-index]');
      if (button && galleryButtons.includes(button)) showGalleryImage(Number(button.dataset.galleryIndex));
    });
    on(dialog, 'keydown', event => {
      if (event.key === 'Escape') {
        event.preventDefault();
        closeLightbox();
      } else if (activeGallery && ['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) {
        event.preventDefault();
        showGalleryImage(event.key === 'Home' ? 0 : event.key === 'End' ? activeGallery.links.length - 1 : galleryIndex + (event.key === 'ArrowLeft' ? -1 : 1));
      } else if (event.key === 'Tab') {
        const focusable = (activeGallery ? [original, closeButton, galleryPrevious, galleryNext, ...galleryButtons] : [closeButton, original]).filter(element => !element.hidden && !element.disabled);
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (event.shiftKey && doc.activeElement === first) {
          event.preventDefault(); last.focus();
        } else if (!event.shiftKey && doc.activeElement === last) {
          event.preventDefault(); first.focus();
        }
      }
    });
    on(image, 'error', () => {
      if (!dialog.open || image.hidden) return;
      image.hidden = true;
      description.textContent = `${description.textContent} Preview unavailable. Open the original image using the link below.`.trim();
    });
  }

  const media = [...doc.querySelectorAll('video[data-notebook-video], audio[data-notebook-audio]')];
  const pauseAll = () => media.forEach(player => { if (!player.paused) player.pause(); });
  const deckDialog = doc.querySelector('#notebook-deck-player');
  const deckSurface = doc.querySelector('#deck-player-surface');
  const deckTitle = doc.querySelector('#deck-player-title');
  const deckDescription = doc.querySelector('#deck-player-description');
  const deckImage = doc.querySelector('#deck-player-image');
  const deckClose = doc.querySelector('#deck-player-close');
  const deckPrevious = doc.querySelector('#deck-player-previous');
  const deckNext = doc.querySelector('#deck-player-next');
  const deckPlay = doc.querySelector('#deck-player-play');
  const deckRange = doc.querySelector('#deck-player-range');
  const deckCounter = doc.querySelector('#deck-player-counter');
  const deckPdf = doc.querySelector('#deck-player-pdf');
  const deckPptx = doc.querySelector('#deck-player-pptx');
  const deckThumbnails = doc.querySelector('#deck-player-thumbnails');
  const deckFullscreen = doc.querySelector('#deck-player-fullscreen');
  const deckStage = doc.querySelector('#deck-player-stage');
  let thumbnailButtons = [];
  let releaseThumbnails = () => {};
  let swipeStart = null;
  const slidePath = (prefix, number) => `${prefix}${String(number).padStart(3, '0')}.webp`;
  const safeMedia = value => typeof value === 'string' &&
    (/^\/presentations\/(?:notebooklm\/media\/run-1|ruflo\/cognitive-architecture\/media|ea-subjects\/media|platform\/media|ai-ba-(?:n[0-9]{2}(?:-[0-9]{2})?|all)\/media|(?:sa|ba|arb)-[a-z-]+\/media)\/[a-zA-Z0-9/_-]+(?:\.(?:pdf|pptx))?$/.test(value) ||
      /^\/custody\/generation\/[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\/[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\.(?:pdf|pptx)$/i.test(value));
  const deckButtons = [...doc.querySelectorAll('button[data-deck-player]')];
  const previewRenderers = new Map();
  const previewControls = [];
  const clampSlide = (number, count) => Number.isSafeInteger(number) ? Math.max(1, Math.min(count, number)) : 1;
  const readDeck = button => {
    const count = Number(button.dataset.slideCount), prefix = button.dataset.slidePrefix, href = button.dataset.pptx;
    if (!Number.isSafeInteger(count) || count < 1 || count > 100 || !safeMedia(prefix) ||
        !prefix.endsWith('-') || !safeMedia(button.dataset.pdf) || (href && !safeMedia(href)) ||
        (button.dataset.thumbnailPrefix && !safeMedia(button.dataset.thumbnailPrefix))) return null;
    return { count, prefix, href, id: deckIdFromPrefix(prefix), title: button.dataset.title || 'NotebookLM slide deck' };
  };
  for (const button of deckButtons) {
    const card = button.closest('[data-deck-preview]');
    const deck = readDeck(button);
    if (!card || !deck) continue;
    const image = button.querySelector('img');
    const previous = [...card.querySelectorAll('[data-preview-previous]')];
    const next = [...card.querySelectorAll('[data-preview-next]')];
    const counters = [...card.querySelectorAll('[data-preview-counter]')];
    const render = initDeckPreview({ card, image, previous, next, counters, title: deck.title,
      slides: Array.from({ length: deck.count }, (_, index) => slidePath(deck.prefix, index + 1)),
      startSlide: Number(button.dataset.startSlide), on,
      onSlide: current => { button.dataset.startSlide = String(current); } });
    if (!render) continue;
    previewRenderers.set(button, render);
    previewControls.push(...previous, ...next);
  }
  const usableDeck = [deckDialog, deckTitle, deckDescription, deckImage, deckClose, deckPrevious,
    deckNext, deckPlay, deckRange, deckCounter, deckPdf, deckPptx].every(Boolean)
    && typeof deckDialog.showModal === 'function' && typeof deckDialog.close === 'function';
  let activeDeck = null;
  let deckOpener = null;
  let slideNumber = 1;
  let slideTimer = null;
  let syncingLocation = false;
  let disposed = false;
  const writeDeckLocation = (deck, number, push = false) => {
    if (syncingLocation || disposed || !win.location?.href || !win.history) return;
    const url = new URL(win.location.href);
    if (deck?.id) { url.searchParams.set('deck', deck.id); url.searchParams.set('slide', String(number)); url.searchParams.delete('infographic'); }
    else { url.searchParams.delete('deck'); url.searchParams.delete('slide'); }
    if (url.href !== win.location.href) win.history[push ? 'pushState' : 'replaceState'](win.history.state, '', url.href);
  };
  const stopSlides = () => {
    if (slideTimer !== null) win.clearInterval(slideTimer);
    slideTimer = null;
    if (deckPlay) { deckPlay.textContent = 'Play ▷'; deckPlay.setAttribute('aria-label', 'Play slides'); }
  };
  const showSlide = number => {
    if (!activeDeck) return;
    slideNumber = clampSlide(number, activeDeck.count);
    writeDeckLocation(activeDeck, slideNumber);
    previewRenderers.get(deckOpener)?.(slideNumber);
    deckImage.hidden = false;
    deckImage.alt = `${activeDeck.title}, slide ${slideNumber} of ${activeDeck.count}`;
    deckImage.setAttribute('src', slidePath(activeDeck.prefix, slideNumber));
    deckDescription.textContent = 'PDF slide rendition. Use the arrow keys or swipe to change slides.';
    deckCounter.textContent = `Slide ${slideNumber} of ${activeDeck.count}`;
    const commentLabel = doc.querySelector('#deck-player-slide-comments-label');
    if (commentLabel) commentLabel.textContent = `Comments on slide ${slideNumber}`;
    deckRange.value = String(slideNumber);
    deckPrevious.disabled = slideNumber === 1;
    deckNext.disabled = slideNumber === activeDeck.count;
    thumbnailButtons.forEach((button, index) => {
      button.setAttribute('aria-current', index + 1 === slideNumber ? 'true' : 'false');
      button.tabIndex = index + 1 === slideNumber ? 0 : -1;
    });
    thumbnailButtons[slideNumber - 1]?.scrollIntoView?.({ block: 'nearest', inline: 'nearest', behavior: 'instant' });
    if (slideNumber === activeDeck.count) stopSlides();
  };
  const finishDeckClose = () => {
    if (!activeDeck || deckDialog?.open) return;
    releaseThumbnails();
    stopSlides();
    if (activeDeck) writeDeckLocation(null);
    if (deckSurface && doc.fullscreenElement === deckSurface) Promise.resolve(doc.exitFullscreen?.()).catch(() => {});
    deckThumbnails?.replaceChildren();
    thumbnailButtons = [];
    swipeStart = null;
    deckImage?.removeAttribute('src');
    activeDeck = null;
    const focusTarget = deckOpener;
    deckOpener = null;
    if (focusTarget?.isConnected !== false) focusTarget?.focus();
  };
  const closeDeck = () => {
    if (deckDialog?.open) deckDialog.close();
    finishDeckClose();
  };
  const openDeck = (button, requestedSlide = Number(button.dataset.startSlide), push = true) => {
    const deck = readDeck(button);
    if (!deck) return false;
    const { count, prefix, href } = deck;
    try { if (!deckDialog.open) deckDialog.showModal(); } catch { return false; }
    closeLightbox();
    stopSlides();
    activeDeck = deck;
    deckOpener = button;
    deckTitle.textContent = activeDeck.title;
    deckDescription.textContent = 'PDF slide rendition. Use the arrow keys or swipe to change slides.';
    deckRange.max = String(count);
    deckPdf.setAttribute('href', button.dataset.pdf || '#');
    deckPptx.hidden = !href;
    if (href) deckPptx.setAttribute('href', href);
    else deckPptx.removeAttribute('href');
    pauseAll();
    if (deckThumbnails) {
      releaseThumbnails();
      deckThumbnails.replaceChildren();
      const images = [];
      thumbnailButtons = Array.from({ length: count }, (_, index) => {
        const thumb = doc.createElement('button');
        thumb.type = 'button';
        thumb.dataset.slide = String(index + 1);
        thumb.setAttribute('aria-label', `Go to slide ${index + 1}`);
        const img = doc.createElement('img');
        img.alt = ''; img.decoding = 'async';
        images.push({ image: img, button: thumb, thumbnail: slidePath(button.dataset.thumbnailPrefix || prefix, index + 1), slide: slidePath(prefix, index + 1) });
        const label = doc.createElement('span');
        label.textContent = String(index + 1);
        thumb.append(img, label); deckThumbnails.append(thumb);
        return thumb;
      });
      releaseThumbnails = loadDeckThumbnails(doc, images);
    }
    writeDeckLocation(deck, clampSlide(requestedSlide, count), push);
    showSlide(requestedSlide);
    deckClose.focus();
    return true;
  };
  const restoreDeckLocation = () => {
    if (!usableDeck || !win.location?.href || disposed) return;
    const params = new URL(win.location.href).searchParams;
    const id = params.get('deck');
    const button = deckButtons.find(candidate => readDeck(candidate)?.id === id && id);
    syncingLocation = true;
    try {
      if (button) {
        const number = clampSlide(Number(params.get('slide')), readDeck(button).count);
        if (deckDialog.open && activeDeck?.id === id) { stopSlides(); showSlide(number); }
        else openDeck(button, number, false);
      } else if (deckDialog.open) closeDeck();
    } finally { syncingLocation = false; }
    if (activeDeck) writeDeckLocation(activeDeck, slideNumber);
  };
  if (usableDeck) {
    for (const button of deckButtons) {
      button.disabled = false;
      on(button, 'click', event => {
        if (event.defaultPrevented || event.button !== 0 || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
        if (openDeck(button)) event.preventDefault();
      });
    }
    on(deckClose, 'click', closeDeck);
    on(deckDialog, 'close', finishDeckClose);
    on(deckDialog, 'keydown', event => {
      if (event.altKey || event.ctrlKey || event.metaKey || /^(INPUT|TEXTAREA|SELECT)$/.test(event.target?.tagName)) return;
      if (event.key === 'Escape') {
        event.preventDefault();
        if (deckSurface && doc.fullscreenElement === deckSurface) Promise.resolve(doc.exitFullscreen()).catch(() => {});
        else closeDeck();
      }
      else if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) {
        event.preventDefault();
        showSlide(event.key === 'Home' ? 1 : event.key === 'End' ? activeDeck?.count : slideNumber + (event.key === 'ArrowLeft' ? -1 : 1));
        if (thumbnailButtons.includes(doc.activeElement)) thumbnailButtons[slideNumber - 1]?.focus();
      }
    });
    on(deckPrevious, 'click', () => showSlide(slideNumber - 1));
    on(deckNext, 'click', () => showSlide(slideNumber + 1));
    on(deckRange, 'input', () => showSlide(Number(deckRange.value)));
    on(deckThumbnails, 'click', event => {
      const button = event.target.closest?.('button[data-slide]');
      if (button && thumbnailButtons.includes(button)) showSlide(Number(button.dataset.slide));
    });
    on(deckStage, 'pointerdown', event => {
      if (event.pointerType !== 'touch' || event.isPrimary === false) { swipeStart = null; return; }
      swipeStart = { id: event.pointerId, x: event.clientX, y: event.clientY };
      deckStage.setPointerCapture?.(event.pointerId);
    });
    on(deckStage, 'pointercancel', () => { swipeStart = null; });
    on(deckStage, 'pointerup', event => {
      const start = swipeStart;
      swipeStart = null;
      if (!start || start.id !== event.pointerId || !activeDeck) return;
      const dx = event.clientX - start.x, dy = event.clientY - start.y;
      if (Math.abs(dx) >= 50 && Math.abs(dx) > Math.abs(dy) * 1.5) showSlide(slideNumber + (dx < 0 ? 1 : -1));
    });
    if (deckFullscreen) deckFullscreen.hidden = !deckSurface?.requestFullscreen;
    on(deckFullscreen, 'click', async () => {
      try {
        if (doc.fullscreenElement === deckSurface) await doc.exitFullscreen();
        else await deckSurface.requestFullscreen();
      } catch { deckDescription.textContent = 'Fullscreen is unavailable in this browser. The page-sized player is still available.'; }
    });
    on(doc, 'fullscreenchange', () => {
      if (doc.fullscreenElement === deckSurface) deckSurface?.focus();
      else if (deckDialog.open && doc.activeElement === deckSurface) deckFullscreen?.focus();
      if (deckFullscreen) {
        deckFullscreen.textContent = doc.fullscreenElement === deckSurface ? 'Exit fullscreen' : 'Fullscreen';
        deckFullscreen.setAttribute('aria-pressed', String(doc.fullscreenElement === deckSurface));
      }
    });
    on(deckPlay, 'click', () => {
      if (!activeDeck || doc.hidden || win.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
      if (slideTimer !== null) { stopSlides(); return; }
      if (slideNumber === activeDeck.count) showSlide(1);
      deckPlay.textContent = 'Pause ‖';
      deckPlay.setAttribute('aria-label', 'Pause slides');
      slideTimer = win.setInterval(() => showSlide(slideNumber + 1), 7000);
    });
    on(deckImage, 'error', () => {
      if (!deckDialog.open || !activeDeck) return;
      stopSlides();
      deckImage.hidden = true;
      deckDescription.textContent = 'This slide could not load. Use the PDF or PowerPoint download below.';
    });
  }
  for (const player of media) on(player, 'play', () => {
    if (doc.hidden) { player.pause(); return; }
    media.forEach(other => { if (other !== player && !other.paused) other.pause(); });
  });
  on(doc, 'visibilitychange', () => { if (doc.hidden) { pauseAll(); stopSlides(); } });
  on(win, 'pagehide', () => { pauseAll(); stopSlides(); });

  on(win, 'popstate', restoreDeckLocation);
  on(win, 'popstate', () => imageLinks.restore());
  restoreDeckLocation();
  imageLinks.restore();
  return () => {
    if (disposed) return;
    disposed = true;
    imageLinks.dispose();
    subscriptions.forEach(unsubscribe => unsubscribe());
    pauseAll();
    if (dialog?.open) dialog.close();
    finishClose();
    if (deckDialog?.open) deckDialog.close();
    finishDeckClose();
    deckButtons.forEach(button => { button.disabled = true; });
    previewControls.forEach(button => { button.disabled = true; });
    previewRenderers.clear();
    carousels.forEach(carousel => carousel.release());
    carousels.clear();
    releaseEditorial();
  };
}

if (typeof document !== 'undefined' && typeof window !== 'undefined') {
  let cleanup = initNotebookGallery(document, window);
  window.addEventListener('pagehide', () => { cleanup?.(); cleanup = null; });
  window.addEventListener('pageshow', event => {
    if (event.persisted && !cleanup) cleanup = initNotebookGallery(document, window);
  });
}
