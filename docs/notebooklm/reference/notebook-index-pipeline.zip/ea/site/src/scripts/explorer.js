// Deliberate architecture selection. No rendering loop, timer, network or stored response.
function setupExplorer() {
  const root = document.querySelector('[data-explorer]');
  if (!root) return () => {};
  const abort = new AbortController();
  const views = [...root.querySelectorAll('[data-explorer-view]')];
  const items = [...root.querySelectorAll('[data-explorer-item]')];
  const relations = [...root.querySelectorAll('[data-explorer-relation]')];
  const overview = root.querySelector('[data-explorer-overview]');
  const status = document.getElementById('explorer-selection-status');
  const nodes = [...root.querySelectorAll('[data-explorer-node]')];
  const viewLinks = [...root.querySelectorAll('[data-explorer-view-link]')];
  const itemLinks = [...root.querySelectorAll('[data-explorer-item-link]')];
  const relationLinks = [...root.querySelectorAll('[data-explorer-relation-link]')];
  const defaultView = views.find(v => v.dataset.explorerView === 'elements') || views[0];
  let currentView = defaultView;

  function viewFor(item) {
    const link = itemLinks.find(a => a.dataset.explorerItemLink === item.dataset.explorerItem && a.closest('[data-explorer-view]'));
    return link?.closest('[data-explorer-view]') || currentView;
  }
  function select(hash, focus = false) {
    let detail = items.find(p => `#${p.id}` === hash) || relations.find(p => `#${p.id}` === hash);
    const selectedView = views.find(p => `#${p.id}` === hash);
    if (hash === '#whole-system' || !hash) currentView = defaultView;
    if (selectedView) {
      currentView = selectedView;
      const firstLink = currentView.querySelector('[data-explorer-item-link]');
      detail = items.find(p => p.dataset.explorerItem === firstLink?.dataset.explorerItemLink);
    } else if (detail?.hasAttribute('data-explorer-item')) currentView = viewFor(detail);
    for (const view of views) view.hidden = view !== currentView;
    for (const panel of [...items, ...relations]) panel.hidden = panel !== detail;
    if (overview) overview.hidden = Boolean(detail);
    for (const link of viewLinks) {
      if (link.dataset.explorerViewLink === currentView?.dataset.explorerView) link.setAttribute('aria-current', 'true');
      else link.removeAttribute('aria-current');
    }
    for (const link of [...itemLinks, ...relationLinks]) {
      const selected = link.getAttribute('href') === (detail ? `#${detail.id}` : '');
      if (selected) link.setAttribute('aria-current', 'true');
      else link.removeAttribute('aria-current');
    }
    const active = (detail?.dataset.elements || '').split(/\s+/).filter(Boolean);
    root.dataset.activeElements = active.join(' ');
    root.dataset.focused = String(Boolean(detail));
    for (const node of nodes) node.dataset.active = String(!detail || active.includes(node.dataset.explorerNode));
    const heading = detail?.querySelector('h2,h3,h4');
    if (status) status.textContent = detail ? `Selected: ${heading?.textContent || detail.id}. Related elements are highlighted.` : 'Whole architecture. Choose a view, element or relationship.';
    if (focus) {
      const target = heading || overview?.querySelector('h2,h3') || document.getElementById('whole-system');
      target?.focus({preventScroll:true});
      const bounds = target?.getBoundingClientRect();
      if (bounds && (bounds.top < 32 || bounds.bottom > innerHeight - 32)) {
        (target.closest('.explorer-board') || target).scrollIntoView({block:'start', behavior:'instant'});
      }
    }
  }

  root.dataset.enhanced = 'true';
  select(location.hash);
  root.addEventListener('click', event => {
    if (event.button || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    const link = event.target.closest('a[data-explorer-view-link],a[data-explorer-item-link],a[data-explorer-relation-link],a[data-explorer-reset],a[data-explorer-node]');
    if (!link || !root.contains(link)) return;
    const hash = link.getAttribute('href');
    if (!hash?.startsWith('#')) return;
    const known = hash === '#whole-system' || [...views, ...items, ...relations].some(p => `#${p.id}` === hash);
    if (!known) return;
    event.preventDefault();
    if (location.hash !== hash) history.pushState(null, '', hash);
    select(hash, true);
  }, {signal:abort.signal});
  addEventListener('hashchange', () => select(location.hash), {signal:abort.signal});
  addEventListener('popstate', () => select(location.hash), {signal:abort.signal});
  return () => abort.abort();
}
let dispose = setupExplorer();
addEventListener('pagehide', () => dispose());
addEventListener('pageshow', event => {if (event.persisted) dispose = setupExplorer();});
