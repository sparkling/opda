import React, { useMemo } from 'react';
import { validateDiagramEnvelope } from '../../research/diagram-contract.mjs';
import { McpAppView, mountMcpApp, type Status } from './mcp-app-frame';

const APP_ENDPOINT = '/api/chat/apps/diagram';
type DiagramEnvelope = ReturnType<typeof validateDiagramEnvelope>;

/** One fixed, authenticated App resource; model content is sent only as tool data. */
export function mountMcpDiagramApp(frame: HTMLIFrameElement, value: unknown, onStatus: (status: Status) => void) {
  const { result }: DiagramEnvelope = validateDiagramEnvelope(value);
  return mountMcpApp(frame, { endpoint: APP_ENDPOINT, result }, onStatus);
}

/** A readable, inert rendition remains available if the authenticated App fails. */
export function renderMcpResponseFallback(value: unknown) {
  const { result }: DiagramEnvelope = validateDiagramEnvelope(value);
  const blocks = result.schema === 'ea-answer/v1' ? result.blocks : [{ ...result, type: 'diagram' as const }];
  return <div style={{ padding: '1rem', overflowWrap: 'anywhere' }}>
    <h3>{result.title}</h3>
    {blocks.map((block, index) => <section key={index} style={{ marginTop: '1rem' }}>
      {block.type === 'diagram' ? <>
        <h4>{block.title}</h4><p style={{ whiteSpace: 'pre-wrap' }}>{block.description}</p>
        {block.notes && <p style={{ whiteSpace: 'pre-wrap' }}>{block.notes}</p>}
      </> : <>
        {block.heading && <h4>{block.heading}</h4>}
        {(block.type === 'text' || block.type === 'callout') && <p style={{ whiteSpace: 'pre-wrap' }}>{block.text}</p>}
        {block.type === 'list' && (block.ordered
          ? <ol style={{ listStyle: 'decimal', paddingInlineStart: '1.5rem' }}>{block.items.map((item, i) => <li key={i}>{item}</li>)}</ol>
          : <ul style={{ listStyle: 'disc', paddingInlineStart: '1.5rem' }}>{block.items.map((item, i) => <li key={i}>{item}</li>)}</ul>)}
        {block.type === 'table' && <table style={{ width: '100%', tableLayout: 'fixed', textAlign: 'left' }}>
          <thead><tr>{block.columns.map((column, i) => <th key={i} scope="col">{column}</th>)}</tr></thead>
          <tbody>{block.rows.map((row, i) => <tr key={i}>{row.map((cell, j) => <td key={j}>{cell}</td>)}</tr>)}</tbody>
        </table>}
      </>}
    </section>)}
  </div>;
}

function McpDiagramApp({ source }: { source: string }) {
  const envelope = useMemo(() => validateDiagramEnvelope(source), [source]);
  return <McpAppView endpoint={APP_ENDPOINT} result={envelope.result} fallback={() => renderMcpResponseFallback(envelope)} />;
}

export function renderMcpDiagram(language: string, source: string): React.ReactNode | undefined {
  if (language !== 'mcp-app') return undefined;
  try { validateDiagramEnvelope(source); }
  catch { return undefined; }
  return <McpDiagramApp source={source} />;
}
