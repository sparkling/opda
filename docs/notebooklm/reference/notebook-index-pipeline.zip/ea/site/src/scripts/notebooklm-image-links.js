import { infographicIdFromPath } from '../data/slide-links.mjs';

/** Resolve only known page images; query strings never become asset paths. */
export function initImageLinks(win, { links, open, close, isOpen }) {
  let syncing = false, disposed = false;
  const write = (link, push = false) => {
    if (syncing || disposed || !win.location?.href || !win.history) return;
    const url = new URL(win.location.href);
    const id = link && infographicIdFromPath(link.getAttribute('href'));
    if (id) {
      url.searchParams.set('infographic', id);
      url.searchParams.delete('deck'); url.searchParams.delete('slide');
    } else url.searchParams.delete('infographic');
    if (url.href !== win.location.href) win.history[push ? 'pushState' : 'replaceState'](win.history.state, '', url.href);
  };
  return {
    write,
    restore() {
      if (disposed || !win.location?.href) return;
      const params = new URL(win.location.href).searchParams;
      const id = params.get('infographic');
      const link = !params.has('deck') && id && links.find(entry => infographicIdFromPath(entry.getAttribute('href')) === id);
      syncing = true;
      try { if (link) open(link); else if (isOpen()) close(); }
      finally { syncing = false; }
    },
    dispose() { disposed = true; },
  };
}
