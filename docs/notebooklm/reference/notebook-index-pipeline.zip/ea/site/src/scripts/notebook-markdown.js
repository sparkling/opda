/** Render generated Markdown only when its shared reading dialog opens. */
import {createElement} from 'react';
import {createRoot} from 'react-dom/client';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

export function markdownDocument(text) {
  return createElement('article', {className: 'editorial-prose'},
    createElement(Markdown, {remarkPlugins: [remarkGfm], skipHtml: true,
      components: {
        table: ({node, ...props}) => createElement('div', {className: 'reading-table',
          tabIndex: 0, role: 'region', 'aria-label': 'Scrollable table'}, createElement('table', props)),
        img: () => null,
      }, children: text}));
}

export function mountMarkdown(container, text) {
  container.replaceChildren();
  const root = createRoot(container);
  root.render(markdownDocument(text));
  return () => root.unmount();
}
