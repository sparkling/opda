import { RenderBudget } from '../design/render-budget.js';

function initialise() {
  const root = document.documentElement;
  const abort = new AbortController();
  const on = (target, event, action, options = {}) => target?.addEventListener(event, action, { ...options, signal: abort.signal });
  const query = (selector) => document.querySelector(selector);
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const read = (key) => { try { return localStorage.getItem(key); } catch { return null; } };
  const save = (key, value) => { try { localStorage.setItem(key, value); } catch { /* reading still works */ } };
  let paused = reduced.matches || read('ea-leadership-motion') === 'paused';
  root.dataset.theme = read('ea-leadership-theme') || root.dataset.theme || 'dark';
  const theme = query('#theme-toggle');
  const labelTheme = () => { theme.textContent = root.dataset.theme === 'dark' ? 'Light mode' : 'Dark mode'; query('meta[name="theme-color"]')?.setAttribute('content', root.dataset.theme === 'dark' ? '#081622' : '#eef3ef'); };
  labelTheme();
  on(theme, 'click', () => { root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark'; save('ea-leadership-theme', root.dataset.theme); labelTheme(); });
  on(query('#notes-toggle'), 'click', (event) => { const show = root.dataset.notes !== 'true'; root.dataset.notes = String(show); event.currentTarget.setAttribute('aria-pressed', String(show)); });
  let closedDetails = [];
  on(window, 'beforeprint', () => { closedDetails = [...document.querySelectorAll('details:not([open])')]; closedDetails.forEach(detail => { detail.open = true; }); });
  on(window, 'afterprint', () => { closedDetails.forEach(detail => { detail.open = false; }); closedDetails = []; });
  on(query('#print-guide'), 'click', () => window.print());

  const images = [...document.querySelectorAll('[data-parallax]')];
  const scrollBudget = new RenderBudget(() => {
    for (const image of images) {
      const bounds = image.parentElement.getBoundingClientRect();
      if (bounds.bottom < 0 || bounds.top > innerHeight) continue;
      const offset = Math.max(-24, Math.min(24, (innerHeight / 2 - bounds.top - bounds.height / 2) * .035));
      image.style.transform = `translateY(${offset.toFixed(1)}px) scale(1.06)`;
    }
  });
  const chapterLinks = [...document.querySelectorAll('.chapter-nav a')];
  const sections = chapterLinks.map(link => query(link.getAttribute('href')));
  const navigationSections = [query('#top'), ...sections, query('#agenda')];
  root.classList.add('has-js');
  const chapterObserver = new IntersectionObserver((entries) => {
    for (const entry of entries) if (entry.isIntersecting) {
      for (const link of chapterLinks) link.setAttribute('aria-current', String(link.hash === '#' + entry.target.id));
    }
  }, { rootMargin: '-20% 0px -65% 0px' });
  sections.forEach(section => chapterObserver.observe(section));
  const stateObserver = new IntersectionObserver((entries) => {
    for (const entry of entries) if (entry.isIntersecting) {
      document.querySelectorAll('[data-state-link]').forEach(link => { const current = link.dataset.stateLink === entry.target.dataset.state; link.classList.toggle('is-current', current); link.setAttribute('aria-current', String(current)); });
      document.querySelectorAll('[data-state-diagram]').forEach(diagram => diagram.classList.toggle('is-current', diagram.dataset.stateDiagram === entry.target.dataset.state));
    }
  }, { rootMargin: '-25% 0px -40% 0px' });
  document.querySelectorAll('[data-state]').forEach(section => stateObserver.observe(section));
  on(document, 'keydown', (event) => {
    if (!['ArrowRight','ArrowLeft'].includes(event.key) || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || event.target.closest('input,textarea,select,button,summary,[contenteditable],.table-scroll')) return;
    const current = navigationSections.reduce((last, section, index) => section.getBoundingClientRect().top < innerHeight * .4 ? index : last, 0);
    const next = Math.max(0, Math.min(navigationSections.length - 1, current + (event.key === 'ArrowRight' ? 1 : -1)));
    event.preventDefault();
    navigationSections[next].scrollIntoView({ behavior: paused || reduced.matches ? 'instant' : 'smooth', block: 'start' });
    history.replaceState(null, '', '#' + navigationSections[next].id);
    navigationSections[next].setAttribute('tabindex', '-1'); navigationSections[next].focus({ preventScroll: true });
  });

  const shell = query('#renewal-film');
  const mount = query('#film-mount');
  const status = query('#film-status');
  const play = query('#film-play');
  const pause = query('#film-pause');
  let player = null, playback = null, readyTimer = null, safetyTimer = null, generation = 0, savedTime = 0, filmVisible = false;
  const clearFilm = (message, complete = false) => {
    generation++;
    if (playback) { savedTime = Math.min(24, savedTime + playback.playbackMs / 1000); playback.dispose(); playback = null; }
    clearTimeout(readyTimer); clearTimeout(safetyTimer); readyTimer = null; safetyTimer = null;
    if (player) { player.pause(); player.remove(); player = null; }
    mount.replaceChildren();
    if (complete) {
      savedTime = 24;
      const still = document.createElement('p'); still.className = 'film-still';
      still.textContent = 'Stable business contract → accepted replacement → retired legacy path. The evaluated method is ready for reuse.';
      mount.append(still);
    }
    play.disabled = paused || reduced.matches; pause.disabled = true;
    play.textContent = savedTime >= 24 ? 'Replay the sequence' : savedTime > 0 ? 'Resume the sequence' : 'Play the sequence';
    status.textContent = message;
    shell.dataset.playback = complete ? 'complete' : 'stopped';
  };
  on(play, 'click', async () => {
    if (paused || reduced.matches || document.hidden || !filmVisible || player) return;
    const version = ++generation;
    play.disabled = true; status.textContent = 'Loading the local HyperFrames composition…';
    try { await import('@hyperframes/player'); } catch { clearFilm('Animation unavailable. The complete static sequence above is ready to use.'); return; }
    if (version !== generation || paused || document.hidden || !filmVisible) return;
    if (savedTime >= 24) savedTime = 0;
    mount.replaceChildren();
    player = document.createElement('hyperframes-player');
    player.setAttribute('src', '/presentations/ea-leadership/renewal/');
    player.setAttribute('runtime-src', shell.dataset.runtime);
    player.setAttribute('width', '960'); player.setAttribute('height', '540');
    player.setAttribute('audio-locked', ''); player.setAttribute('muted', '');
    player.setAttribute('aria-label', 'Incremental responsibility transfer; the static explanation is immediately above');
    player.addEventListener('ready', () => {
      if (version !== generation || !player) return;
      clearTimeout(readyTimer); readyTimer = null;
      const start = savedTime;
      // Never start the player's independent clock. One bounded 12 Hz owner seeks it.
      playback = new RenderBudget(() => {
        const time = Math.min(23.98, start + playback.playbackMs / 1000);
        if (player) player.seek(time);
        if (start + playback.playbackMs / 1000 >= 24) clearFilm('Sequence complete. Playback is unloaded; replay is deliberate.', true);
      }, { onLimit: reason => reason.startsWith('Still') ? clearFilm('Sequence complete. Playback is unloaded; replay is deliberate.', true) : clearFilm('Playback stopped by the safety budget. Use the static sequence or resume.') });
      playback.configure(true, true);
      pause.disabled = false; status.textContent = 'Playing once · 24 seconds maximum · scroll away or pause to unload.';
      shell.dataset.playback = 'playing';
      safetyTimer = setTimeout(() => clearFilm('Playback budget ended; the animation has been unloaded.', true), (24 - start) * 1000 + 1500);
    }, { once: true });
    player.addEventListener('error', () => clearFilm('Animation unavailable. Use the complete static sequence above.'), { once: true });
    readyTimer = setTimeout(() => clearFilm('Animation did not become ready. Use the complete static sequence above.'), 11000);
    mount.append(player);
  });
  on(pause, 'click', () => clearFilm('Paused and unloaded. Resume when you are ready.'));
  const filmObserver = new IntersectionObserver(([entry]) => {
    filmVisible = entry.isIntersecting;
    if (!filmVisible && (player || play.disabled && !paused)) clearFilm('Offscreen: playback is unloaded. Resume when ready.');
  }, { threshold: .05 });
  filmObserver.observe(shell);

  const applyMotion = () => {
    const stopped = paused || reduced.matches || document.hidden;
    root.dataset.motion = stopped ? 'paused' : 'enabled';
    scrollBudget.configure(!stopped, false);
    query('#motion-toggle').textContent = reduced.matches ? 'Reduced motion' : stopped ? 'Resume motion' : 'Pause motion';
    query('#motion-toggle').disabled = reduced.matches;
    query('#motion-toggle').setAttribute('aria-pressed', String(stopped));
    if (stopped) { images.forEach(image => image.style.removeProperty('transform')); clearFilm(reduced.matches ? 'Reduced motion: the full static sequence is shown above.' : 'Motion paused. The full static sequence is shown above.'); }
    else { play.disabled = false; query('#motion-toggle').textContent = 'Pause motion'; }
  };
  on(query('#motion-toggle'), 'click', () => { if (reduced.matches) return; paused = !paused; save('ea-leadership-motion', paused ? 'paused' : 'enabled'); applyMotion(); });
  on(reduced, 'change', applyMotion);
  on(document, 'visibilitychange', applyMotion);
  on(window, 'scroll', () => scrollBudget.request(), { passive: true });
  on(window, 'resize', () => scrollBudget.request(), { passive: true });
  applyMotion();
  // Only minimal read-only diagnostics; no content or participant data leaves the page.
  Object.defineProperty(shell, 'renderMetrics', { configurable: true, get: () => ({ scroll: scrollBudget.metrics(), film: playback?.metrics() || null, mountedPlayers: Number(Boolean(player)) }) });
  return () => { abort.abort(); chapterObserver.disconnect(); stateObserver.disconnect(); filmObserver.disconnect(); scrollBudget.dispose(); clearFilm('Playback released.'); };
}

let dispose = initialise();
window.addEventListener('pagehide', () => { dispose(); });
window.addEventListener('pageshow', event => { if (event.persisted) dispose = initialise(); });
