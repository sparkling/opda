import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { LaikaShell } from 'semantic-app/laika';
import { PrimeRadiantHero, PrimeRadiantArtwork } from './prime-radiant-hero';
import { renderChatCodeBlock } from './chat-code-blocks';
import { reasonerOptions } from '../../research/reasoner-contract.mjs';
import { researchChatConfig, type ResearchChatConfig } from './research-chat-config.mjs';
import styles from '../styles/research-chat.css?inline';

type Session = { user: { name?: string; email: string } };
const avatarUrl = '/images/prime-radiant/icon.webp';
const heroUrl = '/images/prime-radiant/banner.webp';
const brand = { name: 'Prime Radiant', hideSidebarName: true, hideComposerFooter: true, composerLabel: 'Ask the Prime Radiant', icon: <PrimeRadiantArtwork variant="icon" />, renderCodeBlock: renderChatCodeBlock, heroAlt: 'A faceted crystal enclosure holds a nested bronze lattice around a warm core.', style: {
  '--chat-bg': '#F5F2EA', '--chat-dark-bg': '#171B1D', '--chat-text': '#20272B', '--chat-dark-text': '#F2ECE0',
  '--chat-sidebar': '#E8E2D6', '--chat-dark-sidebar': '#242A2C', '--chat-dark-panel': '#2B3132',
  '--chat-accent': '#775424', '--chat-accent-hover': '#62431B', '--chat-muted': '#5B605F', '--chat-dark-muted': '#BDB9AD',
  '--chat-link': '#775424', '--chat-dark-link': '#E3BF83',
  '--chat-bubble': '#E9E0CE', '--chat-dark-bubble': '#393D38', '--chat-caption': '#5B605F', '--chat-dark-caption': '#BDB9AD',
  '--chat-font': 'ui-sans-serif,system-ui,sans-serif', '--chat-content-max-width': '100%',
  '--chat-welcome-alignment': 'flex-start',
  '--chat-icon-size': '64px',
  '--chat-search-width': '64rem', '--chat-search-height': '80dvh',
} };
function ResearchChat({ close, config }: { close: () => void; config: ResearchChatConfig }) {
  const returnUrl = new URL(window.location.href);
  returnUrl.searchParams.set('researchChat', 'open');
  const [session, setSession] = useState<Session | null>(null);
  const [status, setStatus] = useState<'loading' | 'signin' | 'error'>('loading');
  useEffect(() => {
    const abort = new AbortController();
    (async () => {
      try {
        const response = await fetch(config.sessionApi, { credentials: 'same-origin', signal: abort.signal, headers: { Accept: 'application/json' } });
        if (response.status === 401) { setStatus('signin'); return; }
        if (!response.ok || !response.headers.get('content-type')?.includes('application/json')) throw new Error('Unavailable');
        const value: Session = await response.json();
        if (!value?.user || typeof value.user.email !== 'string') throw new Error('Invalid session');
        setSession(value);
      } catch { if (!abort.signal.aborted) setStatus('error'); }
    })();
    return () => abort.abort();
  }, [config.sessionApi]);
  if (status !== 'loading' && !session) return <div className="flex h-full flex-col items-center justify-center gap-4 bg-[#F5F2EA] p-6 text-center text-[#20272B] dark:bg-[#171B1D] dark:text-[#F2ECE0]">
    <img src={avatarUrl} alt="Prime Radiant" className="h-20 w-20 object-contain" />
    <h2 className="text-xl font-bold">Prime Radiant</h2>
    <p role="status">{status === 'signin' ? 'Sign in with your organisation’s account to ask Prime Radiant.' : 'Prime Radiant is unavailable. Please try again later.'}</p>
    {status === 'signin' && <a className="rounded bg-[#775424] px-4 py-2 text-white" href={`${returnUrl.pathname}${returnUrl.search}${returnUrl.hash}`}>Sign in with Cognito</a>}
    <button type="button" onClick={close} className="rounded border px-4 py-2">Close</button>
  </div>;
  return <LaikaShell brand={brand} reasonerOptions={reasonerOptions} hero={<PrimeRadiantHero />} persistentHero title="" api={config.api} conversationsApi={config.conversationsApi} userLabel={session?.user.name || session?.user.email || ''}
    contextLabel={config.contextLabel} heroUrl={heroUrl} avatarUrl={avatarUrl} onClose={close} links={[...config.links]} />;
}

export function mountResearchChat(target: HTMLElement, close: () => void) {
  const config = researchChatConfig(target.dataset.researchChatConfig ? JSON.parse(target.dataset.researchChatConfig) : undefined);
  const shadow = target.shadowRoot || target.attachShadow({ mode: 'open' });
  const style = document.createElement('style'); style.textContent = styles;
  const frame = document.createElement('div'); frame.className = 'laika-frame';
  shadow.replaceChildren(style, frame);
  const syncTheme = () => frame.classList.toggle('dark', document.documentElement.dataset.theme === 'dark');
  syncTheme();
  const observer = new MutationObserver(syncTheme);
  observer.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  const root = createRoot(frame); root.render(<ResearchChat close={close} config={config} />);
  return () => { observer.disconnect(); root.unmount(); shadow.replaceChildren(); };
}
