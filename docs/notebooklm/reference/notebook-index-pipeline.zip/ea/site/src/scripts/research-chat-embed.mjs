/** Opt-in development embedding of the standalone BA research chat (BA ADR-011 `/embed`).
 * The EA chat is unchanged unless a dev build supplies an origin; no production URL lives here.
 */
const frameSandbox = 'allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads';

/** @param {unknown} origin Exact origin, e.g. http://127.0.0.1:4331. Empty means "not configured".
 * @returns {string | undefined} The `/embed` URL, or undefined when not configured. */
export function chatEmbedUrl(origin) {
  if (origin === undefined || origin === null || origin === '') return undefined;
  let url;
  try { url = new URL(String(origin)); } catch { throw new Error('Invalid chat embed origin'); }
  const loopback = url.protocol === 'http:' && url.hostname === '127.0.0.1';
  if ((!loopback && url.protocol !== 'https:') || url.origin !== origin) throw new Error('Invalid chat embed origin');
  return `${url.origin}/embed`;
}

/** The only message the framed chat may send (BA `ba-chat/close-request`): a request, never a command. */
const closeRequestType = 'ba-chat/close-request';
const barStyle = 'display:flex;justify-content:flex-end;padding:.5rem 1rem;border-bottom:1px solid #b9ae96;background:#e8e2d6';
const buttonStyle = 'padding:.375rem .875rem;border:1px solid #20272b;border-radius:8px;background:#f5f2ea;color:#20272b;font:inherit;cursor:pointer';

/** Accept only the exact shape, from the configured origin, sent by this dialog's own frame. */
export function isCloseRequest(event, frame, origin) {
  const data = event.data;
  return event.origin === origin && event.source != null && event.source === frame.contentWindow
    && data !== null && typeof data === 'object' && Object.getPrototypeOf(data) === Object.prototype
    && Object.keys(data).length === 1 && data.type === closeRequestType;
}

/** Same module shape as research-chat-client, so the existing launcher lifecycle is reused. The launcher
 * supplies `close`, which owns teardown and returns focus to the opener. */
export function embeddedChatModule(embedUrl) {
  const src = chatEmbedUrl(embedUrl.replace(/\/embed$/, ''));
  if (src !== embedUrl) throw new Error('Invalid chat embed origin');
  const origin = new URL(src).origin;
  return { mountResearchChat(target, close) {
    const doc = target.ownerDocument, win = doc.defaultView;
    const wrapper = doc.createElement('div'), bar = doc.createElement('div');
    const button = doc.createElement('button'), frame = doc.createElement('iframe');
    wrapper.style.cssText = 'display:flex;flex-direction:column;width:100%;height:100%';
    bar.style.cssText = barStyle;
    button.setAttribute('type', 'button');
    button.setAttribute('aria-label', 'Close research chat');
    button.setAttribute('data-research-chat-embed-close', '');
    button.style.cssText = buttonStyle;
    button.textContent = 'Close';
    frame.setAttribute('src', src);
    frame.setAttribute('title', 'Architecture research');
    frame.setAttribute('sandbox', frameSandbox);
    frame.setAttribute('allow', 'clipboard-write');
    frame.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
    frame.style.cssText = 'display:block;flex:1;min-height:0;width:100%;border:0';
    const onMessage = event => { if (isCloseRequest(event, frame, origin)) close(); };
    button.addEventListener('click', close);
    win.addEventListener('message', onMessage);
    bar.append(button); wrapper.append(bar, frame); target.append(wrapper);
    return () => {
      win.removeEventListener('message', onMessage);
      button.removeEventListener('click', close);
      wrapper.remove();
    };
  } };
}
