const programme = JSON.parse(document.getElementById('programme-data').textContent);
const labels = ['The opportunity','Agentic engineering','The semantic pilot','Collective intelligence','Enterprise architecture','EA governance','Strategic choices','Research & decisions','Programme journal'];
const byId = Object.fromEntries(programme.sites.map((s,i)=>[s.id,{...s,label:labels[i],index:i}]));
const points = [[135,256.2],[333,115.9],[333,414.8],[540,225.7],[567,427],[720,91.5],[765,311.1],[144,512.4],[747,530.7]];
const outcomeRoot = '/research-library/doc/programme/outcomes/';
const journalRoot = '/programme-journal/';
const reading = {
  opportunity:['Explore the opportunity','/opportunity/'],
  'agentic-engineering':['Read the architecture explanation',outcomeRoot+'phase-3/'],
  'semantic-pilot':['Explore the five-element architecture',outcomeRoot+'phase-3/'],
  'collective-intelligence':['Read the memory and learning research','/research-library/doc/research/03-platform/memory-foundation-ea/'],
  'enterprise-architecture':['Explore the connected architecture',outcomeRoot+'phase-3/'],
  'ea-governance':['Read the governance direction',outcomeRoot+'phase-4/'],
  'strategic-choices':['Read the strategic choices',outcomeRoot+'phase-4/'],
  'research-library':['Open the research and decisions',journalRoot+'decisions/'],
  'programme-journal':['Open the programme journal',journalRoot]
};
const $ = selector=>document.querySelector(selector);
let activePath=0, activeSubject='opportunity', animations=[], generation=0;
const reduced=matchMedia('(prefers-reduced-motion: reduce)');
const compact=matchMedia('(max-width:600px)');
const motionStatus=$('#motion-status');
const traceButton=$('#trace'), stopButton=$('#stop-trace');
const nodeElements=[...document.querySelectorAll('.map-node')];
const svgNS='http://www.w3.org/2000/svg';
function curve(a,b) {
  const [x1,y1]=points[byId[a].index], [x2,y2]=points[byId[b].index];
  const mid=(x1+x2)/2;
  return `M${x1} ${y1}C${mid} ${y1},${mid} ${y2},${x2} ${y2}`;
}
function edge(a,b,active=false) {
  const p=document.createElementNS(svgNS,'path');
  p.setAttribute('d',curve(a,b));p.setAttribute('class',active?'active-edge':'base-edge');
  p.dataset.from=a;p.dataset.to=b;
  if(active){p.setAttribute('pathLength','1');p.setAttribute('stroke-dasharray','1');}
  return p;
}
const edges=new Set();
programme.paths.forEach(path=>path.steps.slice(1).forEach((id,i)=>{
  const from=path.steps[i],key=[id,from].sort().join(':');
  if(!edges.has(key)){$('#base-paths').append(edge(from,id));edges.add(key);}
}));
function stopMotion() {
  generation++;
  animations.forEach(a=>a.cancel());animations=[];
  stopButton.hidden=true;
  const available=!reduced.matches&&!compact.matches&&document.body.dataset.motionPaused!=='true';
  traceButton.disabled=!available;
  motionStatus.textContent=reduced.matches?'Still view · reduced motion':compact.matches?'Still view · compact layout':'Still view';
  $('#chart').dataset.motion='still';
}
function tracePath() {
  stopMotion();
  if(reduced.matches||compact.matches||document.hidden||document.body.dataset.motionPaused==='true')return;
  const rect=$('#chart').getBoundingClientRect();
  if(rect.bottom<=0||rect.top>=innerHeight)return;
  const cycle=generation;
  const paths=[...document.querySelectorAll('.active-edge')];
  animations=paths.map((p,i)=>p.animate([{strokeDashoffset:'1'},{strokeDashoffset:'0'}],{duration:800,delay:i*450,iterations:1,easing:'cubic-bezier(.2,.65,.25,1)',fill:'backwards'}));
  traceButton.disabled=true;stopButton.hidden=false;
  motionStatus.textContent='Tracing the selected learning path';$('#chart').dataset.motion='tracing';
  Promise.all(animations.map(a=>a.finished.catch(()=>{}))).then(()=>{if(cycle===generation)stopMotion();});
}
function subjectLink(id,text) {
  const a=document.createElement('a');a.href=`#${id}`;a.dataset.subject=id;a.textContent=text||byId[id].label;return a;
}
function selectPath(index,animate=true) {
  stopMotion();activePath=index;
  const route=programme.paths[index];
  if(!route.steps.includes(activeSubject))selectSubject(route.steps[0],false);
  document.querySelectorAll('[data-path]').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.path)===index)));
  $('#path-purpose').textContent=route.purpose;$('#path-count').textContent=String(route.steps.length);
  const itinerary=$('#itinerary');itinerary.replaceChildren();
  route.steps.forEach(id=>{const li=document.createElement('li');li.append(subjectLink(id));itinerary.append(li);});
  nodeElements.forEach(n=>n.classList.toggle('on-path',route.steps.includes(n.dataset.subject)));
  const active=$('#active-paths');active.replaceChildren();
  route.steps.slice(1).forEach((id,i)=>active.append(edge(route.steps[i],id,true)));
  if(animate)tracePath();
}
function selectSubject(id,focus=true,updateUrl=true) {
  if(!byId[id])return;
  activeSubject=id;const s=byId[id];
  nodeElements.forEach(n=>{const selected=n.dataset.subject===id;n.classList.toggle('selected',selected);if(selected)n.setAttribute('aria-current','true');else n.removeAttribute('aria-current');});
  $('#subject-number').textContent=String(s.index+1).padStart(2,'0');
  $('#subject-title').textContent=s.title;$('#subject-question').textContent=s.question;$('#subject-description').textContent=s.description;
  $('#subject-status').textContent=s.localDelivery?.state==='implemented'?(s.localDelivery.formLabel||'PRESENTATION · CASE · PRACTICE · REFERENCE'):'EXPERIENCE IN PREPARATION · READING AVAILABLE';
  const formats=$('#subject-formats');formats.replaceChildren();s.formats.forEach((f,i)=>{if(i)formats.append(document.createElement('br'));formats.append(document.createTextNode(f));});
  const a=document.createElement('a');a.className='primary-link';a.href=s.localDelivery?.href||reading[id][1];a.textContent=s.localDelivery?.label||reading[id][0];
  const arrow=document.createElement('span');arrow.setAttribute('aria-hidden','true');arrow.textContent='↗';a.append(arrow);$('#subject-links').replaceChildren(a);
  if(updateUrl&&location.hash!==`#${id}`)history.pushState(null,'',`#${id}`);
  if(focus){$('#selected-subject').scrollIntoView({block:'start',behavior:'instant'});$('#selected-subject').focus({preventScroll:true});document.dispatchEvent(new CustomEvent('programme-subject-selected'));}
}
document.addEventListener('click',event=>{
  const route=event.target.closest('[data-path]');if(route){selectPath(Number(route.dataset.path));return;}
  const subject=event.target.closest('a[data-subject]');if(subject){event.preventDefault();selectSubject(subject.dataset.subject);}
});
document.addEventListener('design-motion-pause',stopMotion);
document.addEventListener('design-motion-resume',stopMotion);
traceButton.addEventListener('click',tracePath);stopButton.addEventListener('click',stopMotion);
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopMotion();});
document.addEventListener('keydown',e=>{if(e.key==='Escape')stopMotion();});
reduced.addEventListener('change',stopMotion);compact.addEventListener('change',stopMotion);
const observer=new IntersectionObserver(entries=>{if(!entries[0].isIntersecting)stopMotion();});observer.observe($('#chart'));
addEventListener('pagehide',()=>{stopMotion();observer.disconnect();});
addEventListener('pageshow',()=>observer.observe($('#chart')));
addEventListener('hashchange',()=>{const id=location.hash.slice(1);if(byId[id])selectSubject(id,true,false);});
addEventListener('popstate',()=>{const id=location.hash.slice(1);selectSubject(byId[id]?id:'opportunity',Boolean(byId[id]),false);});
selectPath(0,false);selectSubject(byId[location.hash.slice(1)]?location.hash.slice(1):'opportunity',Boolean(byId[location.hash.slice(1)]),false);stopMotion();
