/** Enhance the native dialog; asset loading never owns whether Ask responds. */
export function initResearchChatLauncher(doc, win, loadClient) {
  const launch = doc.querySelector('#research-chat-open');
  const dialog = doc.querySelector('#research-chat-dialog');
  const target = doc.querySelector('#research-chat-mount');
  const loading = doc.querySelector('#research-chat-loading');
  const actions = doc.querySelector('#research-chat-loading-actions');
  const closeButton = doc.querySelector('#research-chat-fallback-close');
  const recovery = doc.querySelector('#research-chat-reload');
  if (!launch || !dialog || !target || !loading || !actions || !closeButton || !recovery) return () => {};

  let modulePromise, dispose, timer, generation = 0, opening = false, released = false;
  const clearTimer = () => { if (timer !== undefined) win.clearTimeout(timer); timer = undefined; };
  const showRecovery = message => {
    loading.textContent = message; loading.hidden = false;
    actions.hidden = false; recovery.hidden = false;
  };
  const watchLoad = () => {
    clearTimer();
    if (!opening || doc.hidden) return;
    const request = generation;
    timer = win.setTimeout(() => {
      timer = undefined;
      if (request === generation && dialog.open) showRecovery('Chat is taking longer to load. You can reload chat or close this window.');
    }, 10000);
  };
  const client = () => {
    if (!modulePromise) modulePromise = Promise.resolve().then(loadClient).catch(error => {
      modulePromise = undefined;
      throw error;
    });
    return modulePromise;
  };
  const returnUrl = new URL(win.location.href);
  returnUrl.searchParams.set('researchChat', 'open');
  recovery.setAttribute('href', returnUrl.pathname + returnUrl.search + returnUrl.hash);
  const close = () => dialog.close();
  const closed = () => {
    if (dialog.open) return; // Ignore a queued close event after an immediate reopen.
    generation++; opening = false; clearTimer(); dispose?.(); dispose = undefined;
    launch.focus();
  };
  const open = async () => {
    if (released) return;
    if (!dialog.open) dialog.showModal();
    if (opening || dispose) return;
    const request = ++generation;
    opening = true; loading.hidden = true; actions.hidden = false; recovery.hidden = true;
    watchLoad();
    try {
      const { mountResearchChat } = await client();
      if (released || request !== generation || !dialog.open) return;
      dispose = mountResearchChat(target, close);
      loading.hidden = true; actions.hidden = true;
    } catch {
      if (request === generation && dialog.open) showRecovery('Chat could not load. Reload chat to try again.');
    } finally {
      if (request === generation) { opening = false; clearTimer(); }
    }
  };
  launch.addEventListener('click', open);
  closeButton.addEventListener('click', close);
  dialog.addEventListener('close', closed);
  doc.addEventListener('visibilitychange', watchLoad);
  launch.dataset.chatReady = 'true';
  // Download code at page initialization; do not mount or request a session yet.
  void client().catch(() => {});
  const current = new URL(win.location.href);
  if (current.searchParams.get('researchChat') === 'open') {
    current.searchParams.delete('researchChat');
    win.history.replaceState(win.history.state, '', current);
    void open();
  } else if (dialog.open) void open(); // Native Ask may have been clicked before this module arrived.

  return () => {
    released = true; generation++; clearTimer(); dispose?.(); dispose = undefined;
    launch.removeEventListener('click', open);
    closeButton.removeEventListener('click', close);
    dialog.removeEventListener('close', closed);
    doc.removeEventListener('visibilitychange', watchLoad);
    delete launch.dataset.chatReady;
  };
}
