/** Reveal the current hash inside the native, nested contents tree. No scroll loop. */
export function initCatalogueNavigation(doc, win) {
  const nav = doc.querySelector('#catalogue-navigation');
  if (!nav) return () => {};
  const reveal = () => {
    let id;
    try { id = decodeURIComponent(win.location.hash.slice(1)); } catch { return; }
    for (const old of nav.querySelectorAll('a[aria-current]')) old.removeAttribute('aria-current');
    if (!id) return;
    const link = [...nav.querySelectorAll('a[href^="#"]')].find(item => item.getAttribute('href') === `#${id}`);
    if (!link) return;
    for (let parent = link.parentElement; parent && parent !== nav; parent = parent.parentElement) {
      if (parent.tagName === 'DETAILS') parent.open = true;
    }
    link.setAttribute('aria-current', 'location');
  };
  win.addEventListener('hashchange', reveal);
  win.addEventListener('pageshow', reveal);
  reveal();
  return () => { win.removeEventListener('hashchange', reveal); win.removeEventListener('pageshow', reveal); };
}

if (typeof document !== 'undefined' && typeof window !== 'undefined') initCatalogueNavigation(document, window);
