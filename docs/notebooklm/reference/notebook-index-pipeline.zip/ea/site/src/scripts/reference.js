// Document filtering runs only on deliberate input. No network, timers or frames.
function setup() {
  const abort=new AbortController(), filter=document.querySelector('#reference-filter');
  const items=[...document.querySelectorAll('[data-reference-item]')];
  const groups=[...document.querySelectorAll('#reference-tree details[data-major]')];
  const nested=[...document.querySelectorAll('#reference-tree details:not([data-major])')];
  const count=document.querySelector('#reference-filter-count');
  const documentFilter=document.querySelector('#document-search');
  if(documentFilter){
    const records=[...document.querySelectorAll('.journal-record .record')].map(element=>({element,text:element.textContent.toLocaleLowerCase()}));
    const status=document.querySelector('#search-status');
    documentFilter.addEventListener('input',()=>{
      const words=documentFilter.value.toLocaleLowerCase().trim().split(/\s+/).filter(Boolean);
      let found=0;
      for(const {element,text} of records){element.hidden=!words.every(word=>text.includes(word));if(!element.hidden)found++;}
      if(status)status.textContent=`${found} ${words.length?'matching ':''}${found===1?'document':'documents'}`;
    },{signal:abort.signal});
  }
  let currentParent=document.querySelector('#reference-tree a[aria-current="page"]')?.closest('details');
  while(currentParent){currentParent.open=true;currentParent=currentParent.parentElement.closest('details');}
  const initialOpen=groups.find(g=>g.open);
  const initialNested=new Set(nested.filter(g=>g.open));
  const noun=document.body.dataset.collection==='programme-journal'?'pages':'documents';
  filter.addEventListener('input',()=>{
    const words=filter.value.toLocaleLowerCase().trim().split(/\s+/).filter(Boolean);
    let total=0;
    for(const item of items){item.hidden=!words.every(word=>item.dataset.search.includes(word));if(!item.hidden)total++;}
    for(const group of nested){
      group.hidden=!!words.length&&!group.querySelector('[data-reference-item]:not([hidden])');
      group.open=words.length?!group.hidden:initialNested.has(group);
    }
    for(const group of groups)group.hidden=!group.querySelector('[data-reference-item]:not([hidden])');
    const current=groups.find(g=>g.open&&!g.hidden);
    if(!current){const first=words.length?groups.find(g=>!g.hidden):initialOpen;if(first)first.open=true;}
    count.textContent=words.length?`${total} matching ${total===1?noun.slice(0,-1):noun}`:`${items.length} complete ${noun}`;
  },{signal:abort.signal});
  return ()=>abort.abort();
}
let teardown=setup();
addEventListener('pagehide',()=>teardown());
addEventListener('pageshow',event=>{if(event.persisted)teardown=setup();});
