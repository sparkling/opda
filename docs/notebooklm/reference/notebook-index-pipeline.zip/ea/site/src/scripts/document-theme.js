// One deliberate theme update; no timers, animation frames or rendering loop.
(() => {
  const key='hm-programme-document-theme';
  const normalise=value=>value==='dark'?'dark':'light';
  const read=()=>{try{return normalise(localStorage.getItem(key));}catch{return 'light';}};
  const apply=theme=>{
    document.documentElement.dataset.documentTheme=normalise(theme);
    document.querySelectorAll('[data-document-theme-choice]').forEach(button=>{
      button.setAttribute('aria-pressed',String(button.dataset.documentThemeChoice===normalise(theme)));
    });
  };
  apply(read());
  let abort;
  const setup=()=>{
    abort?.abort();
    abort=new AbortController();
    apply(read());
    document.querySelectorAll('[data-document-theme-choice]').forEach(button=>{
      button.addEventListener('click',()=>{
        const theme=normalise(button.dataset.documentThemeChoice);
        apply(theme);
        try{localStorage.setItem(key,theme);}catch{/* Theme still works without storage. */}
      },{signal:abort.signal});
    });
    const menus=[...document.querySelectorAll('.document-menu')];
    document.addEventListener('click',event=>{menus.forEach(menu=>{if(!menu.contains(event.target))menu.open=false;});},{signal:abort.signal});
    document.addEventListener('keydown',event=>{if(event.key==='Escape'){const menu=menus.find(menu=>menu.open);if(menu){menu.open=false;menu.querySelector('summary')?.focus();}}},{signal:abort.signal});
    addEventListener('storage',event=>{if(event.key===key)apply(event.newValue);},{signal:abort.signal});
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup,{once:true});
  else setup();
  addEventListener('pagehide',()=>abort?.abort());
  addEventListener('pageshow',event=>{if(event.persisted)setup();});
})();
