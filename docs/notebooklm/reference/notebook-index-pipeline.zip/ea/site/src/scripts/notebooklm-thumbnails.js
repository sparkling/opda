/** Bounded, finite thumbnail loading for the shared modal player. */
export function loadDeckThumbnails(doc, entries) {
  let disposed = false;
  let cursor = 0;
  let pending = 0;
  const active = new Set();
  const pump = () => {
    while (!disposed && !doc.hidden && pending < 3 && cursor < entries.length) {
      const { image, thumbnail, slide, button } = entries[cursor++];
      const urls = [thumbnail, `${thumbnail}?retry=1`, ...(slide !== thumbnail ? [slide] : [])];
      let attempt = 0;
      pending++;
      image.loading = 'eager';
      image.width = 320;
      image.height = 179;
      const detach = () => {
        image.removeEventListener('load', loaded);
        image.removeEventListener('error', failed);
        active.delete(cancel);
      };
      const finish = () => { detach(); pending--; pump(); };
      const loaded = () => { if (!disposed) finish(); };
      const failed = () => {
        if (disposed) return;
        if (++attempt < urls.length) image.setAttribute('src', urls[attempt]);
        else {
          image.hidden = true;
          button.setAttribute('title', 'Preview unavailable. Select this slide to view it.');
          finish();
        }
      };
      const cancel = () => { detach(); image.removeAttribute('src'); };
      active.add(cancel);
      image.addEventListener('load', loaded);
      image.addEventListener('error', failed);
      image.setAttribute('src', urls[attempt]);
    }
  };
  doc.addEventListener('visibilitychange', pump);
  pump();
  return () => {
    disposed = true;
    doc.removeEventListener('visibilitychange', pump);
    for (const cancel of [...active]) cancel();
  };
}
