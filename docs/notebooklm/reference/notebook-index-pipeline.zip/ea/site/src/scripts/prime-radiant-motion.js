/** Play CPU-rendered image loops only while their placement is visible.
 * No canvas, WebGL, requestAnimationFrame, polling or runtime scene rendering.
 */
export function observeRadiantAnimation(image, { still, loop, occluder } = {}) {
  if (!image) return () => {};
  const doc = image.ownerDocument;
  const win = doc.defaultView;
  const reduced = win.matchMedia('(prefers-reduced-motion: reduce)');
  let visible = false, disposed = false, failed = false;
  const update = () => {
    if (disposed) return;
    const playing = visible && !doc.hidden && !reduced.matches && !occluder?.open && !failed;
    const next = playing ? loop : still;
    if (image.getAttribute('src') !== next) image.setAttribute('src', next);
    image.dataset.animation = playing ? 'looping' : 'still';
  };
  const error = () => { failed = true; update(); };
  const observer = new win.IntersectionObserver(([entry]) => { visible = entry.isIntersecting && entry.intersectionRatio >= .1; update(); }, { threshold: .1 });
  const occlusion = occluder ? new win.MutationObserver(update) : null;
  observer.observe(image);
  occlusion?.observe(occluder, { attributes: true, attributeFilter: ['open'] });
  doc.addEventListener('visibilitychange', update);
  reduced.addEventListener('change', update);
  image.addEventListener('error', error);
  update();
  return () => {
    disposed = true; observer.disconnect(); occlusion?.disconnect();
    doc.removeEventListener('visibilitychange', update);
    reduced.removeEventListener('change', update);
    image.removeEventListener('error', error);
    image.setAttribute('src', still); image.dataset.animation = 'still';
  };
}
