/** One native modal for the exact source editorial of each system. */
export function initEditorialOverlay(doc, on, loadMarkdown = () => import('./notebook-markdown.js')) {
  const dialog = doc.querySelector('#editorial-overlay');
  const content = doc.querySelector('#editorial-overlay-content');
  const title = doc.querySelector('#editorial-overlay-title');
  const close = doc.querySelector('#editorial-overlay-close');
  if (!dialog || !content || !title || !close || typeof dialog.showModal !== 'function') return () => {};
  let opener = null, disposeMarkdown = null, request = 0;
  const release = () => {
    request++;
    disposeMarkdown?.(); disposeMarkdown = null;
    content.replaceChildren();
    opener?.focus();
    opener = null;
  };
  on(dialog, 'close', release);
  on(close, 'click', () => dialog.close());
  for (const button of doc.querySelectorAll('[data-editorial-open]')) {
    on(button, 'click', async () => {
      const template = doc.getElementById(button.dataset.editorialOpen);
      if (!template?.content) return;
      disposeMarkdown?.(); disposeMarkdown = null;
      const current = ++request;
      content.replaceChildren(template.content.cloneNode(true));
      title.textContent = button.dataset.editorialTitle;
      opener = button;
      dialog.showModal();
      dialog.scrollTop = 0;
      close.focus();
      if (template.dataset?.clientMarkdown) {
        const text = template.content.querySelector('[data-markdown-source]')?.content.textContent;
        if (typeof text !== 'string') return;
        try {
          const {mountMarkdown} = await loadMarkdown();
          if (current === request && dialog.open) disposeMarkdown = mountMarkdown(content, text);
        } catch {
          // Keep the pre-rendered HTML readable when the client renderer cannot load.
        }
      }
    });
  }
  return () => { if (dialog.open) dialog.close(); release(); };
}
