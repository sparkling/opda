// OPDA's authenticated comments pattern, adapted to a reusable overlay lifecycle.
// Artalk tokens and author fields never enter the browser.
const drafts = new Map();
export function mountCommentThread(root, { server, key, pageTitle, status }) {
  const controller=new AbortController(), {signal}=controller;
  const el=(tag,text)=>{const node=document.createElement(tag); if(text) node.textContent=text; return node;};
  const list=el('div'), more=el('button','Load more comments'), form=el('form');
  const author=el('p'), reply=el('p'), label=el('label','Your comment'), input=el('textarea');
  const submit=el('button','Post comment'), cancel=el('button','Cancel reply');
  input.id='comment-content'; input.rows=5; input.maxLength=5000; input.required=true;
  input.value=drafts.get(key)||''; label.htmlFor=input.id;
  submit.type='submit'; cancel.type=more.type='button'; more.hidden=form.hidden=cancel.hidden=reply.hidden=true;
  form.append(author,reply,label,input,submit,cancel); root.append(list,more,form);
  let offset=0, replyId=0, busy=false, posting=false;
  const seen=new Set();
  const request=async(method,body)=>{
    const url=new URL(server+'/api/v2/comments',location.origin);
    if(method==='GET') url.search=new URLSearchParams({page_key:key,offset:String(offset)});
    const result=await fetch(url,{method,credentials:'same-origin',redirect:'error',cache:'no-store',signal,
      headers:{accept:'application/json',...(body?{'content-type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})});
    if(!result.ok) throw Error(result.status===401?'Your session expired. Reload the page to sign in.':'Comments are temporarily unavailable.');
    return (await result.json()).data;
  };
  async function load() {
    if(busy||signal.aborted) return;
    busy=true; more.disabled=true; status.textContent='Loading comments…';
    try {
      const data=await request('GET'); if(signal.aborted) return;
      if(!Array.isArray(data.comments)||data.comments.length>20||!Number.isSafeInteger(data.count)||!data.viewer?.name) throw Error('Invalid comment response');
      author.textContent='Commenting as '+data.viewer.name; form.hidden=false;
      for(const comment of data.comments) {
        if(!Number.isSafeInteger(comment.id)||typeof comment.content!=='string'||typeof comment.nick!=='string') throw Error('Invalid comment');
        if(seen.has(comment.id)) continue; seen.add(comment.id);
        const article=el('article'); article.className='comment-entry';
        article.append(el('strong',comment.nick));
        const date=new Date(comment.date);
        if(Number.isFinite(date.getTime())) article.append(el('time',date.toLocaleString('en-GB')));
        if(comment.rid>0) article.append(el('p','Reply to comment #'+comment.rid));
        const content=el('p',comment.content); content.className='comment-content'; article.append(content);
        const respond=el('button','Reply'); respond.type='button';
        respond.addEventListener('click',()=>{replyId=comment.id;reply.textContent='Replying to '+comment.nick;reply.hidden=cancel.hidden=false;input.focus();},{signal});
        article.append(respond); list.append(article);
      }
      offset+=data.comments.length; more.hidden=!data.comments.length||offset>=data.count;
      more.textContent='Load more comments'; status.textContent=seen.size?'':'No comments yet.';
    } catch(error) {if(!signal.aborted){status.textContent=error.message;more.textContent='Retry';more.hidden=false;}}
    finally {busy=false;more.disabled=false;}
  }
  cancel.addEventListener('click',()=>{replyId=0;reply.hidden=cancel.hidden=true;},{signal});
  more.addEventListener('click',load,{signal});
  form.addEventListener('submit',async event=>{
    event.preventDefault(); const content=input.value.trim(); if(posting||busy||!content) return;
    posting=true;submit.disabled=true;status.textContent='Posting your comment…';
    try {
      const result=await request('POST',{page_key:key,content,rid:replyId,
        ...(typeof pageTitle==='string' && pageTitle.trim() && pageTitle.length<=1000 && !/[\u0000-\u001f\u007f-\u009f]/.test(pageTitle) ? {page_title:pageTitle.trim()} : {})});
      if(!Number.isSafeInteger(result?.id)) throw Error('Invalid comment response');
      input.value='';drafts.delete(key);replyId=0;reply.hidden=cancel.hidden=true;
      offset=0;seen.clear();list.replaceChildren(); await load();
      if(result.is_pending) status.textContent='Your comment has been submitted for review.';
    } catch(error) {if(!signal.aborted) status.textContent=error.message;}
    finally {posting=false;submit.disabled=false;}
  },{signal});
  load();
  return {destroy(){if(input.value) drafts.set(key,input.value);controller.abort();root.replaceChildren();}};
}
