import React, { useEffect, useState } from 'react';
import { parseDraftFrame, retractedDraft, terminalDraft } from '../../../src/chat/draft.mjs';

type Draft = { status: string; text: string };
type Frame = { onmessage: ((event: { data: string }) => void) | null; onerror: (() => void) | null; close(): void };
type Host = { EventSource?: new (url: string) => Frame; document?: Pick<Document, 'hidden' | 'addEventListener' | 'removeEventListener'> };
const hex = /^[a-f0-9]{48}$/;

/** One provisional-draft SSE consumer. A `reset` or terminal frame clears the visible text; a malformed or oversized frame, or a
 * stream error, retracts it. It reconnects only while the tab is visible and the draft is not terminal; a hidden tab closes the stream. */
export function openDraftStream(token: string, onDraft: (draft: Draft) => void, host: Host = globalThis as unknown as Host) {
  const Source = host.EventSource!, page = host.document!;
  let stream: Frame | null = null, terminal = false, closed = false;
  const connect = () => {
    stream?.close(); stream = null;
    if (closed || page.hidden || terminal) return;
    const current = stream = new Source(`/api/chat/drafts/${token}`);
    current.onmessage = event => {
      try {
        const next = parseDraftFrame(event.data);
        terminal = terminalDraft(next.status);
        onDraft(next);
        if (terminal) current.close();
      } catch { terminal = true; current.close(); onDraft({ ...retractedDraft }); }
    };
    current.onerror = () => { current.close(); if (!terminal) onDraft({ ...retractedDraft }); };
  };
  connect(); page.addEventListener('visibilitychange', connect);
  return () => { closed = true; stream?.close(); stream = null; page.removeEventListener('visibilitychange', connect); };
}

/** Provisional text is inert text, never Markdown or an App: nothing in it can mount a frame or link before the answer is checked. */
export function DraftView({ draft }: { draft: Draft }) {
  if (!draft.text) return null;
  return <section className="answer-draft" aria-label="Provisional answer">
    <p role="status"><small>{draft.status === 'checking' ? 'Checking this draft against the evidence…' : 'Drafting · not yet verified'}</small></p>
    <p className="answer-draft__text">{draft.text}</p>
  </section>;
}

export function AnswerDraft({ token }: { token: string }) {
  const [draft, setDraft] = useState<Draft>({ status: 'waiting', text: '' });
  useEffect(() => openDraftStream(token, setDraft), [token]);
  return <DraftView draft={draft} />;
}

/** A completed `answer-draft` fence whose body is exactly `{"token":"<48 hex>"}`; anything else stays inert code. */
export function renderAnswerDraft(language: string, source: string): React.ReactNode | undefined {
  if (language !== 'answer-draft' || source.length > 256) return undefined;
  try {
    const value = JSON.parse(source);
    if (value === null || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).join() !== 'token' || !hex.test(value.token)) return undefined;
    return <AnswerDraft token={value.token} />;
  } catch { return undefined; }
}
