/** Passive, bounded carousels. Uses the gallery's listener/teardown owner. */
export function initInfographicCarousels(doc, on, win) {
  const carousels = new Map();
  for (const root of doc.querySelectorAll('[data-infographic-carousel]')) {
    const all = [...root.querySelectorAll('[data-carousel-item]')];
    const allLinks = all.map(item => item.querySelector('a[data-lightbox]'));
    // Artefact filters mark non-matching figures data-filtered; navigate only the rest.
    const visible = () => all.filter(item => !item.hasAttribute('data-filtered'));
    let items = all, links = allLinks;
    const previous = [...root.querySelectorAll('[data-carousel-previous]')];
    const next = [...root.querySelectorAll('[data-carousel-next]')];
    const counter = root.querySelector('[data-carousel-counter]');
    const open = root.querySelector('[data-carousel-open]');
    if (!all.length || allLinks.some(link => !link) || !previous.length || !next.length || !counter || !open) continue;
    let current = 0;
    const show = index => {
      items = visible(); links = items.map(item => allLinks[all.indexOf(item)]);
      all.forEach(item => { if (!items.includes(item)) item.hidden = true; });
      if (!items.length) { counter.textContent = '0 of 0'; previous.concat(next).forEach(button => { button.disabled = true; }); return; }
      current = Math.max(0, Math.min(items.length - 1, index));
      items.forEach((item, i) => { item.hidden = i !== current; });
      previous.forEach(button => { button.disabled = current === 0; });
      next.forEach(button => { button.disabled = current === items.length - 1; });
      counter.textContent = `${current + 1} of ${items.length}`;
      open.textContent = `Open gallery · ${items.length} ${items.length === 1 ? 'preview' : 'previews'} ↗`;
      open.setAttribute('href', links[current].getAttribute('href'));
    };
    show(0);
    on(root, 'artefact-filter', () => { show(0); revealHash(); });
    const revealHash = () => {
      let id;
      try { id = decodeURIComponent(win?.location?.hash?.slice(1) || ''); } catch { return; }
      const index = id ? items.findIndex(item => item.id === id) : -1;
      if (index >= 0) show(index);
    };
    on(win, 'hashchange', revealHash);
    on(win, 'pageshow', revealHash);
    revealHash();
    previous.forEach(button => on(button, 'click', () => show(current - 1)));
    next.forEach(button => on(button, 'click', () => show(current + 1)));
    on(open, 'click', event => {
      if (event.button !== 0 || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
      event.preventDefault();
      links[current]?.click();
    });
    on(root, 'keydown', event => {
      if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      show(event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1 : current + (event.key === 'ArrowLeft' ? -1 : 1));
    });
    let touchStart = null;
    on(root, 'touchstart', event => {
      touchStart = event.touches?.length === 1 ? { x: event.touches[0].clientX, y: event.touches[0].clientY } : null;
    });
    on(root, 'touchend', event => {
      const touch = event.changedTouches?.[0];
      if (touchStart && touch) {
        const dx = touch.clientX - touchStart.x, dy = touch.clientY - touchStart.y;
        if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) show(current + (dx < 0 ? 1 : -1));
      }
      touchStart = null;
    });
    on(root, 'touchcancel', () => { touchStart = null; });
    carousels.set(root.id, { get links() { return links; }, show, release() { [...previous, ...next].forEach(button => { button.disabled = true; }); } });
  }
  return carousels;
}
