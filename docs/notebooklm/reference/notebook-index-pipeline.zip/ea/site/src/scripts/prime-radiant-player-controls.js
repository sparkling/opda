/** Event-driven controls for the existing intro. This adapter never starts
 * playback itself, changes sources, polls or schedules animation frames. */
export function formatMediaTime(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return '--:--';
  const total = Math.floor(seconds), minutes = Math.floor(total / 60);
  return minutes >= 60
    ? `${Math.floor(minutes / 60)}:${String(minutes % 60).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`
    : `${minutes}:${String(total % 60).padStart(2, '0')}`;
}

/** @param {HTMLVideoElement & {webkitEnterFullscreen?: () => void, webkitExitFullscreen?: () => void}} video
 * @param {HTMLElement} surface
 * @param {() => void} play Existing intro's deliberate-play action.
 * @param {(state: {paused: boolean, ended: boolean, duration: number, currentTime: number,
 * muted: boolean, volume: number, fullscreen: boolean, fullscreenSupported: boolean, notice: string}) => void} onState */
export function createRadiantPlayerControls(video, surface, play, onState) {
  const doc = video.ownerDocument;
  const root = /** @type {Document | ShadowRoot} */ (surface.getRootNode());
  const nativeControls = video.controls;
  let disposed = false, fullscreenPending = false, webkitFullscreen = false, notice = '';
  const ownsFullscreen = () => root.fullscreenElement === surface || doc.fullscreenElement === surface;
  const active = () => !disposed && !doc.hidden;
  function update() {
    if (!active()) return;
    const duration = Number.isFinite(video.duration) && video.duration > 0 ? video.duration : 0;
    const currentTime = Number.isFinite(video.currentTime) ? Math.max(0, video.currentTime) : 0;
    surface.dataset.playerPaused = String(video.paused || video.ended);
    onState({ paused: video.paused, ended: video.ended, duration, currentTime,
      muted: video.muted, volume: video.volume,
      fullscreen: ownsFullscreen() || webkitFullscreen,
      fullscreenSupported: Boolean(surface.requestFullscreen || video.webkitEnterFullscreen), notice });
  }
  const events = ['play', 'playing', 'pause', 'ended', 'loadedmetadata', 'durationchange',
    'timeupdate', 'seeking', 'seeked', 'volumechange', 'emptied', 'error'];
  for (const type of events) video.addEventListener(type, update);
  doc.addEventListener('visibilitychange', update);
  doc.addEventListener('fullscreenchange', update);
  const beginNativeFullscreen = () => { webkitFullscreen = true; video.controls = true; update(); };
  const endNativeFullscreen = () => { webkitFullscreen = false; video.controls = false; update(); };
  video.addEventListener('webkitbeginfullscreen', beginNativeFullscreen);
  video.addEventListener('webkitendfullscreen', endNativeFullscreen);
  video.controls = false;
  update();
  return {
    togglePlayback() {
      if (!active()) return;
      if (video.paused || video.ended) play(); else video.pause();
    },
    seek(seconds) {
      if (!active() || !Number.isFinite(seconds) || !Number.isFinite(video.duration) || video.duration <= 0) return;
      video.currentTime = Math.max(0, Math.min(video.duration, seconds));
      update();
    },
    toggleMute() {
      if (!active()) return;
      if (video.muted || video.volume === 0) {
        if (video.volume === 0) video.volume = 1;
        video.muted = false;
      } else video.muted = true;
      update();
    },
    setVolume(value) {
      if (!active() || !Number.isFinite(value)) return;
      video.volume = Math.max(0, Math.min(1, value));
      video.muted = video.volume === 0;
      update();
    },
    async toggleFullscreen() {
      if (!active() || fullscreenPending) return;
      fullscreenPending = true; notice = '';
      try {
        if (ownsFullscreen()) await doc.exitFullscreen();
        else if (surface.requestFullscreen) await surface.requestFullscreen();
        else if (video.webkitEnterFullscreen) video.webkitEnterFullscreen();
        else notice = 'Fullscreen is unavailable in this browser.';
        if (disposed && ownsFullscreen()) await doc.exitFullscreen();
      } catch { notice = 'Fullscreen could not be opened. The video remains available here.'; }
      finally { fullscreenPending = false; update(); }
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      for (const type of events) video.removeEventListener(type, update);
      doc.removeEventListener('visibilitychange', update);
      doc.removeEventListener('fullscreenchange', update);
      video.removeEventListener('webkitbeginfullscreen', beginNativeFullscreen);
      video.removeEventListener('webkitendfullscreen', endNativeFullscreen);
      video.controls = nativeControls;
      delete surface.dataset.playerPaused;
      if (ownsFullscreen()) Promise.resolve().then(() => doc.exitFullscreen()).catch(() => {});
      if (webkitFullscreen) { try { video.webkitExitFullscreen?.(); } catch {} }
    },
  };
}
