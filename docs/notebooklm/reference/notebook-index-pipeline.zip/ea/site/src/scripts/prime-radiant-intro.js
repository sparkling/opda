// Change the browser cache key when replacing the fixed media objects.
export const INTRO_URL = '/videos/prime-radiant/foundation-intro.mp4?v=20261004-audio-start';
export const INTRO_POSTER = '/videos/prime-radiant/foundation-intro-poster.webp?v=20261004-audio-start';
export const INTRO_SOURCES = [
  { src: '/videos/prime-radiant/foundation-intro-av1.mp4?v=20261004-audio-start', type: 'video/mp4; codecs="av01.0.12M.08, mp4a.40.2"' },
  { src: INTRO_URL, type: 'video/mp4' },
];

/** One audible native-video introduction; retain the final frame until replay.
 * @param {HTMLVideoElement} video
 * @param {(status: string) => void} [onStatus]
 */
export function createRadiantIntro(video, onStatus = () => {}) {
  const doc = video.ownerDocument, win = doc.defaultView;
  const reduced = win.matchMedia('(prefers-reduced-motion: reduce)');
  let disposed = false, visible = false, attempted = false, suspended = false, settled = false;
  let blocked = false, failed = false, userPaused = false, automaticPause = false, pending = false;
  let status = '', startupTimer, request = 0, sourceAssigned = false;
  const sources = [];
  const publish = value => { if (!disposed && value !== status) { status = value; onStatus(value); } };
  // Visibility gates initial playback only; scrolling must not interrupt the music.
  const eligible = () => !disposed && (visible || attempted) && !doc.hidden && !reduced.matches;
  const clearStartup = () => { if (startupTimer !== undefined) win.clearTimeout(startupTimer); startupTimer = undefined; };
  const invalidate = () => { request++; pending = false; clearStartup(); };
  const unload = () => { for (const source of sources) source.remove(); sources.length = 0; video.removeAttribute('src'); video.load(); };
  video.loop = false; video.muted = false; video.preload = 'none';

  function suspend() {
    if (!video.paused || pending) {
      suspended = true; automaticPause = !video.paused; invalidate(); video.pause();
    } else clearStartup();
  }
  function fail() {
    if (disposed || failed) return;
    failed = true; invalidate(); video.pause(); unload(); publish('error');
  }
  function play(deliberate = false) {
    if (!eligible() || failed || pending || (!deliberate && (settled || blocked || userPaused || (attempted && !suspended)))) return;
    if (deliberate) {
      if (settled || video.ended) video.currentTime = 0;
      settled = false; blocked = false; userPaused = false;
    }
    if (!sourceAssigned) {
      sourceAssigned = true;
      for (const rendition of INTRO_SOURCES) {
        const source = doc.createElement('source');
        source.src = rendition.src; source.type = rendition.type;
        sources.push(source); video.append(source);
      }
      video.load();
    }
    attempted = true; suspended = false; pending = true;
    const currentRequest = ++request;
    startupTimer = win.setTimeout(fail, 15000);
    try {
      Promise.resolve(video.play()).then(() => {
        if (disposed || currentRequest !== request) return;
        pending = false; clearStartup();
        if (!eligible()) { suspend(); return; }
        if (!video.paused) publish('playing');
      }).catch(error => {
        if (disposed || currentRequest !== request) return;
        pending = false; clearStartup();
        if (error?.name === 'NotAllowedError') { blocked = true; publish('blocked'); }
        else if (error?.name === 'AbortError') publish(reduced.matches ? 'reduced' : 'paused');
        else fail();
      });
    } catch { fail(); }
  }
  function update() {
    if (disposed || failed) return;
    if (!eligible()) { suspend(); if (reduced.matches) publish('reduced'); return; }
    if (settled || blocked || userPaused) {
      publish(settled ? 'ended' : blocked ? 'blocked' : 'paused');
      return;
    }
    play();
  }
  function playing() {
    if (disposed || failed || video.paused) return;
    if (!eligible() || userPaused || settled) { suspend(); return; }
    settled = false; blocked = false; userPaused = false; attempted = true;
    pending = false; automaticPause = false; clearStartup(); publish('playing');
  }
  function requestedPlay() {
    if (disposed || failed || video.paused) return;
    if (!eligible()) { suspend(); return; }
    // Native controls supply fresh intent, including resuming after a manual
    // pause or seeking away from the end. Keep their chosen playback position.
    settled = false; blocked = false; userPaused = false; suspended = false; attempted = true;
  }
  function seeked() {
    if (disposed || failed || !settled || video.ended) return;
    settled = false;
    if (video.paused) {
      userPaused = true; suspended = false;
      publish(reduced.matches ? 'reduced' : 'paused');
    }
  }
  function paused() {
    if (disposed || failed || !video.paused) return;
    clearStartup();
    if (settled || video.ended) { ended(); return; }
    if (!automaticPause) { userPaused = true; suspended = false; invalidate(); }
    automaticPause = false;
    publish(reduced.matches ? 'reduced' : 'paused');
  }
  function ended() {
    if (disposed || failed || !video.ended) return;
    settled = true; suspended = false; invalidate(); publish('ended');
    // Do not seek, unload or replace the source: the decoded final frame stays.
  }
  const observer = new win.IntersectionObserver(([entry]) => {
    visible = entry.isIntersecting && entry.intersectionRatio >= .5; update();
  }, { threshold: .5 });
  observer.observe(video);
  const events = [['play', requestedPlay], ['playing', playing], ['pause', paused], ['seeked', seeked], ['ended', ended], ['error', fail]];
  for (const [type, handler] of events) video.addEventListener(type, handler);
  doc.addEventListener('visibilitychange', update); reduced.addEventListener('change', update);
  publish(reduced.matches ? 'reduced' : 'loading');
  return {
    play: () => play(true),
    dispose() {
      if (disposed) return;
      disposed = true; invalidate(); observer.disconnect();
      doc.removeEventListener('visibilitychange', update); reduced.removeEventListener('change', update);
      for (const [type, handler] of events) video.removeEventListener(type, handler);
      video.pause(); unload();
    },
  };
}
