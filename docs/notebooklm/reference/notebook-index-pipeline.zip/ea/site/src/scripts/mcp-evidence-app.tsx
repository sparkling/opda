import React, { useEffect, useState } from 'react';
import { readBoundedJSON, validateAppReference, validateEvidenceResult, evidenceResultMaxBytes } from '../../../src/chat/app-contract.mjs';
import { evidenceView } from '../../../src/chat/evidence-view.mjs';
import { McpAppView } from './mcp-app-frame';

export const EVIDENCE_APP_ENDPOINT = '/api/chat/apps/evidence';
type EvidenceResult = ReturnType<typeof validateEvidenceResult>;

/** The result is private to the signed-in reader; the token is an opaque server reference, never evidence itself. */
export async function fetchEvidenceResult(token: string, signal?: AbortSignal): Promise<EvidenceResult> {
  const response = await fetch(`/api/chat/evidence/${token}`, { credentials: 'same-origin', redirect: 'error', signal, headers: { Accept: 'application/json' } });
  if (response.redirected) throw new Error('Evidence response unavailable');
  return validateEvidenceResult(await readBoundedJSON(response, evidenceResultMaxBytes));
}

/** A readable, inert rendition from the same view model, shown if the sandboxed App cannot be displayed. */
export function renderEvidenceFallback(result: EvidenceResult) {
  const view = evidenceView(result);
  return <div style={{ padding: '1rem', overflowWrap: 'anywhere' }}>
    <h3>{view.heading}</h3><p>{view.question}</p><p><small>{view.assurance}</small></p>
    {[view.custodyNote, view.correctionNote, view.shortenedNote].filter(Boolean).map((note, index) => <p key={index}>{note}</p>)}
    {view.findings.length > 0 && <section><h4>Findings</h4>{view.findings.map(finding => <div key={finding.index}>
      <p>{finding.statement}</p>
      {finding.refs.map((ref, index) => <blockquote key={index} style={{ whiteSpace: 'pre-wrap' }}>{ref.quote}<br /><small>{ref.sourceLabel} · {ref.origin}{ref.locator ? ` · ${ref.locator}` : ''}</small></blockquote>)}
    </div>)}</section>}
    <section><h4>Cited sources</h4>{view.sources.map(source => <div key={source.id}>
      <h5>{source.label} · {source.title}</h5><p><small>{source.summaryHeading}</small></p><p style={{ whiteSpace: 'pre-wrap' }}>{source.summary}</p>
      {source.note && <p><small>{source.note}</small></p>}
      {source.otherPassages.map((item, index) => <div key={index}><p style={{ whiteSpace: 'pre-wrap' }}>{item.text}</p><p><small>{item.caption}</small></p></div>)}
      {source.morePassagesNotice && <p><small>{source.morePassagesNotice}</small></p>}
      {source.limitation && <p><small>{source.limitation}</small></p>}
    </div>)}</section>
  </div>;
}

function McpEvidenceApp({ token }: { token: string }) {
  const [state, setState] = useState<{ result?: EvidenceResult; error?: boolean }>({});
  useEffect(() => {
    const abort = new AbortController();
    setState({});
    fetchEvidenceResult(token, abort.signal).then(result => { if (!abort.signal.aborted) setState({ result }); },
      () => { if (!abort.signal.aborted) setState({ error: true }); });
    return () => abort.abort();
  }, [token]);
  if (state.result) return <McpAppView endpoint={EVIDENCE_APP_ENDPOINT} result={state.result} fallback={() => renderEvidenceFallback(state.result!)} />;
  return <section className="mcp-diagram-app" aria-label="Evidence behind this answer"><p className="mcp-diagram-app__status" role="status">
    {state.error ? 'The evidence behind this answer could not be displayed.' : 'Loading the evidence behind this answer…'}</p></section>;
}

/** Only a completed `mcp-app` fence holding exactly a `ba-app-reference/v1` becomes the evidence App; anything else is not ours. */
export function renderMcpEvidence(language: string, source: string): React.ReactNode | undefined {
  if (language !== 'mcp-app') return undefined;
  try { return <McpEvidenceApp token={validateAppReference(source).token} />; }
  catch { return undefined; }
}
