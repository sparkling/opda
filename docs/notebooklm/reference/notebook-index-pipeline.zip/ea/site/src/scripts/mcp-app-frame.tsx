import React, { useEffect, useRef, useState } from 'react';
import { AppBridge, PostMessageTransport } from '@modelcontextprotocol/ext-apps/app-bridge';

const MAX_APP_BYTES = 2 * 1024 * 1024;
const frameOwners = new WeakMap<HTMLIFrameElement, symbol>();
export type Status = 'loading' | 'ready' | 'error';

async function readApp(response: Response) {
  if (!response.ok || response.redirected || !/^text\/html(?:;|$)/i.test(response.headers.get('content-type') || '') || !response.body) {
    throw new Error('Research response app unavailable');
  }
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let bytes = 0, html = '';
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) return html + decoder.decode();
      bytes += value.byteLength;
      if (bytes > MAX_APP_BYTES) throw new Error('Research response app too large');
      html += decoder.decode(value, { stream: true });
    }
  } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
}

/** The one iframe-mount owner for every Prime Radiant App: a fixed, authenticated, immutable App resource at `endpoint`;
 * model content is sent only as tool data (`result`), never as markup. */
export function mountMcpApp(frame: HTMLIFrameElement, { endpoint, result }: { endpoint: string; result: { title: string } & Record<string, unknown> }, onStatus: (status: Status) => void) {
  const abort = new AbortController();
  const document = frame.ownerDocument;
  const themeRoot = frame.closest('.laika-frame');
  const hostContext = () => ({ displayMode: 'inline' as const, availableDisplayModes: ['inline' as const], platform: 'web' as const,
    theme: (themeRoot ? themeRoot.classList.contains('dark') : document.documentElement.dataset.theme === 'dark') ? 'dark' as const : 'light' as const });
  const owner = Symbol();
  frameOwners.set(frame, owner);
  let bridge: AppBridge | undefined, disposed = false, initialized = false;
  let resizeTimer: number | undefined, pendingHeight = 480, appliedHeight = 480;
  frame.setAttribute('sandbox', 'allow-scripts');
  frame.setAttribute('referrerpolicy', 'no-referrer');
  frame.setAttribute('allow', "camera 'none'; microphone 'none'; geolocation 'none'; clipboard-read 'none'; clipboard-write 'none'");
  frame.style.height = '480px';
  const deadline = window.setTimeout(fail, 12000);
  // The chat owns its ShadowRoot theme. The SDK diffs complete context objects
  // and sends only changed fields, without recurring theme work.
  const themeObserver = new window.MutationObserver(syncTheme);
  themeObserver.observe(themeRoot || document.documentElement, { attributes: true, attributeFilter: [themeRoot ? 'class' : 'data-theme'] });
  function syncTheme() { if (!disposed && initialized && bridge) bridge.setHostContext(hostContext()); }

  function scheduleResize() {
    if (document.hidden || disposed || resizeTimer !== undefined || pendingHeight === appliedHeight) return;
    resizeTimer = window.setTimeout(() => {
      resizeTimer = undefined;
      if (document.hidden || disposed) return;
      appliedHeight = pendingHeight;
      frame.style.height = `${appliedHeight}px`;
    }, 50);
  }
  function visibilityChanged() {
    if (document.hidden && resizeTimer !== undefined) { window.clearTimeout(resizeTimer); resizeTimer = undefined; }
    else scheduleResize();
  }
  document.addEventListener('visibilitychange', visibilityChanged);
  function stopResizing() {
    themeObserver.disconnect();
    if (resizeTimer !== undefined) window.clearTimeout(resizeTimer);
    resizeTimer = undefined;
    document.removeEventListener('visibilitychange', visibilityChanged);
  }

  function clearFrame() {
    if (frameOwners.get(frame) !== owner) return;
    frameOwners.delete(frame);
    frame.removeAttribute('srcdoc');
  }

  function fail() {
    if (disposed) return;
    disposed = true;
    abort.abort();
    window.clearTimeout(deadline);
    stopResizing();
    void bridge?.close().catch(() => {});
    clearFrame();
    onStatus('error');
  }

  async function deliver() {
    if (disposed || initialized || !bridge) return;
    initialized = true;
    try {
      syncTheme();
      // Saved results have no pending invocation. The required input notification
      // precedes the result, without fabricating the original tool arguments.
      await bridge.sendToolInput({ arguments: {} });
      if (disposed) return;
      await bridge.sendToolResult({ content: [{ type: 'text', text: result.title }], structuredContent: result });
      if (disposed) return;
      window.clearTimeout(deadline);
      onStatus('ready');
    } catch { fail(); }
  }

  void (async () => {
    try {
      const html = await readApp(await fetch(endpoint, {
        credentials: 'same-origin', redirect: 'error', signal: abort.signal,
        headers: { Accept: 'text/html' },
      }));
      if (disposed) return;
      const target = frame.contentWindow;
      if (!target) throw new Error('Research response frame unavailable');
      // A null MCP client and empty capabilities deliberately expose no server
      // tools, resources, links, sampling or model-context updates to the App.
      bridge = new AppBridge(null, { name: 'Prime Radiant', version: '1.0.0' }, {}, {
        hostContext: hostContext(),
      });
      bridge.addEventListener('initialized', () => { void deliver(); });
      bridge.addEventListener('sizechange', ({ height }) => {
        if (!disposed && initialized && typeof height === 'number' && Number.isFinite(height) && height > 0 && height <= 1_000_000) {
          // No display-height cap: use the App's intrinsic content measurement.
          // Reject implausible geometry rather than clipping valid diagrams;
          // coalesce bursts and skip unchanged writes to avoid resize feedback.
          pendingHeight = Math.ceil(height);
          scheduleResize();
        }
      });
      bridge.onerror = fail;
      // Listen before executing the immutable App so its initialize cannot race
      // the host. PostMessageTransport checks the exact source WindowProxy.
      await bridge.connect(new PostMessageTransport(target, target));
      if (disposed) { await bridge.close(); return; }
      frame.srcdoc = html;
    } catch { fail(); }
  })();

  return async () => {
    if (disposed) return;
    disposed = true;
    abort.abort();
    window.clearTimeout(deadline);
    stopResizing();
    try {
      if (initialized) await bridge?.teardownResource({}, { timeout: 250 });
    } catch { /* An already removed iframe cannot acknowledge teardown. */ }
    finally { await bridge?.close(); clearFrame(); }
  };
}

/** One sandboxed App frame with the same loading, error and readable-fallback behaviour for every App. */
export function McpAppView({ endpoint, result, fallback }: { endpoint: string; result: { title: string } & Record<string, unknown>; fallback: () => React.ReactNode }) {
  const frame = useRef<HTMLIFrameElement>(null);
  const [status, setStatus] = useState<Status>('loading');
  useEffect(() => {
    setStatus('loading');
    const release = mountMcpApp(frame.current!, { endpoint, result }, setStatus);
    return () => { void release(); };
  }, [endpoint, result]);
  return <section className="mcp-diagram-app" aria-label={result.title}>
    {status !== 'ready' && <p className="mcp-diagram-app__status" role="status">
      {status === 'loading' ? 'Loading research response…' : 'The research response could not be displayed. A readable version follows.'}
    </p>}
    <iframe ref={frame} title={result.title} className="mcp-diagram-app__frame"
      sandbox="allow-scripts" referrerPolicy="no-referrer" hidden={status === 'error'} />
    {status === 'error' && fallback()}
  </section>;
}
