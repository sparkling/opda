function setupArchitecture(){
 const abort=new AbortController();
 document.querySelectorAll('[data-architecture]').forEach(root=>{
  root.addEventListener('click',event=>{
   const button=event.target.closest('[data-architecture-step]');
   if(!button||!root.contains(button))return;
   const step=button.dataset.architectureStep;
   root.dataset.step=step;
   root.querySelectorAll('[data-architecture-step]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
   root.querySelectorAll('[data-architecture-panel]').forEach(panel=>panel.hidden=panel.dataset.architecturePanel!==step);
  },{signal:abort.signal});
 });
 return()=>abort.abort();
}
let dispose=setupArchitecture();
addEventListener('pagehide',()=>dispose());
addEventListener('pageshow',event=>{if(event.persisted)dispose=setupArchitecture();});
