// Axonometric programme scene: one bounded renderer, finite autoplay, then a still drawing.
// The pure helpers at the top carry the safety rules and are unit-tested without a browser.

export const SCENE_LIMITS = Object.freeze({ maxPixels: 1_500_000, maxPixelRatio: 1.5, fps: 24, autoplayMs: 7200, focusMs: 420 });

const clamp01 = value => Math.min(1, Math.max(0, value));
const easeOut = value => 1 - (1 - value) ** 3;

/** Drawing-buffer size that never exceeds the pixel-ratio or total-pixel budget. */
export function drawingBufferSize(cssWidth, cssHeight, devicePixelRatio = 1, limits = SCENE_LIMITS) {
  const width = Math.max(1, Math.round(cssWidth || 0));
  const height = Math.max(1, Math.round(cssHeight || 0));
  const ratio = Math.min(devicePixelRatio || 1, limits.maxPixelRatio, Math.sqrt(limits.maxPixels / (width * height)));
  return { width, height, ratio, pixels: Math.floor(width * ratio) * Math.floor(height * ratio) };
}

/** Composition at a point in the finite timeline: element i of count settles, then the connections draw. */
export function composeFrame(progress, index, count) {
  const p = clamp01(progress);
  const delay = count > 1 ? (index / (count - 1)) * 0.36 : 0;
  const settle = easeOut(clamp01((p - delay) / 0.42));
  return { lift: (1 - settle) * 1.2, opacity: settle, connection: easeOut(clamp01((p - 0.5) / 0.38)), turn: (easeOut(p) - 1) * 0.42 };
}

/** RAF loop capped to `fps`; stops itself as soon as `frame` reports no further work. */
export function createFrameLoop({ requestFrame, cancelFrame, fps = SCENE_LIMITS.fps, frame }) {
  const interval = 1000 / fps;
  const blocks = new Set();
  let handle = 0, last = 0, wanted = false, destroyed = false;
  const cancel = () => { if (handle) cancelFrame(handle); handle = 0; last = 0; };
  const schedule = () => { if (!handle && wanted && !blocks.size && !destroyed) handle = requestFrame(tick); };
  function tick(time) {
    handle = 0;
    if (!wanted || blocks.size || destroyed) return;
    if (last && time - last < interval - 1) { schedule(); return; }
    const delta = last ? Math.min(time - last, interval * 3) : 0;
    last = time;
    wanted = frame(delta) === true;
    if (wanted) schedule(); else last = 0;
  }
  return {
    start() { wanted = true; schedule(); },
    stop() { wanted = false; cancel(); },
    block(reason) { blocks.add(reason); cancel(); },
    unblock(reason) { blocks.delete(reason); schedule(); },
    get pending() { return handle !== 0; },
    destroy() { destroyed = true; wanted = false; cancel(); },
  };
}

/** Playback, focus easing and visibility gating around a draw callback. */
export function createSceneController({ requestFrame, cancelFrame, draw, onStatus = () => {}, reducedMotion = false, limits = SCENE_LIMITS }) {
  let elapsed = 0, status = 'idle', target = null, reduced = reducedMotion;
  const mix = new Map();
  const setStatus = next => { if (next !== status) { status = next; onStatus(next); } };
  const easeFocus = delta => {
    let moving = false;
    const step = reduced ? 1 : delta / limits.focusMs;
    for (const id of new Set([...mix.keys(), ...(target ? [target] : [])])) {
      const goal = id === target ? 1 : 0, now = mix.get(id) ?? 0;
      const next = now < goal ? Math.min(goal, now + step) : Math.max(goal, now - step);
      if (next === 0 && goal === 0) mix.delete(id); else mix.set(id, next);
      if (next !== goal) moving = true;
    }
    return moving;
  };
  const loop = createFrameLoop({ requestFrame, cancelFrame, fps: limits.fps, frame(delta) {
    if (status === 'playing') {
      elapsed = Math.min(limits.autoplayMs, elapsed + delta);
      if (elapsed >= limits.autoplayMs) setStatus('finished');
    }
    const moving = easeFocus(delta);
    draw({ progress: elapsed / limits.autoplayMs, focus: mix });
    return status === 'playing' || moving;
  } });
  const settle = () => { elapsed = limits.autoplayMs; setStatus('finished'); loop.start(); };
  return {
    get status() { return status; },
    get progress() { return elapsed / limits.autoplayMs; },
    get pending() { return loop.pending; },
    start() { if (reduced) settle(); else { elapsed = 0; setStatus('playing'); loop.start(); } },
    pause() { if (status === 'playing') { setStatus('paused'); loop.stop(); } },
    resume() { if (status === 'paused' && !reduced) { setStatus('playing'); loop.start(); } },
    replay() { if (reduced) return settle(); elapsed = 0; setStatus('playing'); loop.start(); },
    setReducedMotion(value) { reduced = value; if (value && status !== 'finished') settle(); },
    setFocus(id) { target = id || null; loop.start(); },
    invalidate() { loop.start(); },
    setDocumentVisible(visible) { visible ? loop.unblock('hidden') : loop.block('hidden'); },
    setInView(inView) { inView ? loop.unblock('offscreen') : loop.block('offscreen'); },
    destroy() { loop.destroy(); mix.clear(); setStatus('destroyed'); },
  };
}

// Scene data. Lattice density rises from business direction to specification detail.
export const SCENE_VARIANTS = {
  semantic: {
    plates: [
      { id: 'ba', tone: '--layer-ba', y: 1.95, size: [2.6, 2.6], grid: 2 },
      { id: 'ea', tone: '--layer-ea', y: 0.65, size: [2.6, 2.6], grid: 4 },
      { id: 'sa', tone: '--layer-sa', y: -0.65, size: [2.6, 2.6], grid: 6 },
      { id: 'spec', tone: '--layer-spec', y: -1.95, size: [2.6, 2.6], grid: 8 },
    ],
    nodes: [],
    links: [{ tone: '--scene-axis', points: [[0, -2.9, 0], [0, 2.9, 0]] }],
  },
  spec: {
    plates: [
      { id: 'platform', tone: '--layer-spec', y: 0.7, x: -0.7, size: [3.6, 2.6], grid: 6 },
      { id: 'PLM Platform', tone: '--layer-ba', y: -1.2, x: 2.1, z: 1.4, size: [1.6, 1.6], grid: 2 },
    ],
    nodes: [
      { id: 'Builder', plate: 0, at: [-1.2, -0.6], tone: '--scene-axis' },
      { id: 'Ontology', plate: 0, at: [0, -0.6], tone: '--scene-axis' },
      { id: 'Interface', plate: 0, at: [1.2, -0.6], tone: '--scene-axis' },
      { id: 'Controller', plate: 0, at: [0, 0.6], tone: '--scene-axis' },
      { id: 'PLM Platform', plate: 1, at: [0, 0], tone: '--layer-ba' },
    ],
    // Semantic Fabric: the single connection from Interface to the independent PLM platform.
    links: [{ tone: '--scene-axis', points: [[0.5, 0.9, -0.6], [0.5, 0.9, 1.4], [2.1, 0.9, 1.4], [2.1, -0.81, 1.4]] }],
  },
};

function readTones(element) {
  const style = getComputedStyle(element);
  return token => style.getPropertyValue(token).trim() || '#9fb4be';
}

async function buildScene(canvas, variant) {
  const { Box3, BoxGeometry, BufferGeometry, Color, DoubleSide, EdgesGeometry, Float32BufferAttribute, Group, Line, LineBasicMaterial, LineSegments, Mesh, MeshBasicMaterial, OrthographicCamera, Scene, Vector3, WebGLRenderer } = await import('three');
  const renderer = new WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: 'low-power' });
  renderer.setClearColor(0x000000, 0);
  const scene = new Scene();
  const camera = new OrthographicCamera(-1, 1, 1, -1, 0.1, 60);
  const disposables = [];
  const keep = item => (disposables.push(item), item);
  const elements = [];
  const lineMaterial = () => keep(new LineBasicMaterial({ transparent: true, depthWrite: false }));
  const fillMaterial = () => keep(new MeshBasicMaterial({ transparent: true, depthWrite: false, side: DoubleSide }));

  variant.plates.forEach((plate, index) => {
    const [w, d] = plate.size;
    const group = new Group();
    const slab = keep(new BoxGeometry(w, 0.05, d));
    const face = new Mesh(slab, fillMaterial());
    const edge = new LineSegments(keep(new EdgesGeometry(slab)), lineMaterial());
    const lattice = [];
    for (let i = 1; i < plate.grid; i++) {
      const x = -w / 2 + (w * i) / plate.grid, z = -d / 2 + (d * i) / plate.grid;
      lattice.push(x, 0.03, -d / 2, x, 0.03, d / 2, -w / 2, 0.03, z, w / 2, 0.03, z);
    }
    const latticeGeometry = keep(new BufferGeometry());
    latticeGeometry.setAttribute('position', new Float32BufferAttribute(lattice, 3));
    const grid = new LineSegments(latticeGeometry, lineMaterial());
    group.add(face, edge, grid);
    scene.add(group);
    elements.push({ kind: 'plate', id: plate.id, tone: plate.tone, index, group, face, edge, grid, base: [plate.x ?? 0, plate.y, plate.z ?? 0] });
  });
  variant.nodes.forEach(node => {
    const host = elements[node.plate];
    const box = keep(new BoxGeometry(0.62, 0.36, 0.62));
    const group = new Group();
    const face = new Mesh(box, fillMaterial());
    const edge = new LineSegments(keep(new EdgesGeometry(box)), lineMaterial());
    group.add(face, edge);
    host.group.add(group);
    group.position.set(node.at[0], 0.21, node.at[1]);
    elements.push({ kind: 'node', id: node.id, tone: node.tone, index: host.index, group, face, edge });
  });
  const links = variant.links.map(link => {
    const geometry = keep(new BufferGeometry());
    geometry.setAttribute('position', new Float32BufferAttribute(link.points.flat(), 3));
    const line = new Line(geometry, lineMaterial());
    line.frustumCulled = false;
    scene.add(line);
    const lengths = link.points.slice(1).map((point, i) => Math.hypot(...point.map((v, axis) => v - link.points[i][axis])));
    return { line, tone: link.tone, points: link.points, lengths, total: lengths.reduce((a, b) => a + b, 0) };
  });
  // Draw a polyline up to a fraction of its length, so connections are traced rather than switched on.
  function trace(link, reach) {
    const position = link.line.geometry.attributes.position;
    let remaining = link.total * reach, drawn = 1;
    position.setXYZ(0, ...link.points[0]);
    for (let i = 0; i < link.lengths.length && remaining > 0; i++, drawn++) {
      const share = Math.min(1, remaining / link.lengths[i]);
      const [a, b] = [link.points[i], link.points[i + 1]];
      position.setXYZ(i + 1, ...a.map((v, axis) => v + (b[axis] - v) * share));
      remaining -= link.lengths[i];
    }
    position.needsUpdate = true;
    link.line.geometry.setDrawRange(0, reach > 0 ? drawn : 0);
  }

  // Frame the settled composition: centre on its bounds and measure them from the final viewpoint.
  const elevation = Math.atan(1 / Math.SQRT2);
  const target = new Vector3();
  function placeCamera(azimuth) {
    camera.position.set(Math.cos(elevation) * Math.sin(azimuth), Math.sin(elevation), Math.cos(elevation) * Math.cos(azimuth)).multiplyScalar(20).add(target);
    camera.lookAt(target);
    camera.updateMatrixWorld();
  }
  for (const item of elements) if (item.kind === 'plate') item.group.position.set(...item.base);
  for (const link of links) trace(link, 1);
  scene.updateMatrixWorld(true);
  const bounds = new Box3().setFromObject(scene);
  bounds.getCenter(target);
  placeCamera(Math.PI / 4);
  const extent = { x: 0, y: 0 }, corner = new Vector3();
  for (let i = 0; i < 8; i++) {
    corner.set(i & 1 ? bounds.max.x : bounds.min.x, i & 2 ? bounds.max.y : bounds.min.y, i & 4 ? bounds.max.z : bounds.min.z).applyMatrix4(camera.matrixWorldInverse);
    extent.x = Math.max(extent.x, Math.abs(corner.x)); extent.y = Math.max(extent.y, Math.abs(corner.y));
  }

  let tone = readTones(canvas);
  const colour = new Color();
  const paint = material => token => material.color.set(colour.set(tone(token)));
  function applyTones() {
    tone = readTones(canvas);
    for (const item of elements) for (const part of [item.face, item.edge, item.grid].filter(Boolean)) paint(part.material)(item.tone);
    for (const link of links) paint(link.line.material)(link.tone);
  }
  applyTones();

  function frame({ progress, focus }) {
    const count = variant.plates.length;
    const focused = Math.max(0, ...focus.values());
    for (const item of elements) {
      const state = composeFrame(progress, item.index, count);
      const own = focus.get(item.id) ?? 0;
      const presence = state.opacity * (1 - 0.55 * Math.max(0, focused - own));
      if (item.kind === 'plate') {
        item.group.position.set(item.base[0], item.base[1] + state.lift + own * 0.16, item.base[2]);
        item.face.material.opacity = presence * (0.07 + own * 0.1);
        item.edge.material.opacity = presence * (0.75 + own * 0.25);
        item.grid.material.opacity = presence * (0.28 + own * 0.3);
      } else {
        item.group.position.y = 0.21 + (1 - state.opacity) * 0.5 + own * 0.14;
        item.face.material.opacity = presence * (0.18 + own * 0.32);
        item.edge.material.opacity = presence;
      }
    }
    const reach = composeFrame(progress, 0, count).connection;
    for (const link of links) { trace(link, reach); link.line.material.opacity = 0.85 * reach; }
    placeCamera(Math.PI / 4 + composeFrame(progress, 0, 1).turn);
    renderer.render(scene, camera);
  }

  function resize(cssWidth, cssHeight) {
    const size = drawingBufferSize(cssWidth, cssHeight, window.devicePixelRatio);
    renderer.setPixelRatio(size.ratio);
    renderer.setSize(size.width, size.height, false);
    const aspect = size.width / size.height;
    const half = Math.max(extent.y * 1.12, (extent.x * 1.12) / aspect);
    Object.assign(camera, { left: -half * aspect, right: half * aspect, top: half, bottom: -half });
    camera.updateProjectionMatrix();
  }

  function dispose() {
    for (const item of disposables) item.dispose();
    renderer.dispose();
    renderer.forceContextLoss();
  }
  return { frame, resize, applyTones, dispose };
}

/** Mount one scene. Returns a teardown that releases every frame, observer, listener and GPU resource. */
export function mountProgrammeScene(root) {
  const win = root.ownerDocument.defaultView, doc = root.ownerDocument;
  const canvas = root.querySelector('canvas');
  const variant = SCENE_VARIANTS[root.dataset.variant] ?? SCENE_VARIANTS.semantic;
  const motion = win.matchMedia('(prefers-reduced-motion: reduce)');
  const cleanups = [];
  const listen = (target, type, handler, options) => { target.addEventListener(type, handler, options); cleanups.push(() => target.removeEventListener(type, handler, options)); };
  let scene = null, controller = null, inView = false, starting = false, torn = false;

  const visibility = new win.IntersectionObserver(entries => {
    inView = entries.some(entry => entry.isIntersecting);
    if (controller) controller.setInView(inView);
    else if (inView && !starting) start();
  }, { threshold: 0.05 });
  visibility.observe(root);
  cleanups.push(() => visibility.disconnect());

  async function start() {
    starting = true;
    try { scene = await buildScene(canvas, variant); } catch { root.dataset.scene = 'fallback'; return; }
    if (torn) { scene.dispose(); scene = null; return; }
    controller = createSceneController({
      requestFrame: callback => win.requestAnimationFrame(callback),
      cancelFrame: handle => win.cancelAnimationFrame(handle),
      draw: state => scene.frame(state),
      reducedMotion: motion.matches,
      onStatus: status => {
        root.dataset.status = status;
      },
    });
    const sizer = new win.ResizeObserver(([entry]) => { scene.resize(entry.contentRect.width, entry.contentRect.height); controller.invalidate(); });
    sizer.observe(canvas);
    cleanups.push(() => sizer.disconnect());
    const theme = new win.MutationObserver(() => { scene.applyTones(); controller.invalidate(); });
    theme.observe(doc.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    cleanups.push(() => theme.disconnect());
    const scheme = win.matchMedia('(prefers-color-scheme: light)');
    listen(scheme, 'change', () => { scene.applyTones(); controller.invalidate(); });
    listen(motion, 'change', () => controller.setReducedMotion(motion.matches));
    listen(doc, 'visibilitychange', () => controller.setDocumentVisible(!doc.hidden));
    for (const target of doc.querySelectorAll('[data-scene-focus], [data-part]')) {
      const id = target.dataset.sceneFocus ?? target.dataset.part;
      const on = () => controller.setFocus(id), off = () => controller.setFocus(null);
      listen(target, 'pointerenter', on); listen(target, 'pointerleave', off);
      listen(target, 'focusin', on); listen(target, 'focusout', off);
    }
    const rect = canvas.getBoundingClientRect();
    scene.resize(rect.width, rect.height);
    controller.setDocumentVisible(!doc.hidden);
    controller.setInView(inView);
    root.dataset.scene = 'live';
    controller.start();
  }

  return function teardown() {
    if (torn) return;
    torn = true;
    for (const cleanup of cleanups.splice(0)) cleanup();
    controller?.destroy();
    scene?.dispose();
    controller = scene = null;
    root.dataset.scene = 'fallback';
  };
}

/** Mount every scene on the page; tear down on pagehide and remount after a back-forward restore. */
export function mountProgrammeScenes(doc = document) {
  let teardowns = [];
  const mount = () => { teardowns = [...doc.querySelectorAll('[data-programme-scene]')].map(mountProgrammeScene); };
  const unmount = () => { for (const teardown of teardowns.splice(0)) teardown(); };
  doc.defaultView.addEventListener('pagehide', unmount);
  doc.defaultView.addEventListener('pageshow', event => { if (event.persisted) mount(); });
  mount();
}
