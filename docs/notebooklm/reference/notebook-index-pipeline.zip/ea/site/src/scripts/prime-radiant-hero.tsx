import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Maximize, Minimize, Pause, Play, RotateCcw, Volume2, VolumeX } from 'lucide-react';
import { observeRadiantAnimation } from './prime-radiant-motion.js';
import { createRadiantIntro, INTRO_POSTER } from './prime-radiant-intro.js';
import { createRadiantPlayerControls, formatMediaTime } from './prime-radiant-player-controls.js';

const artwork = {
  banner: { still: '/images/prime-radiant/banner.webp', loop: '/images/prime-radiant/banner-loop.webp' },
  icon: { still: '/images/prime-radiant/icon.webp', loop: '/images/prime-radiant/icon-loop.webp' },
};
export function PrimeRadiantArtwork({ variant }: { variant: 'banner' | 'icon' }) {
  const image = useRef<HTMLImageElement>(null);
  const { still, loop } = artwork[variant];
  useEffect(() => observeRadiantAnimation(image.current, { still, loop }), [still, loop]);
  return <img ref={image} src={still} alt={variant === 'banner' ? 'A faceted crystal enclosure holds a nested bronze lattice around a warm core.' : ''}
    width={variant === 'banner' ? 1600 : 256} height={variant === 'banner' ? 640 : 256}
    className={variant === 'icon' ? 'prime-icon' : undefined} />;
}

function PlayerControls({ video, surface, play, disabled }: {
  video: React.RefObject<HTMLVideoElement | null>; surface: React.RefObject<HTMLElement | null>;
  play: () => void; disabled: boolean;
}) {
  const controls = useRef<ReturnType<typeof createRadiantPlayerControls> | null>(null);
  const [media, setMedia] = useState({ paused: true, ended: false, duration: 0, currentTime: 0,
    muted: false, volume: 1, fullscreen: false, fullscreenSupported: false, notice: '' });
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const instance = createRadiantPlayerControls(video.current!, surface.current!, play, setMedia);
    controls.current = instance; setReady(true);
    return () => { instance.dispose(); controls.current = null; };
  }, [video, surface, play]);
  const label = media.ended ? 'Replay intro' : media.paused ? 'Play intro' : 'Pause intro';
  const silent = media.muted || media.volume === 0;
  return <div className="prime-player-bar" role="group" aria-label="Video controls" hidden={!ready}>
    <button type="button" aria-label={label} title={label} disabled={disabled} onClick={() => controls.current?.togglePlayback()}>
      {media.ended ? <RotateCcw size={18} aria-hidden="true" /> : media.paused ? <Play size={18} aria-hidden="true" /> : <Pause size={18} aria-hidden="true" />}
    </button>
    <span className="prime-player-time" aria-hidden="true">{formatMediaTime(media.currentTime)} / {formatMediaTime(media.duration || NaN)}</span>
    <input className="prime-player-seek" type="range" aria-label="Seek intro" min="0" max={media.duration || 1} step="0.1"
      value={Math.min(media.currentTime, media.duration || 0)} disabled={!media.duration || disabled}
      aria-valuetext={`${formatMediaTime(media.currentTime)} of ${formatMediaTime(media.duration || NaN)}`}
      onChange={event => controls.current?.seek(Number(event.target.value))} />
    <button type="button" aria-label={silent ? 'Unmute intro' : 'Mute intro'} title={silent ? 'Unmute intro' : 'Mute intro'}
      onClick={() => controls.current?.toggleMute()}>
      {silent ? <VolumeX size={18} aria-hidden="true" /> : <Volume2 size={18} aria-hidden="true" />}
    </button>
    <input className="prime-player-volume" type="range" aria-label="Volume" min="0" max="1" step="0.05"
      value={silent ? 0 : media.volume} aria-valuetext={`${Math.round((silent ? 0 : media.volume) * 100)} percent`}
      onChange={event => controls.current?.setVolume(Number(event.target.value))} />
    {media.fullscreenSupported && <button type="button" aria-label={media.fullscreen ? 'Exit fullscreen' : 'Fullscreen'}
      title={media.fullscreen ? 'Exit fullscreen' : 'Fullscreen'} onClick={() => controls.current?.toggleFullscreen()}>
      {media.fullscreen ? <Minimize size={18} aria-hidden="true" /> : <Maximize size={18} aria-hidden="true" />}
    </button>}
    {media.notice && <span className="prime-player-notice" role="status">{media.notice}</span>}
  </div>;
}

export function PrimeRadiantHero() {
  const video = useRef<HTMLVideoElement>(null);
  const surface = useRef<HTMLElement>(null);
  const controller = useRef<ReturnType<typeof createRadiantIntro> | null>(null);
  const [status, setStatus] = useState('loading');
  const play = useCallback(() => controller.current?.play(), []);
  useEffect(() => {
    const intro = createRadiantIntro(video.current!, setStatus); controller.current = intro;
    return () => { intro.dispose(); controller.current = null; };
  }, []);
  const statusText = status === 'error' ? 'The intro could not load here.' : status === 'blocked' ? 'Use the video controls to start the intro.' : status === 'reduced' ? 'Intro paused for reduced motion.' : status === 'loading' ? 'Loading intro…' : undefined;
  return <section ref={surface} className="prime-hero" tabIndex={0} aria-label="Prime Radiant research assistant video">
    <video ref={video} className="prime-hero-player" width="3840" height="1920" controls playsInline preload="none" poster={INTRO_POSTER} aria-label="Foundation intro with music" />
    <PlayerControls video={video} surface={surface} play={play} disabled={status === 'error' || status === 'reduced'} />
    {statusText && <div className="prime-hero-controls"><p role="status">{statusText}</p></div>}
  </section>;
}
