import {createPresentationState} from '../design/presentation-state.js';
function setupPresentation(){
 const root=document.querySelector('[data-presentation]');if(!root)return()=>{};
 const abort=new AbortController(),listen=(node,name,fn)=>node.addEventListener(name,fn,{signal:abort.signal});
 const slides=[...root.querySelectorAll('[data-slide]')];
 const state=createPresentationState(slides.map(s=>s.querySelectorAll('[data-beat]').length));
 const previous=document.getElementById('presentation-previous'),next=document.getElementById('presentation-next');
 const overview=document.getElementById('presentation-overview'),overviewButton=document.getElementById('presentation-overview-toggle');
 const fullButton=document.getElementById('presentation-fullscreen');
 let lastIndex=-1;
 function render(focus=false){
  const current=state.value(),slide=slides[current.index];
  slides.forEach((s,i)=>{
   s.hidden=i!==current.index;s.dataset.active=String(i===current.index);s.dataset.reveal=String(i===current.index?current.beat:0);
   if(i===current.index&&lastIndex!==current.index)s.scrollTop=0;
   s.querySelectorAll('[data-beat]').forEach((node,b)=>node.hidden=b>=current.beat);
   s.querySelectorAll('[data-visual-beat]').forEach(node=>{const revealed=Number(node.dataset.visualBeat)<current.beat;node.dataset.revealed=String(revealed);node.hidden=!revealed;});
  });
  root.querySelectorAll('[data-goto-slide]').forEach(b=>b.setAttribute('aria-current',Number(b.dataset.gotoSlide)===current.index?'step':'false'));
  document.getElementById('presentation-progress').textContent=`${current.index+1} / ${current.total} · ${current.beat} / ${slide.querySelectorAll('[data-beat]').length} reveals`;
  previous.disabled=current.first;next.disabled=current.last;
  next.textContent=current.last?'Presentation complete':current.beat<slide.querySelectorAll('[data-beat]').length?'Reveal next point →':'Next scene →';
  document.getElementById('presenter-notes-content').textContent=slide.dataset.presenterNotes;
  document.getElementById('presentation-reading-link').href=slide.dataset.readingHref;
  history.replaceState(null,'',`#slide-${slide.dataset.slide}`);
  lastIndex=current.index;
  if(focus)slide.querySelector('.slide-headline').focus({preventScroll:true});
 }
 function showOverview(open){overview.hidden=!open;overviewButton.setAttribute('aria-expanded',String(open));if(open)overview.querySelector('[aria-current=step]')?.focus();}
 function step(direction){if(!overview.hidden)showOverview(false);state[direction]();render();}
 async function fullscreen(){
  if(document.body.dataset.presenting==='true'){
   document.body.dataset.presenting='false';if(document.fullscreenElement)await document.exitFullscreen().catch(()=>{});
  }else{
   document.body.dataset.presenting='true';await document.documentElement.requestFullscreen?.().catch(()=>{});
  }
  fullButton.textContent=document.body.dataset.presenting==='true'?'Exit presentation view':'Presentation view';
 }
 listen(previous,'click',()=>step('previous'));listen(next,'click',()=>step('next'));
 listen(overviewButton,'click',()=>showOverview(overview.hidden));listen(fullButton,'click',fullscreen);
 listen(root,'click',e=>{const b=e.target.closest('[data-goto-slide]');if(!b)return;state.select(Number(b.dataset.gotoSlide));showOverview(false);render(true);});
 listen(document,'keydown',e=>{
  if(e.defaultPrevented||e.altKey||e.ctrlKey||e.metaKey||e.target.closest('input,textarea,select,[contenteditable=true]')||!document.getElementById('design-studio').hidden)return;
  if(e.key===' '&&e.target.closest('button,a'))return;
  if(['ArrowRight','PageDown',' '].includes(e.key)){e.preventDefault();step('next');}
  else if(['ArrowLeft','PageUp'].includes(e.key)){e.preventDefault();step('previous');}
  else if(e.key==='Home'){e.preventDefault();state.select(0);render();}
  else if(e.key==='Escape'){showOverview(false);document.body.dataset.presenting='false';fullButton.textContent='Presentation view';}
 });
 listen(document,'fullscreenchange',()=>{if(!document.fullscreenElement){document.body.dataset.presenting='false';fullButton.textContent='Presentation view';}});
 const initial=slides.findIndex(s=>`#slide-${s.dataset.slide}`===location.hash);if(initial>=0)state.select(initial);
 document.body.dataset.presentationReady='true';overview.hidden=true;render();
 return()=>abort.abort();
}
let dispose=setupPresentation();addEventListener('pagehide',()=>dispose());addEventListener('pageshow',e=>{if(e.persisted)dispose=setupPresentation();});
