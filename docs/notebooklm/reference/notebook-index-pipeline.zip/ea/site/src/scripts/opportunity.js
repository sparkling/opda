// Learning is a reader's activity. Responses stay in this page and are never sent.
function setup() {
  const abort = new AbortController();
  const listen = (target, event, handler) => target.addEventListener(event, handler, {signal:abort.signal});
  const article = document.querySelector('.chapter-content');
  const outline = document.getElementById('chapter-outline');
  function buildOutline() {
    outline.replaceChildren();
    if (document.body.classList.contains('experience-page')) {
      const stack = [{level:1,list:outline}];
      for (const heading of article.querySelectorAll('h2,h3[id],h4[id]')) {
        if (heading.closest('[hidden]')) continue;
        const section = heading.closest('.lesson-section[id]');
        const id = heading.id || (section?.querySelector('h2') === heading ? section.id : '');
        if (!id) continue;
        const level = Number(heading.tagName.slice(1));
        while (stack.length > 1 && stack.at(-1).level >= level) stack.pop();
        const parent = stack.at(-1), item = document.createElement('li');
        const link = document.createElement('a');
        link.href = `#${id}`; link.textContent = heading.textContent;
        item.append(link); parent.list.append(item);
        const list = document.createElement('ol'); item.append(list);
        stack.push({level,list});
      }
      for (const list of outline.querySelectorAll('ol:empty')) list.remove();
      if (outline.querySelectorAll('a').length > 20) {
        let first = true;
        for (const item of [...outline.children]) {
          const list = item.querySelector(':scope>ol'), link = item.querySelector(':scope>a');
          if (!list || !link) continue;
          const group = document.createElement('details'), summary = document.createElement('summary');
          group.name = 'experience-reading-sections'; summary.textContent = link.textContent;
          group.open = list.querySelector(`a[href="${CSS.escape(location.hash)}"]`) !== null || first;
          first = false;
          const overview = document.createElement('li'); link.textContent = 'Section overview';
          overview.append(link); list.prepend(overview); group.append(summary,list); item.append(group);
        }
      }
      return;
    }
    for (const section of article.querySelectorAll('.lesson-section[id]')) {
      if (section.hidden) continue;
      const heading = section.querySelector('h2');
      if (!heading) continue;
      const item = document.createElement('li'), link = document.createElement('a');
      link.href = `#${section.id}`; link.textContent = heading.textContent;
      item.append(link); outline.append(item);
    }
  }
  for (const form of article.querySelectorAll('form.judgement')) {
    function revealFeedback() {
      const choice = form.querySelector('input:checked')?.value;
      const feedback = form.querySelector('.judgement-feedback');
      if (!feedback) return;
      feedback.hidden = false;
      for (const branch of feedback.querySelectorAll('[data-feedback-for]')) {
        branch.hidden = branch.dataset.feedbackFor !== choice;
      }
      form.dataset.reviewed = 'true';
      for (const section of article.querySelectorAll('[data-unlock-after],[data-unlock-any]')) {
        const alternatives = (section.dataset.unlockAny || '').split(/\s+/).filter(Boolean);
        if (section.dataset.unlockAfter === form.dataset.exercise || alternatives.includes(form.dataset.exercise)) section.hidden = false;
      }
      const button = form.querySelector('[type=submit]');
      button.textContent = 'Revisit the reasoning';
      buildOutline();
      feedback.focus({preventScroll:true});
      feedback.scrollIntoView({block:'nearest',behavior:'instant'});
      document.dispatchEvent(new CustomEvent('programme-judgement-reviewed', {detail:{target:feedback}}));
    }
    listen(form, 'submit', event => {
      event.preventDefault();
      if (form.reportValidity()) revealFeedback();
    });
    for (const button of form.querySelectorAll('[data-review-discussion]')) {
      listen(button, 'click', revealFeedback);
    }
  }
  buildOutline();
  return () => abort.abort();
}
let teardown = setup();
addEventListener('pagehide', () => teardown());
addEventListener('pageshow', event => {if (event.persisted) teardown = setup();});
