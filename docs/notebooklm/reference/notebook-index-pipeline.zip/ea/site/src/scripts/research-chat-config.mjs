/** @typedef {{contextLabel:string, links:readonly {label:string,href:string}[], api:'/api/chat', sessionApi:'/api/chat/session', conversationsApi:'/api/chat/conversations'}} ResearchChatConfig */

/** Website presentation only. Identity, history and corpus scope remain server-owned.
 * @type {ResearchChatConfig}
 */
export const enterpriseChat = Object.freeze({
  contextLabel: 'Enterprise Architecture',
  links: Object.freeze([{ label: 'Research workspace', href: '/research/' }, { label: 'Presentation collections', href: '/' }]),
  api: '/api/chat', sessionApi: '/api/chat/session', conversationsApi: '/api/chat/conversations',
});

/** Validate the static website configuration before mounting the shared UI.
 * @param {unknown} value
 * @returns {ResearchChatConfig}
 */
export function researchChatConfig(value = enterpriseChat) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Invalid chat website configuration');
  const config = /** @type {ResearchChatConfig} */ (value);
  if (typeof config.contextLabel !== 'string' || !config.contextLabel.trim() || config.contextLabel.length > 120 ||
      config.api !== enterpriseChat.api || config.sessionApi !== enterpriseChat.sessionApi || config.conversationsApi !== enterpriseChat.conversationsApi ||
      !Array.isArray(config.links) || config.links.length > 12 || config.links.some(link => !link ||
        typeof link.label !== 'string' || !link.label.trim() || link.label.length > 120 ||
        typeof link.href !== 'string' || !/^\/(?!\/)[^\s\\\u0000-\u001f\u007f]*$/.test(link.href) || link.href.length > 300)) {
    throw new Error('Invalid chat website configuration');
  }
  return { contextLabel: config.contextLabel, links: config.links.map(({ label, href }) => ({ label, href })),
    api: enterpriseChat.api, sessionApi: enterpriseChat.sessionApi, conversationsApi: enterpriseChat.conversationsApi };
}
