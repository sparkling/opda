/** One page-load queue for every rendered preview and video poster. This module is
 * also embedded inline: keep it dependency-free so a failed bundle cannot block it.
 */
export function loadNotebookPreviewImages(doc, win) {
  const queue = [], starts = [], natives = [], watchers = new Set(), active = new Set();
  let disposed = false, startTimer = null, lastStart = -Infinity;
  const now = () => win.performance?.now() ?? Date.now();
  const stopStartTimer = () => {
    if (startTimer !== null) win.clearTimeout(startTimer);
    startTimer = null;
  };
  const startNext = () => {
    if (disposed || doc.hidden || startTimer !== null || !starts.length) return;
    const delay = Math.max(0, 50 - (now() - lastStart));
    if (delay > 0) {
      startTimer = win.setTimeout(() => { startTimer = null; startNext(); }, delay);
      return;
    }
    const job = starts.shift();
    if (active.has(job) && job.start()) lastStart = now();
    startNext();
  };
  const retryUrl = source => {
    const [path, ...fragment] = source.split('#');
    return `${path}${path.includes('?') ? '&' : '?'}preview-retry=1${fragment.length ? `#${fragment.join('#')}` : ''}`;
  };
  for (const target of doc.querySelectorAll('img[data-notebook-preview], video[data-notebook-poster]')) {
    const poster = target.getAttribute('data-notebook-poster');
    const source = poster || target.getAttribute('data-preview-source');
    const attribute = poster ? 'poster' : 'src';
    const initial = target.getAttribute(attribute);
    if (!source && initial && !target.getAttribute('data-preview-native-retried')) {
      natives.push({ target, source: initial, attribute, initial, native: true });
      continue;
    }
    if (!source || ['loaded', 'failed'].includes(target.getAttribute('data-preview-state'))) continue;
    // Inline deck navigation owns any real source it has already selected.
    if (!poster && initial && !initial.startsWith('data:')) continue;
    queue.push({ target, source, attribute, initial });
  }
  const clearTimer = job => {
    if (job.timer !== null) win.clearTimeout(job.timer);
    job.timer = null;
  };
  const armTimer = job => {
    clearTimer(job);
    if (!doc.hidden) job.timer = win.setTimeout(job.failed, 15000);
  };
  const pump = () => {
    while (!disposed && !doc.hidden && active.size < 3 && queue.length) {
      const entry = queue.shift();
      const { target, source, attribute, initial } = entry;
      if (!target.isConnected || target.getAttribute(attribute) !== initial) continue;
      const poster = attribute === 'poster';
      const image = poster ? doc.createElement('img') : target;
      const job = { timer: null, failed: null, cancel: null, start: null, waiting: false };
      let attempt = entry.native ? 1 : 0, requested = source, retrySource = entry.native ? retryUrl(source) : null;
      const ownsSource = () => target.isConnected && target.getAttribute(attribute) === (poster ? initial : requested);
      const detach = () => {
        clearTimer(job);
        image.removeEventListener('load', loaded);
        image.removeEventListener('error', failed);
        active.delete(job);
        if (poster) image.removeAttribute('src');
      };
      const finish = () => { detach(); pump(); };
      const loaded = () => {
        // A reserved job can still receive its placeholder's load before its turn.
        if (job.waiting) return;
        if (ownsSource()) {
          if (poster) target.setAttribute('poster', requested);
          target.setAttribute('data-preview-state', 'loaded');
        }
        finish();
      };
      const start = () => {
        if (attempt > 0 && !ownsSource()) { finish(); return false; }
        if (attempt === 0 && target.getAttribute(attribute) !== initial) { finish(); return false; }
        job.waiting = false;
        requested = retrySource || source;
        if (entry.native) target.setAttribute('data-preview-native-retried', 'true');
        armTimer(job);
        image.setAttribute('src', requested);
        return true;
      };
      const request = () => {
        job.waiting = true;
        starts.push(job);
        startNext();
      };
      const failed = () => {
        clearTimer(job);
        if (job.waiting) return;
        if (!ownsSource()) { finish(); return; }
        if (attempt++ === 0) {
          retrySource = retryUrl(source);
          request();
        } else {
          target.setAttribute('data-preview-state', 'failed');
          // Also cancels a stalled final attempt. Alt text and original links remain.
          image.removeAttribute('src');
          finish();
        }
      };
      job.failed = failed;
      job.start = start;
      job.cancel = () => {
        // Native icons retain their own in-flight source and never restart on teardown.
        if (!poster && !entry.native && ownsSource()) {
          image.setAttribute('src', initial || '');
          target.removeAttribute('data-preview-state');
        }
        detach();
      };
      active.add(job);
      target.setAttribute('data-preview-state', 'loading');
      image.addEventListener('load', loaded);
      image.addEventListener('error', failed);
      request();
    }
  };
  for (const entry of natives) {
    const { target, initial } = entry;
    const detach = () => {
      target.removeEventListener('load', detach);
      target.removeEventListener('error', failed);
      watchers.delete(detach);
    };
    const failed = () => {
      detach();
      if (!disposed && target.getAttribute('src') === initial) {
        queue.unshift(entry);
        pump();
      }
    };
    watchers.add(detach);
    target.addEventListener('load', detach);
    target.addEventListener('error', failed);
    if (target.complete) {
      if (target.naturalWidth === 0) failed();
      else detach();
    }
  }
  const visibility = () => {
    if (doc.hidden) stopStartTimer();
    for (const job of active) {
      if (doc.hidden) clearTimer(job);
      else if (!job.waiting) armTimer(job);
    }
    startNext();
    pump();
  };
  doc.addEventListener('visibilitychange', visibility);
  pump();
  return () => {
    disposed = true;
    queue.length = 0;
    starts.length = 0;
    stopStartTimer();
    doc.removeEventListener('visibilitychange', visibility);
    for (const detach of [...watchers]) detach();
    for (const job of [...active]) job.cancel();
  };
}

export function startNotebookPreviewImages(doc, win) {
  // Do not let the eager preview queue prolong the browser's initial load event.
  // A new task after load leaves the page usable while the finite queue warms.
  let release = null, startup = null;
  const start = () => {
    if (startup !== null || release) return;
    startup = win.setTimeout(() => {
      startup = null;
      release = loadNotebookPreviewImages(doc, win);
    }, 0);
  };
  if (doc.readyState === 'complete') start();
  else win.addEventListener('load', start, { once: true });
  const hide = () => {
    win.removeEventListener('load', start);
    if (startup !== null) win.clearTimeout(startup);
    startup = null;
    release?.(); release = null;
  };
  const show = event => { if (event.persisted && !release) start(); };
  win.addEventListener('pagehide', hide);
  win.addEventListener('pageshow', show);
  return () => {
    hide();
    win.removeEventListener('pagehide', hide);
    win.removeEventListener('pageshow', show);
  };
}
