import { mountCommentThread } from './notebook-comment-thread.js';
const dialog = document.querySelector('#notebook-comments');
if (dialog) {
  const title = dialog.querySelector('#comments-title');
  const status = dialog.querySelector('#comments-status');
  const retry = dialog.querySelector('#comments-retry');
  const thread = dialog.querySelector('#comments-thread');
  const server = new URL(dialog.dataset.server, location.origin);
  if (server.origin !== location.origin) throw Error('Comments must use the authenticated site origin');
  const base = server.href.replace(/\/$/, '');
  const adminLink = document.querySelector('#global-artalk-link');
  const adminSidebar = document.querySelector('#artalk-admin-sidebar');
  if (adminLink && adminSidebar) {
    const frame = adminSidebar.querySelector('iframe');
    adminLink.removeAttribute('target');
    adminLink.setAttribute('aria-haspopup', 'dialog');
    adminLink.setAttribute('aria-controls', adminSidebar.id);
    adminLink.addEventListener('click', event => {
      event.preventDefault();
      if (adminLink.hidden || adminSidebar.open) return;
      frame.src = adminLink.href;
      adminSidebar.showModal();
    });
    const close = () => adminSidebar.close();
    adminSidebar.querySelector('[data-admin-close]').addEventListener('click', close);
    adminSidebar.addEventListener('click', event => {
      const bounds = adminSidebar.getBoundingClientRect();
      if (event.target === adminSidebar && (event.clientX < bounds.left || event.clientX > bounds.right)) close();
    });
    frame.addEventListener('load', () => {
      try { frame.contentDocument?.addEventListener('keydown', event => {
        if (event.key === 'Escape') { event.preventDefault(); close(); }
      }); } catch { /* A redirected login page remains isolated. */ }
    });
    adminSidebar.addEventListener('close', () => { frame.removeAttribute('src'); adminLink.focus(); });
  }
  let instance, active, opener;
  function commentButton(label = 'Comments') {
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'comment-button';
    button.append(document.querySelector('#notebook-comment-icon').content.cloneNode(true));
    button.setAttribute('aria-label', label); button.title = label;
    button.setAttribute('aria-haspopup', 'dialog'); button.setAttribute('aria-controls', dialog.id);
    return button;
  }
  const slug = value => value.normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-|-$/g, '');
  const path = location.pathname;
  const readable = value => String(value || '').replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ').replace(/\s+/g, ' ').trim();
  const headingText = heading => {
    const copy = heading?.cloneNode(true);
    copy?.querySelectorAll('.comment-button,.index-branch-toggle').forEach(button => button.remove());
    return readable(copy?.textContent);
  };
  const pageTitle = headingText(document.querySelector('main h1'));
  const resourceKey = element => {
    const file = element?.querySelector('[data-deck-player]')?.dataset.pdf
      || element?.querySelector('video[src],audio[src]')?.getAttribute('src')
      || element?.querySelector('video source,audio source')?.getAttribute('src')
      || element?.querySelector('a[data-lightbox]')?.getAttribute('href');
    return file ? new URL(file, location.origin).pathname : null;
  };
  const nativePageTitle = (element, label) => {
    const section = element?.closest('.cognitive-level');
    const format = element?.closest('.format-group,.cognitive-media-section,.artefact-type');
    const artefact = element?.closest('.cognitive-card,.artefact-card,figure[data-carousel-item]');
    const artefactTitle = artefact?.querySelector('[data-deck-player]')?.dataset.title
      || artefact?.querySelector('a[data-lightbox]')?.dataset.title
      || headingText(artefact?.querySelector('.media-title,h6'));
    const parts = [dialog.dataset.site, pageTitle,
      headingText(section?.querySelector('.level-heading h2')),
      headingText(format?.querySelector(':scope > h3,:scope > h4')), artefactTitle || label].map(readable).filter(Boolean);
    // This is Artalk's native page title, not a new identity or placement record.
    return [...new Set(parts)].join(' › ').slice(0, 1000).trim();
  };
  function renderThread() {
    instance?.destroy(); instance = null; thread.replaceChildren();
    retry.hidden = true; status.textContent = 'Loading comments…';
    instance=mountCommentThread(thread,{server:base,key:active.key,pageTitle:active.pageTitle,status});
  }
  function openComments(key, label, button, pageTitle) {
    active = { key, title:label, pageTitle }; opener = button;
    title.textContent = `Comments — ${label}`;
    document.querySelectorAll('video,audio').forEach(media => media.pause());
    const play = document.querySelector('#deck-player-play');
    if (play?.getAttribute('aria-label') === 'Pause slides') play.click();
    (document.fullscreenElement || document.body).append(dialog);
    dialog.showModal();
    renderThread();
  }
  function buttonFor(key, label, element) {
    const button = commentButton(`Comments on ${label}`);
    button.dataset.commentKey = key;
    const pageTitle = nativePageTitle(element, label);
    button.addEventListener('click', event => { event.stopPropagation(); openComments(key, label, button, pageTitle); });
    return button;
  }
  // Directory cards are ordinary complete links. Never rewrite their navigation
  // or put comment controls inside them; comments belong to substantive content.
  document.querySelectorAll('main h1,main h2,main h3,main h4,main h5,main h6').forEach(heading => {
    if (heading.closest('[data-comments="off"],a.collection-card')) return;
    const label = headingText(heading);
    const artefact = heading.closest('.cognitive-card,.artefact-card,figure[data-carousel-item]');
    const anchor = heading.closest('[data-comment-anchor],[id]:not(main)');
    const key = heading.tagName === 'H1' ? path : resourceKey(artefact)
      || `${path}#${anchor?.dataset.commentAnchor || anchor?.id || 'page'}:${slug(label)}`;
    if (!heading.querySelector('.index-toggle')) {
      const text = document.createElement('span'); text.className = 'comment-heading-text';
      text.append(...heading.childNodes); heading.append(text);
    }
    heading.classList.add('comment-heading'); heading.append(buttonFor(key, label, heading));
  });
  document.querySelectorAll('figure[data-carousel-item]').forEach(figure => {
    const link = figure.querySelector('a[data-lightbox]');
    const key = resourceKey(figure);
    if (key) figure.querySelector('figcaption')?.append(buttonFor(key, link.dataset.title || 'Infographic', figure));
  });
  for (const [container, fileSelector, titleSelector] of [
    ['.deck-player-header', '#deck-player-pdf', '#deck-player-title'],
    ['.lightbox-header', '#lightbox-original', '#lightbox-title'],
    ['.deck-player-slide-thread', '#deck-player-pdf', '#deck-player-title'],
  ]) {
    const header = document.querySelector(container);
    if (!header) continue;
    const slidePlayer = container === '.deck-player-slide-thread';
    const button = commentButton(slidePlayer ? 'Comments on current slide' : container === '.deck-player-header' ? 'Deck comments' : 'Comments');
    if (slidePlayer) {
      const label = document.createElement('span'); label.id = 'deck-player-slide-comments-label';
      label.textContent = `Comments on slide ${Number(document.querySelector('#deck-player-range')?.value) || 1}`; button.append(label);
      button.setAttribute('aria-labelledby', label.id);
    } else if (container === '.deck-player-header') {
      const label = document.createElement('span'); label.textContent = 'Deck comments'; button.append(label);
    }
    button.addEventListener('click', () => {
      const file = document.querySelector(fileSelector)?.getAttribute('href');
      if (file && file !== '#') {
        const artefactKey = new URL(file,location.origin).pathname;
        const title = document.querySelector(titleSelector).textContent;
        const source = [...document.querySelectorAll('.cognitive-card,.artefact-card,figure[data-carousel-item]')].find(element => resourceKey(element) === artefactKey);
        const range = slidePlayer ? document.querySelector('#deck-player-range') : null;
        const slide = Number(range?.value), count = Number(range?.max);
        if (slidePlayer && (!Number.isSafeInteger(slide) || slide < 1 || !Number.isSafeInteger(count) || slide > count)) return;
        const key = slidePlayer ? `${artefactKey}#slide-${String(slide).padStart(3,'0')}` : artefactKey;
        const label = slidePlayer ? `${title} — slide ${slide} of ${count}` : title;
        const pageTitle = nativePageTitle(source, title) + (slidePlayer ? ` › Slide ${slide} of ${count}` : '');
        openComments(key, label, button, pageTitle.slice(0,1000));
      }
    });
    header.append(button);
  }
  retry.addEventListener('click', renderThread);
  dialog.querySelector('[data-comments-close]').addEventListener('click', () => dialog.close());
  dialog.addEventListener('keydown', event => event.stopPropagation());
  dialog.addEventListener('close', () => { instance?.destroy(); instance = null; thread.replaceChildren(); opener?.focus(); });
}
