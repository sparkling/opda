/** Passive inline deck controls. Callers own media admission and listener teardown. */
export function initDeckPreview({ card, image, previous, next, counters, slides, title,
  startSlide = 1, on, onSlide = () => {} }) {
  if (!card || !image || !previous.length || !next.length || !counters.length || !slides.length) return null;
  const count = slides.length;
  const clamp = number => Number.isSafeInteger(number) ? Math.max(1, Math.min(count, number)) : 1;
  let current = clamp(startSlide);
  const updateControls = () => {
    counters.forEach(counter => { counter.textContent = `Slide ${current} of ${count}`; });
    previous.forEach(control => { control.disabled = current === 1; });
    next.forEach(control => { control.disabled = current === count; });
  };
  const render = number => {
    current = clamp(number);
    onSlide(current, slides[current - 1]);
    image.hidden = false;
    image.alt = `${title}, slide ${current} of ${count}`;
    image.setAttribute('src', slides[current - 1]);
    updateControls();
  };
  updateControls();
  previous.forEach(control => on(control, 'click', () => render(current - 1)));
  next.forEach(control => on(control, 'click', () => render(current + 1)));
  on(card, 'keydown', event => {
    if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || /^(INPUT|TEXTAREA|SELECT)$/.test(event.target?.tagName)) return;
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    render(event.key === 'Home' ? 1 : event.key === 'End' ? count : current + (event.key === 'ArrowLeft' ? -1 : 1));
  });
  on(image, 'error', () => { counters.forEach(counter => { counter.textContent = 'Preview unavailable. Open the original PDF below.'; }); });
  on(image, 'load', updateControls);
  return render;
}
