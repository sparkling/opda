import type React from 'react';
import { renderMcpDiagram } from './mcp-diagram-app';
import { renderMcpEvidence } from './mcp-evidence-app';
import { renderAnswerDraft } from './answer-draft';

/** The chat's one `renderCodeBlock`: a diagram envelope or an evidence reference mounts its immutable App, a draft reference
 * streams the provisional text, and any other fence (or a payload that fails validation) stays inert code. */
export function renderChatCodeBlock(language: string, source: string): React.ReactNode | undefined {
  return renderAnswerDraft(language, source) ?? renderMcpEvidence(language, source) ?? renderMcpDiagram(language, source);
}
