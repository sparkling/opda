/** Reading views for factual selections and exact prompts in every collection. */
export function sourceGuide(brief) {
  const lines = [`# ${brief.title}`, '', brief.status ?? '', '', '## Data sources', ''];
  for (const source of brief.sources ?? []) {
    const title = source.title ?? source.path?.split('/').pop() ?? 'Source';
    lines.push(`- ${source.url ? `[${title}](${source.url})` : title}${source.role ? ` — ${source.role}` : ''}`);
    if (source.path) lines.push(`  - Source path: \`${source.path}\``);
    if (source.notebookSourceId) lines.push(`  - NotebookLM source ID: \`${source.notebookSourceId}\``);
    if (source.admission || source.status) lines.push(`  - ${[source.admission,source.status].filter(Boolean).join(' · ')}`);
    if (source.rationale) lines.push(`  - ${source.rationale}`);
  }
  if (brief.sourceGaps?.length) lines.push('', '## Source limitations', '', ...brief.sourceGaps.map(gap=>`- ${gap}`));
  if (brief.recordedArtefacts?.length) lines.push('', '## Retained artefact records', '', ...brief.recordedArtefacts.map(item=>`- [${item.title}](${item.url}) — \`${item.id}\``));
  if (brief.conditions) lines.push('', `## ${brief.editorialTerm ?? 'Editorial'} conditions`, '', brief.conditions);
  return lines.join('\n');
}

export function promptGuide(brief) {
  const lines = [`# ${brief.title}`, '', brief.status ?? '', '', '## Base prompt', '', brief.basePrompt ?? 'The exact base prompt is not present in the retained record.'];
  for (const [medium,prompt] of Object.entries(brief.mediaPrompts ?? {})) lines.push('', `## ${medium[0].toUpperCase()+medium.slice(1)} prompt`, '', prompt);
  return lines.join('\n');
}

/** Reading-dialog templates for one brief; an authoring decision is optional. */
export function authoringTemplates(brief) {
  if (brief.readingViews) return brief.readingViews.map(view => ({id:`input-${brief.id}-${view.id}`,text:view.text}));
  return [
    { id: `prompts-${brief.id}`, text: promptGuide(brief) },
    { id: `sources-${brief.id}`, text: sourceGuide(brief) },
    ...(brief.decision ? [{ id: `decision-${brief.id}`, text: brief.decision.text }] : []),
  ];
}

/** Dialog openers for one brief, in reading order after the subject's editorial. */
export function authoringResources(brief, subject) {
  if (brief.readingViews) return brief.readingViews.map(view => ({template:`input-${brief.id}-${view.id}`,label:view.label,title:`${subject}: ${view.label}`}));
  return [
    { template: `prompts-${brief.id}`, label: 'Prompts', title: `${subject}: prompts` },
    { template: `sources-${brief.id}`, label: 'Data sources', title: `${subject}: data sources` },
    ...(brief.decision ? [{ template: `decision-${brief.id}`, label: brief.decision.label, title: `${subject}: ${brief.decision.label} authoring decision` }] : []),
  ];
}
