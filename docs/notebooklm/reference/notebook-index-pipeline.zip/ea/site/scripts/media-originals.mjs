/** Shared validation and passive display renditions for NotebookLM media. */
import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import sharp from 'sharp';

export async function digest(file) {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(file)) hash.update(chunk);
  return hash.digest('hex');
}
export async function details(file, url) {
  return { path: url, bytes: (await fs.stat(file)).size, sha256: await digest(file) };
}
export async function copyVerified(from, to) {
  await fs.copyFile(from, to);
  if (await digest(from) !== await digest(to)) throw Error(`Copy verification failed: ${path.basename(from)}`);
}
export function videoInfo(file) {
  const info = JSON.parse(execFileSync('ffprobe', ['-v', 'error', '-select_streams', 'v:0',
    '-show_entries', 'stream=width,height:format=duration', '-of', 'json', file], { encoding: 'utf8' }));
  const stream = info.streams?.[0], duration = Number(info.format?.duration);
  if (!stream?.width || !stream.height || !Number.isFinite(duration) || duration <= 0) throw Error(`Invalid video metadata: ${path.basename(file)}`);
  return { width: stream.width, height: stream.height, duration: Math.round(duration * 1000) / 1000 };
}
export function audioInfo(file) {
  const info = JSON.parse(execFileSync('ffprobe', ['-v', 'error', '-show_entries',
    'stream=codec_type,codec_name:format=format_name,duration', '-of', 'json', file], { encoding: 'utf8' }));
  const stream = info.streams?.find(candidate => candidate.codec_type === 'audio'), duration = Number(info.format?.duration);
  if (!info.format?.format_name?.split(',').some(name => ['mov', 'mp4', 'm4a'].includes(name)) ||
      !stream?.codec_name || info.streams.some(candidate => candidate.codec_type === 'video') ||
      !Number.isFinite(duration) || duration <= 0) throw Error(`Invalid M4A audio: ${path.basename(file)}`);
  return { duration: Math.round(duration * 1000) / 1000, audioCodec: stream.codec_name };
}
export async function prepareRenditions({ original, destination, id, type, preview, poster }) {
  if (type === 'infographic') {
    const info = await sharp(original).metadata();
    if (!info.width || !info.height || info.format !== 'png') throw Error(`Invalid PNG: ${id}`);
    const target = path.join(destination, `${id}-preview.webp`);
    await sharp(original).rotate().resize({ width: 960, withoutEnlargement: true }).webp({ quality: 78 }).toFile(target);
    return { width: info.width, height: info.height, preview: await details(target, preview) };
  }
  if (type === 'video') {
    const info = videoInfo(original);
    const frame = execFileSync('ffmpeg', ['-v', 'error', '-ss', String(Math.min(1, info.duration / 2)),
      '-i', original, '-frames:v', '1', '-f', 'image2pipe', '-vcodec', 'mjpeg', 'pipe:1'], { maxBuffer: 32 * 1024 * 1024 });
    const target = path.join(destination, `${id}-poster.webp`);
    await sharp(frame).resize({ width: 960, withoutEnlargement: true }).webp({ quality: 76 }).toFile(target);
    return { ...info, poster: await details(target, poster) };
  }
  return type === 'audio' ? audioInfo(original) : {};
}
