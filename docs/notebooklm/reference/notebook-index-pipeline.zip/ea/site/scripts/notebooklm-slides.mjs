/** Retain NotebookLM's native PowerPoint exports and make finite, lazy slide renditions. */
import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { renderPdfSlides } from './pdf-slide-images.mjs';

const site = path.resolve(import.meta.dirname, '..');
const source = path.resolve(process.argv[2] || path.join(site, '.local/notebooklm/run-1'));
const destination = path.resolve(process.argv[3] || path.join(site, 'public/presentations/notebooklm/media/run-1'));
const metadataFile = path.resolve(process.argv[4] || path.join(site, 'src/data/notebooklm-slide-media.json'));
const catalog = JSON.parse(await fs.readFile(process.argv[5] || path.join(site, 'src/data/notebooklm-artifacts.json'), 'utf8'));
const decks = catalog.artifacts.filter(item => item.type === 'slide_deck');
const prefix = '/presentations/notebooklm/media/run-1/';
if (!decks.length || new Set(decks.map(item => item.id)).size !== decks.length) throw Error('Expected distinct slide decks');

async function digest(file) {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(file)) hash.update(chunk);
  return hash.digest('hex');
}
async function details(file, url) {
  return { path: url, bytes: (await fs.stat(file)).size, sha256: await digest(file) };
}
function pageCount(pdf) {
  const match = execFileSync('pdfinfo', [pdf], { encoding: 'utf8' }).match(/^Pages:\s+(\d+)$/m);
  const count = Number(match?.[1]);
  if (!Number.isSafeInteger(count) || count < 1 || count > 100) throw Error(`Invalid PDF page count: ${pdf}`);
  return count;
}
function pptxCount(pptx) {
  const names = execFileSync('unzip', ['-Z1', pptx], { encoding: 'utf8' });
  const count = names.split('\n').filter(name => /^ppt\/slides\/slide\d+\.xml$/.test(name)).length;
  if (!count) throw Error(`Invalid PowerPoint: ${pptx}`);
  return count;
}

await fs.mkdir(destination, { recursive: true });
const entries = [];
for (const deck of decks) {
  const { id, run } = deck;
  if (!/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(id) || run !== 1 || deck.src !== `${prefix}${id}.pdf`) {
    throw Error(`Invalid deck mapping: ${id}`);
  }
  const pdf = path.join(source, `${id}.pdf`);
  const original = path.join(source, `${id}.pptx`);
  for (const file of [pdf, original]) if (!(await fs.lstat(file)).isFile()) throw Error(`Not a regular file: ${file}`);
  const count = pageCount(pdf);
  if (pptxCount(original) !== count) throw Error(`PDF and PowerPoint slide counts differ: ${id}`);
  const pptx = path.join(destination, `${id}.pptx`);
  await fs.copyFile(original, pptx);
  if (await digest(original) !== await digest(pptx)) throw Error(`PowerPoint copy mismatch: ${id}`);
  const { slides } = await renderPdfSlides({ pdf, destination, id, urlPrefix: prefix, width: 1440, quality: 80, thumbnails: false });
  if (slides.length !== count) throw Error(`Missing slide renditions: ${id}`);
  entries.push({ id, pptx: await details(pptx, `${prefix}${id}.pptx`), slides });
  console.log(JSON.stringify({ id, slides: count, pptxBytes: entries.at(-1).pptx.bytes }));
}
await fs.mkdir(path.dirname(metadataFile), { recursive: true });
const serialized = ['{', '  "schema": "notebooklm-slides/v1",', '  "run": 1,', '  "complete": true,', '  "decks": [',
  ...entries.map((item, index) => `    ${JSON.stringify(item)}${index + 1 === entries.length ? '' : ','}`),
  '  ]', '}'].join('\n') + '\n';
await fs.writeFile(metadataFile, serialized);
console.log(JSON.stringify({ decks: entries.length, slides: entries.reduce((sum, item) => sum + item.slides.length, 0), metadataFile }));
