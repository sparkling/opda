/** Prepare the exact run-1 NotebookLM originals and small display renditions. */
import fs from 'node:fs/promises';
import path from 'node:path';
import { copyVerified, details, prepareRenditions } from './media-originals.mjs';

const site = path.resolve(import.meta.dirname, '..');
const allowMissing = process.argv.includes('--allow-missing');
const positions = process.argv.slice(2).filter(value => value !== '--allow-missing');
const source = path.resolve(positions[0] || path.join(site, '.local/notebooklm/run-1'));
const destination = path.resolve(positions[1] || path.join(site, 'public/presentations/notebooklm/media/run-1'));
const metadataFile = path.resolve(positions[2] || path.join(site, 'src/data/notebooklm-media.json'));
const catalog = JSON.parse(await fs.readFile(positions[3] || path.join(site, 'src/data/notebooklm-artifacts.json'), 'utf8'));
const urlPrefix = '/presentations/notebooklm/media/run-1/';
const extension = { infographic: '.png', slide_deck: '.pdf', video: '.mp4', audio: '.m4a' };

if (!Array.isArray(catalog.artifacts) || !catalog.artifacts.length) throw Error('Expected catalogue artifacts');
const seen = new Set();
const entries = [];
const missing = [];
await fs.mkdir(destination, { recursive: true });
for (const artifact of catalog.artifacts) {
  const { id, type, src, preview, poster } = artifact;
  if (!/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(id) || seen.has(id)) throw Error(`Invalid or duplicate artifact ID: ${id}`);
  seen.add(id);
  const ext = extension[type];
  if (!ext || artifact.run !== 1 || src !== `${urlPrefix}${id}${ext}` ||
      (type === 'infographic' && preview !== `${urlPrefix}${id}-preview.webp`) ||
      (type === 'video' && poster !== `${urlPrefix}${id}-poster.webp`) ||
      ((type === 'slide_deck' || type === 'audio') && (preview || poster)) ||
      (type === 'infographic' && poster) || (type === 'video' && preview)) {
    throw Error(`Invalid media mapping: ${id}`);
  }
  const original = path.join(source, `${id}${ext}`);
  try { await fs.access(original); } catch { missing.push(`${id}${ext}`); continue; }
  if (!(await fs.lstat(original)).isFile()) throw Error(`Original is not a regular file: ${id}`);
  if (type === 'slide_deck') {
    const pdf = await fs.open(original, 'r');
    try {
      const header = Buffer.alloc(5);
      await pdf.read(header, 0, 5, 0);
      if (header.toString() !== '%PDF-') throw Error(`Invalid PDF: ${id}`);
    } finally { await pdf.close(); }
  }
  const copy = path.join(destination, `${id}${ext}`);
  await copyVerified(original, copy);
  const entry = { id, type, ...await details(copy, src) };
  Object.assign(entry, await prepareRenditions({ original, destination, id, type, preview, poster }));
  entries.push(entry);
  console.log(JSON.stringify({ prepared: entries.length, id, type }));
}
if (missing.length && !allowMissing) throw Error(`Missing ${missing.length} originals: ${missing.join(', ')}`);
const result = { schema: 'notebooklm-media/v1', run: 1, complete: missing.length === 0,
  artifacts: entries, missing };
await fs.mkdir(path.dirname(metadataFile), { recursive: true });
const serialized = ['{', `  "schema": ${JSON.stringify(result.schema)},`, `  "run": ${result.run},`,
  `  "complete": ${result.complete},`, '  "artifacts": [',
  ...entries.map((item, index) => `    ${JSON.stringify(item)}${index + 1 === entries.length ? '' : ','}`),
  '  ],', `  "missing": ${JSON.stringify(missing)}`, '}'].join('\n') + '\n';
await fs.writeFile(metadataFile, serialized);
console.log(JSON.stringify({ artifacts: entries.length, missing: missing.length,
  bytes: entries.reduce((total, item) => total + item.bytes, 0), metadataFile }));
