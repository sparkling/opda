/** Render whole PDF pages, never just embedded pictures. No third-party upload. */
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import sharp from 'sharp';

export async function fileRecord(file, url) {
  const bytes = await fs.readFile(file);
  return { path: url, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
}

export async function renderPdfSlides({ pdf, destination, id, urlPrefix, width = 2048, quality = 88, thumbnails = true, renderer = 'poppler' }) {
  if (!/^[a-zA-Z0-9-]+$/.test(id) || !urlPrefix.startsWith('/presentations/') || urlPrefix.includes('..')) throw Error('Unsafe slide mapping');
  if (!['poppler','pdfium'].includes(renderer)) throw Error('Unknown PDF renderer');
  const count = Number(execFileSync('pdfinfo', [pdf], { encoding: 'utf8' }).match(/^Pages:\s+(\d+)$/m)?.[1]);
  if (!Number.isSafeInteger(count) || count < 1 || count > 100) throw Error('Invalid PDF page count');
  await fs.mkdir(destination, { recursive: true });
  const temp = await fs.mkdtemp(path.join(os.tmpdir(), 'pdf-slides-'));
  const slides = [], previews = [];
  try {
    if (renderer === 'pdfium') {
      execFileSync('python3', [path.join(import.meta.dirname, 'pdf-page-render.py'), pdf, temp, String(width)], {timeout:180000, stdio:'pipe'});
    } else {
      execFileSync('pdftoppm', ['-f', '1', '-l', String(count), '-scale-to', String(width), '-png', pdf, path.join(temp, 'slide')], { timeout: 180000, stdio: 'pipe' });
    }
    const rendered = (await fs.readdir(temp)).filter(name => /^slide-\d+\.png$/.test(name))
      .sort((a, b) => Number(a.match(/\d+/)[0]) - Number(b.match(/\d+/)[0]));
    if (rendered.length !== count) throw Error('Incomplete PDF rendering');
    for (const [index, name] of rendered.entries()) {
      const number = String(index + 1).padStart(3, '0');
      const file = `${id}-slide-${number}.webp`;
      const input = path.join(temp, name);
      const info = await sharp(input).webp({ quality, effort: 5 }).toFile(path.join(destination, file));
      slides.push({ ...await fileRecord(path.join(destination, file), `${urlPrefix}${file}`), width: info.width, height: info.height });
      if (thumbnails) {
        const thumb = `${id}-thumb-${number}.webp`;
        await sharp(input).resize({ width: 320 }).webp({ quality: 72 }).toFile(path.join(destination, thumb));
        previews.push(await fileRecord(path.join(destination, thumb), `${urlPrefix}${thumb}`));
      }
    }
  } finally { await fs.rm(temp, { recursive: true, force: true }); }
  return { slides, thumbnails: previews };
}

if (process.argv[1] && path.resolve(process.argv[1]) === import.meta.filename) {
  const [pdf, destination, metadata, id, prefix] = process.argv.slice(2);
  if (![pdf, destination, metadata, id, prefix].every(Boolean)) throw Error('Usage: pdf-slide-images.mjs PDF DEST METADATA ID URL_PREFIX');
  const result = await renderPdfSlides({ pdf: path.resolve(pdf), destination: path.resolve(destination), id, urlPrefix: prefix });
  const copy = path.join(destination, `${id}.pdf`);
  await fs.copyFile(pdf, copy);
  const receipt = { id, pdf: await fileRecord(copy, `${prefix}${id}.pdf`), ...result };
  await fs.mkdir(path.dirname(metadata), { recursive: true });
  await fs.writeFile(metadata, JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify({ slides: result.slides.length, bytes: result.slides.reduce((sum, s) => sum + s.bytes, 0), metadata }));
}
