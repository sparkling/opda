"""Bounded whole-page PDFium rendering for PDFs that exceed Poppler's budget."""
import argparse
from pathlib import Path
import pypdfium2 as pdfium

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('pdf', type=Path)
parser.add_argument('destination', type=Path)
parser.add_argument('width', type=int)
args = parser.parse_args()
if not 320 <= args.width <= 4096:
    parser.error('Width must be between 320 and 4096 pixels')
source = args.pdf.resolve(strict=True)
destination = args.destination.resolve(strict=True)
if not source.is_file() or not destination.is_dir():
    parser.error('Expected a PDF file and an existing destination directory')
with pdfium.PdfDocument(source) as document:
    if not 1 <= len(document) <= 100:
        raise ValueError('Expected 1–100 PDF pages')
    for index in range(len(document)):
        page = document[index]
        try:
            width, height = page.get_size()
            bitmap = page.render(scale=args.width / max(width, height))
            try:
                bitmap.to_pil().save(destination / f'slide-{index+1:03}.png')
            finally:
                bitmap.close()
        finally:
            page.close()
