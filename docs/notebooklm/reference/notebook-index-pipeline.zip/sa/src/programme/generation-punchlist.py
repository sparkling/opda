"""Persistent failure follow-up, closed only by verified website publication."""
import hashlib
import importlib.util
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
JSON_PATH = ROOT / 'docs/generation/punchlists/unresolved.json'
MD_PATH = ROOT / 'docs/generation/punchlists/unresolved.md'

def module(name):
    spec = importlib.util.spec_from_file_location(name.replace('-', '_'), ROOT / 'src/programme' / (name + '.py'))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def published_ids(runs):
    custody_worker = module('generation-transfer-worker')
    custody = custody_worker.load_verified_state(custody_worker.DEFAULT_RECEIPT)
    index = module('generation-index-publication')
    indexes = index.load_verified_state()
    extensions = {'audio': 'm4a', 'video': 'mp4', 'infographic': 'png', 'slide_deck': 'pdf'}
    published = set()
    for run in runs:
        page_key = run['sectionId'] + '/index.html'
        path = ROOT / 'site/dist' / page_key
        if not path.is_file():
            continue
        body = path.read_bytes()
        if hashlib.sha256(body).hexdigest() != indexes.get(page_key):
            continue
        page = body.decode()
        for job in run['jobs']:
            if job['status'] != 'completed' or not job.get('id'):
                continue
            key = f"custody/generation/{run['notebookId']}/{job['id']}.{extensions[job['type']]}"
            if key in custody and '/' + key in page and job['id'] in page:
                published.add(job['id'])
    return published

def project(runs, previous, published, timestamp):
    entries = {item['key']: dict(item) for item in previous.get('entries', [])}
    for run in runs:
        for job in run['jobs']:
            failures = [attempt for attempt in [*job.get('attemptHistory', []), job] if attempt.get('status') == 'failed']
            uncertain = job['status'] in ('failed', 'missing-provider-record', 'needs-reconciliation')
            if job['key'] not in entries and not uncertain and not (failures and job.get('id') not in published):
                continue
            entry = entries.setdefault(job['key'], {'key': job['key'], 'section': run['sectionId'], 'firstObservedAt': timestamp})
            previously_published = entry.get('state') == 'resolved' and entry.get('currentProviderId') == job.get('id')
            failure_ids = sorted({attempt['id'] for attempt in failures if attempt.get('id')})
            entry.update(currentStatus=job['status'], currentProviderId=job.get('id'),
                         failedProviderIds=sorted(set(entry.get('failedProviderIds', [])) | set(failure_ids)),
                         failedAttempts=len(failures), lastObservedAt=timestamp)
            resolved = job['status'] == 'completed' and (job.get('id') in published or previously_published)
            entry['state'] = 'resolved' if resolved else 'open'
            entry['followUp'] = ('Generated and verified on website' if resolved else
                                 'Awaiting verified website publication' if job['status'] == 'completed' else
                                 'Retry in progress' if job['status'] == 'submitted' else
                                 'Queued for replacement' if job['status'] == 'planned' else
                                 'Automatic retry / reconciliation required')
            if resolved:
                entry.setdefault('resolvedAt', timestamp)
            else:
                entry.pop('resolvedAt', None)
    return {'schema': 'sa-artefact-punchlist/v1', 'updatedAt': timestamp,
            'entries': sorted(entries.values(), key=lambda item: (item['state'] != 'open', item['key']))}

def atomic_write(path, body):
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_suffix(path.suffix + '.pending')
    pending.write_text(body)
    pending.replace(path)

def refresh():
    runs = [json.loads(path.read_text()) for path in sorted((ROOT / 'docs/generation').glob('*.json'))]
    previous = json.loads(JSON_PATH.read_text()) if JSON_PATH.is_file() else {}
    result = project(runs, previous, published_ids(runs), datetime.now(timezone.utc).isoformat())
    atomic_write(JSON_PATH, '{"schema":"sa-artefact-punchlist/v1","updatedAt":' + json.dumps(result['updatedAt']) + ',"entries":[\n'
                 + ',\n'.join(json.dumps(item) for item in result['entries']) + '\n]}\n')
    rows = [item for item in result['entries'] if item['state'] == 'open']
    lines = ['# Unresolved artefact punchlist', '', 'Updated: ' + result['updatedAt'], '',
             'Automatically refreshed by the index worker. A retry remains open until the replacement original has verified AWS custody and a verified deployed page link.', '',
             '| Artefact | Current state | Failed attempts | Follow-up |', '|---|---|---:|---|']
    lines += [f"| `{item['key']}` | {item['currentStatus']} | {item['failedAttempts']} | {item['followUp']} |" for item in rows]
    if not rows:
        lines += ['| None | — | 0 | No unresolved artefact failures |']
    lines += ['', f"Open: {len(rows)}. Resolved: {len(result['entries']) - len(rows)}. IDs and retained history: [machine-readable punchlist](unresolved.json).", '',
              'Provider inventory timeouts and authentication errors remain in pipeline stage-status records; they are not evidence that individual artefacts failed.', '']
    atomic_write(MD_PATH, '\n'.join(lines))
    return len(rows)

if __name__ == '__main__':
    print(json.dumps({'open': refresh()}))
