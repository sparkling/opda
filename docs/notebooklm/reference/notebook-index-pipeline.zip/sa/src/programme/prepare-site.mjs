import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { sharedRenderer } from './shared-renderer.mjs';
import { createHash } from 'node:crypto';
const root=fileURLToPath(new URL('../../',import.meta.url));
const hash=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const assetPath=value=>typeof value==='string' && /^(?:fonts|images\/prime-radiant|videos\/prime-radiant)\/[a-z0-9][a-z0-9.-]*$/.test(value) && !value.includes('..');

/** Copy only explicitly admitted shared branding bytes, never the EA media tree. */
export function prepareSharedAssets(project, renderer) {
  const pin=JSON.parse(fs.readFileSync(path.join(project,'config/shared-renderer.json'),'utf8'));
  if(!Array.isArray(pin.assets)||new Set(pin.assets).size!==pin.assets.length||!pin.assets.every(assetPath))throw Error('Invalid shared asset admission');
  let assets=[];
  if(pin.mediaAssetManifest){
    if(pin.mediaAssetManifest!=='config/prime-radiant-assets.json')throw Error('Invalid shared media manifest path');
    const manifest=JSON.parse(fs.readFileSync(path.join(project,pin.mediaAssetManifest),'utf8'));
    if(manifest.schema!=='shared-brand-assets/v1'||!Array.isArray(manifest.assets)||manifest.assets.length>10)throw Error('Invalid shared media manifest');
    assets=manifest.assets;
    if(new Set(assets.map(item=>item.path)).size!==assets.length||assets.some(item=>!assetPath(item.path)||!pin.assets.includes(item.path)||
      !Number.isSafeInteger(item.bytes)||item.bytes<1||item.bytes>512*1024*1024||!/^[a-f0-9]{64}$/.test(item.sha256)||
      !['git','canonical-file'].includes(item.source)||item.contentType!==(item.path.endsWith('.webp')?'image/webp':item.path.endsWith('.mp4')?'video/mp4':null)))throw Error('Invalid shared media record');
  }
  const admitted=new Map(assets.map(item=>[item.path,item]));
  const copies=pin.assets.map(asset=>{
    const record=admitted.get(asset);
    if(!asset.startsWith('fonts/')&&!record)throw Error('Shared media has no byte manifest: '+asset);
    const base=fs.realpathSync(path.resolve(record?.source==='canonical-file'?renderer.checkout:renderer.directory,'site/public'));
    const source=path.join(base,asset);
    const target=path.join(project,'site/public',asset);
    if(!fs.realpathSync(source).startsWith(base+path.sep)||fs.lstatSync(source).isSymbolicLink()||!fs.statSync(source).isFile())throw Error('Unsafe shared asset source');
    if(record&&(fs.statSync(source).size!==record.bytes||hash(source)!==record.sha256))throw Error('Shared media differs from admitted bytes: '+asset);
    return {source,target,record};
  });
  for(const {source,target,record} of copies){
    fs.mkdirSync(path.dirname(target),{recursive:true});
    const publicRoot=fs.realpathSync(path.join(project,'site/public'));
    if(!fs.realpathSync(path.dirname(target)).startsWith(publicRoot+path.sep)||(fs.existsSync(target)&&fs.lstatSync(target).isSymbolicLink()))throw Error('Unsafe shared asset target');
    fs.copyFileSync(source,target);
    if(record&&(fs.statSync(target).size!==record.bytes||hash(target)!==record.sha256))throw Error('Copied shared media failed verification');
  }
  return copies.length;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))prepareSharedAssets(root,sharedRenderer());
