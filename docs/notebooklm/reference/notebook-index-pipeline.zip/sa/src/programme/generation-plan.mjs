/** Freeze the approved 34-resource EA matrix for all SA subjects, without submitting jobs. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { validateSources } from './validate.mjs';
import { readNotebookEvidence } from '../corpus/notebook.mjs';
const root=fileURLToPath(new URL('../../',import.meta.url));
const read=file=>JSON.parse(fs.readFileSync(path.resolve(root,file),'utf8'));
const digest=value=>crypto.createHash('sha256').update(value).digest('hex');
const programme=read('config/programme.json');
const pin=read('config/shared-renderer.json');
const shared=path.resolve(root,pin.checkout);
const templateFile='docs/programme/ea-subject-media/run-2026-09-27.json';
const templates=JSON.parse(fs.readFileSync(path.join(shared,templateFile),'utf8')).jobs.filter(job=>job.subject==='E1');
if(templates.length!==34)throw Error('The approved EA matrix must contain 34 resources');
const sourceCommit=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const notebookId='e6dbcad2-e94f-4305-9e0b-62a6c03216e6';
const {bundles,uploads}=await readNotebookEvidence(root);
const directory=path.join(root,'docs/generation');fs.mkdirSync(directory,{recursive:true});
let total=0;
for(const section of programme.sections){
  const file=path.join(directory,section.id+'.json');
  if(fs.existsSync(file))throw Error('Refusing to overwrite a generation ledger: '+section.id);
  const briefs=read(`config/authoring/${section.id}.json`).subjects;
  const subjects=briefs.map((brief,level)=>{
    validateSources(root,brief,bundles,uploads);
    if(brief.factualInput?.state!=='indexed-verified')throw Error('Unverified factual input '+brief.id);
    const frozen=JSON.parse(execFileSync('git',['show',`${sourceCommit}:config/authoring/${section.id}.json`],{cwd:root,encoding:'utf8'})).subjects[level];
    if(JSON.stringify(brief)!==JSON.stringify(frozen))throw Error('Uncommitted authoring input '+brief.id);
    return {id:brief.id,title:brief.title,level,factualSourceIds:brief.factualSourceIds,editorialSourceId:null,
      editorialSha256:digest(brief.editorialNote),editorialVersion:brief.editorialVersion,
      promptHashes:Object.fromEntries(Object.entries(brief.mediaPrompts).map(([medium,text])=>[medium,digest(text)]))};
  });
  const jobs=subjects.flatMap(subject=>templates.map(template=>{
    const {focus_prompt,source_ids,title,notebook_id,...options}=template.settings;
    const medium={slide_deck:'deck',audio:'audio',video:'video',infographic:'infographic'}[template.type];
    if(!medium)throw Error('Unexpected matrix medium');
    return {key:`${subject.id}-${template.type}-${template.format}-${template.editorial?'with':'without'}-editorial-${template.ordinal}`,
      subject:subject.id,level:subject.level,type:template.type,format:template.format,ordinal:template.ordinal,
      editorial:template.editorial,version:subject.editorialVersion,medium,
      title:`${section.name} — ${subject.title} — ${template.format.replaceAll('_',' ')}${template.type==='infographic'?' '+template.ordinal+' of 10':''} — ${template.editorial?'With':'Without'} editorial v${subject.editorialVersion}`,
      settings:options,status:'planned',id:null};
  }));
  if(new Set(jobs.map(job=>job.key)).size!==briefs.length*34)throw Error('Matrix identity mismatch');
  const header={schemaVersion:1,sourceCommit,notebookId,sectionId:section.id,requested:jobs.length,
    commissioned:true,publish:true,createdAt:new Date().toISOString(),matrixSource:templateFile,
    matrixRendererCommit:pin.revision,subjects};
  fs.writeFileSync(file,JSON.stringify(header).slice(0,-1)+',"jobs":[\n'+jobs.map(job=>JSON.stringify(job)).join(',\n')+'\n]}\n');
  total+=jobs.length;
}
if(total!==3060)throw Error('Expected 3060 artefacts');
console.log(JSON.stringify({requested:total,sections:programme.sections.length,notebookId,sourceCommit,submitted:0}));
