// A read-only machine projection. Artalk signing material never leaves this owner.
import { createHash, createHmac, timingSafeEqual } from 'node:crypto';
import { nativeCommentLocation, commentSites } from './comments-location.mjs';
const encode = value => Buffer.from(JSON.stringify(value)).toString('base64url');
const digest = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');

export function createResearchFeed({ token, config, sanitize, validPage, origin = 'http://127.0.0.1:23366', fetcher = fetch }) {
  if (typeof token !== 'string' || !/^[A-Za-z0-9_-]{48,128}$/.test(token) || !Number.isSafeInteger(config?.userId) || config.userId < 1 || typeof config.appKey !== 'string' || config.appKey.length < 16) throw Error('Research feed configuration required');
  let active = false, deadline = 0;
  const record = (comment,pages,includeContext,context) => {
    const safe = sanitize(comment);
    const site=context.name;
    if (safe.is_pending || comment.site_name !== site) return null;
    if (!Number.isSafeInteger(comment.user_id) || comment.user_id < 1 || !validPage(comment.page_key)) throw Error('Invalid comment custody');
    const page=pages.get(comment.page_key);
    if(!page)throw Error('Native comment page missing');
    const location=nativeCommentLocation(comment.page_key,page,context);
    if(page.admin_only)return null;
    const result = { id: `artalk:${context.id}:${safe.id}`, authorKey: `artalk:${context.id}:user:${comment.user_id}`,
      authorName: safe.nick, page: comment.page_key, site, text: safe.content, createdAt: safe.date,
      parentId: safe.rid ? `artalk:${context.id}:${safe.rid}` : null, visibility: 'shared-cognito-ea-sa',
      url: includeContext?page.url:`${context.origin}${comment.page_key}`,
      ...(includeContext?{pageTitle:page.title,location}:{}) };
    return { ...result, sha256: digest(result) };
  };
  async function upstream(path) {
    const remaining = deadline - Date.now();
    if (remaining <= 0) throw Error('Feed deadline reached');
    const now = Math.floor(Date.now() / 1000);
    const unsigned = encode({ alg: 'HS256', typ: 'JWT' }) + '.' + encode({ user_id: config.userId, iat: now, exp: now + 20 });
    const signed = unsigned + '.' + createHmac('sha256', config.appKey).update(unsigned).digest('base64url');
    const response = await fetcher(origin + path, { headers: { authorization: `Bearer ${signed}`, accept: 'application/json' }, redirect: 'error', signal: AbortSignal.timeout(Math.min(5000, remaining)) });
    if (!response.ok) { await response.body?.cancel(); const error = Error('Comments source unavailable'); error.status = response.status; throw error; }
    const reader = response.body.getReader(); let size = 0; const chunks = [];
    try { while (true) { const part = await reader.read(); if (part.done) break; size += part.value.length; if (size > 4 * 1024 * 1024) throw Error('Feed page too large'); chunks.push(Buffer.from(part.value)); } }
    finally { await reader.cancel(); }
    const data = JSON.parse(Buffer.concat(chunks)); return data.data ?? data;
  }
  async function pageCatalogue(context,search) {
    const pages=new Map();let count;
    for(let offset=0;offset<10000;offset+=100){
      const data=await upstream('/api/v2/pages?'+new URLSearchParams({site_name:context.name,limit:'100',offset:String(offset),...(search?{search}:{})}));
      if(data.count===0&&data.pages===null)data.pages=[]; // Native Go API encodes an empty slice as null.
      if(!Number.isSafeInteger(data.count)||data.count<0||data.count>10000||!Array.isArray(data.pages)||data.pages.length>100||(count!==undefined&&count!==data.count))throw Error('Invalid native page catalogue');
      count=data.count;
      for(const page of data.pages){if(!validPage(page.key)||pages.has(page.key))throw Error('Unstable native page catalogue');nativeCommentLocation(page.key,page,context);pages.set(page.key,page);}
      if(pages.size===count)return pages;
      if(!data.pages.length)throw Error('Incomplete native page catalogue');
    }
    throw Error('Native page catalogue exceeds bound');
  }
  async function scan(includeContext,context) {
    const pages=await pageCatalogue(context);
    const records = []; const seen = new Set(); let count, bytes = 0;
    for (let offset = 0; offset < 10000; offset += 100) {
      const data = await upstream('/api/v2/comments?' + new URLSearchParams({ scope: 'site', type: 'all', site_name: context.name, page_key: '/', limit: '100', offset: String(offset), flat_mode: 'true', sort_by: 'date_asc' }));
      if(data.count===0&&data.comments===null)data.comments=[];
      if (!Number.isSafeInteger(data.count) || data.count < 0 || data.count > 10000 || !Array.isArray(data.comments) || data.comments.length > 100 || (count !== undefined && count !== data.count)) throw Error('Source changed or exceeds feed bound');
      count = data.count;
      for (const comment of data.comments) {
        if (seen.has(comment.id)) throw Error('Unstable feed pagination'); seen.add(comment.id);
        const value = record(comment,pages,includeContext,context);
        if (value) { bytes += Buffer.byteLength(JSON.stringify(value)); if (bytes > 8 * 1024 * 1024) throw Error('Feed exceeds bound'); records.push(value); }
      }
      if (seen.size === count) return records.sort((a, b) => a.id.localeCompare(b.id));
      if (!data.comments.length) throw Error('Incomplete feed');
    }
    throw Error('Incomplete feed');
  }
  return async (req, res) => {
    const send = (code, data) => { res.writeHead(code, { 'content-type': 'application/json', 'cache-control': 'private, no-store', 'x-content-type-options': 'nosniff' }); res.end(JSON.stringify(data)); };
    const offered = Buffer.from(req.headers.authorization || ''), expected = Buffer.from('Bearer ' + token);
    if (offered.length !== expected.length || !timingSafeEqual(offered, expected)) return send(403, { error: 'Forbidden' });
    if (req.method !== 'GET') return send(405, { error: 'Read-only feed' });
    const context=req.headers['x-ea-comment-context'];
    if(context!==undefined&&!['v1','v2'].includes(context))return send(400,{error:'Unsupported comment context version'});
    const includeContext=context!==undefined,multiSite=context==='v2';
    const url = new URL(req.url, 'https://comments.sa.hm.sparklingideas.co.uk');
    if (url.search) return send(400, { error: 'Unsupported parameters' });
    if (active) return send(503, { error: 'Feed busy' });
    active = true; deadline = Date.now() + 10000;
    try {
      const match = url.pathname.match(/^\/research-feed\/comments\/(?:(sa|ea)\/)?([1-9]\d{0,9})$/);
      if (match) {
        if(match[1]&&!multiSite)return send(404,{error:'Not found'});
        const selected=commentSites[match[1]||'sa'];
        let data;
        try { data = await upstream('/api/v2/comments/' + match[2]); } catch (error) { if (error.status === 404) return send(404, { error: 'Comment unavailable' }); throw error; }
        if (data.comment?.id !== Number(match[2])) throw Error('Comment identity mismatch');
        if(data.comment.site_name!==selected.name)return send(404,{error:'Comment unavailable'});
        // Join the same native page record shown by Artalk administration on every exact read.
        const pages=await pageCatalogue(selected,data.comment.page_key);
        const value = record(data.comment,pages,includeContext,selected); return send(value ? 200 : 404, value || { error: 'Comment unavailable' });
      }
      if (url.pathname !== '/research-feed/snapshot') return send(404, { error: 'Not found' });
      const observe=async()=>{
        const records=[];
        for(const site of multiSite?[commentSites.sa,commentSites.ea]:[commentSites.sa])records.push(...await scan(includeContext,site));
        if(records.length>10000||Buffer.byteLength(JSON.stringify(records))>8*1024*1024)throw Error('Combined feed exceeds bound');
        return records.sort((a,b)=>a.id.localeCompare(b.id));
      };
      const first = await observe(), second = await observe();
      if (digest(first) !== digest(second)) throw Error('Source changed during reconciliation');
      if (Buffer.byteLength(JSON.stringify(second)) > 8 * 1024 * 1024) throw Error('Feed exceeds bound');
      return send(200, { schema: multiSite?'artalk-comment-snapshot/v2':'sa-comment-snapshot/v1',
        ...(multiSite?{sites:['sa','ea']} : {}), complete: true, consistency: 'two-identical-bounded-observations', observedAt: new Date().toISOString(), version: digest(second), visibility: 'shared-cognito-ea-sa', records: second });
    } catch { return send(503, { error: 'Comments feed unavailable or changing' }); }
    finally { active = false; }
  };
}
