/** Reuse the one verified EA dependency resolver across Node build consumers. */
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
let renderer;
export function sharedRenderer(){
  return renderer ??= JSON.parse(execFileSync('python3',
    [fileURLToPath(new URL('./shared-renderer.py',import.meta.url))],
    {encoding:'utf8',env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'}}));
}
