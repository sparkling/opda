/** Activate verified outputs through the unchanged EA owner. */
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {root,load} from './generation-state.mjs';
import {custodyKey,verifiedCustody,mediaIdentity} from './generation-import.mjs';
import {sharedRenderer} from './shared-renderer.mjs';
export function validateRelease(run,catalogue,{partial=false,publicationPolicy='approved',custody={}}={}){
  if(!['approved','uploaded'].includes(publicationPolicy))throw Error('Unknown publication policy');
  const uploaded=publicationPolicy==='uploaded';
  if(!run.commissioned || !run.publish || catalogue.sourceCommit!==run.sourceCommit || catalogue.notebookId!==run.notebookId || catalogue.sectionId!==run.sectionId)throw Error('Uncommissioned or mismatched publication');
  const items=[...catalogue.decks,...catalogue.multimedia];
  const current=items.filter(item=>!item.retainedAttempt);
  if((!current.length && !partial) || current.length>run.requested || (!partial && current.length!==run.requested) || new Set(current.map(i=>i.key)).size!==current.length || new Set(items.map(i=>i.id)).size!==items.length || (!uploaded && current.length!==items.length))throw Error('Incomplete or duplicate publication matrix');
  if(run.jobs.length!==run.requested || new Set(run.jobs.map(j=>j.key)).size!==run.requested)throw Error('Invalid commissioned job matrix');
  for(const item of items){
    const owner=run.jobs.find(j=>j.key===item.key);
    if(!owner)throw Error('Unknown publication job');
    const job=item.retainedAttempt?owner.attemptHistory?.find(attempt=>attempt.id===item.id):owner;
    if(!job || Boolean(item.retainedAttempt)!==(job!==owner))throw Error('Provider identity or retained variant mismatch');
    const subject=run.subjects.find(s=>s.id===job.subject);
    if(!job.id || job.status!=='completed' || !job.providerProof?.settingsVerified || (!uploaded && job.qualityReview?.status!=='approved'))throw Error(uploaded?'Output is not provider verified':'Output is not quality approved');
    if(!subject || item.subject!==job.subject || item.id!==job.id || item.type!==job.type || item.format!==job.format || item.editorial!==job.editorial || item.ordinal!==job.ordinal || item.level!==job.level || item.version!==job.version)throw Error('Provider identity or variant mismatch');
    const review=job.qualityReview;
    if((review && (review.providerId!==item.id || review.originalSha256!==item.original?.sha256)) || item.qualityStatus!==(review?.status??'pending'))throw Error('Quality review belongs to another original');
    if(uploaded && custody[custodyKey(run,job)]!==item.original?.sha256)throw Error('Original lacks exact verified remote custody');
    if(uploaded && item.publicationKey!==(item.retainedAttempt?`${owner.key}--${item.id}`:owner.key))throw Error('Invalid publication identity');
    if(uploaded){
      const basename=catalogue.prefix+mediaIdentity(job);
      if(item.original?.path!=='/'+custodyKey(run,job) || (item.preview && item.preview.path!==basename+'-preview.webp') || (item.poster && item.poster.path!==basename+'-poster.webp'))throw Error('Provider identity or media path mismatch');
      if(job.type==='slide_deck' && (item.pdf!==item.original.path || item.slug!==mediaIdentity(job) || item.cover?.path!==item.slides?.[0]?.path || item.cover?.sha256!==item.slides?.[0]?.sha256 || item.slides?.some((slide,i)=>slide.path!==basename+'-slide-'+String(i+1).padStart(3,'0')+'.webp') || item.thumbnails?.some((thumb,i)=>thumb.path!==basename+'-thumb-'+String(i+1).padStart(3,'0')+'.webp')))throw Error('Provider identity or slide mapping mismatch');
    }
    const expected=[...subject.factualSourceIds,...(job.editorial?[subject.editorialSourceId]:[])].sort();
    if(JSON.stringify(expected)!==JSON.stringify(item.sourceIds) || JSON.stringify(expected)!==JSON.stringify(job.providerProof.sourceIds) || item.promptSha256!==subject.promptHashes[job.medium])throw Error('Published input scope mismatch');
    if(job.type==='slide_deck' && (!item.slides?.length || item.slideCount!==item.slides.length || item.thumbnails?.length!==item.slideCount || !item.cover))throw Error('Incomplete slide previews');
    if(job.type==='infographic' && !item.preview)throw Error('Missing infographic preview');
    if(job.type==='video' && (!item.poster || !(item.duration>0)))throw Error('Missing video poster or duration');
    if(job.type==='audio' && !(item.duration>0))throw Error('Missing audio duration');
  }
  return items;
}
export function mediaFiles(items,prefix,{custody={}}={}){
  const files=new Map();
  function visit(value){
    if(!value || typeof value!=='object')return;
    if(value.path && value.sha256){
      if(value.path.startsWith('/custody/')){
        if(custody[value.path.slice(1)]!==value.sha256 || !/^[a-f0-9]{64}$/.test(value.sha256) || !(value.bytes>0))throw Error('Unsafe or unverified custody mapping');
        // Original bytes already have zero-mismatch remote body receipts.
        // Keep the browser URL; exclude them from another upload manifest.
        return;
      }
      if(!value.path.startsWith(prefix) || !/^\/presentations\/sa-[a-z]+\/media\/[a-z0-9-]+\.(pdf|webp|png|mp4|m4a)$/.test(value.path) || !/^[a-f0-9]{64}$/.test(value.sha256) || !(value.bytes>0))throw Error('Unsafe or incomplete media mapping');
      const old=files.get(value.path);
      if(old && (old.sha256!==value.sha256 || old.bytes!==value.bytes))throw Error('Conflicting media digest');
      files.set(value.path,value);
    }
    for(const child of Object.values(value))visit(child);
  }
  items.forEach(visit);return [...files.values()];
}
if(process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  if(process.argv.length>4 || (process.argv[3] && !['--partial','--uploaded'].includes(process.argv[3])))throw Error('Usage: generation-release.mjs <section> [--partial|--uploaded]');
  const section=process.argv[2],uploaded=process.argv[3]==='--uploaded',partial=uploaded||process.argv[3]==='--partial',{run}=load(section);
  const catalogue=JSON.parse(await fs.readFile(path.join(root,'docs/generation/catalogues',section+'.json'),'utf8'));
  const custody=uploaded?verifiedCustody():{};
  if(partial)for(const kind of ['decks','multimedia'])catalogue[kind]=catalogue[kind].filter(item=>uploaded?custody[custodyKey(run,item)]===item.original?.sha256:item.qualityStatus==='approved');
  const publicationPolicy=uploaded?'uploaded':'approved',items=validateRelease(run,catalogue,{partial,publicationPolicy,custody});
  const {details,copyVerified}=await import(pathToFileURL(path.resolve(sharedRenderer().directory,'site/scripts/media-originals.mjs')).href);
  const files=mediaFiles(items,catalogue.prefix,{custody});
  for(const record of files){
    const source=path.join(root,'.local/artefact-generation/public',record.path);
    const actual=await details(source,record.path);
    if(actual.sha256!==record.sha256 || actual.bytes!==record.bytes)throw Error('Publication bytes changed');
  }
  for(const record of files){
    const target=path.join(root,'site/public',record.path);await fs.mkdir(path.dirname(target),{recursive:true});
    await copyVerified(path.join(root,'.local/artefact-generation/public',record.path),target);
  }
  const available=items.filter(item=>!item.retainedAttempt).length,retained=items.length-available;
  const release={sectionId:section,sourceCommit:run.sourceCommit,notebookId:run.notebookId,prefix:catalogue.prefix,publicationPolicy,requested:run.requested,available,retained,complete:available===run.requested,stagedAt:new Date().toISOString(),decks:catalogue.decks,multimedia:catalogue.multimedia};
  const file=path.join(root,'docs/generation/releases',section+'.json');await fs.mkdir(path.dirname(file),{recursive:true});
  const {decks,multimedia,...header}=release;
  const pending=file+'.tmp';await fs.writeFile(pending,JSON.stringify(header).slice(0,-1)+',"decks":[\n'+decks.map(d=>JSON.stringify(d)).join(',\n')+'\n],"multimedia":[\n'+multimedia.map(m=>JSON.stringify(m)).join(',\n')+'\n]}\n');await fs.rename(pending,file);
  console.log(JSON.stringify({section,artefacts:items.length,files:files.length,staged:true}));
}
