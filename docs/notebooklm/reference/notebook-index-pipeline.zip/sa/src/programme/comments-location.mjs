// Native Artalk page records are the only location owner; no auxiliary database.
export const commentOrigins = ['https://sa.hm.sparklingideas.co.uk','https://ea.hm.sparklingideas.co.uk','https://ba.hm.sparklingideas.co.uk','https://arb.hm.sparklingideas.co.uk'];
export const commentSites = Object.freeze({
  sa:Object.freeze({id:'sa',name:'Solutions Architecture',origin:commentOrigins[0]}),
  ea:Object.freeze({id:'ea',name:'Enterprise Architecture',origin:commentOrigins[1]}),
  ba:Object.freeze({id:'ba',name:'Business Architecture',origin:commentOrigins[2]}),
  arb:Object.freeze({id:'arb',name:'Product Domain ARB',origin:commentOrigins[3]}),
});
export const validPageTitle = title => typeof title==='string' && title.trim().length>0 && title.length<=1000 && !/[\u0000-\u001f\u007f]/u.test(title);
export function nativeCommentLocation(key,page,context=commentSites.sa) {
  if(page?.key!==key||page.site_name!==context.name||!Number.isSafeInteger(page.id)||page.id<1
    ||typeof page.title!=='string'||page.title.length>1000||/[\u0000-\u001f\u007f]/u.test(page.title)||typeof page.admin_only!=='boolean')throw Error('Invalid native comment page');
  const url=new URL(page.url);
  const origins=context.id==='sa'?commentOrigins.slice(0,2):[context.origin];
  if(!origins.includes(url.origin)||url.href!==new URL(key,url.origin).href)throw Error('Invalid native comment page URL');
  const hash=key.indexOf('#');
  const path=hash<0?key:key.slice(0,hash);
  const artefactType=/\.pdf$/i.test(path)?'slide_deck':/\.(mp4|webm)$/i.test(path)?'video':/\.(mp3|m4a|wav|ogg)$/i.test(path)?'audio':/\.(png|jpe?g|webp|svg|avif)$/i.test(path)?'infographic':null;
  return {schema:'comment-location/v1',origin:url.origin,buttonId:key,page:artefactType?null:key.split('#')[0],
    subsection:hash<0?null:key.slice(hash+1),artefactType,artefact:artefactType?path:null,label:page.title||null,provenance:'native-page-catalog'};
}
