import {commentSites} from './comments-location.mjs';

/** Provision a named native site without renaming or migrating existing data. */
export async function ensureNativeSite(request, expected=commentSites.ea) {
  const read=async()=>{
    const result=await request('/api/v2/sites');
    if(!Array.isArray(result.sites)||result.sites.length>100||result.count!==result.sites.length)throw Error('Invalid native sites response');
    if(new Set(result.sites.map(site=>site.id)).size!==result.sites.length)throw Error('Duplicate native site identity');
    return result.sites;
  };
  const validate=site=>{
    if(!Number.isSafeInteger(site?.id)||site.id<1||site.name!==expected.name
      ||JSON.stringify(site.urls)!==JSON.stringify([expected.origin])||site.first_url!==expected.origin)throw Error(`${expected.id.toUpperCase()} native site configuration differs`);
    return site;
  };
  const before=await read(),existing=before.filter(site=>site.name===expected.name);
  if(existing.length>1)throw Error(`Duplicate ${expected.id.toUpperCase()} native site`);
  if(existing.length){const site=validate(existing[0]);return {id:site.id,name:site.name,origin:expected.origin,created:false};}
  const created=validate(await request('/api/v2/sites','POST',{name:expected.name,urls:[expected.origin]}));
  const after=await read(),matches=after.filter(site=>site.name===expected.name);
  if(matches.length!==1||validate(matches[0]).id!==created.id)throw Error(`${expected.id.toUpperCase()} native site readback differs`);
  for(const site of before)if(JSON.stringify(after.find(row=>row.id===site.id))!==JSON.stringify(site))throw Error('Existing native site changed');
  return {id:created.id,name:created.name,origin:expected.origin,created:true};
}
export const ensureEnterpriseSite=request=>ensureNativeSite(request,commentSites.ea);
