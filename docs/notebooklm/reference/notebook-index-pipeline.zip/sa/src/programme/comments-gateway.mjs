// Adapted from OPDA's comments-api: identity and Artalk tokens remain server-side.
import { createServer } from 'node:http';
import { createHash, createHmac, randomUUID, timingSafeEqual } from 'node:crypto';
import { readFileSync, existsSync } from 'node:fs';
import { createAdminHandler } from './comments-admin.mjs';
import { createResearchFeed } from './comments-research-feed.mjs';
import { commentSites, validPageTitle } from './comments-location.mjs';
const origin = process.env.ARTALK_ORIGIN || 'http://127.0.0.1:23366';
const encode = value => Buffer.from(JSON.stringify(value)).toString('base64url');
export const validPage = value => typeof value === 'string' && value.startsWith('/') && value.length <= 2048
  && !/[\\\u0000-\u001f\u007f]|\/\/|(?:^|\/)\.{1,2}(?:\/|$)/u.test(value);
export function safeComment(value) {
  if (!Number.isSafeInteger(value?.id) || value.id < 1 || typeof value.content !== 'string'
    || value.content.length > 100000 || typeof value.nick !== 'string' || typeof value.date !== 'string'
    || !Number.isSafeInteger(value.rid) || value.rid < 0) throw Error('Invalid upstream comment');
  return { id:value.id, rid:value.rid, content:value.content, nick:value.nick.slice(0,256),
    date:value.date.slice(0,64), is_pending:value.is_pending === true };
}
export function createGateway({ originSecret, eaOriginSecret, baOriginSecret, arbOriginSecret, gatewayKey, fetcher = fetch, admin = null, eaAdmin = null, baAdmin = null, arbAdmin = null, researchFeed = null }) {
  if (!/^[a-f0-9]{64}$/.test(gatewayKey) || originSecret.length < 48
    || [eaOriginSecret,baOriginSecret,arbOriginSecret].some(secret=>secret!==undefined&&(typeof secret!=='string'||secret.length<48))
    || new Set([originSecret,eaOriginSecret,baOriginSecret,arbOriginSecret].filter(Boolean)).size!==[originSecret,eaOriginSecret,baOriginSecret,arbOriginSecret].filter(Boolean).length) throw Error('Gateway not configured');
  async function upstream(path, method='GET', body, token) {
    const result = await fetcher(origin + path, { method, redirect:'error', signal:AbortSignal.timeout(5000),
      headers:{ accept:'application/json', ...(body ? {'content-type':'application/json'} : {}),
        ...(token ? {authorization:`Bearer ${token}`} : {}) }, ...(body ? {body:JSON.stringify(body)} : {}) });
    if (!result.ok) { await result.body?.cancel(); throw Error('Upstream request failed'); }
    const reader = result.body.getReader(); const chunks=[]; let size=0;
    try { while (true) { const part=await reader.read(); if(part.done) break;
      size+=part.value.length; if(size>2*1024*1024) throw Error('Response too large'); chunks.push(Buffer.from(part.value));
    }} finally { await reader.cancel(); }
    const json=JSON.parse(Buffer.concat(chunks)); return json.data ?? json;
  }
  return async function handle(req,res) {
    const send=(code,data)=>{res.writeHead(code,{'content-type':'application/json','cache-control':'private, no-store','x-content-type-options':'nosniff'});res.end(JSON.stringify(data));};
    if (req.url.startsWith('/research-feed/')) return researchFeed ? researchFeed(req,res) : send(404,{error:'Not found'});
    const offeredHeaders={sa:req.headers['x-sa-comments-origin'],ea:req.headers['x-ea-comments-origin'],ba:req.headers['x-ba-comments-origin'],arb:req.headers['x-arb-comments-origin']};
    // Only the distribution's independent credential selects a fixed server context.
    // No browser host, Origin, page key, site name, or identity can select it.
    const selected=Object.entries(offeredHeaders).filter(([,value])=>value!==undefined);
    if(selected.length!==1)return send(403,{error:'Forbidden'});
    const [siteId,value]=selected[0];
    const secret={sa:originSecret,ea:eaOriginSecret,ba:baOriginSecret,arb:arbOriginSecret}[siteId];
    if(!secret)return send(403,{error:'Forbidden'});
    if(typeof value!=='string')return send(403,{error:'Forbidden'});
    const offered=Buffer.from(value); const expected=Buffer.from(secret);
    if(offered.length!==expected.length || !timingSafeEqual(offered,expected)) return send(403,{error:'Forbidden'});
    const context=commentSites[siteId],site=context.name,administrator={sa:admin,ea:eaAdmin,ba:baAdmin,arb:arbAdmin}[siteId];
    const sub=req.headers['x-semantic-user-id'], name=req.headers['x-semantic-user-email'];
    if(typeof sub!=='string'||!/^[\w-]{1,128}$/.test(sub)||typeof name!=='string'||!name.trim()||name.length>256) return send(401,{error:'Sign in to comment.'});
    const url=new URL(req.url,'http://localhost');
    if(url.pathname==='/api/v2/session'&&req.method==='GET') return send(200,{data:{admin:administrator?.isAllowed(sub)===true}});
    if(url.pathname.startsWith('/admin/')) {
      if(!administrator) return send(403,{error:'Administrator access required.'});
      return administrator.handle(req,res,sub);
    }
    if(url.pathname!=='/api/v2/comments') return send(404,{error:'Not found'});
    try {
      if(req.method==='GET') {
        const page=url.searchParams.get('page_key'), offset=url.searchParams.get('offset') || '0';
        if(!validPage(page)||!/^\d{1,6}$/.test(offset)) return send(400,{error:'Invalid thread'});
        const result=await upstream('/api/v2/comments?'+new URLSearchParams({page_key:page,site_name:site,limit:'20',offset,flat_mode:'true',sort_by:'date_asc'}));
        if(result.count===0&&result.comments===null)result.comments=[];
        if(!Array.isArray(result.comments)||result.comments.length>20||!Number.isSafeInteger(result.count)
          ||result.comments.some(comment=>comment.site_name!==site||comment.page_key!==page)) throw Error('Invalid response');
        return send(200,{data:{comments:result.comments.map(safeComment),count:result.count,viewer:{name:name.trim()}}});
      }
      if(req.method!=='POST') return send(405,{error:'Use GET or POST'});
      if(req.headers.origin!==context.origin||(req.headers['sec-fetch-site']&&req.headers['sec-fetch-site']!=='same-origin')) return send(403,{error:'Same-origin request required'});
      if(!/^application\/json(?:;\s*charset=utf-8)?$/i.test(req.headers['content-type']||'')) return send(415,{error:'Use JSON'});
      let text=''; for await(const part of req) {text+=part; if(Buffer.byteLength(text)>24000) return send(413,{error:'Comment too large'});}
      let body; try { body=JSON.parse(text); } catch {return send(400,{error:'Invalid JSON'});}
      if(!body||Array.isArray(body)||Object.keys(body).some(k=>!['page_key','page_title','content','rid'].includes(k))
        ||!validPage(body.page_key)||typeof body.content!=='string'||!body.content.trim()||body.content.length>5000
        ||(body.rid!==undefined&&(!Number.isSafeInteger(body.rid)||body.rid<0))
        ||(body.page_title!==undefined&&!validPageTitle(body.page_title))) return send(400,{error:'Invalid comment'});
      if(body.rid) {
        let parent;try{parent=(await upstream('/api/v2/comments/'+body.rid)).comment;}catch{return send(400,{error:'Invalid reply'});}
        if(parent?.id!==body.rid||parent.site_name!==site||parent.page_key!==body.page_key||parent.is_pending===true)return send(400,{error:'Invalid reply'});
      }
      const participantId=`${context.id}:${sub}`, issued=Math.floor(Date.now()/1000);
      const signed=encode({alg:'HS256',typ:'JWT'})+'.'+encode({iss:'opda-comments-gateway',aud:'artalk-comments',sub:participantId,name:name.trim(),iat:issued,exp:issued+15,jti:randomUUID()});
      const assertion=signed+'.'+createHmac('sha256',Buffer.from(gatewayKey,'hex')).update(signed).digest('base64url');
      const session=await upstream('/api/v2/opda/session','POST',{assertion});
      const email=createHash('sha256').update(participantId).digest('hex')+'@members.comments.opda.org.uk';
      if(typeof session.token!=='string'||!session.token||session.token.length>4096||session.user?.is_admin!==false
        ||session.user.name!==name.trim()||session.user.email!==email) throw Error('Invalid identity binding');
      const result=await upstream('/api/v2/comments','POST',{page_key:body.page_key,content:body.content.trim(),rid:body.rid??0,
        ...(body.page_title===undefined?{}:{page_title:body.page_title.trim()}),name:session.user.name,email,site_name:site},session.token);
      return send(200,{data:safeComment(result)});
    } catch { return send(503,{error:'Comments are temporarily unavailable.'}); }
  };
}
if(process.argv[1] && import.meta.url===new URL(process.argv[1],'file://').href) {
  const adminConfig = existsSync('/opt/sa-artalk/admin-config.json') ? JSON.parse(readFileSync('/opt/sa-artalk/admin-config.json','utf8')) : null;
  const server=createServer(createGateway({originSecret:readFileSync('/opt/sa-artalk/origin-secret','utf8').trim(),
    eaOriginSecret:existsSync('/opt/sa-artalk/ea-origin-secret')?readFileSync('/opt/sa-artalk/ea-origin-secret','utf8').trim():undefined,
    baOriginSecret:existsSync('/opt/sa-artalk/ba-origin-secret')?readFileSync('/opt/sa-artalk/ba-origin-secret','utf8').trim():undefined,
    arbOriginSecret:existsSync('/opt/sa-artalk/arb-origin-secret')?readFileSync('/opt/sa-artalk/arb-origin-secret','utf8').trim():undefined,
    gatewayKey:readFileSync('/opt/sa-artalk/gateway-key','utf8').trim(),
    admin:adminConfig ? createAdminHandler({config:adminConfig,origin}):null,
    eaAdmin:adminConfig ? createAdminHandler({config:adminConfig,origin,siteOrigin:commentSites.ea.origin}):null,
    baAdmin:adminConfig ? createAdminHandler({config:adminConfig,origin,siteOrigin:commentSites.ba.origin}):null,
    arbAdmin:adminConfig ? createAdminHandler({config:adminConfig,origin,siteOrigin:commentSites.arb.origin}):null,
    researchFeed:adminConfig && existsSync('/opt/sa-artalk/research-feed-token') ? createResearchFeed({token:readFileSync('/opt/sa-artalk/research-feed-token','utf8').trim(),config:adminConfig,sanitize:safeComment,validPage,origin}):null}));
  server.requestTimeout=15000; server.headersTimeout=10000;
  server.listen(23367,'127.0.0.1');
}
