#!/usr/bin/env python3
"""Reusable transfer wrapper around the pinned EA static publisher.

Two modes:
  --custody   Build a deterministic, private custody tree of generated
              originals (completed attempts and retained rejected attempts)
              from the section ledgers, write its ea-static-scope/v1
              manifest, then publish it.
  (default)   Publish an already-prepared --build / --scope-manifest exactly
              as supplied, for the main thread's own scoped releases. This
              mode never populates the build with custody files and never
              replaces or expands the caller's manifest.

In both modes, publication runs the unchanged, pinned EA publisher
(publish-static-ea.py / release_scope.py) in this process via runpy, with
narrow runtime patches so its ThreadPoolExecutor and botocore Config pick up
the requested bounded worker count and a matching S3 connection pool. Every
other check the publisher performs -- scope/SHA-256, account/bucket/edge
verification, remote body-hash verification, upload-before-HTML ordering --
is untouched. Runtime adapters supply concurrency, authenticated CLI credentials
and the verified export revision for receipt metadata. Patched globals and sys.argv
are always restored, without editing the EA checkout.

Never starts generation, resubmission or quality retries.
"""
import argparse
import asyncio
import concurrent.futures
import datetime
import hashlib
import importlib.util
import json
import os
import re
import runpy
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

import botocore.config
import boto3

ROOT = Path(__file__).resolve().parents[2]
WORKER_PATH = ROOT / 'src/programme/generation-worker.py'
LEDGERS = sorted((ROOT / 'docs/generation').glob('*.json'))
ORIGINALS = ROOT / '.local/artefact-generation/originals'
REJECTED = ROOT / '.local/artefact-generation/rejected'
WORKER_LOCK = ROOT / '.local/artefact-generation/worker.lock'
EXT = {'audio': 'm4a', 'video': 'mp4', 'infographic': 'png', 'slide_deck': 'pdf'}
UUID_RE = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')


def event(**fields):
    print(json.dumps(fields), flush=True)


def validated_workers(value, maximum=32):
    if type(value) is not int or not (1 <= value <= maximum):
        raise ValueError(f'Concurrency must be an integer between 1 and {maximum}: {value!r}')
    return value


def check_ea_pin():
    """Resolve exact approved publisher bytes, independent of EA working-tree edits."""
    pin = json.loads((ROOT / 'config/shared-renderer.json').read_text())
    spec = importlib.util.spec_from_file_location('shared_renderer', ROOT / 'src/programme/shared-renderer.py')
    resolver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(resolver)
    checkout = Path(resolver.resolve_renderer(ROOT)['directory'])
    script = checkout / 'site/scripts/deployment/publish-static-ea.py'
    if not script.is_file() or not (checkout / 'site/scripts/deployment/release_scope.py').is_file():
        raise RuntimeError('Pinned EA publisher is missing')
    return checkout, pin, script


def _load_worker_module():
    spec = importlib.util.spec_from_file_location('generation_worker', WORKER_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.dont_write_bytecode = True
    spec.loader.exec_module(module)
    return module


def load_ledger_runs():
    """One frozen read of every section ledger, for reuse across a single cycle.

    Ledgers mutate continuously while generation runs; reading them once and
    passing the same snapshot through downloads and custody discovery avoids
    acting on a job that appeared completed in one read but not the next.
    """
    return [json.loads(path.read_text()) for path in LEDGERS]


def find_missing_originals(runs=None):
    """Completed, acknowledged jobs whose original was never downloaded locally."""
    missing = []
    for run in runs if runs is not None else load_ledger_runs():
        for job in run.get('jobs', []):
            if job.get('status') == 'completed' and job.get('id') and job.get('type') in EXT:
                target = ORIGINALS / f"{job['key']}.{EXT[job['type']]}"
                if not target.is_file():
                    missing.append((run, job))
    return missing


def _process_is_alive(pid):
    """Liveness via a real signal probe, never inferred from a ps exit code."""
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _process_argv(pid):
    """This PID's argv tokens, or None if they cannot be determined."""
    try:
        output = subprocess.check_output(['ps', '-ww', '-p', str(pid), '-o', 'args='], text=True)
    except subprocess.CalledProcessError:
        return None
    output = output.strip()
    try:
        return shlex.split(output) if output else None
    except ValueError:
        return None


def _process_cwd(pid):
    """This PID's absolute working directory via lsof, or None if undeterminable."""
    try:
        output = subprocess.check_output(['lsof', '-a', '-p', str(pid), '-d', 'cwd', '-Fn'], text=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None
    for line in output.splitlines():
        if line.startswith('n'):
            return line[1:]
    return None


def generation_worker_permits_downloads():
    """True unless a live, unknown or download-capable worker holds worker.lock.

    worker.lock is only a safe hand-off when its PID is actually alive (checked
    by signalling it, never inferred from a ps error), its argv's script
    position is this checkout's generation-worker.py (resolved against that
    process's own cwd, not assumed to be ROOT) and --skip-downloads is present
    (ADR-099: that mode delegates all original downloads to the transfer agent).
    A lock proven to name a dead PID has no live owner, so it does not block.
    A malformed/empty lock, or any ps/lsof failure for a live PID, cannot prove
    the absence of a live owner, so it blocks rather than assumes safety. Any
    other live owner -- unknown script, missing --skip-downloads, wrong cwd, or
    an argv match outside the script position (e.g. a decoy `-c` invocation
    that merely mentions the path) -- still blocks; this never deletes or
    touches the lock.
    """
    if not WORKER_LOCK.exists():
        return True
    try:
        pid_text = WORKER_LOCK.read_text().strip()
    except FileNotFoundError:
        return True
    if not pid_text.isdigit() or int(pid_text) <= 0:
        return False
    pid = int(pid_text)
    if not _process_is_alive(pid):
        return True
    argv = _process_argv(pid)
    if (not argv or len(argv) < 2 or '--skip-downloads' not in argv[2:]
            or not re.fullmatch(r'python(?:\d+(?:\.\d+)*)?', Path(argv[0]).name)):
        return False
    cwd = _process_cwd(pid)
    if cwd is None:
        return False
    script = Path(argv[1])
    if not script.is_absolute():
        script = Path(cwd) / script
    try:
        return script.resolve() == WORKER_PATH
    except OSError:
        return False


def ensure_downloaded(concurrency, runs=None):
    """Reuse the generation-worker download path; never resubmits or retries."""
    concurrency = validated_workers(concurrency)
    missing = find_missing_originals(runs)
    if not missing:
        event(missingOriginals=0, downloadSkipped=True)
        return
    if not generation_worker_permits_downloads():
        event(missingOriginals=len(missing), downloadSkipped=True,
              reason='worker.lock is held by a live worker that is not this checkout\'s '
                     'generation-worker.py in --skip-downloads mode; not contending for the provider client')
        return
    event(missingOriginals=len(missing), downloadConcurrency=concurrency)
    worker = _load_worker_module()
    client = worker.get_client()
    runs = runs if runs is not None else load_ledger_runs()
    asyncio.run(worker.downloads(client, runs, concurrency=concurrency))


def _require_uuid(value, what):
    if not isinstance(value, str) or not UUID_RE.match(value):
        raise RuntimeError(f'Not a canonical UUID for {what}: {value!r}')
    return value


def _validate_source(path):
    if not path.is_absolute() or not path.resolve().is_relative_to(ROOT.resolve()):
        raise RuntimeError(f'Custody path escapes this checkout: {path}')
    if path.is_symlink():
        raise RuntimeError(f'Symlink sources are not accepted in custody: {path}')
    for parent in path.parents:
        if parent.is_symlink():
            raise RuntimeError(f'Symlinked parent directory is not accepted in custody: {path}')
        if parent == ROOT:
            break


def discover_custody_entries(runs=None):
    """Current completed job IDs and retained attemptHistory IDs, with no silent gaps.

    A completed, acknowledged job must have a local original (ensure_downloaded
    runs first); a missing one is refused rather than dropped. Retained
    Completed attemptHistory entries also require their archived original.
    Every quality-review
    hash on record is checked against the actual bytes.
    """
    entries = {}
    for run in runs if runs is not None else load_ledger_runs():
        notebook_id = run.get('notebookId')
        if not notebook_id:
            continue
        _require_uuid(notebook_id, 'notebookId')
        for job in run.get('jobs', []):
            _collect_current(entries, notebook_id, job)
            for attempt in job.get('attemptHistory') or []:
                _collect_retained(entries, notebook_id, attempt)
    return sorted(entries.values(), key=lambda e: (e['notebookId'], e['providerId']))


def _validated_entry(notebook_id, job, source, rejected):
    provider_id = _require_uuid(job['id'], 'job id')
    ext = EXT[job['type']]
    _validate_source(source)
    review = job.get('qualityReview') or {}
    expected_sha = review.get('originalSha256')
    actual_sha = hashlib.sha256(source.read_bytes()).hexdigest()
    if review and (review.get('providerId') != provider_id or not isinstance(expected_sha, str)
                   or not re.fullmatch(r'[0-9a-f]{64}', expected_sha)):
        raise RuntimeError(f'Quality review belongs to another original: {provider_id}')
    if expected_sha and actual_sha != expected_sha:
        raise RuntimeError(f'Quality-review hash mismatch for {provider_id}: {source}')
    catalogue = ROOT / 'docs/generation/catalogues' / (job['subject'].rsplit('-', 1)[0] + '.json')
    if catalogue.is_file():
        record = json.loads(catalogue.read_text())
        for kind in ('decks', 'multimedia', 'rejected'):
            for item in record.get(kind, []):
                if item.get('id') == provider_id and item.get('original', {}).get('sha256') != actual_sha:
                    raise RuntimeError(f'Catalogue hash mismatch for {provider_id}')
    return {'notebookId': notebook_id, 'providerId': provider_id, 'ext': ext,
            'source': source, 'rejected': rejected, 'sha256': actual_sha}


def _collect_current(entries, notebook_id, job):
    if job.get('status') != 'completed' or not job.get('id') or job.get('type') not in EXT:
        return
    key, ext = job['key'], EXT[job['type']]
    if not isinstance(key, str) or not re.fullmatch(r'[a-z0-9_-]+', key):
        raise RuntimeError('Unsafe original job key')
    source = ORIGINALS / f'{key}.{ext}'
    if not source.is_file():
        raise RuntimeError(f'Completed job is missing its local original: {key} -> {source}')
    entries[(notebook_id, job['id'])] = _validated_entry(notebook_id, job, source, rejected=False)


def _collect_retained(entries, notebook_id, attempt):
    if attempt.get('status') != 'completed':
        return
    _require_uuid(attempt.get('id'), 'retained provider id')
    if attempt.get('type') not in EXT:
        raise RuntimeError('Unknown retained original type')
    ext = EXT[attempt['type']]
    source = REJECTED / f"{attempt['id']}.{ext}"
    if not source.is_file():
        raise RuntimeError(f'Retained attempt is missing its archived original: {attempt["id"]}')
    key = (notebook_id, attempt['id'])
    if key not in entries:
        entries[key] = _validated_entry(notebook_id, attempt, source, rejected=True)


def custody_key(entry):
    return f"custody/generation/{entry['notebookId']}/{entry['providerId']}.{entry['ext']}"


def build_custody_tree(entries, custody_root, workers):
    """Deterministic custody/generation/<notebook>/<provider>.<ext> tree. No index links."""
    workers = validated_workers(workers)
    _validate_source(custody_root)
    custody_root.mkdir(parents=True, exist_ok=True)

    def place(entry):
        target = custody_root / custody_key(entry)
        _validate_source(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if not ((target.stat().st_ino, target.stat().st_dev) == (entry['source'].stat().st_ino, entry['source'].stat().st_dev)
                    or hashlib.sha256(target.read_bytes()).hexdigest() == entry['sha256']):
                target.unlink()
                _link_or_copy(entry['source'], target)
        else:
            _link_or_copy(entry['source'], target)
        return {'key': custody_key(entry), 'bytes': target.stat().st_size, 'rejected': entry['rejected']}

    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(place, entry) for entry in entries]
        for future in concurrent.futures.as_completed(futures):
            results.append(future.result())
    return results


def _link_or_copy(source, target):
    try:
        os.link(source, target)
    except OSError:
        shutil.copy2(source, target)


def current_head():
    return subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()


def write_manifest_from_entries(entries, build_root, manifest_path):
    """Manifest lists exactly the discovered entries, never a directory scan."""
    head = current_head()
    files = []
    for entry in entries:
        path = build_root / custody_key(entry)
        if not path.is_file():
            raise RuntimeError(f'Custody file missing for manifest: {path}')
        files.append({'key': custody_key(entry), 'sha256': entry['sha256']})
    files.sort(key=lambda f: f['key'])
    manifest = {'schema': 'ea-static-scope/v1', 'sourceCommit': head, 'files': files}
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    return manifest


def cli_credentials():
    """Read the already-authenticated CLI session into memory; never persist it."""
    result = subprocess.run(['aws', 'configure', 'export-credentials', '--profile', 'claude',
                             '--format', 'process'], capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(f'AWS CLI credential export failed (exit {result.returncode})')
    value = json.loads(result.stdout)
    if not all(isinstance(value.get(k), str) and value[k] for k in
               ('AccessKeyId', 'SecretAccessKey', 'SessionToken', 'Expiration')):
        raise RuntimeError('AWS CLI returned incomplete temporary credentials')
    expiry = datetime.datetime.fromisoformat(value['Expiration'].replace('Z', '+00:00'))
    if expiry <= datetime.datetime.now(datetime.UTC):
        raise RuntimeError('AWS CLI temporary credentials have expired')
    return value


def run_publisher_inprocess(script, build, scope_manifest, receipt, workers, aws_cli_credentials=False):
    """Run the unchanged, pinned publisher in-process with bounded concurrency.

    Runtime adapters configure the executor and S3 pool. The explicit CLI option
    supplies the same profile's authenticated credentials to boto3.Session in
    memory. Every check, verification and ordering guarantee is the publisher's
    unmodified code. All patches and sys.argv are restored in `finally`.
    """
    workers = validated_workers(workers)
    pool_size = workers + 1
    real_executor = concurrent.futures.ThreadPoolExecutor
    real_config = botocore.config.Config
    real_session = boto3.Session
    real_check_output = subprocess.check_output
    credentials = cli_credentials() if aws_cli_credentials else None
    deployment_dir = str(script.parent)
    renderer_root = script.resolve().parents[3] if len(script.resolve().parents) > 3 else None
    exported = renderer_root is not None and renderer_root.parent == ROOT.resolve() / '.local/shared-renderer'
    renderer_revision = renderer_root.name if exported else None
    if exported and not re.fullmatch(r'[0-9a-f]{40}', renderer_revision):
        raise RuntimeError('Invalid renderer export revision')

    def publisher_metadata(command, *args, **kwargs):
        # The unchanged publisher asks its checkout for a receipt revision.
        # This dependency export has no checkout: supply its verified Git version.
        if exported and command == ['git', '-C', str(renderer_root), 'rev-parse', 'HEAD']:
            value = renderer_revision + '\n'
            return value if kwargs.get('text') or kwargs.get('encoding') else value.encode()
        return real_check_output(command, *args, **kwargs)

    class BoundedExecutor(real_executor):
        def __init__(self, *args, **kwargs):
            kwargs['max_workers'] = workers
            super().__init__(*args, **kwargs)

    def bounded_config(*args, **kwargs):
        kwargs['max_pool_connections'] = max(pool_size, kwargs.get('max_pool_connections') or 0)
        return real_config(*args, **kwargs)

    class CliSession(real_session):
        def __init__(self, *args, **kwargs):
            if args or kwargs.get('profile_name') != 'claude':
                raise RuntimeError('CLI credential bridge requires the commissioned claude profile')
            super().__init__(**kwargs, aws_access_key_id=credentials['AccessKeyId'],
                             aws_secret_access_key=credentials['SecretAccessKey'],
                             aws_session_token=credentials['SessionToken'])

    saved_argv = sys.argv[:]
    saved_path = sys.path[:]
    saved_bytecode = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    sys.argv = [str(script), '--site', 'sa', '--source-repo', str(ROOT),
                '--build', str(build), '--scope-manifest', str(scope_manifest), '--receipt', str(receipt)]
    sys.path.insert(0, deployment_dir)
    concurrent.futures.ThreadPoolExecutor = BoundedExecutor
    botocore.config.Config = bounded_config
    subprocess.check_output = publisher_metadata
    if credentials:
        boto3.Session = CliSession
    try:
        runpy.run_path(str(script), run_name='__main__')
    finally:
        sys.argv = saved_argv
        sys.path[:] = saved_path
        sys.dont_write_bytecode = saved_bytecode
        concurrent.futures.ThreadPoolExecutor = real_executor
        botocore.config.Config = real_config
        boto3.Session = real_session
        subprocess.check_output = real_check_output
    return json.loads(receipt.read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    transfers_root = ROOT / '.local/artefact-generation/transfers'
    parser.add_argument('--build', type=Path,
                         help='Build root. In --custody mode this wrapper populates it (default: transfers/custody-release); '
                              'otherwise it must already be an exact, caller-prepared scoped build.')
    parser.add_argument('--scope-manifest', type=Path,
                         help='ea-static-scope/v1 manifest. In --custody mode this wrapper writes it '
                              '(default: transfers/custody-release-scope.json); otherwise used exactly as supplied.')
    parser.add_argument('--receipt', type=Path, default=ROOT / 'docs/site/sa-generation-custody-transfer.json')
    parser.add_argument('--custody', action='store_true',
                         help='Build the private custody tree and its manifest from section ledgers before publishing')
    parser.add_argument('--aws-cli-credentials', action='store_true',
                         help='Use the authenticated claude AWS CLI session in memory for this run')
    parser.add_argument('--workers', type=int, default=32,
                         help='Bounded upload I/O concurrency the publisher runs with (max 32)')
    parser.add_argument('--download-concurrency', type=int, default=16,
                         help='Bounded concurrency reused from generation-worker.py downloads, if needed (max 32)')
    args = parser.parse_args()
    workers = validated_workers(args.workers)

    checkout, pin, script = check_ea_pin()
    event(eaPinVerified=pin['revision'])

    if args.custody:
        build = args.build or transfers_root / 'custody-release'
        manifest_path = args.scope_manifest or transfers_root / 'custody-release-scope.json'
        runs = load_ledger_runs()
        ensure_downloaded(args.download_concurrency, runs=runs)
        entries = discover_custody_entries(runs=runs)
        event(custodyEntries=len(entries), rejectedRetained=sum(1 for e in entries if e['rejected']))
        if not entries:
            event(note='No local originals matched current job IDs or retained attemptHistory; nothing to transfer')
            return
        placed = build_custody_tree(entries, build, workers)
        localBytes = sum(p['bytes'] for p in placed)
        event(custodyBuilt=len(placed), localBytes=localBytes, custodyWorkers=workers)
        manifest = write_manifest_from_entries(entries, build, manifest_path)
        event(scopeManifest=str(manifest_path), sourceCommit=manifest['sourceCommit'], manifestFiles=len(manifest['files']))
    else:
        if not args.build or not args.scope_manifest:
            parser.error('--build and --scope-manifest are required without --custody')
        build, manifest_path = args.build, args.scope_manifest
        localBytes = None

    receipt = run_publisher_inprocess(script, build, manifest_path, args.receipt, workers, args.aws_cli_credentials)
    event(uploadWorkers=workers, uploadedFiles=receipt.get('uploadedFiles'),
          publishedFileCount=receipt.get('fileCount'), publishedBytes=receipt.get('totalBytes'),
          bodyHashMismatches=receipt.get('bodyHashMismatches'), receiptPath=str(args.receipt),
          transferComplete=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        event(errorType=type(error).__name__, error=str(error))
        raise SystemExit(1)
