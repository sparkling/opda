#!/usr/bin/env python3
"""Independent resumable original downloads and bounded custody uploads.
Persistent mode keeps retrying after failures; verified originals are never
hashed or uploaded again. Index publication belongs to its separate owner.
"""
import argparse
import datetime
import importlib.util
import json
import os
import re
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TRANSFER_MODULE_PATH = ROOT / 'src/programme/generation-transfer.py'
INDEX_MODULE_PATH = ROOT / 'src/programme/generation-index-publication.py'
TRANSFER_LOCK = ROOT / '.local/artefact-generation/transfer.lock'
STATE_PATH = ROOT / '.local/artefact-generation/transfers/verified-custody-state.json'
CYCLE_RECEIPTS = ROOT / '.local/artefact-generation/transfers/custody-cycle-receipts'
DEFAULT_RECEIPT = ROOT / 'docs/site/sa-generation-custody-transfer.json'
TOTAL_COMMISSIONED = 3060
MAX_BATCH_FILES = 32
MAX_BATCH_BYTES = 512 * 1024 * 1024


def event(**fields):
    print(json.dumps(fields), flush=True)


def load_transfer_module():
    spec = importlib.util.spec_from_file_location('generation_transfer', TRANSFER_MODULE_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.dont_write_bytecode = True
    spec.loader.exec_module(module)
    return module


def publish_indexes(m, workers):
    spec = importlib.util.spec_from_file_location('generation_index_publication', INDEX_MODULE_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    ownership = load_ownership()
    with ownership.StageLock('index', ROOT / '.local/artefact-generation/index.lock') as lock:
        module.INDEX_LOCK_DESCRIPTOR = lock.descriptor
        try:
            return module.run_cycle(m, workers)
        finally:
            module.INDEX_LOCK_DESCRIPTOR = None


class ExclusiveLock:
    """transfer.lock this process creates, checks and removes itself -- unlike
    worker.lock, which belongs to generation-worker.py and is only ever read."""

    def __init__(self, path):
        self.path = path

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            raise RuntimeError('transfer.lock already exists; refusing another owner or automatic stale-lock replacement')
        with os.fdopen(fd, 'w') as file:
            file.write(str(os.getpid()))
        return self

    def __exit__(self, *exc_info):
        if self.path.is_file() and self.path.read_text().strip() == str(os.getpid()):
            self.path.unlink()


def load_verified_state(seed_receipt):
    # Summary state is never proof: rebuild from actual body-verification receipts.
    state = {}
    receipts = ([seed_receipt] if seed_receipt.is_file() else []) + sorted(CYCLE_RECEIPTS.glob('*.json'))
    for path in receipts:
        for key, sha in verified_receipt_files(json.loads(path.read_text())).items():
            state[key] = sha
    return state


def verified_receipt_files(receipt, expected=None):
    files = receipt.get('files', [])
    if (receipt.get('bodyHashMismatches') != 0 or str(receipt.get('account')) != '841291679368'
            or receipt.get('fileCount') != len(files) or receipt.get('bucketPublicAccessBlocked') is not True
            or receipt.get('outputs', {}).get('BucketName') != 'hm-website-sa-841291679368'):
        raise RuntimeError('Custody receipt lacks the required remote-verification evidence')
    result = {}
    uuid = r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
    for item in files:
        key, sha = item.get('key', ''), item.get('sha256', '')
        if (not re.fullmatch(rf'custody/generation/{uuid}/{uuid}\.(png|pdf|mp4|m4a)', key)
                or not re.fullmatch(r'[0-9a-f]{64}', sha) or key in result):
            raise RuntimeError('Custody receipt has invalid or duplicate original identities')
        result[key] = sha
    if expected is not None and result != expected:
        raise RuntimeError('Custody receipt does not verify the exact selected originals')
    return result


def save_verified_state(state):
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    pending = STATE_PATH.with_suffix('.pending')
    pending.write_text(json.dumps({'schema': 'sa-custody-progress/v1',
        'updatedAt': datetime.datetime.now(datetime.UTC).isoformat(),
        'verifiedOriginals': len(state), 'files': state}, sort_keys=True) + '\n')
    pending.replace(STATE_PATH)


def programme_complete(m, runs, entries, verified_state):
    """Exact current matrix completion and byte-bound custody; quality remains separate."""
    jobs = [j for r in runs for j in r.get('jobs', [])]
    if (len(runs) != 10 or len(jobs) != TOTAL_COMMISSIONED
            or len({j['subject'] for j in jobs}) != 90
            or any(j.get('status') != 'completed' or not j.get('providerProof', {}).get('settingsVerified') for j in jobs)):
        return False
    current_keys = {f"custody/generation/{r['notebookId']}/{j['id']}.{m.EXT[j['type']]}"
                    for r in runs for j in r['jobs']}
    hashes = {m.custody_key(e): e['sha256'] for e in entries}
    return (len(current_keys) == TOTAL_COMMISSIONED
            and all(key in hashes and verified_state.get(key) == hashes[key] for key in current_keys))


def acknowledged_keys(m, runs):
    return {f"custody/generation/{r['notebookId']}/{j['id']}.{m.EXT[j['type']]}"
            for r in runs for job in r['jobs'] for j in [job, *(job.get('attemptHistory') or [])]
            if j.get('status') == 'completed' and j.get('id') and j.get('type') in m.EXT}


def ready_custody_entries(m, runs, verified_state, blocked=None):
    entries = {}
    for run in runs:
        for current in run['jobs']:
            for job in [current, *(current.get('attemptHistory') or [])]:
                if (job.get('status') != 'completed' or not job.get('id')
                        or not job.get('providerProof', {}).get('settingsVerified') or job.get('type') not in m.EXT):
                    continue
                identity = {'notebookId': run['notebookId'], 'providerId': job['id'], 'ext': m.EXT[job['type']]}
                key = m.custody_key(identity)
                review = job.get('qualityReview') or {}
                if key in verified_state:
                    if review and (review.get('providerId') != job['id'] or review.get('originalSha256') != verified_state[key]):
                        if blocked is not None:blocked.append({'id': job['id'], 'errorType': 'ReviewIdentityMismatch'})
                        event(custodyItemFailed=job['id'], errorType='ReviewIdentityMismatch', retryNextCycle=True)
                        continue
                    entries[(run['notebookId'], job['id'])] = {**identity, 'sha256': verified_state[key]}
                    continue
                try:
                    if job is current:
                        m._collect_current(entries, run['notebookId'], job)
                    else:
                        m._collect_retained(entries, run['notebookId'], job)
                except Exception as error:
                    if blocked is not None:blocked.append({'id': job['id'], 'errorType': type(error).__name__})
                    event(custodyItemFailed=job['id'], errorType=type(error).__name__, retryNextCycle=True)
    return sorted(entries.values(), key=lambda entry: (entry['notebookId'], entry['providerId']))


def select_batch(entries, blocked=None):
    selected, total = [], 0
    for entry in entries:
        size = entry['source'].stat().st_size
        if size <= 0 or size > MAX_BATCH_BYTES:
            issue = {'id': entry['providerId'], 'errorType': 'OriginalExceedsBatchBudget' if size > 0 else 'OriginalEmpty', 'bytes': size}
            if blocked is not None:blocked.append(issue)
            event(custodyItemFailed=entry['providerId'], errorType=issue['errorType'], bytes=size)
            continue
        if len(selected) >= MAX_BATCH_FILES or total + size > MAX_BATCH_BYTES:
            continue
        selected.append(entry)
        total += size
    return selected


def run_cycle(m, args, verified_state):
    runs = m.load_ledger_runs()
    args.lastDownloadError = None
    args.blockedOriginals = []
    download_runs = [{**run, 'jobs': [job for job in run['jobs']
        if job.get('status') == 'completed' and job.get('id') and job.get('type') in m.EXT
        and f"custody/generation/{run['notebookId']}/{job['id']}.{m.EXT[job['type']]}" not in verified_state]}
        for run in runs]
    if m.generation_worker_permits_downloads():
        try:
            m.ensure_downloaded(args.download_concurrency, runs=download_runs)
        except Exception as error:
            args.lastDownloadError = load_ownership().safe_error(error)
            event(downloadErrorType=type(error).__name__, retryNextCycle=True)
    else:
        args.lastDownloadError = {'errorType': 'DownloadOwnershipPending'}
        event(downloadBlocked=True, reason='Download ownership is not established')
    missing = m.find_missing_originals(download_runs)
    args.pendingDownloads = len(missing)
    if missing:
        event(downloadsPending=len(missing), reason='Retry downloads on the next bounded cycle')
    entries = ready_custody_entries(m, runs, verified_state, args.blockedOriginals)
    delta = [e for e in entries if verified_state.get(m.custody_key(e)) != e['sha256']]
    event(ledgerEntries=len(entries), verifiedUnion=len(verified_state), deltaEntries=len(delta))
    if not delta:
        return runs, entries, False

    # Re-check the selected provider IDs/hashes against fresh ledger state
    # before committing. A root quality retry between the frozen snapshot and
    # this commit changes a job's id/hash; that entry is dropped here and
    # retried from a fresh snapshot next cycle rather than published stale.
    fresh = acknowledged_keys(m, m.load_ledger_runs())
    current = [e for e in delta if m.custody_key(e) in fresh]
    dropped = len(delta) - len(current)
    if dropped:
        event(deltaDropped=dropped, reason='selected provider id/hash changed since snapshot; retrying next cycle')
    confirmed = select_batch(current, args.blockedOriginals)
    if not confirmed:
        return runs, entries, False

    build = ROOT / '.local/artefact-generation/transfers/custody-release'
    manifest_path = ROOT / '.local/artefact-generation/transfers/custody-release-scope.json'
    placed = m.build_custody_tree(confirmed, build, args.workers)
    manifest = m.write_manifest_from_entries(confirmed, build, manifest_path)
    event(custodyBuilt=len(placed), manifestFiles=len(manifest['files']))

    _, _, script = m.check_ea_pin()
    CYCLE_RECEIPTS.mkdir(parents=True, exist_ok=True)
    stamp = datetime.datetime.now(datetime.UTC).strftime('%Y%m%dT%H%M%S%fZ')
    cycle_receipt_path = CYCLE_RECEIPTS / f'{stamp}.json'
    pending = cycle_receipt_path.with_suffix('.pending')
    receipt = m.run_publisher_inprocess(script, build, manifest_path, pending,
                                         args.workers, aws_cli_credentials=True)
    event(uploadedFiles=receipt.get('uploadedFiles'), bodyHashMismatches=receipt.get('bodyHashMismatches'),
          cycleReceipt=str(cycle_receipt_path))

    proof = verified_receipt_files(receipt, {m.custody_key(e): e['sha256'] for e in confirmed})
    pending.write_text(json.dumps(receipt) + '\n')
    pending.replace(cycle_receipt_path)
    verified_state.update(proof)
    save_verified_state(verified_state)
    event(verifiedUnion=len(verified_state), cycleReceipt=str(cycle_receipt_path))
    return runs, entries, True


def load_ownership():
    spec = importlib.util.spec_from_file_location('generation_ownership', ROOT / 'src/programme/generation-ownership.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def supervise(m, args, ownership):
    verified_state = load_verified_state(args.receipt)
    deadline = time.monotonic() + args.seconds
    with ownership.StageLock('custody', TRANSFER_LOCK):
        while args.persistent or time.monotonic() < deadline:
            if not ownership.supervisor_alive():
                return
            ownership.write_stage_status('custody', 'running', verifiedOriginals=len(verified_state))
            try:
                if not args.skip_indexes:
                    publish_indexes(m, args.workers)
                with ownership.StageLock('custody-snapshot'):
                    runs, entries, _ = run_cycle(m, args, verified_state)
                complete = programme_complete(m, runs, entries, verified_state)
                download_error = getattr(args, 'lastDownloadError', None)
                pending_downloads = getattr(args, 'pendingDownloads', 0)
                blocked_originals = getattr(args, 'blockedOriginals', [])
                blocked = download_error is not None or pending_downloads > 0
                ownership.write_stage_status('custody', 'complete' if complete else 'blocked' if blocked_originals else 'retry' if blocked else 'waiting',
                    lastSuccess=datetime.datetime.now(datetime.UTC).isoformat(),
                    lastError={'errorType': 'OriginalsBlocked'} if blocked_originals else (download_error or {'errorType': 'OriginalDownloadsPending'}) if blocked else None,
                    nextRetryAt=(datetime.datetime.now(datetime.UTC) + datetime.timedelta(seconds=args.interval)).isoformat() if blocked or blocked_originals else None,
                    blockedOriginals=blocked_originals, pendingDownloads=pending_downloads, verifiedOriginals=len(verified_state), generationAndCustodyComplete=complete)
                if complete and not args.persistent:
                    return
            except Exception as error:
                if not args.persistent:
                    raise
                failure = ownership.safe_error(error)
                ownership.write_stage_status('custody', 'auth_wait' if failure.get('reason') == 'aws-credentials-unavailable' else 'retry', lastError=failure,
                    nextRetryAt=(datetime.datetime.now(datetime.UTC) + datetime.timedelta(seconds=args.interval)).isoformat())
                event(custodyRetry=True, **ownership.safe_error(error))
            duration = args.interval if args.persistent else max(0, min(args.interval, deadline - time.monotonic()))
            time.sleep(duration)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds', type=int, default=900, help='Bounded run time (60..1800)')
    parser.add_argument('--interval', type=int, default=45, help='Idle seconds between cycles with no delta')
    parser.add_argument('--workers', type=int, default=32)
    parser.add_argument('--download-concurrency', type=int, default=32)
    parser.add_argument('--receipt', type=Path, default=DEFAULT_RECEIPT)
    parser.add_argument('--persistent', action='store_true')
    parser.add_argument('--skip-indexes', action='store_true')
    args = parser.parse_args()
    if not (60 <= args.seconds <= 1800):
        parser.error('--seconds must be between 60 and 1800')
    if not (5 <= args.interval <= 60):
        parser.error('--interval must be between 5 and 60')
    if args.persistent and not args.skip_indexes:
        parser.error('Persistent custody requires --skip-indexes and a separate index owner')

    m = load_transfer_module()
    m.validated_workers(args.workers)
    m.validated_workers(args.download_concurrency)
    m.check_ea_pin()
    supervise(m, args, load_ownership())


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        event(errorType=type(error).__name__)
        raise SystemExit(1)
