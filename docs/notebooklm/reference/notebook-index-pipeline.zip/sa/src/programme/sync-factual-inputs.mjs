/** Rebind reviewed factual selections without altering source bodies or narrative. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { validateSources } from './validate.mjs';
import { readNotebookEvidence, verifySubsectionBundles } from '../corpus/notebook.mjs';
const root = fileURLToPath(new URL('../../', import.meta.url));
const read = file => JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');

export function retireBinding(source) {
  if (source.notebookSourceId) {
    const old = Object.fromEntries(['notebookSourceId', 'notebookBundleKey', 'notebookBundleSha256']
      .filter(key => source[key]).map(key => [key, source[key]]));
    source.historicalAdmissions ??= [];
    if (!source.historicalAdmissions.some(item => JSON.stringify(item) === JSON.stringify(old))) source.historicalAdmissions.push(old);
  }
  source.notebookSourceId = null;
  delete source.notebookBundleKey;
  delete source.notebookBundleSha256;
}

export function bindBrief(brief, bundle, upload, check, manifest, indexed) {
  if (bundle.subject !== brief.id || bundle.role !== 'factual' ||
      upload.key !== bundle.key || upload.sha256 !== bundle.sha256 ||
      check.sourceId !== upload.sourceId || check.key !== bundle.key || check.sha256 !== bundle.sha256 ||
      check.status !== 'success' || check.missingHashes !== 0 || check.missingUrls !== 0 || check.missingMarkers !== 0) {
    throw Error(`Unverified factual binding: ${brief.id}`);
  }
  const selected = brief.sources.filter(s => s.admission !== 'reference-only');
  const identities = values => values.map(s => `${s.path ?? s.file}:${s.sha256}`).sort();
  if (JSON.stringify(identities(selected)) !== JSON.stringify(identities(bundle.members))) throw Error(`Selection differs: ${brief.id}`);
  for (const source of selected) {
    retireBinding(source);
    Object.assign(source, { admission: 'admitted', notebookSourceId: upload.sourceId,
      notebookBundleKey: bundle.key, notebookBundleSha256: bundle.sha256 });
  }
  brief.factualSourceIds = [upload.sourceId];
  brief.status = 'Accepted';
  brief.factualInput = { state: 'indexed-verified', mode: 'isolated-subsection',
    approvalRecord: manifest.admissionReview.file, approvalSha256: manifest.admissionReview.sha256,
    manifest: 'docs/notebooklm/subsections/manifest.json', publication: 'docs/notebooklm/subsections/publication.json',
    indexedVerification: 'docs/notebooklm/subsections/indexed-verification.json', verifiedAt: indexed.verifiedAt,
    documents: selected.length, bundleKey: bundle.key, bundleSha256: bundle.sha256 };
  brief.generationReady = false;
  brief.generationStatus = 'Replacement commissioned; factual input verified; frozen run and editorial sync required.';
}

async function main() {
  const [mode, reviewFile] = process.argv.slice(2);
  if (!['prepare', 'bind'].includes(mode)) throw Error('Use prepare <approved-review> or bind');
  const programme = read('config/programme.json');
  const records = programme.sections.map(s => ({file: `config/authoring/${s.id}.json`, data: read(`config/authoring/${s.id}.json`)}));
  const expected = records.flatMap(r => r.data.subjects.map(b => b.id)).sort();
  const evidence = await readNotebookEvidence(root);
  if (mode === 'prepare') {
    if (!/^docs\/reviews\/[a-zA-Z0-9_-]+\.json$/.test(reviewFile ?? '')) throw Error('Invalid review path');
    const review = read(reviewFile);
    if (review.admissionDecision !== 'approved' || JSON.stringify(review.admissions.map(a => a.subject).sort()) !== JSON.stringify(expected)) throw Error('Incomplete approved review');
    for (const {data} of records) for (const brief of data.subjects) {
      const selected = review.admissions.find(a => a.subject === brief.id).approved;
      if (!selected.length || new Set(selected.map(a => a.file)).size !== selected.length) throw Error(`Invalid selection: ${brief.id}`);
      for (const item of selected) {
        if (!brief.sources.some(s => s.path === item.file && s.sha256 === item.sha256 && s.pathScope === 'local')) throw Error(`Unknown source: ${brief.id}`);
      }
      for (const source of brief.sources) {
        retireBinding(source);
        source.admission = selected.some(s => s.file === source.path && s.sha256 === source.sha256) ? 'pending' : 'reference-only';
      }
      brief.factualSourceIds = [];
      brief.factualInput = {state: 'review-approved', mode: 'isolated-subsection', approvalRecord: reviewFile};
      brief.generationReady = false;
      brief.generationStatus = 'Replacement commissioned; revised factual input awaits indexed verification.';
      validateSources(root, brief, evidence.bundles, evidence.uploads);
    }
  } else {
    await verifySubsectionBundles(root);
    const manifest = read('docs/notebooklm/subsections/manifest.json');
    const publication = read('docs/notebooklm/subsections/publication.json');
    const indexed = read('docs/notebooklm/subsections/indexed-verification.json');
    if (manifest.notebookId !== publication.notebookId || manifest.notebookId !== indexed.notebookId || publication.pending ||
        manifest.bundles.length !== expected.length || indexed.checks.length !== expected.length || indexed.sourceCount !== expected.length) throw Error('Incomplete source sync');
    if (hash(fs.readFileSync(path.join(root, manifest.admissionReview.file))) !== manifest.admissionReview.sha256) throw Error('Review changed');
    for (const {data} of records) for (const brief of data.subjects) {
      const bundles = manifest.bundles.filter(b => b.subject === brief.id);
      if (bundles.length !== 1) throw Error(`Expected one isolated bundle: ${brief.id}`);
      const bundle = bundles[0];
      const uploads = publication.uploads.filter(u => u.key === bundle.key && u.sha256 === bundle.sha256 && publication.currentSourceIds.includes(u.sourceId));
      if (uploads.length !== 1) throw Error(`Ambiguous upload: ${brief.id}`);
      const check = indexed.checks.find(c => c.sourceId === uploads[0].sourceId);
      if (!check) throw Error(`Missing indexed proof: ${brief.id}`);
      bindBrief(brief, bundle, uploads[0], check, manifest, indexed);
      validateSources(root, brief, evidence.bundles, evidence.uploads);
    }
  }
  // Validate the whole programme before touching any canonical authoring record.
  for (const {file, data} of records) {
    const target = path.join(root, file), pending = target + '.pending';
    fs.writeFileSync(pending, JSON.stringify(data, null, 2) + '\n');
    fs.renameSync(pending, target);
  }
  console.log(JSON.stringify({mode, subjects: expected.length}));
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) await main();
