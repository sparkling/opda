#!/usr/bin/env python3
"""Sync and read back frozen editorial sources before enabling generation.

Reuses the existing state owner's durable intent, exact hash/title and indexed
text checks. A failed unacknowledged upload is never blindly submitted again;
the next invocation reconciles the exact title or reports the pending source.
"""
import argparse
import importlib.util
import json
import logging
from pathlib import Path
import subprocess
import sys
import time

from notebooklm_tools.mcp.tools._utils import get_client

logging.disable(logging.CRITICAL)
ROOT = Path(__file__).resolve().parents[2]


def module(name):
    spec = importlib.util.spec_from_file_location(name.replace('-', '_'), ROOT / 'src/programme' / (name + '.py'))
    value = importlib.util.module_from_spec(spec)
    sys.dont_write_bytecode = True
    spec.loader.exec_module(value)
    return value


def state(command, run, subject, value=None, content=None):
    args = ['node', 'src/programme/generation-state.mjs', command, run['sectionId'], subject['id']]
    if value:
        args.append(value)
    result = subprocess.run(args, cwd=ROOT, input=content, capture_output=True, text=True, check=True)
    return json.loads(result.stdout)


def indexed_source(client, identity, expected, seconds=120):
    deadline = time.monotonic() + seconds
    while True:
        content = client.get_source_fulltext(identity).get('content')
        if isinstance(content, str) and content.strip():
            # The authoritative JS owner does Unicode-normalized full-body
            # validation, so citation/rendering conversion does not weaken it.
            try:
                state('editorial-verify', expected['run'], expected['subject'], content=content)
                return
            except subprocess.CalledProcessError:
                pass
        if time.monotonic() >= deadline:
            raise RuntimeError('Editorial indexing verification pending: ' + expected['subject']['id'])
        time.sleep(2)


def sync_subject(client, file, subject_id, native, wait_seconds=120):
    run = json.loads(file.read_text())
    subject = next(s for s in run['subjects'] if s['id'] == subject_id)
    expected = state('editorial-intent', run, subject)
    live = client.get_notebook_sources_with_types(run['notebookId'])
    matches = [row for row in live if row['title'] == expected['title']]
    if len(matches) > 1:
        raise RuntimeError('Ambiguous editorial source: ' + subject_id)
    identity = subject.get('editorialSourceId')
    if identity:
        if len(matches) != 1 or matches[0]['id'] != identity:
            raise RuntimeError('Acknowledged editorial source identity differs: ' + subject_id)
    elif matches:
        identity = matches[0]['id']
        state('editorial-ack', run, subject, identity)
    else:
        fresh = json.loads(file.read_text())
        owner = next(s for s in fresh['subjects'] if s['id'] == subject_id)
        if owner['editorialSync'].get('createAttemptedAt'):
            raise RuntimeError('Unacknowledged editorial upload requires reconciliation: ' + subject_id)
        owner['editorialSync']['createAttemptedAt'] = native.NOW()
        native.save(file, fresh)
        native.durable_file(file)
        result = native.create_once(client, client.add_text_source, run['notebookId'],
            expected['text'], title=expected['title'], wait=False, fenced_rpc=client.RPC_ADD_SOURCE)
        if not isinstance(result, dict) or not (result.get('id') or result.get('source_id')):
            raise RuntimeError('Editorial upload was not acknowledged: ' + subject_id)
        identity = result.get('id') or result['source_id']
        state('editorial-ack', run, subject, identity)
    indexed_source(client, identity, {'run': run, 'subject': subject}, seconds=wait_seconds)
    return {'subject': subject_id, 'sourceId': identity, 'status': 'indexed-verified'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--section')
    parser.add_argument('--wait-seconds', type=int, default=120, choices=range(1, 181))
    args = parser.parse_args()
    programme = json.loads((ROOT / 'config/programme.json').read_text())
    sections = [row['id'] for row in programme['sections']]
    if args.section and args.section not in sections:
        raise ValueError('Unknown section')
    native, owner = module('generation-native'), module('generation-ownership')
    count = 0
    with owner.StageLock('generation', ROOT / '.local/artefact-generation/worker.lock'):
        client = get_client()
        for section in [args.section] if args.section else sections:
            file = ROOT / f'docs/generation/{section}.json'
            for subject in json.loads(file.read_text())['subjects']:
                print(json.dumps(sync_subject(client, file, subject['id'], native, args.wait_seconds)), flush=True)
                count += 1
    print(json.dumps({'editorialsVerified': count, 'submittedArtefacts': 0}))


if __name__ == '__main__':
    main()
