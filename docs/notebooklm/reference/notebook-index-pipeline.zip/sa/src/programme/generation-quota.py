"""Restart-safe quota eligibility; section ledgers remain the job identity owner.

Read contract verified with the existing native client: EylDcb([null], '/').
https://github.com/teng-lin/notebooklm-py/blob/main/src/notebooklm/_web/usage.py
Numeric action mapping follows its captured frontend translator, not enum labels.
"""
import json
import math
import os
from datetime import datetime, timedelta, timezone

KINDS = ('audio', 'video', 'infographic', 'slide_deck')
MAX_ACTIVE = 4

def capacity_available(active, kind):
    """Local scheduling policy, never evidence of a provider limit. None removes it."""
    return MAX_ACTIVE is None or active[kind] < MAX_ACTIVE

def timestamp(value):
    stamp = datetime.fromisoformat(value.replace('Z', '+00:00'))
    assert stamp.utcoffset() is not None, 'Timezone required'
    return stamp.astimezone(timezone.utc)

def iso(stamp):
    return stamp.astimezone(timezone.utc).isoformat()

def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_name(path.name + '.tmp')
    with pending.open('w') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    pending.replace(path)
    descriptor = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)

def config(path):
    value = json.loads(path.read_text())
    assert isinstance(value, dict) and set(value) <= {'schemaVersion', 'desiredState', 'reconcileSeconds', 'userResetAt', 'probeBackoffSeconds'}
    assert type(value.get('schemaVersion')) is int and value['schemaVersion'] == 1
    result = {'desiredState': 'run', 'reconcileSeconds': 30, 'probeBackoffSeconds': 60, **value}
    assert result['desiredState'] in ('run', 'drain', 'hold')
    assert type(result['reconcileSeconds']) is int and 5 <= result['reconcileSeconds'] <= 60
    assert type(result['probeBackoffSeconds']) is int and 30 <= result['probeBackoffSeconds'] <= 900
    assert result.get('userResetAt') is None or isinstance(result['userResetAt'], str)
    if result.get('userResetAt'):
        timestamp(result['userResetAt'])
    return result

def load_state(path):
    value = json.loads(path.read_text()) if path.exists() else {'schemaVersion': 1, 'limits': {}, 'probes': {}}
    assert isinstance(value, dict) and type(value.get('schemaVersion')) is int and value['schemaVersion'] == 1
    assert isinstance(value.get('limits'), dict) and set(value['limits']) <= set(KINDS)
    assert isinstance(value.get('probes'), dict) and set(value['probes']) <= set(KINDS)
    for entry in value['limits'].values():
        timestamp(entry['nextProbeAt'])
        timestamp(entry['limitObservedAt'])
        assert type(entry.get('backoffAttempt')) is int and 0 <= entry['backoffAttempt'] <= 10
    return value

def read_meter(client, now):
    data = client._call_rpc('EylDcb', [None], path='/')
    assert isinstance(data, list) and len(data) >= 4 and type(data[0]) is int and data[0] == 1, 'Quota response unavailable'
    assert isinstance(data[1], list) and isinstance(data[3], list)
    windows = {}
    for row in data[1]:
        assert isinstance(row, list) and len(row) >= 6 and type(row[4]) is int and row[4] in (1, 2)
        assert row[4] not in windows
        pair = row[5]
        assert isinstance(pair, list) and 1 <= len(pair) <= 2 and type(pair[0]) is int
        nanos = pair[1] if len(pair) > 1 else 0
        assert type(nanos) is int and 0 <= nanos < 1000000000
        reset = datetime.fromtimestamp(pair[0], timezone.utc) + timedelta(microseconds=(nanos + 999) // 1000)
        percentages = [row[index] if len(row) > index else None for index in (6, 7)]
        assert any(v is not None for v in percentages)
        assert all(v is None or (type(v) in (int, float) and math.isfinite(v) and 0 <= v <= 100) for v in percentages)
        used, remaining = percentages
        windows[str(row[4])] = {'resetTimestamp': [pair[0], nanos], 'resetsAt': iso(reset), 'usedPercent': used if used is not None else 100 - remaining, 'remainingPercent': remaining if remaining is not None else 100 - used}
    assert set(windows) == {'1', '2'}
    exhausted = data[2] or []
    assert isinstance(exhausted, list) and all(type(code) is int and code > 0 for code in exhausted)
    actions = {}
    for row in data[3]:
        assert isinstance(row, list) and len(row) >= 2 and type(row[0]) is int and row[0] > 0
        assert row[1] is None or type(row[1]) is bool
        assert str(row[0]) not in actions and not (row[1] is True and row[0] in exhausted)
        actions[str(row[0])] = row[1] is True  # Protobuf false is normally elided.
    assert actions
    return {'checkedAt': iso(now), 'rpc': 'EylDcb', 'resetProvenance': 'provider-read-only-ListQuotaSummary', 'windows': windows, 'actions': actions, 'outOfQuotaActions': exhausted}

def action(job):
    if job['type'] == 'video':
        return '3' if job['format'] == 'cinematic' else '2'
    return {'audio': '1', 'infographic': '8', 'slide_deck': '6'}[job['type']]

def available(meter, job):
    return meter is not None and meter['actions'].get(action(job)) is True

def deadline(meter, cfg, now, delay):
    if meter is not None:
        resets = [timestamp(w['resetsAt']) for w in meter['windows'].values() if w['remainingPercent'] == 0]
        future = [value for value in resets if value > now]
        if future:
            return iso(max(future)), meter['resetProvenance']
    if cfg.get('userResetAt') and timestamp(cfg['userResetAt']) > now:
        return cfg['userResetAt'], 'user-reported-reset'
    return iso(now + timedelta(seconds=delay)), 'bounded-backoff-estimate'

def sync_limits(state, runs, meter, cfg, now):
    observed = {}
    for run in runs:
        for kind, entry in run.get('providerLimits', {}).items():
            assert kind in KINDS and entry['errorType'] == 'ResourceExhaustedError'
            if kind not in observed or timestamp(entry['checkedAt']) > timestamp(observed[kind]['checkedAt']):
                observed[kind] = entry
    for kind, entry in observed.items():
        current = state['limits'].get(kind)
        restored = any(available(meter, j) for r in runs for j in r['jobs'] if j['type'] == kind and j['status'] == 'planned')
        if not current or current['limitObservedAt'] != entry['checkedAt']:
            due, provenance = deadline(meter, cfg, now, cfg['probeBackoffSeconds'])
            if not current and restored:
                due, provenance = iso(now), 'provider-observed-availability-restored'
            state['limits'][kind] = {'limitObservedAt': entry['checkedAt'], 'errorType': entry['errorType'], 'nextProbeAt': due, 'resetProvenance': provenance, 'backoffAttempt': current['backoffAttempt'] if current else 0}
        elif restored and (current.get('resetProvenance') == 'provider-read-only-ListQuotaSummary'
                           or current.get('availabilityLastSeen') is False):
            current['nextProbeAt'], current['resetProvenance'] = iso(now), 'provider-observed-availability-restored'
        elif timestamp(current['nextProbeAt']) <= now and not restored:
            current['nextProbeAt'], current['resetProvenance'] = deadline(meter, cfg, now, cfg['probeBackoffSeconds'])
        state['limits'][kind]['availabilityLastSeen'] = restored
    for kind in set(state['limits']) - set(observed):
        del state['limits'][kind]

def accepted_probes(state, runs, checked_after=None):
    accepted = []
    for kind, probe in state['probes'].items():
        if not probe.get('attemptedAt'):
            continue
        job = next((j for r in runs if r['sectionId'] == probe['sectionId'] for j in r['jobs'] if j['key'] == probe['key']), None)
        if not job:
            continue
        attempts = [job] + job.get('attemptHistory', [])
        record = next((j for j in attempts if j.get('attemptedAt') == probe['attemptedAt']), None)
        if not record or record.get('status') not in ('submitted', 'completed', 'failed') or not record.get('id') or not record.get('acknowledgedAt'):
            continue
        if record.get('reconciliationAssociation', {}).get('returnedAcknowledgement') is False:
            continue
        proof = record.get('providerProof', {})
        if not proof.get('settingsVerified') or not proof.get('verifiedAt'):
            continue
        if timestamp(proof['verifiedAt']) < timestamp(record['acknowledgedAt']) or timestamp(record['acknowledgedAt']) < timestamp(probe['attemptedAt']):
            continue
        if checked_after and probe.get('phase') != 'accepted' and timestamp(proof['verifiedAt']) < timestamp(checked_after):
            continue
        limit = state['limits'].get(kind)
        if limit and timestamp(record['acknowledgedAt']) <= timestamp(limit['limitObservedAt']):
            continue
        accepted.append((kind, {'key': probe['key'], 'id': record['id'], 'acknowledgedAt': record['acknowledgedAt'], 'verifiedAt': proof['verifiedAt'], 'returnedAcknowledgement': True}))
    return accepted

def failed_probe(state, kind, now, meter, cfg):
    entry = state['limits'][kind]
    entry['backoffAttempt'] = min(10, entry['backoffAttempt'] + 1)
    delay = min(900, cfg['probeBackoffSeconds'] * 2 ** (entry['backoffAttempt'] - 1))
    entry['nextProbeAt'], entry['resetProvenance'] = deadline(meter, cfg, now, delay)

def eligibility(state, runs, meter, cfg, now, active, uncertain):
    limits = set(state['limits'])
    normal = [kind for kind in KINDS if kind not in limits | uncertain and capacity_available(active, kind)]
    order = list(KINDS)
    if state.get('lastProbeKind') in order:
        index = order.index(state['lastProbeKind']) + 1
        order = order[index:] + order[:index]
    probe = next((kind for kind in order if kind in limits and kind not in uncertain and capacity_available(active, kind)
                  and state['probes'].get(kind, {}).get('phase') != 'awaiting-proof'
                  and timestamp(state['limits'][kind]['nextProbeAt']) <= now
                  and any(j['type'] == kind and j['status'] == 'planned' and available(meter, j) for r in runs for j in r['jobs'])), None)
    next_probe = min((entry['nextProbeAt'] for entry in state['limits'].values()), default=None)
    phase = 'runnable' if probe or any(available(meter, j) for r in runs for j in r['jobs'] if j['type'] in normal and j['status'] == 'planned') else 'provider_capacity_wait' if any(active.values()) else 'uncertainty_wait' if uncertain else 'quota_wait'
    disabled = {kind for kind in KINDS if any(j['type'] == kind and j['status'] == 'planned' for r in runs for j in r['jobs']) and not any(available(meter, j) for r in runs for j in r['jobs'] if j['type'] == kind and j['status'] == 'planned')}
    waits = {kind: 'uncertainty_wait' if kind in uncertain else 'provider_capacity_wait' if not capacity_available(active, kind) else 'quota_wait' if kind in limits | disabled else 'runnable' for kind in KINDS}
    return {'normalKinds': normal, 'probeKind': probe, 'phase': phase, 'nextProbeAt': next_probe, 'waitingByMedium': waits}
