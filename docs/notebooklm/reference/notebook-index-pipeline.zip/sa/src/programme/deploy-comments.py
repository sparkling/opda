#!/usr/bin/env python3
"""Deploy Artalk, or update only SA's routes to the existing research service."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import secrets
import shlex
import subprocess
import textwrap
import urllib.request
import zipfile
import boto3
from botocore.exceptions import ClientError

ROOT = Path(__file__).resolve().parents[2]
ACCOUNT = '841291679368'


def replacement_parameters(stack, replacements):
    """Preserve opaque existing values, including NoEcho comments credentials."""
    return [
        {'ParameterKey': row['ParameterKey'], 'UsePreviousValue': True}
        for row in stack['Parameters'] if row['ParameterKey'] not in replacements
    ] + [
        {'ParameterKey': key, 'ParameterValue': value}
        for key, value in replacements.items()
    ]


def research_parameters(stack, research, enable):
    if not enable:
        return replacement_parameters(stack, {
            'ResearchOriginDomain': '', 'ResearchOriginSecretArn': '',
        })
    if research.get('StackStatus') not in ('CREATE_COMPLETE', 'UPDATE_COMPLETE'):
        raise RuntimeError('Research stack must be ready before SA routing activation')
    outputs = {row['OutputKey']: row['OutputValue'] for row in research.get('Outputs', [])}
    domain = outputs.get('OriginDomain', '')
    secret = outputs.get('SaOriginSecretArn', '')
    if not re.fullmatch(r'[A-Za-z0-9-]+\.us-east-1\.elb\.amazonaws\.com', domain):
        raise RuntimeError('Research origin output is missing or invalid')
    if not re.fullmatch(r'arn:aws:secretsmanager:us-east-1:' + ACCOUNT + r':secret:[A-Za-z0-9/_+=.@-]+', secret):
        raise RuntimeError('SA-specific research origin secret output is missing or invalid')
    if secret == outputs.get('OriginSecretArn'):
        raise RuntimeError('SA and EA research origin credentials must be distinct')
    return replacement_parameters(stack, {
        'ResearchOriginDomain': domain, 'ResearchOriginSecretArn': secret,
    })


def verify_research_tls(session, stack, domain):
    """Forwarded SA Host must match a certificate actually attached to the ALB."""
    certificate = next(row['ParameterValue'] for row in stack['Parameters']
                       if row['ParameterKey'] == 'CertificateArn')
    metadata = session.client('acm').describe_certificate(CertificateArn=certificate)['Certificate']
    if metadata['Status'] != 'ISSUED' or 'sa.hm.sparklingideas.co.uk' not in metadata['SubjectAlternativeNames']:
        raise RuntimeError('Existing SA certificate is not issued for the exact website')
    elb = session.client('elbv2')
    matches = [load for page in elb.get_paginator('describe_load_balancers').paginate()
               for load in page['LoadBalancers'] if load['DNSName'] == domain]
    if len(matches) != 1:
        raise RuntimeError('Research origin must match one existing ALB')
    listeners = elb.describe_listeners(LoadBalancerArn=matches[0]['LoadBalancerArn'])['Listeners']
    https = [listener for listener in listeners if listener['Port'] == 443 and listener['Protocol'] == 'HTTPS']
    if len(https) != 1:
        raise RuntimeError('Research origin HTTPS listener is unavailable')
    certificates = [cert for page in elb.get_paginator('describe_listener_certificates').paginate(
        ListenerArn=https[0]['ListenerArn']) for cert in page['Certificates']]
    if not any(cert['CertificateArn'] == certificate for cert in certificates):
        raise RuntimeError('Attach the existing SA certificate to the research ALB before activation')


def deploy_research_routes(session, action, plan_only=False):
    """No SSH, Artalk, Lambda, secret-value retrieval, or content publication."""
    cloud = session.client('cloudformation')
    stack = cloud.describe_stacks(StackName='hm-site-sa')['Stacks'][0]
    if stack['StackStatus'] not in ('CREATE_COMPLETE', 'UPDATE_COMPLETE', 'UPDATE_ROLLBACK_COMPLETE'):
        raise RuntimeError('SA stack must be stable before changing routes')
    enable = action == 'enable'
    research = cloud.describe_stacks(StackName='hm-ea-research')['Stacks'][0] if enable else {}
    parameters = research_parameters(stack, research, enable)
    if enable:
        domain = next(row['ParameterValue'] for row in parameters if row['ParameterKey'] == 'ResearchOriginDomain')
        verify_research_tls(session, stack, domain)
    template = (ROOT/'config/hosting/sa-site.yaml').read_text()
    cloud.validate_template(TemplateBody=template)
    if not plan_only:
        try:
            cloud.update_stack(StackName='hm-site-sa', TemplateBody=template,
                               Parameters=parameters, Capabilities=['CAPABILITY_IAM'])
        except ClientError as error:
            if error.response.get('Error', {}).get('Message') != 'No updates are to be performed.':
                raise
            print(json.dumps({'stack': 'hm-site-sa', 'researchRoutes': action, 'unchanged': True}))
            return
    print(json.dumps({'stack': 'hm-site-sa', 'researchRoutes': action,
                      'planOnly': plan_only, 'updateStarted': not plan_only}))


def deploy_comments(args, session):
    # Store the origin secret only on the host and in the protected AWS configuration.
    remote = r'''
    import json,os,pathlib,subprocess,sys
    token_path=pathlib.Path('/opt/sa-artalk/origin-secret')
    if not token_path.exists() or ROTATE_ORIGIN_SECRET:
     token_path.write_text(sys.stdin.read().strip())
     os.chmod(token_path,0o640)
    subprocess.run(['chown','root:sa-comments',str(token_path)],check=True)
    token=token_path.read_text().strip()
    route=pathlib.Path('/etc/caddy/sa-comments.caddy')
    contexts=[('sa',token)]
    ea_path=pathlib.Path('/opt/sa-artalk/ea-origin-secret')
    if ea_path.exists():contexts.append(('ea',ea_path.read_text().strip()))
    route.write_text(''.join('@'+site+'Comments {\n path /comments/*\n header X-'+site.upper()+'-Comments-Origin '+value+'\n}\nhandle @'+site+'Comments {\n uri strip_prefix /comments\n reverse_proxy 127.0.0.1:23367\n}\n' for site,value in contexts))
    subprocess.run(['chown','root:caddy',str(route)],check=True)
    os.chmod(route,0o640)
    config=pathlib.Path('/etc/caddy/Caddyfile')
    feed=' import /etc/caddy/sa-research-feed.caddy\n' if pathlib.Path('/etc/caddy/sa-research-feed.caddy').exists() else ''
    config.write_text('comments.sa.hm.sparklingideas.co.uk {\n import /etc/caddy/sa-comments.caddy\n'+feed+' handle {\n respond 404\n }\n}\n')
    check=subprocess.run(['caddy','validate','--config',str(config)],capture_output=True)
    if check.returncode: raise RuntimeError('Caddy validation failed; inspect host diagnostics')
    subprocess.run(['systemctl','reload','caddy'],check=True,capture_output=True)
    subprocess.run(['systemctl','restart','sa-comments-gateway'],check=True,capture_output=True)
    print(json.dumps({'secret':token}))
    '''
    remote=textwrap.dedent(remote).replace('ROTATE_ORIGIN_SECRET',repr(args.rotate_origin_secret))
    # Only the non-secret program is an SSH argument; new credentials travel via stdin.
    ssh=['ssh','-i',str(args.identity),'-o','BatchMode=yes',args.host]
    result=subprocess.run(ssh+['sudo -n python3 -c '+shlex.quote(remote)],input=secrets.token_urlsafe(48),text=True,check=True,capture_output=True)
    token=json.loads(result.stdout)['secret']
    print('Private origin configured',flush=True)
    if args.configure_only:
     raise SystemExit(0)

    client=session.client('lambda')
    function=client.get_function(FunctionName='hm-sa-cognito-auth')
    body=urllib.request.urlopen(function['Code']['Location'],timeout=60).read()
    source=zipfile.ZipFile(io.BytesIO(body))
    handler=source.read('auth-handler.mjs').decode()
    guard="    if (request.uri.startsWith('/comments/')) return;"
    changed=guard not in handler
    if changed:
     marker='  const rewriteStaticIndex = (request, host) => {'
     assert handler.count(marker)==1
     handler=handler.replace(marker,marker+'\n'+guard)
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as target:
     for entry in source.infolist():
      target.writestr(entry,handler.encode() if entry.filename=='auth-handler.mjs' else source.read(entry.filename))
    artifact=output.getvalue()
    key='sa/cognito-auth-'+hashlib.sha256(artifact).hexdigest()+'.zip'
    uploaded=session.client('s3').put_object(Bucket='hm-lambda-edge-artifacts-841291679368',Key=key,Body=artifact) if changed else None
    cloud=session.client('cloudformation')
    stack=cloud.describe_stacks(StackName='hm-site-sa')['Stacks'][0]
    parameters=[{'ParameterKey':p['ParameterKey'],'UsePreviousValue':True} for p in stack['Parameters']
                if p['ParameterKey'] not in (('ArtifactKey','ArtifactVersionId','CommentsOriginSecret','CommentsOriginDomain') if changed else ('CommentsOriginSecret','CommentsOriginDomain'))]
    if changed: parameters.extend([
     {'ParameterKey':'ArtifactKey','ParameterValue':key},
     {'ParameterKey':'ArtifactVersionId','ParameterValue':uploaded['VersionId']},
    ])
    parameters.append({'ParameterKey':'CommentsOriginSecret','ParameterValue':token})
    parameters.append({'ParameterKey':'CommentsOriginDomain','ParameterValue':'comments.sa.hm.sparklingideas.co.uk'})
    cloud.update_stack(StackName='hm-site-sa',TemplateBody=(ROOT/'config/hosting/sa-site.yaml').read_text(),
     Parameters=parameters,Capabilities=['CAPABILITY_IAM'])
    print('CloudFormation update started: hm-site-sa',flush=True)



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rotate-origin-secret', action='store_true')
    parser.add_argument('--configure-only', action='store_true', help='Prepare Artalk before CloudFront cutover')
    parser.add_argument('--host', help='SSH destination of the provisioned Lightsail instance')
    parser.add_argument('--identity', type=Path, default=Path.home()/'.ssh/sa-artalk')
    parser.add_argument('--research-routes', choices=['enable', 'disable'],
                        help='Update only chat routing; reuse ready EA stack outputs and existing SA TLS certificate')
    parser.add_argument('--plan', action='store_true', help='Validate research routing without changing AWS')
    args = parser.parse_args()
    if args.research_routes:
        if args.host or args.rotate_origin_secret or args.configure_only:
            parser.error('--research-routes cannot be combined with Artalk configuration options')
    elif args.plan or not args.host or not re.fullmatch(r'[a-z_][a-z0-9_-]*@[a-zA-Z0-9.-]+', args.host):
        parser.error('Artalk deployment requires --host user@hostname; --plan requires --research-routes')
    session = boto3.Session(profile_name='claude', region_name='us-east-1')
    if session.client('sts').get_caller_identity()['Account'] != ACCOUNT:
        raise RuntimeError('Unexpected AWS account')
    if args.research_routes:
        deploy_research_routes(session, args.research_routes, args.plan)
    else:
        deploy_comments(args, session)


if __name__ == '__main__':
    main()
