"""Single stage ownership across restarts, with legacy PID-file compatibility.

The advisory lock inode is never removed. A killed owner releases the kernel
lock automatically; a PID mirror is diagnostic and is recovered only when its
recorded process is proven absent. No memory/database handles are involved.
"""
import errno
import datetime
import fcntl
import json
import os
import re
import shlex
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / '.local/artefact-generation'


def supervisor_alive():
    expected = os.environ.get('SA_PIPELINE_SUPERVISOR_PID')
    return expected is None or (expected.isdigit() and os.getppid() == int(expected))


def transfer_recovery_allowed():
    """Only the new custody owner honours the short shared snapshot mutex.
    A legacy/unknown live transfer must still block generation recovery.
    """
    mirror = WORK / 'transfer.lock'
    try:
        text = mirror.read_text().strip()
    except FileNotFoundError:
        return True
    if mirror.is_symlink() or not text.isdigit() or int(text) < 1:
        return False
    try:
        os.kill(int(text), 0)
    except ProcessLookupError:
        return True
    except PermissionError:
        return False
    result = subprocess.run(['/bin/ps', '-p', text, '-o', 'command='], capture_output=True, text=True)
    if result.returncode:
        return False
    try:
        argv = shlex.split(result.stdout.strip())
    except ValueError:
        return False
    return (len(argv) >= 4 and re.fullmatch(r'python(?:\d+(?:\.\d+)*)?', Path(argv[0]).name)
        and Path(argv[1]).is_absolute()
        and Path(argv[1]).resolve() == ROOT / 'src/programme/generation-transfer-worker.py'
        and all(flag in argv[2:] for flag in ('--persistent', '--skip-indexes')))


def safe_error(error):
    fields = {'errorType': type(error).__name__}
    for candidate in (error, error.__cause__, error.__context__):
        if candidate is None:
            continue
        message = str(candidate).lower()
        if 'authentication expired' in message:
            fields['reason'] = 'notebook-auth-expired'
        elif 'aws cli credential' in message:
            fields['reason'] = 'aws-credentials-unavailable'
        status = getattr(getattr(candidate, 'response', None), 'status_code', None)
        if type(status) is int and 100 <= status <= 599:
            fields['httpStatus'] = status
        rpc_code = getattr(candidate, 'error_code', None)
        if type(rpc_code) is int and 1 <= rpc_code <= 16:
            fields['rpcErrorCode'] = rpc_code
        code = getattr(candidate, 'returncode', None)
        if type(code) is int:
            fields['exitCode'] = code
    return fields


def write_stage_status(stage, phase, **safe_fields):
    if not re.fullmatch(r'[a-z][a-z-]{0,40}', stage):
        raise ValueError('Invalid stage name')
    path = WORK / 'pipeline' / (stage + '-status.json')
    previous = json.loads(path.read_text()) if path.exists() else {}
    previous.update(safe_fields, phase=phase, pid=os.getpid(),
                    updatedAt=datetime.datetime.now(datetime.UTC).isoformat())
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_suffix('.pending')
    pending.write_text(json.dumps(previous, sort_keys=True) + '\n')
    pending.replace(path)


class StageLock:
    def __init__(self, name, mirror=None):
        if not re.fullmatch(r'[a-z][a-z-]{0,40}', name):
            raise ValueError('Invalid stage name')
        self.path = WORK / (name + '.owner.lock')
        self.mirror = Path(mirror) if mirror else None
        if self.mirror and (self.mirror.parent != WORK or self.mirror.suffix != '.lock'):
            raise ValueError('PID mirror must be a project worker lock')
        self.descriptor = None

    def __enter__(self):
        if not supervisor_alive():
            raise RuntimeError('Pipeline supervisor exited before stage ownership')
        WORK.mkdir(parents=True, exist_ok=True)
        flags = os.O_CREAT | os.O_RDWR | getattr(os, 'O_NOFOLLOW', 0)
        self.descriptor = os.open(self.path, flags, 0o600)
        try:
            fcntl.flock(self.descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            if self.mirror:
                self._claim_mirror()
        except BaseException:
            os.close(self.descriptor)
            self.descriptor = None
            raise
        return self

    def _claim_mirror(self):
        if self.mirror.is_symlink():
            raise RuntimeError('Refusing a symlinked PID mirror')
        try:
            previous = self.mirror.read_text()
        except FileNotFoundError:
            previous = None
        if previous is not None:
            if not re.fullmatch(r'[1-9][0-9]*\s*', previous):
                raise RuntimeError('Unknown PID mirror owner; refusing recovery')
            try:
                os.kill(int(previous), 0)
            except OSError as error:
                if error.errno != errno.ESRCH:
                    raise RuntimeError('PID mirror owner cannot be proven absent') from error
            else:
                raise RuntimeError('Legacy stage owner is still alive')
            if self.mirror.read_text() != previous:
                raise RuntimeError('PID mirror changed during recovery')
            self.mirror.unlink()
        fd = os.open(self.mirror, os.O_CREAT | os.O_EXCL | os.O_WRONLY |
                     getattr(os, 'O_NOFOLLOW', 0), 0o600)
        with os.fdopen(fd, 'w') as file:
            file.write(str(os.getpid()))
            file.flush()
            os.fsync(file.fileno())

    def __exit__(self, *exc_info):
        try:
            if self.mirror and not self.mirror.is_symlink():
                try:
                    if self.mirror.read_text().strip() == str(os.getpid()):
                        self.mirror.unlink()
                except FileNotFoundError:
                    pass
        finally:
            if self.descriptor is not None:
                os.close(self.descriptor)
                self.descriptor = None
