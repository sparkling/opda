"""Resolve the approved EA Git revision as a verified, local dependency export.

The canonical repository supplies every byte. Its working tree is never changed,
and this export has no Git metadata, branches or separately maintained source.
"""
import fcntl
import hashlib
import io
import json
import re
import shutil
import subprocess
import tarfile
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
INPUTS = ('site/src', 'site/public/fonts', 'site/scripts',
          'site/public/images/prime-radiant/banner.webp',
          'site/public/images/prime-radiant/banner-loop.webp',
          'site/public/images/prime-radiant/icon.webp',
          'site/public/images/prime-radiant/icon-loop.webp',
          # Browser imports only; never export the research service or its state.
          'site/research/reasoner-contract.mjs', 'site/research/diagram-contract.mjs',
          'site/research/reasoner-models.mjs',
          'site/research/comment-location.mjs',
          # Browser modules the shared evidence/draft chat client imports from EA's src/chat.
          'src/chat/draft.mjs', 'src/chat/app-contract.mjs', 'src/chat/evidence-view.mjs',
          'src/chat/reader-evidence.mjs', 'src/chat/source-selection.mjs', 'src/chat/comparison.mjs',
          'site/package.json', 'site/package-lock.json',
          'docs/programme/editorial-guides', 'docs/programme/notebooklm-decks/runs')

# Installed EA packages, reused from the checkout at the same relative path. The browser
# chat modules in `src/chat/` resolve against EA's own `src/chat/node_modules`.
PACKAGE_LINKS = ('site/node_modules', 'src/chat/node_modules')


def git(checkout, *args):
    return subprocess.check_output(['git', '-C', str(checkout), *args])


def blob_hash(body):
    return hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()


def records_for(checkout, revision):
    if git(checkout, 'cat-file', '-t', revision).strip() != b'commit':
        raise ValueError('Renderer revision must identify a commit')
    records = {}
    for record in git(checkout, 'ls-tree', '-rz', revision, '--', *INPUTS).split(b'\0'):
        if not record:
            continue
        metadata, name = record.decode().split('\t', 1)
        mode, kind, oid = metadata.split()
        relative = Path(name)
        if (relative.is_absolute() or '..' in relative.parts or kind != 'blob'
                or mode not in ('100644', '100755')
                or not any(name == p or name.startswith(p + '/') for p in INPUTS)):
            raise ValueError('Unsupported renderer dependency path or mode')
        records[name] = (mode, oid)
    required = ('site/src/components/NotebookIndexShell.astro',
                'site/scripts/deployment/publish-static-ea.py',
                'site/scripts/deployment/release_scope.py', 'site/package.json')
    if not all(name in records for name in required):
        raise ValueError('Pinned renderer dependency is incomplete')
    return records


def verify_export(directory, records):
    if directory.is_symlink():
        raise ValueError('Renderer dependency cannot be a symlink')
    for name, (_, oid) in records.items():
        target = directory / name
        if any(p.is_symlink() for p in (target, *target.parents) if p != directory.parent):
            raise ValueError('Renderer dependency contains a symlinked source')
        if not target.is_file() or blob_hash(target.read_bytes()) != oid:
            raise ValueError('Renderer dependency differs from its pinned Git blob: ' + name)
    # Installed packages are reused, but cannot introduce another source file.
    actual = set()
    for item in directory.rglob('*'):
        name = item.relative_to(directory).as_posix()
        if item.is_symlink() and name not in PACKAGE_LINKS:
            raise ValueError('Renderer dependency contains an unexpected symlink')
        if item.is_file() and not item.is_symlink():
            actual.add(name)
    if actual != set(records):
        raise ValueError('Renderer dependency contains unexpected files')


def resolve_renderer(root=ROOT):
    root = Path(root).resolve()
    pin = json.loads((root / 'config/shared-renderer.json').read_text())
    revision = pin['revision']
    if not isinstance(revision, str) or not re.fullmatch(r'[0-9a-f]{40}', revision):
        raise ValueError('Invalid renderer revision')
    checkout = (root / pin['checkout']).resolve()
    records = records_for(checkout, revision)
    base = root / '.local/shared-renderer'
    base.mkdir(parents=True, exist_ok=True)
    if base.is_symlink():
        raise ValueError('Renderer dependency directory cannot be a symlink')
    directory = base / revision
    with (base / '.export.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if not directory.exists():
            pending = Path(tempfile.mkdtemp(prefix='.pending-', dir=base))
            try:
                archive = git(checkout, 'archive', '--format=tar', revision, '--', *records)
                with tarfile.open(fileobj=io.BytesIO(archive)) as source:
                    for member in source:
                        if member.isdir():
                            continue
                        if not member.isfile() or member.name not in records:
                            raise ValueError('Unexpected renderer archive member')
                        body = source.extractfile(member).read()
                        mode, oid = records[member.name]
                        if blob_hash(body) != oid:
                            raise ValueError('Renderer archive failed Git blob verification')
                        target = pending / member.name
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_bytes(body)
                        target.chmod(int(mode[-3:], 8))
                verify_export(pending, records)
                pending.rename(directory)
            finally:
                if pending.exists():
                    shutil.rmtree(pending)
        verify_export(directory, records)
        for name in PACKAGE_LINKS:
            packages = checkout / name
            link = directory / name
            if link.is_symlink():
                if link.resolve() != packages.resolve():
                    raise ValueError('Renderer package link changed')
            elif link.exists():
                raise ValueError('Renderer packages must reuse the installed EA dependencies')
            elif packages.is_dir():
                link.symlink_to(packages, target_is_directory=True)
    return {'directory': str(directory), 'checkout': str(checkout), 'revision': revision}


if __name__ == '__main__':
    print(json.dumps(resolve_renderer()))
