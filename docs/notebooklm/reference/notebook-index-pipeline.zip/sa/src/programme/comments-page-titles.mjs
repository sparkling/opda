import { validPageTitle } from './comments-location.mjs';

/** Explicit reviewed native title repair; never rename a page or change its access. */
export async function updateNativePageTitles(entries, request) {
  if(!Array.isArray(entries)||entries.length>100||new Set(entries.map(row=>row?.id)).size!==entries.length)throw Error('Invalid title plan');
  for(const row of entries)if(!row||Object.keys(row).sort().join(',')!=='id,key,previousTitle,title'||!Number.isSafeInteger(row.id)||row.id<1
    ||typeof row.key!=='string'||!row.key.startsWith('/')||row.key.length>2048||typeof row.previousTitle!=='string'||row.previousTitle.length>1000||!validPageTitle(row.title))throw Error('Invalid title plan');
  const read=async row=>{
    const result=await request('/api/v2/pages?'+new URLSearchParams({site_name:'Solutions Architecture',search:row.key,limit:'100',offset:'0'}));
    if(!Array.isArray(result.pages)||!Number.isSafeInteger(result.count)||result.count>100||result.count!==result.pages.length)throw Error('Title lookup exceeds bound');
    const matches=result.pages.filter(page=>page.id===row.id&&page.key===row.key&&page.site_name==='Solutions Architecture');
    if(matches.length!==1||typeof matches[0].admin_only!=='boolean')throw Error('Native page identity changed');
    const page=matches[0];
    if(page.title!==row.previousTitle&&page.title!==row.title)throw Error('Native page title changed since review');
    return page;
  };
  // Check the whole reviewed plan before the first mutation, then reread each row.
  for(const row of entries)await read(row);
  const results=[];
  for(const row of entries){
    const page=await read(row);
    if(page.title===row.title){results.push({id:row.id,status:'already-current'});continue;}
    const updated=await request('/api/v2/pages/'+page.id,'PUT',{site_name:page.site_name,key:page.key,title:row.title,admin_only:page.admin_only});
    if(updated.id!==page.id||updated.key!==page.key||updated.site_name!==page.site_name||updated.admin_only!==page.admin_only||updated.title!==row.title)throw Error('Native title update not confirmed');
    if((await read(row)).title!==row.title)throw Error('Native title readback did not match');
    results.push({id:row.id,status:'updated'});
  }
  return results;
}
