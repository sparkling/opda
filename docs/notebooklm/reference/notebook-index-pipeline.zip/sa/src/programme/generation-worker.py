"""Bounded, resumable execution of all commissioned SA jobs; one ledger writer.

The MCP batch tool cannot express per-job source sets/prompts or native Long.
Reuse its installed NotebookLM client for this durable queue, with the same
validated settings. Root reviews outputs separately; this worker never approves
quality, publishes media, deletes provider records or retries uncertain jobs.
"""
import argparse
import asyncio
import concurrent.futures
import importlib.util
import json
import logging
import os
import subprocess
import sys
import time
from pathlib import Path
from functools import wraps
from datetime import datetime, timezone
from notebooklm_tools.core import constants
from notebooklm_tools.mcp.tools._utils import get_client as sdk_get_client

logging.disable(logging.CRITICAL)
ROOT = Path(__file__).resolve().parents[2]
NATIVE = ROOT / 'src/programme/generation-native.py'
spec = importlib.util.spec_from_file_location('generation_native', NATIVE)
native = importlib.util.module_from_spec(spec)
sys.dont_write_bytecode = True
spec.loader.exec_module(native)
FILES = sorted((ROOT / 'docs/generation').glob('*.json'))
EXT = native.EXT
WORK = ROOT / '.local/artefact-generation'

def get_client():
    client = sdk_get_client()
    if not getattr(client, '_sa_inventory_timeout', False):
        original = client._call_rpc
        @wraps(original)
        def rpc(rpc_id, params, path='/', timeout=None, *args, **kwargs):
            # A 1,123-record inventory took 32s, exceeding the SDK default.
            # Extend reads only; preserve mutation timeouts and retry fences.
            if rpc_id == client.RPC_POLL_STUDIO and timeout is None:
                timeout = 90.0
            return original(rpc_id, params, path, timeout, *args, **kwargs)
        client._call_rpc = rpc
        client._sa_inventory_timeout = True
    return client

def module(name):
    spec = importlib.util.spec_from_file_location(name.replace('-', '_'), ROOT / 'src/programme' / (name + '.py'))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def event(**fields):
    print(json.dumps(fields), flush=True)

def node(command, run, job, value=None):
    args = ['node', 'src/programme/generation-state.mjs', command, run['sectionId'], job['key']]
    if value is not None:
        args.append(value)
    return json.loads(subprocess.check_output(args, cwd=ROOT))

def create(client, settings):
    common = {'source_ids': settings['source_ids'], 'language': settings['language'], 'focus_prompt': settings['focus_prompt']}
    notebook = settings['notebook_id']
    kind = settings['artifact_type']
    if kind == 'audio':
        return native.create_once(client, client.create_audio_overview, notebook, **common, format_code=constants.AUDIO_FORMATS.get_code(settings['audio_format']), length_code=constants.AUDIO_LENGTHS.get_code(settings['audio_length']))
    if kind == 'video':
        return native.create_once(client, client.create_video_overview, notebook, **common, format_code=constants.VIDEO_FORMATS.get_code(settings['video_format']), visual_style_code=constants.VIDEO_STYLES.get_code(settings['visual_style']))
    if kind == 'infographic':
        return native.create_once(client, client.create_infographic, notebook, **common, orientation_code=constants.INFOGRAPHIC_ORIENTATIONS.get_code(settings['orientation']), detail_level_code=constants.INFOGRAPHIC_DETAILS.get_code(settings['detail_level']), visual_style_code=constants.INFOGRAPHIC_STYLES.get_code(settings['infographic_style']))
    raise ValueError('Long decks use the existing native adapter')

def download_original(client, run, job, path):
    row = client.get_artifact(run['notebookId'], job['id'])
    if not row or row[0] != job['id']:
        raise RuntimeError('Requested provider artefact is missing or mismatched')
    native.settings_proof(run, job, row)
    snapshot = native.studio_snapshot(client, run['notebookId'], [row], refresh=True)
    return getattr(snapshot, 'download_' + job['type'])(run['notebookId'], path, artifact_id=job['id'])

async def downloads(client, runs, concurrency=16, refresh_runs=None):
    assert type(concurrency) is int and 1 <= concurrency <= 32, 'Download concurrency must be an integer between 1 and 32'
    assert refresh_runs is None or callable(refresh_runs), 'Fresh runs must come from the existing ledger reader'
    semaphore = asyncio.Semaphore(concurrency)
    loop = asyncio.get_running_loop()
    originals = WORK / 'originals'
    originals.mkdir(parents=True, exist_ok=True)
    async def one(run, job):
        target = originals / (job['key'] + '.' + EXT[job['type']])
        if target.exists():
            return
        async with semaphore:
            pending = target.with_name(job['key'] + '.part.' + EXT[job['type']])
            try:
                # SDK async methods begin with a synchronous RPC. Its compatibility
                # wrappers own separate loops, so that RPC cannot starve other streams.
                await loop.run_in_executor(pool, download_original, client, run, job, str(pending))
                assert pending.is_file() and pending.stat().st_size > 0
                pending.replace(target)
                event(downloaded=job['key'], id=job['id'])
            except Exception as error:
                # Never leave a partial file looking like a finished original.
                if pending.exists():
                    pending.unlink()
                fields = {'downloadFailed': job['key'], 'errorType': type(error).__name__}
                cause = error.__cause__ or error.__context__
                if cause is not None:
                    fields['causeType'] = type(cause).__name__
                    status = getattr(getattr(cause, 'response', None), 'status_code', None)
                    if type(status) is int and 100 <= status <= 599:
                        fields['httpStatus'] = status
                event(**fields)
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:
        seen, pending = set(), set()
        def admit(rows):
            for run in rows:
                for job in run['jobs']:
                    identity = (run['notebookId'], job.get('id'))
                    if (job['status'] != 'completed' or not job.get('id') or identity in seen
                            or not job.get('providerProof', {}).get('settingsVerified')
                            or (originals / (job['key'] + '.' + EXT[job['type']])).exists()):
                        continue
                    seen.add(identity)
                    pending.add(asyncio.create_task(one(run, job)))
        admit(runs)
        while pending:
            done, pending = await asyncio.wait(pending, timeout=30, return_when=asyncio.FIRST_COMPLETED)
            for task in done: task.result()
            if refresh_runs is not None: admit(refresh_runs())

def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds', type=int, default=900)
    parser.add_argument('--download-concurrency', type=int, default=16)
    parser.add_argument('--skip-downloads', action='store_true',
                        help='Leave originals to the separate transfer owner; retain sole ledger ownership')
    parser.add_argument('--persistent', action='store_true', help='Continue quota-aware generation under the OS stage supervisor')
    parser.add_argument('--control-config', type=Path)
    args = parser.parse_args(argv)
    assert 60 <= args.seconds <= 1800
    assert 1 <= args.download_concurrency <= 32
    if args.persistent:
        assert args.skip_downloads and args.control_config, 'Persistent generation requires transfer separation and a control config'
        args.control_config = args.control_config.resolve()
        assert args.control_config.is_relative_to(WORK.resolve()) and args.control_config.suffix == '.json', 'Control config must stay inside project runtime custody'
    else:
        assert args.control_config is None, 'Control config requires persistent mode'
    return args

def ledger_file(run):
    return next(file for file in FILES if file.stem == run['sectionId'])

def persistent_submit(client, run, job, state, state_file, quota, cfg, meter, probe=False, ownership=None):
    kind = job['type']
    file = ledger_file(run)
    if ownership and not ownership.supervisor_alive():
        return False
    if kind == 'slide_deck':
        fresh = json.loads(file.read_text())
        fresh['nativeLongReference'] = native.long_reference()
        native.save(file, fresh)
    if probe:
        state['lastProbeKind'] = kind
        state['probes'][kind] = {'sectionId': run['sectionId'], 'key': job['key'], 'phase': 'selected', 'selectedAt': native.NOW()}
        quota.atomic_json(state_file, state)
    settings = node('job-intent', run, job)
    native.durable_file(file)
    fresh = json.loads(file.read_text())
    intended = next(j for j in fresh['jobs'] if j['key'] == job['key'])
    if probe:
        state['probes'][kind].update(attemptedAt=intended['attemptedAt'], phase='intent')
        quota.atomic_json(state_file, state)
    if ownership and not ownership.supervisor_alive():
        # The call has not been issued: retain that local abort evidence and
        # return this exact job to planned without inventing a provider failure.
        intended.update(status='planned', submissionAbortedAt=native.NOW(), submissionAbortReason='supervisor-unavailable-before-create')
        native.save(file, fresh)
        if probe:
            state['probes'][kind]['phase'] = 'not-sent'
            quota.atomic_json(state_file, state)
        return False
    try:
        made = native.create_long(client, settings) if kind == 'slide_deck' else create(client, settings)
        assert made and made.get('artifact_id'), 'Unacknowledged provider result'
    except Exception as error:
        node('job-uncertain', run, job, type(error).__name__)
        fresh = json.loads(file.read_text())
        next(j for j in fresh['jobs'] if j['key'] == job['key'])['errorAt'] = native.NOW()
        native.save(file, fresh)
        if type(error).__name__ == 'ResourceExhaustedError':
            checked = native.NOW()
            for target in FILES:
                fresh = json.loads(target.read_text())
                fresh.setdefault('providerLimits', {})[kind] = {'errorType': type(error).__name__, 'checkedAt': checked}
                native.save(target, fresh)
            runs = [json.loads(target.read_text()) for target in FILES]
            now = datetime.now(timezone.utc)
            quota.sync_limits(state, runs, meter, cfg, now)
            quota.failed_probe(state, kind, now, meter, cfg)
        if probe:
            state['probes'][kind].update(phase='uncertain', errorType=type(error).__name__)
        quota.atomic_json(state_file, state)
        event(stopped=job['key'], errorType=type(error).__name__, quotaProbe=probe)
        return False
    # A failed acknowledgement checkpoint terminates this process. Startup census
    # reconciles the intent before anything can submit that job again.
    node('job-ack', run, job, made['artifact_id'])
    native.durable_file(file)
    if probe:
        state['probes'][kind].update(phase='awaiting-proof', id=made['artifact_id'])
        quota.atomic_json(state_file, state)
    event(submitted=job['key'], id=made['artifact_id'], quotaProbe=probe)
    return True

def persistent_cycle(client, state, state_file, quota, owner, control_file):
    cfg = quota.config(control_file)
    if not owner.supervisor_alive():
        return {'phase': 'held', 'reason': 'supervisor-unavailable'}
    if cfg['desiredState'] != 'run':
        return {'phase': 'held', 'desiredState': cfg['desiredState']}
    checked_after = native.NOW()
    # Ordinary reconciliation never replaces an identity or its original.
    # Reserve custody exclusion for actual recovery; network polling otherwise
    # repeatedly starves downloads of the shared snapshot lock.
    snapshots = [json.loads(file.read_text()) for file in FILES]
    needs_recovery = any(native.retryable_failure(job) or job['status'] in ('submitting', 'needs-reconciliation')
                         for run in snapshots for job in run['jobs'])
    barrier = owner.StageLock('custody-snapshot')
    if not needs_recovery or not owner.transfer_recovery_allowed():
        census = native.reconcile(client, FILES)
    else:
        try:
            barrier.__enter__()
        except (BlockingIOError, RuntimeError):
            census = native.reconcile(client, FILES)
        else:
            try:
                allowed = owner.transfer_recovery_allowed()
                census = native.reconcile(client, FILES, associate=allowed, recover=allowed)
            finally:
                barrier.__exit__(None, None, None)
    runs = [json.loads(file.read_text()) for file in FILES]
    now = datetime.now(timezone.utc)
    meter = None
    try:
        meter = quota.read_meter(client, now)
        state['meter'] = meter
    except Exception as error:
        state['meterError'] = {'errorType': type(error).__name__, 'checkedAt': quota.iso(now)}
        event(quotaReadFailed=type(error).__name__)
    recovery = globals().get('recover_stalled')
    if recovery:
        recovery(client, runs, meter, cfg, now)
        runs = [json.loads(file.read_text()) for file in FILES]
    # Only a real returned acknowledgement plus a new exact provider proof
    # clears a limit. Temporal policy association never supplies that evidence.
    for kind, evidence in quota.accepted_probes(state, runs, checked_after):
        state['probes'][kind].update(phase='accepted', evidence=evidence)
        quota.atomic_json(state_file, state)
        for run in runs:
            limit = run.get('providerLimits', {}).get(kind)
            if limit and quota.timestamp(limit['checkedAt']) < quota.timestamp(evidence['acknowledgedAt']):
                del run['providerLimits'][kind]
                native.save(ledger_file(run), run)
        state.setdefault('lastAcceptedProbe', {})[kind] = evidence
        del state['probes'][kind]
    quota.sync_limits(state, runs, meter, cfg, now)
    external = census['unownedActiveByMedium']
    active = native.capacity_counts(runs, census)
    uncertain = native.uncertain_kinds(runs)
    decision = quota.eligibility(state, runs, meter, cfg, now, active, uncertain)
    quota.atomic_json(state_file, state)
    submitted = 0
    queues = {kind: iter(native.pending_jobs(runs, kind)) for kind in
              decision['normalKinds'] + ([decision['probeKind']] if decision['probeKind'] else [])}
    blocked_actions = set()
    while queues:
        for kind in list(queues):
            probe = kind == decision['probeKind'] or kind in state['limits']
            if not quota.capacity_available(active, kind) or quota.config(control_file)['desiredState'] != 'run' or not owner.supervisor_alive():
                del queues[kind]
                continue
            candidate = next(((run, job) for run, job in queues[kind]
                              if quota.available(meter, job) and quota.action(job) not in blocked_actions), None)
            if candidate is None:
                del queues[kind]
                continue
            run, job = candidate
            if not persistent_submit(client, run, job, state, state_file, quota, cfg, meter, probe, ownership=owner):
                if kind in state['limits']:
                    # A rejected explainer must not hide an available cinematic
                    # action. At most one failed create per action in this cycle.
                    blocked_actions.add(quota.action(job))
                if not owner.supervisor_alive():
                    queues.clear()
                    break
                continue  # A quarantined uncertain job must not stop independent planned jobs.
            active[kind] += 1
            submitted += 1
            if probe:
                del queues[kind]  # One acknowledged probe still needs exact proof.
    runs = [json.loads(file.read_text()) for file in FILES]
    counts = {}
    for run in runs:
        for job in run['jobs']:
            counts[job['status']] = counts.get(job['status'], 0) + 1
    complete = all(j['status'] == 'completed' and j.get('id') and j.get('providerProof', {}).get('settingsVerified') for r in runs for j in r['jobs'])
    retries = [{'key': job['key'], 'retryAt': deadline.isoformat()}
               for run in runs for job in run['jobs']
               if (deadline := native.failure_retry_at(job)) is not None]
    decision['failureRetries'] = retries
    if retries and not submitted and not any(native.active_counts(runs).values()):
        if not any(next(native.pending_jobs(runs, kind), None) for kind in native.EXT):
            decision.update(phase='failure_retry_wait', nextRetryAt=min(row['retryAt'] for row in retries))
    return {**decision, 'phase': 'complete' if complete else decision['phase'], 'counts': counts, 'activeByMedium': native.active_counts(runs), 'retiredOrUnownedActiveByMedium': external, 'submittedThisCycle': submitted, 'quota': meter, 'limits': state['limits'], 'qualityAndPublicationComplete': False}

def validate_frozen_runs(runs):
    """Accept a fresh committed freeze, never a mixed or obsolete hard-coded pin."""
    assert len(runs) == 10 and sum(r['requested'] for r in runs) == 3060 and sum(len(r['subjects']) for r in runs) == 90
    commits = {r['sourceCommit'] for r in runs}
    assert len(commits) == 1 and len(next(iter(commits))) == 40, 'Mixed source freeze'
    native.reject_retired_freeze(runs)
    script = """
import {load,frozenBrief,verifyFacts} from './src/programme/generation-state.mjs';
import fs from 'node:fs';
const programme=JSON.parse(fs.readFileSync('config/programme.json'));
for(const section of programme.sections){
  const {run}=load(section.id);
  for(const subject of run.subjects){
    frozenBrief(run,subject.id);verifyFacts(run,subject);
    if(subject.editorialSync?.status!=='indexed-verified')throw Error('Unsynced editorial '+subject.id);
  }
}
"""
    subprocess.run(['node', '--input-type=module', '-e', script], cwd=ROOT, check=True)

def cycle_delay(result, cfg, now):
    if result.get('submittedThisCycle', 0) and result['phase'] == 'runnable':
        return 0  # Prove an acknowledged probe and refill without an idle interval.
    due = [datetime.fromisoformat(result[key].replace('Z', '+00:00')) for key in
           ('nextProbeAt', 'nextRetryAt') if result.get(key)]
    return min([cfg['reconcileSeconds']] + [(stamp - now).total_seconds() for stamp in due if stamp > now])

def persistent_main(args):
    quota = module('generation-quota')
    owner = module('generation-ownership')
    state_file = WORK / 'generation-control-state.json'
    with owner.StageLock('generation', WORK / 'worker.lock'):
        runs = [json.loads(file.read_text()) for file in FILES]
        validate_frozen_runs(runs)
        state = quota.load_state(state_file)
        client = None
        while True:
            if not owner.supervisor_alive():
                owner.write_stage_status('generation', 'held', reason='supervisor-unavailable')
                return
            try:
                if client is None:
                    client = get_client()
                result = persistent_cycle(client, state, state_file, quota, owner, args.control_config)
            except Exception as error:
                failure = owner.safe_error(error)
                owner.write_stage_status('generation', 'auth_wait' if failure.get('reason') == 'notebook-auth-expired' else 'retry',
                    lastError=failure, desiredState=quota.config(args.control_config)['desiredState'])
                event(**failure)
                # Return to the supervisor after a bounded wait: a fresh process
                # reloads repaired credentials rather than retaining an SDK client.
                time.sleep(60)
                return
            owner.write_stage_status('generation', result['phase'], lastError=None, desiredState=quota.config(args.control_config)['desiredState'], **{k: v for k, v in result.items() if k not in ('phase', 'desiredState')})
            event(**result)
            if result['phase'] in ('held', 'complete'):
                return
            time.sleep(cycle_delay(result, quota.config(args.control_config), datetime.now(timezone.utc)))

def main():
    args = parse_args()
    WORK.mkdir(parents=True, exist_ok=True)
    if getattr(args, 'persistent', False):
        return persistent_main(args)
    lock = WORK / 'worker.lock'
    descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.write(descriptor, str(os.getpid()).encode())
    os.close(descriptor)
    try:
        native.reject_retired_freeze([json.loads(file.read_text()) for file in FILES])
        client = get_client()
        end = time.monotonic() + args.seconds
        while time.monotonic() < end:
            census = native.reconcile(client, FILES)
            runs = [json.loads(f.read_text()) for f in FILES]
            assert sum(r['requested'] for r in runs) == 3060
            if not args.skip_downloads:
                asyncio.run(downloads(client, runs, concurrency=args.download_concurrency))
            limits = {kind for r in runs for kind in r.get('providerLimits', {})}
            uncertain = native.uncertain_kinds(runs)
            limits.update(uncertain)
            inflight = native.capacity_counts(runs, census)
            long_slots = 4 - inflight['slide_deck']
            if long_slots > 0 and 'slide_deck' not in limits:
                subprocess.run([sys.executable, str(NATIVE), 'long', '--limit', str(long_slots)], cwd=ROOT, check=True)
            submitted = 0
            for kind in EXT:
                if kind == 'slide_deck' or kind in limits:
                    continue
                for run, job in native.pending_jobs(runs, kind):
                    if inflight[kind] >= 4:
                        break
                    settings = node('job-intent', run, job)
                    try:
                        made = create(client, settings)
                        assert made and made.get('artifact_id'), 'Unacknowledged provider result'
                        node('job-ack', run, job, made['artifact_id'])
                        inflight[kind] += 1
                        submitted += 1
                        event(submitted=job['key'], id=made['artifact_id'])
                    except Exception as error:
                        node('job-uncertain', run, job, type(error).__name__)
                        fresh = json.loads((ROOT / 'docs/generation' / (run['sectionId'] + '.json')).read_text())
                        next(item for item in fresh['jobs'] if item['key'] == job['key'])['errorAt'] = native.NOW()
                        native.save(ROOT / 'docs/generation' / (run['sectionId'] + '.json'), fresh)
                        if type(error).__name__ == 'ResourceExhaustedError':
                            for target in FILES:
                                fresh = json.loads(target.read_text())
                                fresh.setdefault('providerLimits', {})[kind] = {'errorType': type(error).__name__, 'checkedAt': native.NOW()}
                                native.save(target, fresh)
                        event(stopped=job['key'], errorType=type(error).__name__)
                        limits.add(kind)
                        break
            event(queued=3060, submittedThisCycle=submitted, active=inflight)
            if all(j['status'] == 'completed' for r in runs for j in r['jobs']):
                event(generationComplete=True, qualityAndPublicationComplete=False)
                return
            time.sleep(min(30, max(0, end - time.monotonic())))
        event(stopped='Finite worker budget reached; all provider identities remain in section ledgers')
    finally:
        lock.unlink()

if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        event(errorType=type(error).__name__)
        raise SystemExit(1)
