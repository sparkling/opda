/** Derived subsection ADRs share one reviewed data owner; the site reads them in its dialog. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { validateSources } from './validate.mjs';
import { readNotebookEvidence } from '../corpus/notebook.mjs';
const root = fileURLToPath(new URL('../../', import.meta.url));
const read = file => JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
const programme = read('config/programme.json');
const { bundles, uploads: publication } = await readNotebookEvidence(root);
const escapeCell = value => String(value ?? 'Not recorded').replaceAll('|', '\\|').replaceAll('\n', ' ');
const write = (file, text) => { const target = path.join(root, file); fs.mkdirSync(path.dirname(target), {recursive:true}); fs.writeFileSync(target, text); };
// The site no longer publishes raw ADR or JSON downloads; remove earlier generated copies.
for (const dir of ['site/public/decisions', 'site/public/authoring']) fs.rmSync(path.join(root, dir), {recursive:true, force:true});
let number = 9;
const index = ['# Subsection authoring decisions', '', 'All 90 records follow the complete-architecture authoring rule governed by [ADR-008](ADR-008-presentation-index-and-subsection-authoring.md). Generation is commissioned separately by [ADR-099](ADR-099-full-artefact-generation-and-publication.md); completion is tracked in docs/generation.', ''];
for (const section of programme.sections) {
  index.push(`## ${section.name}`, '', '| Decision | Subsection |', '|---|---|');
  const data = read(`config/authoring/${section.id}.json`);
  if (data.sectionId !== section.id || data.subjects.length !== section.chapters.length) throw Error(`Subject count: ${section.id}`);
  for (const [i, brief] of data.subjects.entries()) {
    if (brief.id !== `${section.id}-${i+1}` || brief.adrNumber !== number++ || brief.title !== section.chapters[i][0]) throw Error(`Identity mismatch: ${brief.id}`);
    if (!brief.sources.length || !brief.basePrompt || !brief.editorialNote) throw Error(`Incomplete brief: ${brief.id}`);
    for (const medium of ['deck','video','audio','infographic']) if (!brief.mediaPrompts[medium]) throw Error(`Missing ${medium} prompt: ${brief.id}`);
    validateSources(root, brief, bundles, publication);
    const id = `ADR-${String(brief.adrNumber).padStart(3,'0')}`;
    const file = `${id}-${brief.id}.md`;
    index.push(`| [${id}](${file}) | ${escapeCell(brief.title)} |`);
    const sourceLabel = s => s.title ?? path.basename(s.upstreamPath ?? s.path);
    const sources = brief.sources.map(s => `| ${[s.role,s.url ? `[${sourceLabel(s)}](${s.url})` : `${sourceLabel(s)} (retained locally; remote body unavailable or not applicable)`,s.status,s.admission,s.notebookSourceId ?? 'Not active',s.rationale].map(escapeCell).join(' | ')} |`).join('\n');
    const inputScope = brief.factualInput?.state === 'indexed-verified' ? `${brief.sources.filter(s => s.admission === 'admitted').length} exact reviewed bodies are activated through this subsection's verified factual NotebookLM source IDs: ${brief.factualSourceIds.map(id => '`' + id + '`').join(', ')}. Bundle membership matches the approved file/SHA selection, and indexed read-back verifies its document/excerpt markers and provenance. Reference-only and pending records are excluded from this input. A source-set change requires a new admission review, bundle verification and indexed read-back. Architectural authority and benchmark scope remain attached to the selected sources.` : 'Before generation, isolate the approved factual bodies and verify the actual admitted input scope for both conditions; prompt exclusions and factualSourceIds do not prove isolation. Recorded mixed-bundle scope gaps remain generation blockers under ADR-008.';
    const text = `# ${id}: ${section.name} — ${brief.title}\n\n- **Status:** Accepted — owner-directed authoring contract; corrected source admission and replacement generation tracked separately.\n- **Date:** 2026-09-29\n- **Updated:** 2026-10-01 — ADR-008 requires every presentation to describe the complete planned architecture as working, in the present tense, without implementation-status narration. Earlier reviews remain historical; the current correction and replacement follow ADR-099.\n- **Section / subsection:** ${section.name} / ${brief.id}\n- **Audience:** Solution architects, agentic engineers and technical leads.\n- **Depends on:** ADR-006, ADR-007, ADR-008, ADR-099.\n- **Canonical authoring record:** config/authoring/${section.id}.json, subject ${brief.id}.\n\n## Context and learning outcome\n\n${brief.question}\n\n${brief.learningOutcome}\n\n## Selected factual sources\n\n| Role | Exact source | Upstream status | Admission | NotebookLM source ID | Why selected |\n|---|---|---|---|---|---|\n${sources}\n\n### Provenance\n\n${brief.sources.map(s=>`- \`${s.path}\` — ${s.repository}; revision \`${s.revision ?? (s.derivedFrom ? 'verbatim derivative of ' + s.derivedFrom.revision : 'working-tree evidence; see custody')}\`.`).join('\n')}\n\n### Source gaps and exclusions\n\n${[...brief.sourceGaps,...brief.excludedSources].map(s=>`- ${s}`).join('\n') || 'No additional source exclusions identified.'}\n\n## Decision: generation contract\n\nDescribe the architecture in the present tense as fully built and working. This premise is implicit; do not state it in the artefact. Exclude current delivery progress, built-versus-planned comparisons and implementation disclaimers. Preserve architectural constraints, domain boundaries and measurement scope.\n\n${programme.editorialConditions}\n\nA URL is not a NotebookLM source ID. NotebookLM IDs activate whole bundles, not individual selected files. ${inputScope}\n\nReuse ADR-008 settings: Detailed Deck and Presenter Slides (Long, landscape), Explainer and Cinematic video, Deep Dive/Brief/Debate audio (Default length), and ten Detailed landscape Auto-style infographics per condition. British English throughout. Total: 4 decks + 4 videos + 6 audio + 20 infographics = 34. Generation is authorised separately by ADR-099. The frozen input commit, verified factual and editorial IDs, provider identities and completion state are recorded in docs/generation/${section.id}.json; commissioning is not proof of generated or published outputs.\n\n## Base prompt\n\n${brief.basePrompt}\n\n## Medium prompts\n\n${Object.entries(brief.mediaPrompts).map(([k,v])=>`### ${k}\n\n${v}`).join('\n\n')}\n\n## Editorial note — version ${brief.editorialVersion ?? 1}\n\n${brief.editorialNote.replace(/^# /gm, "### ").replace(/^## /gm, "#### ")}\n\n## Acceptance evidence\n\n${brief.acceptanceChecks.map(s=>`- ${s}`).join('\n')}\n\n## Consequences\n\nThis brief preserves application ownership, source provenance and consistent factual inputs across both editorial conditions. The shared programme retains two navigation levels.\n`;
    write(`docs/adr/${file}`,text);
  }
  index.push('');
}
write('docs/adr/subsections.md', index.join('\n'));
// The programme hierarchy has the same data owner as the live section pages.
const planFile = 'docs/adr/ADR-006-solution-architecture-presentation-plan.md';
const plan = fs.readFileSync(path.join(root, planFile), 'utf8');
const hierarchy = ['## Programme hierarchy', '',
  'The ten sections and ninety subsections below derive from `config/programme.json`.',
  'Every presentation describes its architecture as built and working, with that premise implicit.', '',
  ...programme.sections.flatMap((section, i) => [
    `### ${i + 1}. ${section.name}`, '', section.purpose, '',
    `Audience output: ${section.audienceOutput}`, '',
    '| Subsection | Architectural question | Scope |', '|---|---|---|',
    ...section.chapters.map(chapter => `| ${chapter.slice(0, 3).map(escapeCell).join(' | ')} |`), '',
  ])].join('\n');
const updatedPlan = plan.replace(/## (?:Historical hierarchy review — 29 September 2026|Programme hierarchy)[\s\S]*?(?=## Audience success and decision architecture)/, hierarchy + '\n');
if (!updatedPlan.includes(hierarchy)) throw Error('Missing programme hierarchy boundary');
write(planFile, updatedPlan);
if (number !== 99) throw Error(`Expected90 briefs, got ${number-9}`);
console.log('Rendered 90 subsection ADRs.');
