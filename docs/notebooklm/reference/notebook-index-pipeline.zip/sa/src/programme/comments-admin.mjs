// Native Artalk dashboard, authenticated by the existing website's immutable subject.
// JWT format follows Artalk server/common/auth.go; bearer credentials never reach the browser.
import {createHmac, randomBytes} from 'node:crypto';
import {commentOrigins} from './comments-location.mjs';
const encode=value=>Buffer.from(JSON.stringify(value)).toString('base64url');
export function createAdminHandler({config, origin='http://127.0.0.1:23366', siteOrigin=commentOrigins[0], fetcher=fetch}) {
  if(!commentOrigins.includes(siteOrigin))throw Error('Invalid administrator site origin');
  if(!Array.isArray(config.subjects)||!config.subjects.length||config.subjects.some(s=>!/^[\w-]{1,128}$/.test(s))
    ||!Number.isSafeInteger(config.userId)||config.userId<1||typeof config.appKey!=='string'||config.appKey.length<16
    ||typeof config.name!=='string'||typeof config.email!=='string') throw Error('Invalid admin configuration');
  const isAllowed=subject=>config.subjects.includes(subject);
  async function handle(req,res,subject) {
    const send=(code,message)=>{res.writeHead(code,{'content-type':'text/plain','cache-control':'no-store'});res.end(message);};
    if(!isAllowed(subject)) return send(403,'Administrator access required.');
    if(req.headers['sec-fetch-site']==='cross-site') return send(403,'Same-origin request required');
    const url=new URL(req.url,siteOrigin);
    const path=url.pathname.slice('/admin'.length);
    if(!path.startsWith('/sidebar/')&&!path.startsWith('/api/v2/')) return send(404,'Not found');
    if(path.startsWith('/api/v2/auth/')||path==='/api/v2/user/access_token') return send(404,'Use the website login.');
    if(!['GET','HEAD','POST','PUT','PATCH','DELETE'].includes(req.method)) return send(405,'Method not allowed');
    if(!['GET','HEAD'].includes(req.method) && (req.headers.origin!==siteOrigin
      ||(req.headers['sec-fetch-site']&&req.headers['sec-fetch-site']!=='same-origin'))) return send(403,'Same-origin request required');
    try {
      let body;
      if(!['GET','HEAD'].includes(req.method)) {
        const chunks=[];let size=0;
        for await(const chunk of req) {size+=chunk.length;if(size>8*1024*1024)return send(413,'Request too large');chunks.push(chunk);}
        body=Buffer.concat(chunks);
        const type=req.headers['content-type']||'';
        if(type.startsWith('application/json')&&body.length) {
          const parsed=JSON.parse(body);if(parsed && typeof parsed==='object') delete parsed.token;
          body=Buffer.from(JSON.stringify(parsed));
        } else if(type.startsWith('application/x-www-form-urlencoded')) {
          const parsed=new URLSearchParams(body.toString());parsed.delete('token');body=Buffer.from(parsed.toString());
        } else if(body.length && !type.startsWith('multipart/form-data')) return send(415,'Unsupported content type');
      }
      url.searchParams.delete('token');
      const now=Math.floor(Date.now()/1000);
      const signed=encode({alg:'HS256',typ:'JWT'})+'.'+encode({user_id:config.userId,iat:now,exp:now+30});
      const token=signed+'.'+createHmac('sha256',config.appKey).update(signed).digest('base64url');
      const response=await fetcher(origin+path+url.search,{method:req.method,redirect:'manual',signal:AbortSignal.timeout(15000),
        headers:{authorization:`Bearer ${token}`,accept:req.headers.accept||'*/*',
          ...(req.headers['content-type']?{'content-type':req.headers['content-type']}:{})},...(body?{body}:{})});
      if(response.status>=300&&response.status<400) return send(502,'Unexpected upstream redirect');
      const chunks=[];let length=0;
      if(response.body) {
        const reader=response.body.getReader();
        try {while(true){const part=await reader.read();if(part.done)break;length+=part.value.length;
          if(length>16*1024*1024)throw Error('Response too large');chunks.push(Buffer.from(part.value));}}
        finally {await reader.cancel();}
      }
      let output=Buffer.concat(chunks);const type=response.headers.get('content-type')||'application/octet-stream';
      const nonce=randomBytes(18).toString('base64');
      if(path==='/sidebar/'&&type.includes('text/html')) {
        const user=JSON.stringify({name:config.name,email:config.email,token:'website-session',is_admin:true})
          .replace(/</g,'\\u003c');
        output=Buffer.from(output.toString().replace('<head>',`<head><script nonce="${nonce}">localStorage.setItem('ArtalkUser',JSON.stringify(${user}));</script>`));
      }
      res.writeHead(response.status,{'content-type':type,'cache-control':'private, no-store',
        'x-content-type-options':'nosniff','referrer-policy':'same-origin',
        'content-security-policy':`default-src 'self'; script-src 'self' 'nonce-${nonce}'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self' data:; base-uri 'none'; frame-ancestors 'self'; form-action 'self'`});
      res.end(output);
    } catch {return send(502,'Artalk administration is temporarily unavailable.');}
  }
  return {isAllowed,handle};
}
