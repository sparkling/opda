"""Native read-back and Long decks for gaps in the installed Studio MCP wrapper.

Reuse the approved EA native Long proof and client. Never persist signed URLs.
Run serially with ledger mutations; downloads use their own later custody step.
"""
import argparse
import copy
import hashlib
import inspect
import importlib.util
import json
import logging
import os
import subprocess
from datetime import datetime, timezone, timedelta
from pathlib import Path
from notebooklm_tools.core import base as sdk_base, constants
from notebooklm_tools.mcp.tools._utils import get_client

logging.disable(logging.CRITICAL)
ROOT = Path(__file__).resolve().parents[2]
DIRECTORY = ROOT / 'docs/generation'
NOW = lambda: datetime.now(timezone.utc).isoformat()
HASH = lambda text: hashlib.sha256(text.encode()).hexdigest()
EXT = {'audio': 'm4a', 'video': 'mp4', 'infographic': 'png', 'slide_deck': 'pdf'}
TERMINAL = {'completed', 'failed'}

def provider_status(client, row):
    status = client._normalize_studio_status(row)
    # Backend enum, independently live-verified upstream issue #2127. The
    # installed SDK swaps INITIALIZED and PROCESSING. Retain audio+media proof.
    if status == 'completed':
        return status
    return {1: 'pending', 2: 'in_progress', 5: 'suggested',
            6: 'pending-review', 7: 'scheduled'}.get(row[4], status)

def active_counts(runs):
    identities = {kind: set() for kind in EXT}
    for run in runs:
        for job in run['jobs']:
            if job['status'] == 'submitted' and job.get('id'):
                identities[job['type']].add(job['id'])
            for candidate in job.get('reconciliationCandidates', []):
                if candidate['status'] not in TERMINAL:
                    identities[job['type']].add(candidate['id'])
    return {kind: len(ids) for kind, ids in identities.items()}

def uncertain_kinds(runs):
    return {job['type'] for run in runs for job in run['jobs']
            if job['status'] in ('submitting', 'needs-reconciliation', 'missing-provider-record')
            or (job['status'] == 'submitted' and not job.get('id'))
            or any(c['status'] not in TERMINAL | {'pending', 'in_progress', 'submitted', 'scheduled'}
                   or c.get('verificationProblem') for c in job.get('reconciliationCandidates', []))}

def iso_nanoseconds(value):
    stamp = datetime.fromisoformat(value.replace('Z', '+00:00'))
    assert stamp.utcoffset() is not None, 'Timestamp must include a timezone'
    delta = stamp - datetime(1970, 1, 1, tzinfo=timezone.utc)
    return (delta.days * 86400 + delta.seconds) * 1000000000 + delta.microseconds * 1000

def provider_creation(row, position=15):
    stamp = row[position]
    assert isinstance(stamp, list) and len(stamp) == 2
    assert type(stamp[0]) is int and type(stamp[1]) is int and stamp[0] > 1700000000
    assert 0 <= stamp[1] < 1000000000
    return stamp

def refresh_candidates(client, run, job, by_id, used, associate=False, retired=frozenset()):
    """Preserve every identity; association is an explicit temporal policy."""
    candidates = {c['id']: dict(c) for c in job.get('reconciliationCandidates', [])}
    intent = job.get('attemptedAt')
    error_at = job.get('errorAt') or run.get('providerLimits', {}).get(job['type'], {}).get('checkedAt')
    pool = dict(by_id) if not job.get('id') else {identity: by_id.get(identity) for identity in candidates}
    pool.update({identity: by_id.get(identity) for identity in candidates})
    for identity, row in pool.items():
        if identity in retired:
            if identity in candidates:
                candidates[identity]['verificationProblem'] = 'retired-provider-identity'
            continue
        if identity in used and identity not in candidates:
            continue
        if row is None:
            candidates[identity]['status'] = 'missing-provider-record'
            candidates[identity]['verificationProblem'] = 'missing-provider-record'
            continue
        try:
            proof = settings_proof(run, job, row)
        except (AssertionError, IndexError, TypeError, StopIteration):
            if identity in candidates:
                candidates[identity].update(status=provider_status(client, row), verificationProblem='provider-proof-mismatch')
            continue
        if identity not in candidates:
            try:
                creation = provider_creation(row)
                created = creation[0] * 1000000000 + creation[1]
                if not iso_nanoseconds(intent) <= created <= iso_nanoseconds(error_at):
                    continue
            except (AssertionError, IndexError, TypeError, ValueError, AttributeError):
                pass  # Retain an exact-scope identity whose timestamp cannot be proved.
        candidate = candidates.setdefault(identity, {'id': identity, 'intentAt': intent, 'errorAt': error_at})
        candidate.setdefault('intentAt', intent)
        candidate.setdefault('errorAt', error_at)
        candidate.update(status=provider_status(client, row), providerRawStatus=row[4], providerProof=proof, checkedAt=NOW())
        candidate.pop('verificationProblem', None)
        try:
            creation = provider_creation(row)
            candidate['providerCreationTimestamp'] = creation
            created = creation[0] * 1000000000 + creation[1]
            assert iso_nanoseconds(candidate['intentAt']) <= created <= iso_nanoseconds(candidate['errorAt'])
        except (AssertionError, IndexError, TypeError, ValueError, AttributeError):
            candidate['verificationProblem'] = 'invalid-intent-timestamp-window'
    job['reconciliationCandidates'] = list(candidates.values())
    if not job.get('id') and len(candidates) > 1:
        job['reconciliationProblem'] = 'ambiguous-provider-identities'
    if job.get('id') or not associate:
        return
    current = [c for c in candidates.values() if c.get('intentAt') == intent]
    if not current or any(c.get('verificationProblem') for c in current):
        job['reconciliationProblem'] = 'unverified-provider-association'
        return
    ordered = sorted(current, key=lambda c: c['providerCreationTimestamp'])
    if len(ordered) > 1 and ordered[0]['providerCreationTimestamp'] == ordered[1]['providerCreationTimestamp']:
        job['reconciliationProblem'] = 'tied-provider-creation-timestamps'
        return
    chosen = ordered[0]
    job['id'] = chosen['id']
    job['reconciledAt'] = NOW()
    job['reconciliationAssociation'] = {'policy': 'unique-earliest-provider-creation-in-intent-window-v1',
                                      'selectedId': chosen['id'], 'intentAt': intent, 'errorAt': error_at,
                                      'providerCreationTimestamp': chosen['providerCreationTimestamp'],
                                      'candidateIds': [c['id'] for c in ordered], 'returnedAcknowledgement': False}
    job.pop('reconciliationProblem', None)
    used.add(chosen['id'])

def failure_retry_at(job):
    if job['status'] != 'failed' or not job.get('id') or len(job.get('attemptHistory', [])) < 2:
        return None
    try:
        attempted = datetime.fromisoformat(job['attemptedAt'].replace('Z', '+00:00'))
        return attempted + timedelta(hours=6) if attempted.tzinfo is not None else None
    except (KeyError, ValueError, TypeError):
        return None

def retryable_failure(job):
    if job['status'] != 'failed' or not job.get('id'):
        return False
    if len(job.get('attemptHistory', [])) < 2:
        return True
    # Persistent programmes must not deadlock after the initial retry burst.
    # Retry a proven terminal failure at most once per six hours thereafter.
    deadline = failure_retry_at(job)
    return deadline is not None and datetime.now(timezone.utc) >= deadline

def recover_failed(client, run, job, row):
    if not row or not retryable_failure(job) or row[0] != job['id'] or client._normalize_studio_status(row) != 'failed':
        return False
    settings_proof(run, job, row)
    if any(c['status'] not in TERMINAL or c.get('verificationProblem') for c in job.get('reconciliationCandidates', [])):
        return False
    history = job.get('attemptHistory', [])
    originals = ROOT / '.local/artefact-generation/originals'
    target = originals / (job['key'] + '.' + EXT[job['type']])
    assert target.parent == originals, 'Unsafe original path'
    if target.exists() or target.with_name(job['key'] + '.part.' + EXT[job['type']]).exists():
        return False
    attempt = {key: value for key, value in job.items() if key != 'attemptHistory'}
    attempt['providerFailureRecovery'] = {'preparedAt': NOW(), 'terminalStatus': 'failed',
                                         'providerCreationTimestamp': provider_creation(row),
                                         'providerStatusTimestamp': provider_creation(row, 10)}
    job['attemptHistory'] = history + [attempt]
    for field in ('providerProof', 'providerRawStatus', 'qualityReview', 'mediaReady', 'generatedTitle', 'acknowledgedAt',
                  'checkedAt', 'attemptedAt', 'errorAt', 'errorType', 'reconciledAt', 'reconciliationAssociation', 'reconciliationProblem'):
        job.pop(field, None)
    job.update(id=None, status='planned')
    return True

def create_once(client, method, *args, fenced_rpc=None, **kwargs):
    """Fence transport replay for a non-idempotent create; keep read retries."""
    rpc = client._call_rpc
    signature = inspect.signature(rpc)
    assert '_server_retry' in signature.parameters, 'SDK create retry contract changed'
    ceiling = max(sdk_base.DEFAULT_MAX_RETRIES, sdk_base._rate_limit_max_retries())
    target_rpc = client.RPC_CREATE_STUDIO if fenced_rpc is None else fenced_rpc
    def guarded(rpc_id, *parameters, **options):
        if rpc_id == target_rpc:
            call = signature.bind(rpc_id, *parameters, **options)
            call.arguments['_server_retry'] = max(ceiling, call.arguments.get('_server_retry', 0))
            return rpc(*call.args, **call.kwargs)
        return rpc(rpc_id, *parameters, **options)
    client._call_rpc = guarded
    try:
        return method(*args, **kwargs)
    finally:
        client._call_rpc = rpc

def save(file, run):
    header = {k: v for k, v in run.items() if k != 'jobs'}
    body = json.dumps(header, ensure_ascii=False)[:-1] + ',"jobs":[\n'
    body += ',\n'.join(json.dumps(j, ensure_ascii=False) for j in run['jobs']) + '\n]}\n'
    pending = file.with_suffix('.json.tmp')
    with pending.open('w') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    pending.replace(file)
    durable_file(file)

def durable_file(file):
    """Sync the existing intent owner before a non-idempotent provider call."""
    with file.open('rb') as stream:
        os.fsync(stream.fileno())
    descriptor = os.open(file.parent, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)

def pending_jobs(runs, kind, preferred_formats=()):
    """Rotate sections and least-served formats, preserving editorial job order."""
    if not runs:
        return
    latest = [(job['attemptedAt'], index) for index, run in enumerate(runs)
              for job in run['jobs'] if job['type'] == kind and job.get('attemptedAt')]
    start = (max(latest)[1] + 1) % len(runs) if latest else 0
    ordered = runs[start:] + runs[:start]
    lane = lambda job: job.get('format')
    lanes, attempted = {}, {}
    for run in ordered:
        for job in run['jobs']:
            if job['type'] != kind:
                continue
            key = lane(job)
            attempted[key] = attempted.get(key, 0) + bool(job.get('attemptedAt') or job.get('id'))
            if job['status'] == 'planned':
                lanes.setdefault(key, None)
    buckets = {key: [(run, iter([job for job in run['jobs']
                    if job['type'] == kind and job['status'] == 'planned' and lane(job) == key]))
                    for run in ordered] for key in sorted(lanes,
                        key=lambda key: (key not in preferred_formats, attempted[key]))}
    while buckets:
        for key in list(buckets):
            rows = buckets[key]
            while rows:
                run, jobs = rows.pop(0)
                job = next(jobs, None)
                if job is not None:
                    rows.append((run, jobs))
                    yield run, job
                    break
            else:
                del buckets[key]

def brief(run, job):
    record = json.loads(subprocess.check_output(['git', 'show', f"{run['sourceCommit']}:config/authoring/{run['sectionId']}.json"], cwd=ROOT))
    return next(b for b in record['subjects'] if b['id'] == job['subject'])

def expected_sources(run, job):
    subject = next(s for s in run['subjects'] if s['id'] == job['subject'])
    ids = subject['factualSourceIds'][:]
    if job['editorial']:
        assert subject.get('editorialSync', {}).get('status') == 'indexed-verified'
        ids.append(subject['editorialSourceId'])
    return sorted(ids)

def settings_proof(run, job, row):
    kind, position, inner = {'slide_deck': (8, 16, 0), 'infographic': (7, 14, 0), 'audio': (1, 6, 1), 'video': (3, 8, 2)}[job['type']]
    assert row[2] == kind and len(row) > position and row[position], 'Provider type mismatch'
    options = row[position][inner]
    prompt_index = 2 if kind == 3 else 0
    prompt = brief(run, job)['mediaPrompts'][job['medium']]
    sources = sorted(s[0][0] for s in row[3])
    assert sources == expected_sources(run, job), 'Provider source scope mismatch'
    assert HASH(options[prompt_index]) == HASH(prompt), 'Provider prompt mismatch'
    settings = job['settings']
    if kind == 8:
        assert options[2] == constants.SLIDE_DECK_FORMATS.get_code(job['format']) and options[3] == 4, 'Native Long or format mismatch'
        assert options[1] == settings['language'], 'Provider language mismatch'
    elif kind == 7:
        assert options[1] == settings['language']
        assert options[3:6] == [constants.INFOGRAPHIC_ORIENTATIONS.get_code(settings['orientation']), constants.INFOGRAPHIC_DETAILS.get_code(settings['detail_level']), constants.INFOGRAPHIC_STYLES.get_code(settings['infographic_style'])]
    elif kind == 1:
        assert options[6] == constants.AUDIO_FORMATS.get_code(job['format']) and options[1] == constants.AUDIO_LENGTHS.get_code(settings['audio_length']) and options[4] == settings['language']
    elif kind == 3:
        assert options[4] == constants.VIDEO_FORMATS.get_code(job['format']) and options[1] == settings['language']
        if job['format'] == 'explainer':
            assert options[5] == constants.VIDEO_STYLES.get_code(settings['visual_style'])
    return {'sourceIds': sources, 'promptSha256': HASH(prompt), 'settingsVerified': True, 'verifiedAt': NOW()}

def long_reference():
    pin = json.loads((ROOT / 'config/shared-renderer.json').read_text())
    reference = 'docs/programme/ea-subject-media/native-decks.json'
    body = subprocess.check_output(['git', 'show', f"{pin['revision']}:{reference}"], cwd=(ROOT / pin['checkout']).resolve())
    proof = next(r for r in json.loads(body) if r['id'] == '83d14c64-dfd9-410c-aa69-f868663c0bbe')
    assert proof['status'] == 'completed' and proof['nativeSettings']['lengthCode'] == 4, 'Native Long proof changed'
    return {'path': reference, 'revision': pin['revision'], 'sha256': hashlib.sha256(body).hexdigest(), 'artifactId': proof['id'], 'lengthCode': 4}

def create_long(client, settings):
    return create_once(client, client.create_slide_deck, settings['notebook_id'], source_ids=settings['source_ids'], format_code=constants.SLIDE_DECK_FORMATS.get_code(settings['slide_format']), length_code=4, language=settings['language'], focus_prompt=settings['focus_prompt'])

def retired_provider_ids(notebook):
    identities = set()
    for file in sorted((ROOT / '.local/artefact-generation/resets').glob('*/manifest.json')):
        receipt = json.loads(file.read_text())
        if receipt.get('schema') == 'sa-generation-retirement/v1' and receipt.get('retiredAt'):
            identities.update(row['id'] for row in receipt['providerIdentities'] if row['notebookId'] == notebook)
    return identities

def reject_retired_freeze(runs):
    commits = set()
    for file in sorted((ROOT / '.local/artefact-generation/resets').glob('*/manifest.json')):
        receipt = json.loads(file.read_text())
        if receipt.get('schema') == 'sa-generation-retirement/v1' and receipt.get('retiredAt'):
            commits.update(run['sourceCommit'] for run in receipt['runs'])
    assert not commits & {run.get('sourceCommit') for run in runs}, 'Generation contains a retired source freeze'

def owned_provider_ids(runs):
    return {identity for run in runs for job in run['jobs']
            for identity in ([job.get('id')] + [a.get('id') for a in job.get('attemptHistory', [])]
                             + [c.get('id') for c in job.get('reconciliationCandidates', [])]) if identity}

def unowned_active_counts(client, rows, owned):
    identities = {kind: set() for kind in EXT}
    kinds = {1: 'audio', 3: 'video', 7: 'infographic', 8: 'slide_deck'}
    for row in rows:
        if isinstance(row, list) and len(row) > 4 and row[0] not in owned and row[2] in kinds:
            if provider_status(client, row) not in TERMINAL:
                identities[kinds[row[2]]].add(row[0])
    return {kind: len(ids) for kind, ids in identities.items()}

def capacity_counts(runs, census):
    external = census['unownedActiveByMedium']
    return {kind: count + external[kind] for kind, count in active_counts(runs).items()}

def studio_snapshot(client, notebook, rows, refresh=False):
    """Isolate one census; let download retries request fresh media URLs."""
    snapshot = copy.copy(client)
    expected = [[2], notebook, 'NOT artifact.status = "ARTIFACT_STATUS_SUGGESTED"']
    consumed = False
    def snapshot_rpc(rpc_id, params, path='/', *args, **kwargs):
        nonlocal consumed
        if rpc_id != client.RPC_POLL_STUDIO or params != expected or path != f'/notebook/{notebook}':
            raise RuntimeError('Studio snapshot requested an unexpected RPC')
        if refresh and consumed:
            return client._call_rpc(rpc_id, params, path, *args, **kwargs)
        consumed = True
        return [rows]
    snapshot._call_rpc = snapshot_rpc
    return snapshot

def media_from_rows(client, notebook, rows):
    """Reuse the SDK parser on this census without a second inventory request."""
    return studio_snapshot(client, notebook, rows).poll_studio_status(notebook)

def reconcile(client, files, associate=False, recover=False, on_proof_mismatch=None):
    """One fresh census shared by the native CLI and sole generation writer."""
    notebook = json.loads(files[0].read_text())['notebookId']
    rows = client._list_raw(notebook)
    archive = None
    if any(job.get('providerArchive') for file in files for job in json.loads(file.read_text())['jobs']):
        spec = importlib.util.spec_from_file_location('provider_archive', ROOT / 'src/programme/generation-provider-archive.py')
        archive = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(archive)
        verified_archives = archive.custody()
    by_id = {r[0]: r for r in rows if isinstance(r, list) and len(r) > 4}
    media = {r['artifact_id']: r for r in media_from_rows(client, notebook, rows)}
    active_used = {identity for f in files for j in json.loads(f.read_text())['jobs'] for identity in ([j.get('id')] + [a.get('id') for a in j.get('attemptHistory', [])]) if identity}
    retired = retired_provider_ids(notebook)
    assert not active_used & retired, 'Active run contains a retired provider identity'
    used = active_used | retired
    counts = {}
    for file in files:
        run = json.loads(file.read_text())
        for job in run['jobs']:
            if archive and archive.validate(run, job, verified_archives, EXT):
                counts['completed'] = counts.get('completed', 0) + 1
                continue
            if job.get('reconciliationCandidates') or (not job.get('id') and job['status'] in ('submitting', 'needs-reconciliation')):
                refresh_candidates(client, run, job, by_id, used, associate, retired)
            row = by_id.get(job.get('id'))
            if row:
                try:
                    proof = settings_proof(run, job, row)
                except (AssertionError, IndexError, TypeError) as error:
                    if on_proof_mismatch is None:
                        raise
                    on_proof_mismatch(run, job, row, error)
                    counts[job['status']] = counts.get(job['status'], 0) + 1
                    continue
                job['providerProof'] = proof
                status = provider_status(client, row)
                for field, position in (('providerCreationTimestamp', 15), ('providerStatusTimestamp', 10)):
                    try: job[field] = provider_creation(row, position)
                    except (AssertionError, IndexError, TypeError, ValueError): pass
                job.setdefault('providerFirstObservedAt', NOW())
                if job.get('providerObservedState') != status:
                    job['providerStateChangedAt'] = NOW()
                if status == 'in_progress': job.setdefault('providerProcessingFirstSeenAt', NOW())
                job['providerObservedState'] = status
                if job.get('errorType') and not job.get('acknowledgedAt'):
                    job['submissionOutcome'] = 'identity-observed-after-error; kickoff not acknowledged'
                ready = bool(media.get(job['id'], {}).get(job['type'] + '_url'))
                job['status'] = 'failed' if status == 'failed' else 'completed' if status == 'completed' or ready else 'submitted'
                job['providerRawStatus'] = row[4]
                job['checkedAt'] = NOW()
                job['mediaReady'] = ready
                job['generatedTitle'] = row[1]
            elif job.get('id'):
                job['status'] = 'missing-provider-record'
            if recover and job['status'] == 'failed':
                recover_failed(client, run, job, row)
            counts[job['status']] = counts.get(job['status'], 0) + 1
        run['reconciledAt'] = NOW()
        run['providerArtifactCount'] = len(rows)
        save(file, run)
    # Retired or unacknowledged provider work still consumes capacity. It can
    # never become an active output merely because it appears in this census.
    owned = owned_provider_ids([json.loads(file.read_text()) for file in files])
    return {'counts': counts, 'providerArtifactCount': len(rows),
            'unownedActiveByMedium': unowned_active_counts(client, rows, owned)}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['long', 'reconcile'])
    parser.add_argument('--section')
    parser.add_argument('--limit', type=int, default=4)
    parser.add_argument('--associate-uncertain', action='store_true')
    parser.add_argument('--recover-failed', action='store_true')
    args = parser.parse_args()
    assert 1 <= args.limit <= 4
    if args.associate_uncertain or args.recover_failed:
        assert args.action == 'reconcile', 'Recovery flags require reconciliation'
        for owner in ('transfer.lock', 'worker.lock'):
            assert not (ROOT / '.local/artefact-generation' / owner).exists(), 'Recovery requires idle generation and transfer boundaries'
    files = sorted(DIRECTORY.glob('*.json'))
    if args.section:
        assert args.section.isalpha() and args.section.islower()
        files = [DIRECTORY / f'{args.section}.json']
    client = get_client()
    if args.action == 'long':
        # Reuse the committed native-UI read-back, without a large EA notebook fetch.
        reference = long_reference()
        runs = [json.loads(file.read_text()) for file in files]
        all_runs = [json.loads(file.read_text()) for file in sorted(DIRECTORY.glob('*.json'))]
        reject_retired_freeze(all_runs)
        blocked = any(run.get('providerLimits', {}).get('slide_deck') for run in all_runs)
        blocked |= 'slide_deck' in uncertain_kinds(all_runs)
        if blocked:
            print(json.dumps({'stoppedKind': 'slide_deck', 'reason': 'Existing uncertain submission or recorded provider limit'}), flush=True)
            return
        notebooks = {run['notebookId'] for run in all_runs}
        assert len(notebooks) == 1, 'Mixed generation notebooks'
        rows = client._list_raw(next(iter(notebooks)))
        census = {'unownedActiveByMedium': unowned_active_counts(client, rows, owned_provider_ids(all_runs))}
        active = capacity_counts(all_runs, census)['slide_deck']
        limit = min(args.limit, max(0, 4 - active))
        submitted = 0
        for run, job in pending_jobs(runs, 'slide_deck'):
            if submitted >= limit:
                break
            if run.get('providerLimits', {}).get('slide_deck'):
                continue
            file = DIRECTORY / (run['sectionId'] + '.json')
            run = json.loads(file.read_text())
            run['nativeLongReference'] = reference
            save(file, run)
            settings = json.loads(subprocess.check_output(['node', 'src/programme/generation-state.mjs', 'job-intent', run['sectionId'], job['key']], cwd=ROOT))
            run = json.loads(file.read_text())
            job = next(j for j in run['jobs'] if j['key'] == job['key'])
            durable_file(file)
            try:
                result = create_once(client, client.create_slide_deck, run['notebookId'], source_ids=settings['source_ids'], format_code=constants.SLIDE_DECK_FORMATS.get_code(job['format']), length_code=4, language=settings['language'], focus_prompt=settings['focus_prompt'])
                assert result and result.get('artifact_id'), 'No acknowledged artifact identity'
                subprocess.check_output(['node', 'src/programme/generation-state.mjs', 'job-ack', run['sectionId'], job['key'], result['artifact_id']], cwd=ROOT)
                submitted += 1
                print(json.dumps({'key': job['key'], 'id': result['artifact_id'], 'status': 'submitted', 'nativeLengthCode': 4}), flush=True)
            except Exception as error:
                run = json.loads(file.read_text())
                job = next(j for j in run['jobs'] if j['key'] == job['key'])
                job.update(status='needs-reconciliation', errorType=type(error).__name__, errorAt=NOW())
                if type(error).__name__ == 'ResourceExhaustedError':
                    run.setdefault('providerLimits', {})['slide_deck'] = {'checkedAt': NOW(), 'errorType': type(error).__name__}
                save(file, run)
                print(json.dumps({'key': job['key'], 'status': job['status'], 'errorType': type(error).__name__}), flush=True)
                return
        return
    print(json.dumps(reconcile(client, files, args.associate_uncertain, args.recover_failed)))

if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        # RPC exceptions can contain authenticated URLs; expose only the class.
        print(json.dumps({'errorType': type(error).__name__}), flush=True)
        raise SystemExit(1)
