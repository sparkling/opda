"""Release provider space only after exact original custody is proven."""
import argparse
import concurrent.futures
import contextlib
import hashlib
import importlib.util
import json
import logging
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / '.local/artefact-generation'

def module(name):
    spec = importlib.util.spec_from_file_location(name.replace('-', '_'), ROOT / 'src/programme' / (name + '.py'))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def custody():
    transfer = module('generation-transfer-worker')
    return transfer.load_verified_state(transfer.DEFAULT_RECEIPT)

def validate(run, job, verified, extensions):
    proof = job.get('providerArchive')
    if not proof:
        return False
    key = f"custody/generation/{run['notebookId']}/{job['id']}.{extensions[job['type']]}"
    if (proof.get('schema') != 'sa-provider-archive/v1' or proof.get('custodyKey') != key
            or proof.get('sha256') != verified.get(key) or not verified.get(key)
            or job['status'] != 'completed' or not job.get('mediaReady')
            or not job.get('providerProof', {}).get('settingsVerified')):
        raise RuntimeError('Provider archive lacks exact verified original custody')
    return True

def now():
    return datetime.now(timezone.utc).isoformat()

def published_originals():
    """Require actual website links, rather than trusting staged releases."""
    result = {}
    for file in (ROOT / 'docs/generation/releases').glob('*.json'):
        release = json.loads(file.read_text())
        page = subprocess.check_output(['aws', 's3', 'cp',
            f's3://hm-website-sa-841291679368/{file.stem}/index.html', '-',
            '--profile', 'claude', '--only-show-errors'], timeout=60).decode()
        for item in [*release['decks'], *release['multimedia']]:
            original = item.get('original', {})
            if original.get('path') and original['path'] in page and item['id'] in page:
                result[item['id']] = original
    return result

def archive(count):
    if type(count) is not int or not 1 <= count <= 3060:
        raise ValueError('Archive count must be between 1 and 3060')
    worker, owner, quota = module('generation-worker'), module('generation-ownership'), module('generation-quota')
    control = WORK / 'generation-control.json'
    original = json.loads(control.read_text())
    if original['desiredState'] != 'run':
        raise RuntimeError('Generation must be running before bounded archive maintenance')
    receipt_dir = WORK / 'transfers' / ('provider-archive-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    receipt_dir.mkdir(parents=True)
    quota.atomic_json(control, {**original, 'desiredState': 'hold'})
    try:
        deadline = time.monotonic() + 180
        while True:
            locks = contextlib.ExitStack()
            try:
                locks.enter_context(owner.StageLock('generation'))
                locks.enter_context(owner.StageLock('custody-snapshot'))
                break
            except BlockingIOError:
                locks.close()
                if time.monotonic() > deadline:
                    raise RuntimeError('Archive maintenance lock unavailable')
                time.sleep(.2)
        with locks:
            files = sorted((ROOT / 'docs/generation').glob('*.json'))
            runs = [json.loads(file.read_text()) for file in files]
            verified = custody()
            published = published_originals()
            objects = json.loads(subprocess.check_output(['aws', 's3api', 'list-objects-v2',
                '--bucket', 'hm-website-sa-841291679368', '--prefix', f"custody/generation/{runs[0]['notebookId']}/",
                '--profile', 'claude', '--query', 'Contents[].{key:Key,bytes:Size}', '--output', 'json'], timeout=90))
            remote_sizes = {item['key']: item['bytes'] for item in objects}
            eligible = []
            for run in runs:
                for job in run['jobs']:
                    if (job['status'] != 'completed' or not job.get('id') or job.get('providerArchive')
                            or job.get('reconciliationCandidates') or job['id'] not in published
                            or not job.get('mediaReady') or not job.get('providerProof', {}).get('settingsVerified')):
                        continue
                    key = f"custody/generation/{run['notebookId']}/{job['id']}.{worker.EXT[job['type']]}"
                    path = WORK / 'originals' / (job['key'] + '.' + worker.EXT[job['type']])
                    if (key in verified and path.is_file() and not path.is_symlink()
                            and published[job['id']].get('sha256') == verified[key]
                            and published[job['id']].get('path') == '/' + key):
                        eligible.append((run, job, key, path))
            selected = sorted(eligible, key=lambda row: (row[1].get('attemptedAt', ''), row[1]['id']))[:count]
            if len(selected) != count:
                raise RuntimeError('Insufficient published, custody-verified originals')
            def check(row):
                _, _, key, path = row
                with path.open('rb') as stream:
                    digest = hashlib.file_digest(stream, 'sha256').hexdigest()
                if digest != verified[key]:
                    raise RuntimeError('Local original differs from verified AWS original')
                if remote_sizes.get(key) != path.stat().st_size:
                    raise RuntimeError('Deployed website original is missing or differs in size')
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
                list(pool.map(check, selected))
            selected_ids = {job['id'] for _, job, _, _ in selected}
            for file, run in zip(files, runs):
                if not any(job.get('id') in selected_ids for job in run['jobs']):
                    continue
                (receipt_dir / file.name).write_bytes(file.read_bytes())
                for job in run['jobs']:
                    if job.get('id') in selected_ids:
                        key = f"custody/generation/{run['notebookId']}/{job['id']}.{worker.EXT[job['type']]}"
                        job['providerArchive'] = {'schema': 'sa-provider-archive/v1', 'custodyKey': key,
                                                  'sha256': verified[key], 'requestedAt': now()}
                        validate(run, job, verified, worker.EXT)
                worker.native.save(file, run)
            print(json.dumps({'phase': 'deleting', 'selected': count, 'receipt': str(receipt_dir.relative_to(ROOT))}), flush=True)
            def remove(row):
                run, job, key, _ = row
                try:
                    client = worker.get_client()
                    acknowledged = client.delete_studio_artifact(job['id'])
                    try:
                        raw = client.get_artifact(run['notebookId'], job['id'])
                    except Exception as error:
                        if getattr(error, 'error_code', None) != 5:
                            raise
                        raw = None
                    return {'id': job['id'], 'custodyKey': key, 'acknowledged': acknowledged, 'absent': raw is None}
                except Exception as error:
                    return {'id': job['id'], **owner.safe_error(error)}
            results = []
            with (receipt_dir / 'deletions.jsonl').open('w') as stream, concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
                for result in pool.map(remove, selected):
                    result['checkedAt'] = now()
                    stream.write(json.dumps(result) + '\n')
                    stream.flush()
                    results.append(result)
                    if len(results) % 100 == 0:
                        print(json.dumps({'checked': len(results), 'absent': sum(r.get('absent') is True for r in results)}), flush=True)
            by_id = {result['id']: result for result in results}
            for file, run in zip(files, runs):
                changed = False
                for job in run['jobs']:
                    result = by_id.get(job.get('id'))
                    if result and result.get('absent') is True:
                        job['providerArchive']['verifiedAbsentAt'] = result['checkedAt']
                        changed = True
                if changed:
                    worker.native.save(file, run)
            print(json.dumps({'selected': count, 'verifiedAbsent': sum(r.get('absent') is True for r in results)}), flush=True)
    finally:
        quota.atomic_json(control, original)
        print('Generation control restored to run', flush=True)

if __name__ == '__main__':
    logging.disable(logging.CRITICAL)
    sys.dont_write_bytecode = True
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--count', type=int, required=True)
    archive(parser.parse_args().count)
