#!/usr/bin/env python3
"""Retire one commissioned generation without altering research sources.

Snapshot is read-only apart from its private evidence archive. Retirement moves
old active ledgers and media on the same filesystem, so reused job filenames
cannot consume old bytes. Source pointers remain active until explicit handoff.
Original custody receipts and provider records remain historical evidence.
"""
import argparse
from contextlib import ExitStack
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / '.local/artefact-generation'
EPOCHS = WORK / 'resets'
UUID = r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}'


def now():
    return datetime.now(timezone.utc).isoformat()


def module(name):
    spec = importlib.util.spec_from_file_location(name.replace('-', '_'), ROOT / 'src/programme' / (name + '.py'))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_suffix('.pending')
    with pending.open('w') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    pending.replace(path)
    sync_parent(path)


def sync_parent(path):
    descriptor = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def epoch_path(epoch):
    if not re.fullmatch(r'[a-z][a-z0-9-]{3,79}', epoch):
        raise ValueError('Invalid retirement epoch')
    return EPOCHS / epoch


def inventory(path):
    if path.is_symlink():
        raise RuntimeError('Archive scope contains a symlink')
    if not path.exists():
        return []
    files = [path] if path.is_file() else sorted(path.rglob('*'))
    rows = []
    for file in files:
        if file.is_symlink():
            raise RuntimeError('Archive scope contains a symlink')
        if file.is_file():
            stat = file.stat()
            row = {'path': str(file.relative_to(ROOT)), 'bytes': stat.st_size, 'modifiedNs': stat.st_mtime_ns}
            if file.suffix in ('.json', '.md'):
                row['sha256'] = hashlib.sha256(file.read_bytes()).hexdigest()
            rows.append(row)
    return rows


def make_plan():
    programme = json.loads((ROOT / 'config/programme.json').read_text())
    sections = [s['id'] for s in programme['sections']]
    if len(sections) != 10 or any(not re.fullmatch(r'[a-z]+', s) for s in sections):
        raise RuntimeError('Retirement requires the explicit ten-section programme')
    paths, runs, published = [], [], []
    provider = set()
    for section in sections:
        ledger = ROOT / f'docs/generation/{section}.json'
        run = json.loads(ledger.read_text())
        if run['sectionId'] != section or len(run['jobs']) != run['requested']:
            raise RuntimeError('Invalid old commissioned ledger')
        runs.append({'section': section, 'sourceCommit': run['sourceCommit'], 'notebookId': run['notebookId'],
                     'subjects': [s['id'] for s in run['subjects']], 'jobs': len(run['jobs']),
                     'statuses': {status: sum(j['status'] == status for j in run['jobs']) for status in sorted({j['status'] for j in run['jobs']})}})
        for job in run['jobs']:
            for attempt in [job, *job.get('attemptHistory', []), *job.get('reconciliationCandidates', [])]:
                if attempt.get('id'):
                    if not re.fullmatch(UUID, attempt['id']):
                        raise RuntimeError('Invalid old provider identity')
                    provider.add((run['notebookId'], attempt['id']))
        for group in ('', 'catalogues/', 'releases/'):
            paths.append(f'docs/generation/{group}{section}.json')
        release = ROOT / f'docs/generation/releases/{section}.json'
        if release.is_file():
            row = json.loads(release.read_text())
            published += [{'section': section, 'id': item['id'], 'key': item['key'], 'original': item.get('original'),
                           'retainedAttempt': item.get('retainedAttempt', False)} for item in [*row['decks'], *row['multimedia']]]
        paths.append(f'site/public/presentations/sa-{section}')
    paths += [f'.local/artefact-generation/{name}' for name in ('originals', 'rejected', 'public', 'generation-control-state.json', 'pipeline')]
    source_paths = ['docs/notebooklm/subsections']
    return {'schema': 'sa-generation-retirement/v1', 'createdAt': now(), 'phase': 'snapshot',
            'sections': sections, 'subsections': [s for run in runs for s in run['subjects']], 'runs': runs,
            'requested': sum(run['jobs'] for run in runs), 'providerIdentities': [{'notebookId': n, 'id': i} for n, i in sorted(provider)],
            'publishedIdentities': published, 'retirementPaths': paths, 'sourceHandoffPaths': source_paths,
            'files': [row for p in paths + source_paths for row in inventory(ROOT / p)],
            'preserved': ['docs/sources', 'docs/notebooklm/sources', 'docs/site custody receipts', 'transfers/*-cycle-receipts', 'NotebookLM provider records', 'EA notebook and media'],
            'providerCancellation': False, 'remoteOriginalDeletion': False}


def ownership():
    owner = module('generation-ownership')
    stack = ExitStack()
    try:
        for stage, mirror in (('generation', 'worker.lock'), ('custody', 'transfer.lock'), ('index', 'index.lock'), ('custody-snapshot', None)):
            stack.enter_context(owner.StageLock(stage, WORK / mirror if mirror else None))
    except BaseException:
        stack.close()
        raise
    return stack


def archive_copy(source, destination):
    """Resume a small evidence copy without replacing existing custody bytes."""
    if source.is_symlink() or destination.is_symlink():
        raise RuntimeError('Archive scope contains a symlink')
    if source.is_dir():
        if destination.exists() and not destination.is_dir():
            raise RuntimeError('Archive evidence type changed: ' + str(destination))
        if destination.exists():
            for archived in destination.rglob('*'):
                original = source / archived.relative_to(destination)
                if archived.name.endswith('.copy-pending'):
                    original = original.with_name(original.name[:-len('.copy-pending')])
                    if original.is_file() and archived.is_file() and not archived.is_symlink():
                        continue
                if archived.is_symlink() or not original.exists() or archived.is_dir() != original.is_dir():
                    raise RuntimeError('Archive evidence differs: ' + str(archived))
        destination.mkdir(parents=True, exist_ok=True)
        for original in sorted(source.iterdir()):
            archive_copy(original, destination / original.name)
    elif source.is_file():
        if destination.exists():
            if not destination.is_file() or destination.read_bytes() != source.read_bytes():
                raise RuntimeError('Archive evidence differs: ' + str(destination))
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            pending = destination.with_name(destination.name + '.copy-pending')
            if pending.is_symlink() or (pending.exists() and not pending.is_file()):
                raise RuntimeError('Unsafe pending archive evidence: ' + str(pending))
            shutil.copy2(source, pending)
            with pending.open('rb') as stream:
                os.fsync(stream.fileno())
            pending.replace(destination)
            sync_parent(destination)
    elif destination.exists():
        raise RuntimeError('Archive evidence has no original: ' + str(destination))


def retired_inventory(path, relative):
    rows = inventory(path)
    prefix = str(path.relative_to(ROOT))
    return [dict(row, path=relative + row['path'][len(prefix):]) for row in rows]


def expected_inventory(plan, relative):
    return [row for row in plan['files'] if row['path'] == relative or row['path'].startswith(relative + '/')]


def verify_snapshot_scope(plan):
    for relative in plan['retirementPaths'] + plan['sourceHandoffPaths']:
        if inventory(ROOT / relative) != expected_inventory(plan, relative):
            raise RuntimeError('Active snapshot input changed: ' + relative)


def snapshot(epoch):
    target = epoch_path(epoch)
    receipt = target / 'manifest.json'
    with ownership():
        plan = json.loads(receipt.read_text()) if receipt.exists() else make_plan()
        incomplete = plan['phase'] == 'snapshot-in-progress' or not receipt.exists()
        if incomplete:
            verify_snapshot_scope(plan)
            plan['phase'] = 'snapshot-in-progress'
            save(receipt, plan)
        # Only small custody/ledger/source records are copied. Binary media is
        # inventoried now and later moved, avoiding another multi-GB copy.
        for relative in [p for p in plan['retirementPaths'] if p.startswith('docs/generation/')] + plan['sourceHandoffPaths']:
            source, destination = ROOT / relative, target / 'evidence' / relative
            retired = target / 'retired' / relative
            if retired.exists():
                source = retired
            archive_copy(source, destination)
        for run in plan['runs']:
            file = f"config/authoring/{run['section']}.json"
            body = subprocess.check_output(['git', 'show', f"{run['sourceCommit']}:{file}"], cwd=ROOT)
            destination = target / 'frozen-inputs' / file
            destination.parent.mkdir(parents=True, exist_ok=True)
            if destination.exists():
                if destination.is_symlink() or destination.read_bytes() != body:
                    raise RuntimeError('Frozen archive evidence differs: ' + file)
            else:
                pending = destination.with_name(destination.name + '.copy-pending')
                if pending.is_symlink() or (pending.exists() and not pending.is_file()):
                    raise RuntimeError('Unsafe pending frozen archive evidence: ' + file)
                with pending.open('wb') as stream:
                    stream.write(body)
                    stream.flush()
                    os.fsync(stream.fileno())
                pending.replace(destination)
                sync_parent(destination)
        if incomplete:
            verify_snapshot_scope(plan)
            plan['phase'] = 'snapshot'
            plan['snapshotCompletedAt'] = now()
            save(receipt, plan)
        return plan


def retire(epoch, sources=False):
    target, manifest = epoch_path(epoch), epoch_path(epoch) / 'manifest.json'
    with ownership():
        plan = json.loads(manifest.read_text())
        if plan['phase'] not in ('snapshot', 'retired'):
            raise RuntimeError('Complete snapshot before retirement')
        if sources and not plan.get('retiredAt'):
            raise RuntimeError('Retire generation before source handoff')
        paths = plan['sourceHandoffPaths'] if sources else plan['retirementPaths']
        moved = plan.setdefault('sourceHandoffMoves' if sources else 'retirementMoves', [])
        # Prove scope unchanged before the first move; retries accept only
        # already archived paths and the exact remaining snapshot bytes.
        for relative in paths:
            destination = target / 'retired' / relative
            expected = expected_inventory(plan, relative)
            if destination.exists() and not (ROOT / relative).exists():
                if retired_inventory(destination, relative) != expected:
                    raise RuntimeError('Archived retirement input changed: ' + relative)
                continue
            if destination.exists():
                raise RuntimeError('Active and archived retirement paths both exist: ' + relative)
            if inventory(ROOT / relative) != expected:
                raise RuntimeError('Active retirement input changed: ' + relative)
        for relative in paths:
            source, destination = ROOT / relative, target / 'retired' / relative
            if source.exists():
                destination.parent.mkdir(parents=True, exist_ok=True)
                source.rename(destination)
            if relative not in moved:
                moved.append(relative)
                save(manifest, plan)
        plan['sourcePointersRetiredAt' if sources else 'retiredAt'] = now()
        plan['phase'] = 'retired'
        save(manifest, plan)
    return plan


def publish_retirement(epoch, workers=32):
    target = epoch_path(epoch)
    plan = json.loads((target / 'manifest.json').read_text())
    if plan.get('phase') != 'retired':
        raise RuntimeError('Retire active generation before publishing empty indexes')
    for section in plan['sections']:
        if (ROOT / f'docs/generation/releases/{section}.json').exists():
            raise RuntimeError('Retirement publication must have no active releases')
    transfer, publisher, owner = module('generation-transfer'), module('generation-index-publication'), module('generation-ownership')
    transfer.check_ea_pin()
    with owner.StageLock('index', WORK / 'index.lock') as lock:
        publisher.INDEX_LOCK_DESCRIPTOR = lock.descriptor
        published = publisher.publish_current(transfer, transfer.validated_workers(workers))
    plan.update(retirementIndexesPublishedAt=now(), retirementIndexChanged=published)
    save(target / 'manifest.json', plan)
    return plan


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--epoch', required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--snapshot', action='store_true')
    group.add_argument('--retire', action='store_true')
    group.add_argument('--handoff-sources', action='store_true')
    group.add_argument('--publish-retirement', action='store_true')
    args = parser.parse_args()
    if args.snapshot:
        plan = snapshot(args.epoch)
    elif args.publish_retirement:
        plan = publish_retirement(args.epoch)
    else:
        plan = retire(args.epoch, sources=args.handoff_sources)
    print(json.dumps({'epoch': args.epoch, 'phase': plan['phase'], 'sections': len(plan['sections']),
                      'subsections': len(plan['subsections']), 'requested': plan['requested'],
                      'providerIdentities': len(plan['providerIdentities']), 'publishedIdentities': len(plan['publishedIdentities']),
                      'manifest': str(epoch_path(args.epoch) / 'manifest.json')}))


if __name__ == '__main__':
    main()
