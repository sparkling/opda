#!/usr/bin/env python3
"""Verify live comment lifecycle using one temporary source record, then remove it."""
import argparse
import json
from pathlib import Path
import shlex
import subprocess

parser=argparse.ArgumentParser()
parser.add_argument('--receipt',type=Path,required=True)
args=parser.parse_args()
remote=r'''
import base64,hashlib,hmac,json,pathlib,time,uuid,urllib.request,urllib.error,urllib.parse
base=pathlib.Path('/opt/sa-artalk')
admin=json.loads((base/'admin-config.json').read_text())
feed=(base/'research-feed-token').read_text().strip()
origin='https://comments.sa.hm.sparklingideas.co.uk'
site='Solutions Architecture'
page='/__research-feed-verification__/'+str(uuid.uuid4())
comment_id=None
checks={}
def request(url,method='GET',body=None,token=None):
    headers={'Accept':'application/json'}
    if token: headers['Authorization']='Bearer '+token
    if body is not None: headers['Content-Type']='application/json'
    req=urllib.request.Request(url,data=json.dumps(body).encode() if body is not None else None,headers=headers,method=method)
    try:
        with urllib.request.urlopen(req,timeout=15) as response:
            value=json.loads(response.read(9*1024*1024));return response.status,value.get('data',value)
    except urllib.error.HTTPError as error: return error.code,None
def atk(path,method='GET',body=None):
    enc=lambda value:base64.urlsafe_b64encode(json.dumps(value,separators=(',',':')).encode()).decode().rstrip('=')
    now=int(time.time());unsigned=enc({'alg':'HS256','typ':'JWT'})+'.'+enc({'user_id':admin['userId'],'iat':now,'exp':now+30})
    signature=base64.urlsafe_b64encode(hmac.new(admin['appKey'].encode(),unsigned.encode(),hashlib.sha256).digest()).decode().rstrip('=')
    return request('http://127.0.0.1:23366/api/v2/'+path,method,body,unsigned+'.'+signature)
def snapshot():
    status,result=request(origin+'/research-feed/snapshot',token=feed)
    assert status==200 and result['complete'] is True
    return result
def exact(): return request(origin+'/research-feed/comments/'+str(comment_id),token=feed)
def update(content,pending=False):
    status,_=atk('comments/'+str(comment_id),'PUT',{'site_name':site,'page_key':page,'content':content,'rid':0,'is_collapsed':False,'is_pending':pending,'is_pinned':False})
    assert status==200
try:
    before=snapshot()
    status,created=atk('comments','POST',{'name':admin['name'],'email':admin['email'],'site_name':site,'page_key':page,'content':'Synthetic Prime Gradient feed lifecycle verification; remove immediately.','rid':0})
    assert status==200
    comment_id=created['id'];key='artalk:sa:'+str(comment_id)
    first=snapshot();created_row=next(row for row in first['records'] if row['id']==key)
    assert created_row['authorKey']=='artalk:sa:user:'+str(admin['userId'])
    checks['createExported']=True
    update('Synthetic Prime Gradient feed lifecycle verification, revised; remove immediately.')
    second=snapshot();changed=next(row for row in second['records'] if row['id']==key)
    assert changed['sha256']!=created_row['sha256'] and exact()[1]['sha256']==changed['sha256']
    checks['editExported']=True
    update('Synthetic pending verification; remove immediately.',True)
    assert exact()[0]==404 and all(row['id']!=key for row in snapshot()['records'])
    checks['pendingExcluded']=True
    status,_=atk('comments/'+str(comment_id),'DELETE');assert status==200
    assert exact()[0]==404 and all(row['id']!=key for row in snapshot()['records'])
    checks['deleteExported']=True
finally:
    if comment_id is not None:
        status,_=atk('comments/'+str(comment_id),'DELETE')
        if status not in [200,404]: raise RuntimeError('Verification comment cleanup failed')
    status,pages=atk('pages?'+urllib.parse.urlencode({'site_name':site,'search':page,'limit':10,'offset':0}))
    if status!=200: raise RuntimeError('Verification page cleanup lookup failed')
    for item in pages['pages']:
        if item['key']==page and item['site_name']==site:
            status,_=atk('pages/'+str(item['id']),'DELETE')
            if status!=200: raise RuntimeError('Verification page cleanup failed')
after=snapshot()
assert after['version']==before['version']
print(json.dumps({'schema':'sa-comments-feed-live-verification/v1','checks':checks,'temporaryCommentRemoved':True,'temporaryPageRemoved':True,
  'preexistingSourceUnchanged':True,'approvedRecords':len(after['records']),'sourceVersion':after['version']}))
'''
command=['ssh','-i',str(Path.home()/'.ssh/sa-artalk'),'-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',
    'ubuntu@35.176.61.190','sudo -n python3 -c '+shlex.quote(remote)]
result=subprocess.run(command,capture_output=True,text=True)
if result.returncode:
    raise RuntimeError('Live lifecycle verification failed; inspect host safely, credential output suppressed')
receipt=json.loads(result.stdout)
args.receipt.parent.mkdir(parents=True,exist_ok=True)
args.receipt.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
