#!/usr/bin/env python3
"""Render body-verified uploaded originals concurrently and incrementally
activate sections through the unchanged EA renderer/publisher. Quality review
is preserved separately; it no longer prevents an uploaded original appearing.
Only the main thread stages releases, builds and publishes. Immutable receipts
prove each activated delta; historical publication receipts remain unchanged.
"""
import argparse
import datetime
import hashlib
import importlib.util
import json
import re
import subprocess
import sys
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT = Path(__file__).resolve().parents[2]
TRANSFER_MODULE_PATH = ROOT / 'src/programme/generation-transfer.py'
SITE_DIST = ROOT / 'site/dist'
HISTORICAL_RECEIPT = ROOT / 'docs/site/sa-approved-artefact-publication.json'
CYCLE_RECEIPTS = ROOT / '.local/artefact-generation/transfers/index-cycle-receipts'
MANIFEST_PATH = ROOT / '.local/artefact-generation/transfers/index-release-scope.json'
BUCKET = 'hm-website-sa-841291679368'
DISTRIBUTION = 'E3SMUNTX4XREG4'
INDEX_LOCK_DESCRIPTOR = None


def writer_options():
    # A surviving writer keeps the kernel ownership lock after parent death.
    return {'pass_fds': (INDEX_LOCK_DESCRIPTOR,)} if INDEX_LOCK_DESCRIPTOR is not None else {}


def sections():
    return [section['id'] for section in json.loads((ROOT / 'config/programme.json').read_text())['sections']]


def event(**fields):
    print(json.dumps(fields), flush=True)


def load_transfer_module():
    spec = importlib.util.spec_from_file_location('generation_transfer', TRANSFER_MODULE_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.dont_write_bytecode = True
    spec.loader.exec_module(module)
    return module


def render_uploaded_sections(render_concurrency=4, node_bin='node', selected_sections=None):
    """Workers own disjoint catalogues/renditions, never releases or site/dist."""
    if not 1 <= render_concurrency <= 4:
        raise ValueError('Render concurrency must be between one and four')
    with ThreadPoolExecutor(max_workers=render_concurrency) as executor:
        pending = {executor.submit(subprocess.run,
            [node_bin, str(ROOT / 'src/programme/generation-import.mjs'), section, '--uploaded'],
            check=True, cwd=ROOT, **writer_options()): section for section in (sections() if selected_sections is None else selected_sections)}
        for future in as_completed(pending):
            section = pending[future]
            try:
                future.result()
                yield section
            except Exception as error:
                event(sectionRenderFailed=section, errorType=type(error).__name__, retryNextCycle=True)


def stage_uploaded_release(section, node_bin='node'):
    """Serial release owner: unchanged selection never rewrites timestamps."""
    catalogue_path = ROOT / f'docs/generation/catalogues/{section}.json'
    if not catalogue_path.is_file():
        return False
    catalogue = json.loads(catalogue_path.read_text())
    selected = [*catalogue['decks'], *catalogue['multimedia']]
    release_path = ROOT / f'docs/generation/releases/{section}.json'
    if not selected and not release_path.is_file():
        return False
    if release_path.is_file():
        release = json.loads(release_path.read_text())
        existing = [*release['decks'], *release['multimedia']]
        if release.get('publicationPolicy') == 'uploaded' and selected == existing:
            return False
    subprocess.run([node_bin, str(ROOT / 'src/programme/generation-release.mjs'), section, '--uploaded'],
                    check=True, cwd=ROOT, **writer_options())
    return True


def build_site():
    subprocess.run(['npm', '--prefix', 'site', 'run', 'build'], check=True, cwd=ROOT, **writer_options())


def selected_media():
    # Reuse the release owner's custody, provider, input and path checks.
    script = """
import fs from 'node:fs';
import {root,load} from './src/programme/generation-state.mjs';
import {validateRelease,mediaFiles} from './src/programme/generation-release.mjs';
import {verifiedCustody} from './src/programme/generation-import.mjs';
const programme=JSON.parse(fs.readFileSync(root+'/config/programme.json'));
const records=[];
const custody=verifiedCustody();
for(const {id} of programme.sections){
  const file=root+'/docs/generation/releases/'+id+'.json';
  if(!fs.existsSync(file))continue;
  const release=JSON.parse(fs.readFileSync(file));
  records.push(...mediaFiles(validateRelease(load(id).run,release,{partial:true,publicationPolicy:release.publicationPolicy??'approved',custody}),release.prefix,{custody}));
}
console.log(JSON.stringify(records));
"""
    result = subprocess.run(['node', '--input-type=module', '-e', script], cwd=ROOT,
                            check=True, capture_output=True, text=True)
    return json.loads(result.stdout)


def hash_build_tree():
    # Only index routes, shared build assets/fonts and validated selected media.
    # Stale or unrelated site/public files never enter the release manifest.
    keys = {'index.html', *(f'{section}/index.html' for section in sections())}
    keys.update(str(file.relative_to(SITE_DIST)) for file in (SITE_DIST / '_astro').glob('*')
                if file.suffix in ('.js', '.css') and file.is_file())
    keys.update(json.loads((ROOT / 'config/shared-renderer.json').read_text())['assets'])
    keys.update(image['src'].lstrip('/') for image in json.loads((ROOT / 'config/section-card-art.json').read_text())['artwork'])
    media = {record['path'].removeprefix('/'): record['sha256'] for record in selected_media()}
    keys.update(media)
    files = {}
    for key in sorted(keys):
        path = SITE_DIST / key
        if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(SITE_DIST.resolve()):
            raise RuntimeError(f'Missing or unsafe approved release file: {key}')
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        if key in media and sha != media[key]:
            raise RuntimeError(f'Approved release bytes changed: {key}')
        files[key] = sha
    return files


def compute_delta(current, verified):
    return {key: sha for key, sha in current.items() if verified.get(key) != sha}


def dependency_closed_scope(script, delta, current, commit):
    """Reuse the pinned publisher's dependency rules within admitted build bytes."""
    source = Path(script).parent / 'release_scope.py'
    spec = importlib.util.spec_from_file_location('pinned_release_scope', source)
    scope = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scope)
    manifest = scope.build_scope(SITE_DIST, sorted(delta), commit)
    selected = {item['key']: item['sha256'] for item in manifest['files']}
    if (not set(delta).issubset(selected)
            or any(current.get(key) != sha for key, sha in selected.items())):
        raise RuntimeError('Compiled dependency is outside the admitted build or its bytes changed')
    return manifest


def verified_index_files(receipt, expected=None):
    """Validate a receipt actually proves remote custody for exactly its
    files: 0 body-hash mismatches, the commissioned private account/bucket,
    and safe, non-duplicate relative keys. Summary counts are never proof."""
    files = receipt.get('files', [])
    if (receipt.get('bodyHashMismatches') != 0 or str(receipt.get('account')) != '841291679368'
            or receipt.get('fileCount') != len(files) or receipt.get('bucketPublicAccessBlocked') is not True
            or receipt.get('outputs', {}).get('BucketName') != BUCKET
            or receipt.get('outputs', {}).get('DistributionId') != DISTRIBUTION):
        raise RuntimeError('Index receipt lacks the required remote-verification evidence')
    result = {}
    for item in files:
        key, sha = item.get('key', ''), item.get('sha256', '')
        if (not key or key.startswith('/') or '..' in key.split('/') or '\\' in key
                or any(ord(character) < 32 for character in key)
                or not re.fullmatch(r'[0-9a-f]{64}', sha) or key in result):
            raise RuntimeError('Index receipt has an unsafe or duplicate key')
        result[key] = sha
    if expected is not None and result != expected:
        raise RuntimeError('Index receipt does not verify the exact selected files')
    return result


def load_verified_state():
    state = {}
    receipts = ([HISTORICAL_RECEIPT] if HISTORICAL_RECEIPT.is_file() else []) + sorted(CYCLE_RECEIPTS.glob('*.json'))
    for path in receipts:
        receipt = json.loads(path.read_text())
        if path != HISTORICAL_RECEIPT and receipt.get('invalidationStatus') != 'Completed':
            raise RuntimeError('Cycle index receipt lacks completed cache invalidation')
        state.update(verified_index_files(receipt))
    return state


def complete_invalidation(receipt, keys):
    invalidation = receipt.get('invalidationId')
    if not invalidation:
        # Retry may find uploaded HTML before its previous cache clear succeeded.
        stamp = datetime.datetime.now(datetime.UTC).isoformat()
        batch = {'Paths': {'Quantity': len(keys), 'Items': ['/' + key for key in sorted(keys)]},
                 'CallerReference': 'sa-index-' + stamp}
        result = subprocess.run(['aws', 'cloudfront', 'create-invalidation', '--profile', 'claude',
            '--distribution-id', DISTRIBUTION, '--invalidation-batch', json.dumps(batch)],
            check=True, capture_output=True, text=True)
        invalidation = json.loads(result.stdout)['Invalidation']['Id']
    subprocess.run(['aws', 'cloudfront', 'wait', 'invalidation-completed', '--profile', 'claude',
                    '--distribution-id', DISTRIBUTION, '--id', invalidation], check=True)
    receipt.update(invalidationId=invalidation, invalidationStatus='Completed')


def publish_current(m, workers):
    head_before = m.current_head()
    build_site()
    current = hash_build_tree()
    if m.current_head() != head_before:
        event(indexPublishSkipped=True, reason='sourceCommit changed during build; retrying next cycle')
        return False

    verified = load_verified_state()
    delta = compute_delta(current, verified)
    event(buildFiles=len(current), verifiedFiles=len(verified), deltaFiles=len(delta))
    if not delta:
        event(indexUpToDate=True)
        return False

    _, _, script = m.check_ea_pin()
    manifest = dependency_closed_scope(script, delta, current, head_before)
    selected = {item['key']: item['sha256'] for item in manifest['files']}
    MANIFEST_PATH.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST_PATH.write_text(json.dumps(manifest, indent=2) + '\n')

    CYCLE_RECEIPTS.mkdir(parents=True, exist_ok=True)
    stamp = datetime.datetime.now(datetime.UTC).strftime('%Y%m%dT%H%M%S%fZ')
    cycle_receipt_path = CYCLE_RECEIPTS / f'{stamp}.json'
    pending = cycle_receipt_path.with_suffix('.pending')
    receipt = m.run_publisher_inprocess(script, SITE_DIST, MANIFEST_PATH, pending,
                                         workers, aws_cli_credentials=True)
    event(uploadedFiles=receipt.get('uploadedFiles'), bodyHashMismatches=receipt.get('bodyHashMismatches'),
          cycleReceipt=str(cycle_receipt_path))
    verified_index_files(receipt, selected)
    complete_invalidation(receipt, delta)
    pending.write_text(json.dumps(receipt, indent=2) + '\n')
    pending.replace(cycle_receipt_path)
    return True


def needs_original_url_migration():
    for section in sections():
        path = ROOT / f'docs/generation/releases/{section}.json'
        if path.is_file():
            release = json.loads(path.read_text())
            if any(not item.get('original', {}).get('path', '').startswith('/custody/generation/')
                   for item in [*release['decks'], *release['multimedia']]):
                return True
    return False


def run_cycle(m, workers, render_concurrency=4):
    published = False
    rendered = False
    publish_failed = False
    migration = needs_original_url_migration()
    for section in render_uploaded_sections(render_concurrency):
        rendered = True
        try:
            changed = stage_uploaded_release(section)
            event(sectionStaged=section, releaseChanged=changed)
        except Exception as error:
            event(sectionStageFailed=section, errorType=type(error).__name__, retryNextCycle=True)
            continue
        if changed and not migration:
            # Other workers keep rendering; they never mutate the releases read
            # by this serialized build/hash/upload/invalidation transaction.
            try:
                published = publish_current(m, workers) or published
            except Exception as error:
                publish_failed = True
                event(indexPublishFailed=section, errorType=type(error).__name__, retryAfterStaging=True)
    if migration or not rendered or not published or publish_failed:
        published = publish_current(m, workers) or published
    return published


def load_ownership():
    spec = importlib.util.spec_from_file_location('generation_ownership', ROOT / 'src/programme/generation-ownership.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def publication_selection(m):
    """Only remote-admitted identities affect index work; provider polling
    timestamps and completed jobs awaiting custody never trigger a rebuild."""
    spec = importlib.util.spec_from_file_location('custody_worker', ROOT / 'src/programme/generation-transfer-worker.py')
    custody_worker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(custody_worker)
    custody = custody_worker.load_verified_state(custody_worker.DEFAULT_RECEIPT)
    result = {}
    for section in sections():
        run = json.loads((ROOT / f'docs/generation/{section}.json').read_text())
        selected = []
        for current in run['jobs']:
            for job in [current, *(current.get('attemptHistory') or [])]:
                if job.get('status') != 'completed' or not job.get('id') or not job.get('providerProof', {}).get('settingsVerified') or job.get('type') not in m.EXT:
                    continue
                key = f"custody/generation/{run['notebookId']}/{job['id']}.{m.EXT[job['type']]}"
                if key not in custody:
                    continue
                selected.append({'id': job['id'], 'key': current['key'], 'retainedAttempt': job is not current,
                    'sha256': custody[key], 'providerProof': {field: job['providerProof'].get(field)
                        for field in ('settingsVerified', 'sourceIds', 'promptSha256')},
                    'qualityReview': job.get('qualityReview'), 'title': job.get('title'),
                    'generatedTitle': job.get('generatedTitle')})
        payload = {'sourceCommit': run['sourceCommit'], 'notebookId': run['notebookId'], 'selected': selected}
        result[section] = {'fingerprint': hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest(),
                           'ids': {item['id'] for item in selected}}
    return m.current_head(), result


def sections_needing_retry(selection):
    retry = set()
    for section, selected in selection.items():
        path = ROOT / f'docs/generation/releases/{section}.json'
        release = json.loads(path.read_text()) if path.is_file() else {'decks': [], 'multimedia': []}
        available = {item['id'] for item in [*release['decks'], *release['multimedia']]}
        if available != selected['ids']:
            retry.add(section)
    return retry


def supervise(m, args, ownership):
    staged, previous_head, activation_pending = {}, None, True
    retry = set()
    while True:
        if not ownership.supervisor_alive():
            return
        try:
            head, selection = publication_selection(m)
            dirty = [section for section, selected in selection.items()
                     if head != previous_head or staged.get(section) != selected['fingerprint'] or section in retry]
            ownership.write_stage_status('index', 'rendering' if dirty else 'waiting',
                                         queuedSections=len(dirty))
            for section in render_uploaded_sections(args.render_concurrency, selected_sections=dirty):
                try:
                    changed = stage_uploaded_release(section)
                except Exception as error:
                    event(sectionStageFailed=section, **ownership.safe_error(error))
                    continue
                staged[section] = selection[section]['fingerprint']
                activation_pending = activation_pending or changed
            activation_pending = activation_pending or head != previous_head
            previous_head = head
            retry = sections_needing_retry(selection)
            if activation_pending:
                ownership.write_stage_status('index', 'publishing', queuedSections=len(retry))
                publish_current(m, args.workers)
                activation_pending = m.current_head() != head
                if not activation_pending:
                    ownership.write_stage_status('index', 'waiting', queuedSections=len(retry),
                        lastSuccess=datetime.datetime.now(datetime.UTC).isoformat(), lastError=None, nextRetryAt=None)
            elif not dirty:
                ownership.write_stage_status('index', 'waiting', queuedSections=len(retry))
            if retry:
                ownership.write_stage_status('index', 'retry', queuedSections=len(retry),
                    lastError={'errorType': 'RenditionsPending'},
                    nextRetryAt=(datetime.datetime.now(datetime.UTC) + datetime.timedelta(seconds=args.interval)).isoformat())
        except Exception as error:
            activation_pending = True
            failure = ownership.safe_error(error)
            ownership.write_stage_status('index', 'auth_wait' if failure.get('reason') == 'aws-credentials-unavailable' else 'retry', lastError=failure,
                nextRetryAt=(datetime.datetime.now(datetime.UTC) + datetime.timedelta(seconds=args.interval)).isoformat())
            event(indexRetry=True, **ownership.safe_error(error))
        try:
            spec = importlib.util.spec_from_file_location('generation_punchlist', ROOT / 'src/programme/generation-punchlist.py')
            punchlist = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(punchlist)
            punchlist.refresh()
        except Exception as error:
            event(punchlistUpdateFailed=True, **ownership.safe_error(error))
        time.sleep(args.interval)


def main():
    global INDEX_LOCK_DESCRIPTOR
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers', type=int, default=32)
    parser.add_argument('--render-concurrency', type=int, default=4, choices=range(1, 5))
    parser.add_argument('--persistent', action='store_true')
    parser.add_argument('--interval', type=int, default=30, choices=range(5, 61))
    args = parser.parse_args()
    m = load_transfer_module()
    workers = m.validated_workers(args.workers)
    m.check_ea_pin()
    ownership = load_ownership()
    with ownership.StageLock('index', ROOT / '.local/artefact-generation/index.lock') as lock:
        INDEX_LOCK_DESCRIPTOR = lock.descriptor
        try:
            if args.persistent:
                supervise(m, args, ownership)
                return
            published = run_cycle(m, workers, args.render_concurrency)
        finally:
            INDEX_LOCK_DESCRIPTOR = None
    event(published=published)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        event(errorType=type(error).__name__)
        raise SystemExit(1)
