/** Durable intent and acknowledgements for the commissioned NotebookLM matrix. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
export const root=fileURLToPath(new URL('../../',import.meta.url));
export const digest=text=>crypto.createHash('sha256').update(text).digest('hex');
const timestamp=()=>new Date().toISOString();
const uuid=value=>{if(!/^[a-f0-9-]{36}$/.test(value??''))throw Error('Invalid provider identity');return value;};
export function load(section){
  if(!/^[a-z]+$/.test(section))throw Error('Invalid section');
  const file=path.join(root,'docs/generation',section+'.json');
  const run=JSON.parse(fs.readFileSync(file,'utf8'));
  if(run.sectionId!==section || !run.commissioned || !run.publish || !/^[a-f0-9]{40}$/.test(run.sourceCommit))throw Error('Invalid commissioned ledger');
  if(run.jobs.length!==run.requested || run.requested!==run.subjects.length*34 || new Set(run.jobs.map(j=>j.key)).size!==run.requested)throw Error('Invalid generation matrix');
  return {file,run};
}
export function save(file,run){
  const {jobs,...header}=run;
  const body=JSON.stringify(header).slice(0,-1)+',"jobs":[\n'+jobs.map(j=>JSON.stringify(j)).join(',\n')+'\n]}\n';
  const pending=file+'.tmp';fs.writeFileSync(pending,body);fs.renameSync(pending,file);
}
export function frozenBrief(run,id){
  const record=JSON.parse(execFileSync('git',['show',`${run.sourceCommit}:config/authoring/${run.sectionId}.json`],{cwd:root,encoding:'utf8',maxBuffer:4e6}));
  const brief=record.subjects.find(b=>b.id===id),subject=run.subjects.find(s=>s.id===id);
  if(!brief || !subject || digest(brief.editorialNote)!==subject.editorialSha256 || JSON.stringify(brief.factualSourceIds)!==JSON.stringify(subject.factualSourceIds))throw Error('Frozen source identity mismatch');
  for(const [medium,prompt] of Object.entries(brief.mediaPrompts))if(digest(prompt)!==subject.promptHashes[medium])throw Error('Frozen prompt mismatch');
  return brief;
}
export function verifyFacts(run,subject){
  const proof=JSON.parse(fs.readFileSync(path.join(root,'docs/notebooklm/subsections/indexed-verification.json'),'utf8'));
  const brief=frozenBrief(run,subject.id);
  if(proof.notebookId!==run.notebookId || proof.sourceCount!==90 || proof.checks.length!==90)throw Error('Incomplete factual sync');
  for(const id of subject.factualSourceIds){
    const check=proof.checks.find(c=>c.sourceId===id && c.sha256===brief.factualInput.bundleSha256);
    if(!check || check.status!=='success' || check.missingMarkers || check.missingHashes || check.missingUrls)throw Error('Unverified factual input');
  }
  return proof.verifiedAt;
}
export function resolvedSettings(run,job){
  const subject=run.subjects.find(s=>s.id===job.subject);
  if(!subject)throw Error('Unknown subsection');
  verifyFacts(run,subject);
  if(job.editorial && subject.editorialSync?.status!=='indexed-verified')throw Error('Editorial is not indexed');
  return {...job.settings,notebook_id:run.notebookId,title:job.title,
    source_ids:[...subject.factualSourceIds,...(job.editorial?[uuid(subject.editorialSourceId)]:[])],
    focus_prompt:frozenBrief(run,subject.id).mediaPrompts[job.medium]};
}
export function editorialTitle(subject){return `SA — ${subject.id} — editorial v${subject.editorialVersion} [${subject.editorialSha256.slice(0,12)}]`;}
export function indexedWords(text){return text.normalize('NFKC').replace(/[^\p{L}\p{N}]+/gu,' ').trim();}
export function acknowledgeEditorial(subject,id){
  uuid(id);
  if(subject.editorialSourceId && subject.editorialSourceId!==id)throw Error('Editorial identity cannot be overwritten');
  subject.editorialSourceId=id;
  subject.editorialSync={...subject.editorialSync,status:'submitted',acknowledgedAt:timestamp()};
}
export function acknowledgeJob(job,id){
  uuid(id);
  if(job.id && job.id!==id)throw Error('Job identity cannot be overwritten');
  if(job.status!=='submitting' && job.status!=='needs-reconciliation' && !job.id)throw Error('No persisted submission intent');
  job.id=id;job.status='submitted';job.acknowledgedAt=timestamp();
}
export function reviewQuality(job,original,disposition,notes){
  if(!job?.id || job.status!=='completed' || !['approved','garbled_text','incorrect_content','unreadable'].includes(disposition))throw Error('Invalid quality review');
  if(typeof notes!=='string' || !notes.trim() || notes.length>2000)throw Error('Quality review requires a bounded explanation');
  return {status:disposition==='approved'?'approved':'rejected',reason:disposition,notes:notes.trim(),providerId:job.id,originalSha256:digest(original),reviewedAt:timestamp()};
}
export function reconcileCatalogueQuality(run,catalogue,{includeRejected=false,includeHistory=false}={}){
  const rejected=new Map((catalogue.rejected??[]).map(item=>[item.id,item]));
  if(includeRejected)for(const item of rejected.values()){
    const group=item.type==='slide_deck'?'decks':'multimedia';
    if(!catalogue[group].some(existing=>existing.id===item.id))catalogue[group].push(item);
  }
  for(const group of ['decks','multimedia']){
    catalogue[group]=catalogue[group].filter(item=>{
      const job=run.jobs.find(j=>j.key===item.key);
      const attempt=job?.id===item.id?job:job?.attemptHistory?.find(a=>a.id===item.id);
      if(!attempt)throw Error('Catalogue provider identity is not in the job history');
      const review=attempt.qualityReview;
      if(review && (review.providerId!==item.id || review.originalSha256!==item.original?.sha256))throw Error('Catalogue review belongs to another original');
      item.qualityStatus=review?.status??'pending';
      if(item.qualityStatus==='rejected'){rejected.set(item.id,item);if(!includeRejected)return false;}
      if(attempt!==job && !includeHistory)throw Error('Unreviewed replacement in catalogue');
      item.retainedAttempt=attempt!==job;
      item.publicationKey=item.retainedAttempt?`${job.key}--${item.id}`:job.key;
      return true;
    });
  }
  if(rejected.size)catalogue.rejected=[...rejected.values()];
  return catalogue;
}
if(process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const [command,section,key,value,notes]=process.argv.slice(2);
  if(['quality-review','retry-quality'].includes(command) && fs.existsSync(path.join(root,'.local/artefact-generation/worker.lock')))throw Error('Stop the generation writer before changing quality records');
  const {file,run}=load(section);
  const subject=run.subjects.find(s=>s.id===key),job=run.jobs.find(j=>j.key===key);
  let result;
  if(command==='editorial-intent'){
    if(!subject)throw Error('Unknown subsection');verifyFacts(run,subject);
    subject.editorialSync??={status:'submitting',attemptedAt:timestamp(),title:editorialTitle(subject)};
    save(file,run);
    result={notebookId:run.notebookId,subject:subject.id,title:editorialTitle(subject),text:frozenBrief(run,subject.id).editorialNote,sourceId:subject.editorialSourceId,status:subject.editorialSync.status};
  }else if(command==='editorial-ack'){
    if(!subject)throw Error('Unknown subsection');acknowledgeEditorial(subject,value);save(file,run);result={subject:key,id:value};
  }else if(command==='editorial-verify'){
    if(!subject?.editorialSourceId)throw Error('No acknowledged editorial');
    const content=fs.readFileSync(0,'utf8'),expected=frozenBrief(run,key).editorialNote;
    if(!indexedWords(content).includes(indexedWords(expected)))throw Error('Incomplete indexed editorial');
    subject.editorialSync={...subject.editorialSync,status:'indexed-verified',verifiedAt:timestamp(),indexedSha256:digest(content),characters:content.length};
    save(file,run);result={subject:key,status:'indexed-verified'};
  }else if(command==='job-intent'){
    if(!job || job.status!=='planned' || job.id)throw Error('Job must be reconciled before resubmission');
    result=resolvedSettings(run,job);
    job.status='submitting';job.attemptedAt=timestamp();job.sourceIds=result.source_ids;job.promptSha256=digest(result.focus_prompt);save(file,run);
  }else if(command==='job-ack'){
    if(!job)throw Error('Unknown job');acknowledgeJob(job,value);
    if(run.jobs.some(other=>other!==job && other.id===job.id))throw Error('Provider identity already assigned');
    save(file,run);result={key,id:value,status:job.status};
  }else if(command==='job-uncertain'){
    if(!job || job.status!=='submitting' || !/^[A-Za-z][A-Za-z0-9_-]{0,80}$/.test(value??''))throw Error('Invalid submission failure');
    job.status='needs-reconciliation';job.errorType=value;save(file,run);result={key,status:job.status,errorType:value};
  }else if(command==='quality-review'){
    if(!job?.id || job.status!=='completed')throw Error('Invalid quality review');
    const ext={infographic:'png',audio:'m4a',video:'mp4',slide_deck:'pdf'}[job.type];
    const original=fs.readFileSync(path.join(root,'.local/artefact-generation/originals',job.key+'.'+ext));
    job.qualityReview=reviewQuality(job,original,value,notes);
    save(file,run);result={key,quality:job.qualityReview.status};
  }else if(command==='retry-quality'){
    if(!job?.id || job.qualityReview?.status!=='rejected' || (job.attemptHistory?.length??0)>=2)throw Error('Quality retry requires a reviewed rejection and stays bounded');
    const ext={infographic:'png',audio:'m4a',video:'mp4',slide_deck:'pdf'}[job.type];
    const original=path.join(root,'.local/artefact-generation/originals',job.key+'.'+ext);
    const archive=path.join(root,'.local/artefact-generation/rejected');fs.mkdirSync(archive,{recursive:true});
    fs.renameSync(original,path.join(archive,job.id+'.'+ext));
    const {attemptHistory,...attempt}=job;job.attemptHistory=[...(attemptHistory??[]),attempt];
    for(const field of ['providerProof','qualityReview','mediaReady','generatedTitle','acknowledgedAt','checkedAt','attemptedAt'])delete job[field];
    job.id=null;job.status='planned';save(file,run);result={key,status:'planned',rejectedProviderId:attempt.id};
  }else if(command==='summary'){
    result={section,requested:run.requested,editorialsVerified:run.subjects.filter(s=>s.editorialSync?.status==='indexed-verified').length,statuses:run.jobs.reduce((m,j)=>(m[j.status]=(m[j.status]??0)+1,m),{})};
  }else throw Error('Unknown generation state command');
  console.log(JSON.stringify(result));
}
