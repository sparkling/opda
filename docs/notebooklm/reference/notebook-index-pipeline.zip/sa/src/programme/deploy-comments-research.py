#!/usr/bin/env python3
"""Deploy the shared comments owner; optionally provision its fixed EA context."""
import argparse
import hashlib
import json
from pathlib import Path
import secrets
import shlex
import subprocess
import urllib.error
import urllib.request
import boto3

parser = argparse.ArgumentParser()
parser.add_argument('--host', required=True)
parser.add_argument('--identity', type=Path, default=Path.home()/'.ssh/sa-artalk')
parser.add_argument('--receipt', type=Path, required=True)
parser.add_argument('--page-titles', type=Path, help='Reviewed native title plan: id, key, previousTitle, title; no page renaming')
parser.add_argument('--enable-ea-site', action='store_true', help='Provision the approved EA native site and independent origin credential')
parser.add_argument('--enable-ba-site', action='store_true', help='Provision the BA native site and independent origin credential')
parser.add_argument('--enable-arb-site', action='store_true', help='Provision the isolated Product Domain ARB native site and independent origin credential')
args = parser.parse_args()
if sum([args.enable_ea_site,args.enable_ba_site,args.enable_arb_site]) > 1:
    parser.error('Provision one native site per deployment')
if args.host != 'ubuntu@35.176.61.190':
    parser.error('This deployment is restricted to the existing SA comments owner')
root = Path(__file__).resolve().parents[2]
session = boto3.Session(profile_name='claude', region_name='us-east-1')
assert session.client('sts').get_caller_identity()['Account'] == '841291679368'
manager = session.client('secretsmanager')
name = 'hm/ea-research/comments-feed'
try:
    existing = manager.get_secret_value(SecretId=name)
    token, arn = existing['SecretString'], existing['ARN']
except manager.exceptions.ResourceNotFoundException:
    token = secrets.token_urlsafe(48)
    created = manager.create_secret(Name=name, SecretString=token,
        Description='Read-only EA research access to approved SA comments; not a browser or Artalk administrator credential',
        Tags=[{'Key':'Project','Value':'semantic-enterprise-architecture'}])
    arn = created['ARN']
if len(token) < 48 or not all(c.isalnum() or c in '_-' for c in token):
    raise RuntimeError('Invalid existing feed credential')
files = {name:(root/'src/programme'/name).read_text() for name in ['comments-gateway.mjs','comments-admin.mjs','comments-research-feed.mjs','comments-location.mjs','comments-page-titles.mjs','comments-native-site.mjs','backup-comments.py']}
title_plan = json.loads(args.page_titles.read_text()) if args.page_titles else []
remote = r'''
import json,pathlib,subprocess,sys,os,hashlib,datetime,shutil,secrets,socket,time
p=json.load(sys.stdin)
base=pathlib.Path('/opt/sa-artalk')
config=pathlib.Path('/etc/caddy/Caddyfile')
route=pathlib.Path('/etc/caddy/sa-research-feed.caddy')
comments_route=pathlib.Path('/etc/caddy/sa-comments.caddy')
paths=[base/name for name in p['files']]+[config,route,comments_route,base/'research-feed-token',base/'ea-origin-secret',base/'ba-origin-secret',base/'arb-origin-secret']
before={str(path):(path.read_bytes(),path.stat().st_mode & 0o777) if path.exists() else None for path in paths}
backup=base/'research-release-backups'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
backup.mkdir(parents=True,mode=0o700)
os.chmod(backup.parent,0o700)
for path in paths:
    if path.exists(): shutil.copy2(path,backup/path.name)
def run(argv):
    result=subprocess.run(argv,capture_output=True,text=True)
    if result.returncode: raise RuntimeError('Deployment command failed: '+argv[0])
try:
    for name,body in p['files'].items():
        target=base/name;target.write_text(body);os.chmod(target,0o644)
        if name.endswith('.mjs'):run([str(base/'node'),'--check',str(target)])
        elif name.endswith('.py'):compile(body,str(target),'exec')
    secret=base/'research-feed-token';secret.write_text(p['token']);os.chmod(secret,0o640)
    run(['chown','root:sa-comments',str(secret)])
    route.write_text('@researchFeed path /research-feed/*\nhandle @researchFeed {\n reverse_proxy 127.0.0.1:23367\n}\n')
    os.chmod(route,0o644)
    body=config.read_text();line=' import /etc/caddy/sa-research-feed.caddy\n'
    if line not in body:
        marker=' import /etc/caddy/sa-comments.caddy\n'
        if body.count(marker)!=1: raise RuntimeError('Unexpected Caddy owner configuration')
        config.write_text(body.replace(marker,marker+line))
    titles=[];native_site=None
    if p['titlePlan'] or p['enableEA'] or p['enableBA'] or p['enableARB']:
        script="""
import {readFileSync} from 'node:fs';
import {createHmac} from 'node:crypto';
import {updateNativePageTitles} from './comments-page-titles.mjs';
import {ensureEnterpriseSite,ensureNativeSite} from './comments-native-site.mjs';
import {commentSites} from './comments-location.mjs';
const config=JSON.parse(readFileSync('/opt/sa-artalk/admin-config.json','utf8'));
const encode=value=>Buffer.from(JSON.stringify(value)).toString('base64url');
const request=async(path,method='GET',body)=>{
 const now=Math.floor(Date.now()/1000),unsigned=encode({alg:'HS256',typ:'JWT'})+'.'+encode({user_id:config.userId,iat:now,exp:now+20});
 const token=unsigned+'.'+createHmac('sha256',config.appKey).update(unsigned).digest('base64url');
 const response=await fetch('http://127.0.0.1:23366'+path,{method,headers:{authorization:'Bearer '+token,'content-type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),redirect:'error',signal:AbortSignal.timeout(5000)});
 if(!response.ok)throw Error('Native title operation failed');const data=await response.json();return data.data??data;
};
const plan=JSON.parse(readFileSync(0,'utf8'));
console.log(JSON.stringify({titles:await updateNativePageTitles(plan.titles,request),nativeSite:plan.enableEA?await ensureEnterpriseSite(request):plan.enableBA?await ensureNativeSite(request,commentSites.ba):plan.enableARB?await ensureNativeSite(request,commentSites.arb):null}));
"""
        result=subprocess.run([str(base/'node'),'--input-type=module','-e',script],cwd=base,input=json.dumps({'titles':p['titlePlan'],'enableEA':p['enableEA'],'enableBA':p['enableBA'],'enableARB':p['enableARB']}),capture_output=True,text=True,timeout=30)
        if result.returncode: raise RuntimeError('Native title plan failed; inspect reviewed state before retry')
        native_result=json.loads(result.stdout);titles=native_result['titles'];native_site=native_result['nativeSite']
    if p['enableEA'] or p['enableBA'] or p['enableARB']:
        site='arb' if p['enableARB'] else 'ba' if p['enableBA'] else 'ea'
        credential=base/(site+'-origin-secret')
        if not credential.exists():credential.write_text(secrets.token_urlsafe(48))
        os.chmod(credential,0o640);run(['chown','root:sa-comments',str(credential)])
        contexts=[]
        for context in ['sa','ea','ba','arb']:
            path=base/('origin-secret' if context=='sa' else context+'-origin-secret')
            if path.exists():contexts.append((context,path.read_text().strip()))
        if any(len(value)<48 or any(not(c.isalnum() or c in '_-') for c in value) for _,value in contexts) or len(set(value for _,value in contexts))!=len(contexts):raise RuntimeError('Invalid origin credentials')
        comments_route.write_text(''.join('@'+context+'Comments {\n path /comments/*\n header X-'+context.upper()+'-Comments-Origin '+value+'\n}\nhandle @'+context+'Comments {\n uri strip_prefix /comments\n reverse_proxy 127.0.0.1:23367\n}\n' for context,value in contexts))
        os.chmod(comments_route,0o640);run(['chown','root:caddy',str(comments_route)])
    run(['caddy','validate','--config',str(config)])
    run(['systemctl','restart','sa-comments-gateway'])
    run(['systemctl','is-active','sa-comments-gateway'])
    # systemd Type=simple becomes active before Node has opened its listener.
    for attempt in range(25):
        try:
            with socket.create_connection(('127.0.0.1',23367),timeout=1):break
        except OSError:
            if attempt==24:raise RuntimeError('Comments gateway did not become ready')
            time.sleep(0.2)
    run(['systemctl','reload','caddy'])
    print(json.dumps({'gatewaySha256':hashlib.sha256((base/'comments-gateway.mjs').read_bytes()).hexdigest(),
      'feedSha256':hashlib.sha256((base/'comments-research-feed.mjs').read_bytes()).hexdigest(),
      'credentialMode':oct(secret.stat().st_mode & 0o777),'services':'active','nativeTitles':titles,'nativeSite':native_site,
      'credentialPath':str(credential) if p['enableEA'] or p['enableBA'] or p['enableARB'] else None}))
except Exception:
    for filename,value in before.items():
        path=pathlib.Path(filename)
        if value is None: path.unlink(missing_ok=True)
        else: path.write_bytes(value[0]);os.chmod(path,value[1])
    subprocess.run(['systemctl','restart','sa-comments-gateway'],capture_output=True)
    subprocess.run(['systemctl','reload','caddy'],capture_output=True)
    raise RuntimeError('Feed deployment failed and source/configuration rollback was attempted') from None
'''
ssh = ['ssh','-i',str(args.identity),'-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',args.host]
result = subprocess.run(ssh+['sudo -n python3 -c '+shlex.quote(remote)],
    input=json.dumps({'files':files,'token':token,'titlePlan':title_plan,'enableEA':args.enable_ea_site,'enableBA':args.enable_ba_site,'enableARB':args.enable_arb_site}),capture_output=True,text=True)
if result.returncode:
    raise RuntimeError('Remote comments feed deployment failed; credential output suppressed')
deployed = json.loads(result.stdout)
origin = 'https://comments.sa.hm.sparklingideas.co.uk'
def fetch(path, credential=None, context=False):
    headers={'Authorization':'Bearer '+credential} if credential else {}
    if context: headers['X-EA-Comment-Context']=context if isinstance(context,str) else 'v1'
    request=urllib.request.Request(origin+path,headers=headers)
    try:
        with urllib.request.urlopen(request,timeout=15) as response:
            body=response.read(9*1024*1024)
            return response.status,json.loads(body)
    except urllib.error.HTTPError as error:
        return error.code,None
status,snapshot=fetch('/research-feed/snapshot',token)
assert status==200 and snapshot['schema']=='sa-comment-snapshot/v1' and snapshot['complete'] is True
context_status,context_snapshot=fetch('/research-feed/snapshot',token,True)
assert context_status==200 and context_snapshot['complete'] is True
assert all('location' in row and 'pageTitle' in row for row in context_snapshot['records'])
if args.enable_ea_site:
    combined_status,combined=fetch('/research-feed/snapshot',token,'v2')
    assert combined_status==200 and combined['schema']=='artalk-comment-snapshot/v2' and combined['sites']==['sa','ea'] and combined['complete'] is True
unsigned,_=fetch('/research-feed/snapshot')
admin,_=fetch('/research-feed/admin/api/v2/comments',token)
assert unsigned==403 and admin==404
receipt={'schema':'sa-comments-feed-release/v1','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'origin':origin,'credentialSecretArn':arn,'host':'sa-artalk','deployed':deployed,
    'checks':{'authenticatedSnapshot':status,'unsignedRejected':unsigned,'adminRouteAbsent':admin,
        'complete':snapshot['complete'],'records':len(snapshot['records']),'sourceVersion':snapshot['version'],
        'contextSnapshot':context_status,'contextRecords':len(context_snapshot['records']),'contextSourceVersion':context_snapshot['version'],
        **({'combinedSnapshot':combined_status,'combinedSites':combined['sites'],'combinedRecords':len(combined['records']),'combinedSourceVersion':combined['version']} if args.enable_ea_site else {})},
    'files':{name:hashlib.sha256(body.encode()).hexdigest() for name,body in files.items()}}
args.receipt.parent.mkdir(parents=True,exist_ok=True)
args.receipt.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'deployed','secretArn':arn,'checks':receipt['checks'],'receipt':str(args.receipt)}))
