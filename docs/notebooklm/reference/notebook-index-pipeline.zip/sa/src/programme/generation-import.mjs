/** Decode and render tracked SA media through the existing EA custody helpers. */
import fs from 'node:fs/promises';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {root,load,frozenBrief,reconcileCatalogueQuality} from './generation-state.mjs';
import {sharedRenderer} from './shared-renderer.mjs';
export function shouldImport(job,{approvedOnly=false,uploaded=false}={}){
  if(job.status!=='completed' || !job.id || !job.providerProof?.settingsVerified || (!uploaded && job.qualityReview?.status==='rejected'))return false;
  return !approvedOnly || job.qualityReview?.status==='approved';
}
export function verifiedCustody(){
  // The authoritative receipt parser stays owned by the custody worker.
  const script=`import importlib.util, json, sys\nsys.dont_write_bytecode=True\nspec=importlib.util.spec_from_file_location('custody', 'src/programme/generation-transfer-worker.py')\nm=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\nprint(json.dumps(m.load_verified_state(m.DEFAULT_RECEIPT)))`;
  return JSON.parse(execFileSync('python3',['-c',script],{cwd:root,encoding:'utf8',maxBuffer:4e6,env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'}}));
}
export function custodyKey(run,job){
  const ext={infographic:'png',audio:'m4a',video:'mp4',slide_deck:'pdf'}[job.type];
  if(!ext || !/^[a-f0-9-]{36}$/.test(run.notebookId??'') || !/^[a-f0-9-]{36}$/.test(job.id??''))throw Error('Invalid custody identity');
  return `custody/generation/${run.notebookId}/${job.id}.${ext}`;
}
export function publicationAttempts(run){return run.jobs.flatMap(job=>[job,...(job.attemptHistory??[])].map(attempt=>({job,attempt,retained:attempt!==job})));}
export function mediaIdentity(job){
  if(!/^[a-z0-9_-]+$/.test(job.key??'') || !/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(job.id??''))throw Error('Invalid media identity');
  return job.key.replaceAll('_','-')+'-'+job.id;
}
export async function resolveOriginal(source,url,{uploaded=false,custodySha,existing,details}){
  let record,local=true;
  try{record=await details(source,url);}
  catch(error){
    if(error.code!=='ENOENT' || !uploaded || existing?.original?.sha256!==custodySha || !(existing.original.bytes>0))throw error;
    record={...existing.original,path:url};local=false;
  }
  if(uploaded && record.sha256!==custodySha)throw Error('Original lacks exact verified remote custody');
  if(existing && (record.sha256!==existing.original.sha256 || record.bytes!==existing.original.bytes))throw Error('Downloaded original changed');
  return {record,local};
}
if(process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  if(process.argv.length>4 || (process.argv[3] && !['--approved-only','--uploaded'].includes(process.argv[3])))throw Error('Usage: generation-import.mjs <section> [--approved-only|--uploaded]');
  const approvedOnly=process.argv[3]==='--approved-only';
  const uploaded=process.argv[3]==='--uploaded',custody=uploaded?verifiedCustody():{};
  const shared=sharedRenderer().directory;
  const helper=name=>pathToFileURL(path.resolve(shared,'site/scripts',name)).href;
  const {copyVerified,details,prepareRenditions}=await import(helper('media-originals.mjs'));
  const {renderPdfSlides}=await import(helper('pdf-slide-images.mjs'));
  const section=process.argv[2];
  const {run}=load(section);
  const prefix=`/presentations/sa-${section}/media/`;
  const destination=path.join(root,'.local/artefact-generation/public',prefix);
  const catalogueFile=path.join(root,'docs/generation/catalogues',section+'.json');
  let catalogue={sourceCommit:run.sourceCommit,notebookId:run.notebookId,sectionId:section,prefix,decks:[],multimedia:[]};
  try{catalogue=JSON.parse(await fs.readFile(catalogueFile,'utf8'));}catch(error){if(error.code!=='ENOENT')throw error;}
  if(catalogue.sourceCommit!==run.sourceCommit || catalogue.notebookId!==run.notebookId)throw Error('Media catalogue identity mismatch');
  await fs.mkdir(destination,{recursive:true});
  await fs.mkdir(path.dirname(catalogueFile),{recursive:true});
  const extensions={infographic:'png',audio:'m4a',video:'mp4',slide_deck:'pdf'};
  const save=async()=>{
    const {decks,multimedia,...header}=catalogue;
    const pending=catalogueFile+'.tmp';
    await fs.writeFile(pending,JSON.stringify(header).slice(0,-1)+',"decks":[\n'+decks.map(d=>JSON.stringify(d)).join(',\n')+'\n],"multimedia":[\n'+multimedia.map(m=>JSON.stringify(m)).join(',\n')+'\n]}\n');await fs.rename(pending,catalogueFile);
  };
  reconcileCatalogueQuality(run,catalogue,{includeRejected:uploaded,includeHistory:uploaded});await save();
  const failures=[],verifiedSubjects=new Set();
  for(const {job:current,attempt:job,retained} of publicationAttempts(run)){
    if(!shouldImport(job,{approvedOnly,uploaded}) || (retained && !uploaded))continue;
    if(uploaded && !custody[custodyKey(run,job)])continue;
    try{
    if(!/^[a-z0-9_-]+$/.test(job.key))throw Error('Invalid media key');
    const subject=run.subjects.find(s=>s.id===job.subject);
    const expected=[...subject.factualSourceIds,...(job.editorial?[subject.editorialSourceId]:[])].sort();
    if(JSON.stringify(job.providerProof.sourceIds)!==JSON.stringify(expected))throw Error('Unverified actual source scope');
    if(job.providerProof.promptSha256!==subject.promptHashes[job.medium])throw Error('Unverified actual prompt');
    if(!verifiedSubjects.has(job.subject)){frozenBrief(run,job.subject);verifiedSubjects.add(job.subject);}
    const source=path.join(root,'.local/artefact-generation',retained?'rejected':'originals',(retained?job.id:job.key)+'.'+extensions[job.type]);
    const group=job.type==='slide_deck'?catalogue.decks:catalogue.multimedia;
    const id=mediaIdentity(job);
    const target=path.join(destination,id+'.'+extensions[job.type]);
    const originalUrl=uploaded?'/'+custodyKey(run,job):prefix+path.basename(target);
    let existing=group.find(item=>item.id===job.id);
    let resolved;
    try{resolved=await resolveOriginal(source,originalUrl,{uploaded,custodySha:custody[custodyKey(run,job)],existing,details});}
    catch(error){if(error.code==='ENOENT' && !uploaded)continue;throw error;}
    const actual=resolved.record;
    if(job.qualityReview && (job.qualityReview.providerId!==job.id || job.qualityReview.originalSha256!==actual.sha256))throw Error('Quality review belongs to another original');
    if(existing){
      // Reuse the existing private S3 object, never copy/upload the original
      // under another key. Renditions still use provider-specific media URLs.
      existing.original={...existing.original,path:originalUrl};
      if(job.type==='slide_deck')existing.pdf=originalUrl;
      const records=[...(!uploaded?[existing.original]:[]),existing.preview,existing.poster,existing.cover,...(existing.slides??[]),...(existing.thumbnails??[])].filter(Boolean);
      let reusable=job.type==='slide_deck'?Boolean(existing.cover && existing.slides?.length && existing.slideCount===existing.slides.length && existing.thumbnails?.length===existing.slideCount):job.type==='infographic'?Boolean(existing.preview):job.type==='video'?Boolean(existing.poster && existing.duration>0):existing.duration>0;
      if(job.type==='slide_deck' && existing.slug!==id)reusable=false;
      for(const record of records){
        if(!record.path.startsWith(prefix+id) || record.path.includes('..')){reusable=false;break;}
        try{
          const actual=await details(path.join(root,'.local/artefact-generation/public',record.path),record.path);
          if(actual.sha256!==record.sha256 || actual.bytes!==record.bytes){reusable=false;break;}
        }catch(error){if(error.code!=='ENOENT')throw error;reusable=false;break;}
      }
      if(!reusable){
        if(!resolved.local){const error=Error('Local bytes are needed to repair missing renditions');error.code='RENDER_PENDING';throw error;}
        group.splice(group.indexOf(existing),1);existing=null;
      }
    }
    if(existing){
      existing.qualityStatus=job.qualityReview?.status??'pending';existing.retainedAttempt=retained;
      existing.publicationKey=retained?`${job.key}--${job.id}`:job.key;
      existing.title=job.title+(retained?' · Previous attempt':'');
      if(retained)existing.description=existing.title;
      await save();
      continue;
    }
    let original=actual;
    if(!uploaded){await copyVerified(source,target);original=await details(target,originalUrl);}
    const common={id:job.id,key:current.key,publicationKey:retained?`${current.key}--${job.id}`:current.key,retainedAttempt:retained,subject:job.subject,level:job.level,type:job.type,format:job.format,editorial:job.editorial,version:job.version,ordinal:job.ordinal,title:job.title+(retained?' · Previous attempt':''),
      notebook:`https://notebooklm.google.com/notebook/${run.notebookId}?artifactId=${job.id}`,
      sourceCommit:run.sourceCommit,sourceIds:expected,promptSha256:job.providerProof.promptSha256,qualityStatus:job.qualityReview?.status??'pending',importedAt:new Date().toISOString()};
    if(job.type==='slide_deck'){
      const rendered=await renderPdfSlides({pdf:source,destination,id,urlPrefix:prefix,width:1376,renderer:'pdfium'});
      if(!uploaded && rendered.slides.some(s=>s.width<=s.height))throw Error('Non-landscape deck');
      group.push({...common,slug:id,pdf:original.path,original,slideCount:rendered.slides.length,cover:rendered.slides[0],...rendered});
    }else{
      const media=await prepareRenditions({original:source,destination,id,type:job.type,preview:prefix+id+'-preview.webp',poster:prefix+id+'-poster.webp'});
      if(!uploaded && job.type==='infographic' && media.width<=media.height)throw Error('Non-landscape infographic');
      group.push({...common,description:retained?common.title:(job.generatedTitle||job.title),original:{...original,width:media.width,height:media.height},preview:media.preview,poster:media.poster,duration:media.duration});
    }
    await save();
    console.log(JSON.stringify({imported:job.key,id:job.id,count:catalogue.decks.length+catalogue.multimedia.length}));
    }catch(error){
      if(!uploaded)throw error;
      const group=job.type==='slide_deck'?catalogue.decks:catalogue.multimedia;
      const poisoned=group.findIndex(item=>item.id===job.id);
      if(poisoned>=0 && error.code!=='RENDER_PENDING')group.splice(poisoned,1);
      failures.push({key:current.key,id:job.id,retainedAttempt:retained,error:error.message});
      console.log(JSON.stringify({importFailed:job.id,error:error.message}));
    }
  }
  if(uploaded){catalogue.importFailures=failures;await save();console.log(JSON.stringify({section,importFailures:failures.length}));}
}
