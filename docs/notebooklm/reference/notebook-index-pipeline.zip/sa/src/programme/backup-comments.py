#!/usr/bin/env python3
"""Consistent Artalk SQLite backup; never access Ruflo/AgentDB memory stores."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tarfile
import tempfile
import uuid
import boto3


def snapshot(source, target):
    with sqlite3.connect(f'file:{source}?mode=ro', uri=True) as live:
        with sqlite3.connect(target) as copy:
            live.backup(copy, pages=128, sleep=0.05)
            if copy.execute('PRAGMA integrity_check').fetchall() != [('ok',)]:
                raise RuntimeError('Artalk backup failed integrity check')


def main():
    os.umask(0o077)
    root = Path('/opt/sa-artalk')
    config = json.loads((root / 'backup-credentials.json').read_text())
    s3 = boto3.client('s3', region_name='eu-west-2',
                      aws_access_key_id=config['AccessKeyId'],
                      aws_secret_access_key=config['SecretAccessKey'])
    now = datetime.datetime.now(datetime.timezone.utc)
    with tempfile.TemporaryDirectory(prefix='sa-artalk-backup-') as work:
        database = Path(work) / 'artalk.db'
        snapshot(root / 'data/artalk.db', database)
        digest = hashlib.sha256(database.read_bytes()).hexdigest()
        archive = Path(work) / 'backup.tar.gz'
        with tarfile.open(archive, 'w:gz') as bundle:
            bundle.add(database, arcname='data/artalk.db')
            for name in ['data/artalk.yml', 'gateway-key', 'gateway.env', 'origin-secret']:
                bundle.add(root / name, arcname=name)
            if (root / 'admin-config.json').is_file():
                bundle.add(root / 'admin-config.json', arcname='admin-config.json')
            if (root / 'ea-origin-secret').is_file():
                bundle.add(root / 'ea-origin-secret', arcname='ea-origin-secret')
            if (root / 'ba-origin-secret').is_file():
                bundle.add(root / 'ba-origin-secret', arcname='ba-origin-secret')
        key = f'hourly/{now:%Y/%m/%d/%H%M%S}-{uuid.uuid4().hex}.tar.gz'
        with archive.open('rb') as body:
            result = s3.put_object(Bucket=config['Bucket'], Key=key, Body=body,
                                   ServerSideEncryption='AES256', ChecksumAlgorithm='SHA256',
                                   Metadata={'database-sha256': digest})
        receipt = {'at': now.isoformat(), 'bucket': config['Bucket'], 'key': key,
                   'versionId': result['VersionId'], 'databaseSha256': digest}
        pending = root / 'backup-last-success.tmp'
        pending.write_text(json.dumps(receipt) + '\n')
        pending.replace(root / 'backup-last-success.json')
        print(json.dumps(receipt))


if __name__ == '__main__':
    main()
