"""Supervise the three existing artefact stages independently of this chat.

Run through the user's LaunchAgent, using the installed NotebookLM interpreter
and explicit tool PATH. No model, authentication or database settings change.
"""
import argparse
import datetime
import importlib.util
import json
import os
import plistlib
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / '.local/artefact-generation'
SDK_PYTHON = Path.home() / '.local/share/uv/tools/notebooklm-mcp-cli/bin/python3'
LABEL = 'co.uk.sparklingideas.sa-artefacts'
PLIST = Path.home() / 'Library/LaunchAgents' / (LABEL + '.plist')
LOGS = WORK / 'transfers'
CONTROL = WORK / 'generation-control.json'
STATE = WORK / 'pipeline/supervisor-status.json'

spec = importlib.util.spec_from_file_location('ownership', ROOT / 'src/programme/generation-ownership.py')
ownership = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ownership)


def commands():
    common = [str(SDK_PYTHON)]
    source = ROOT / 'src/programme'
    return {
        'generation': common + [str(source / 'generation-worker.py'), '--persistent', '--skip-downloads',
                               '--control-config', str(CONTROL)],
        'custody': common + [str(source / 'generation-transfer-worker.py'), '--persistent', '--skip-indexes',
                            '--workers', '32', '--download-concurrency', '32', '--interval', '45'],
        'index': common + [str(source / 'generation-index-publication.py'), '--persistent', '--workers', '32',
                           '--render-concurrency', '4', '--interval', '30'],
    }


def pinned_environment():
    if not SDK_PYTHON.is_file():
        raise RuntimeError('Installed NotebookLM interpreter is unavailable')
    # The shared EA renderer invokes python3 from this same pinned PATH.
    # Prove its PDF/image dependencies before starting a durable publication loop.
    subprocess.run([str(SDK_PYTHON), '-c', 'import notebooklm_tools, pypdfium2, PIL'],
                   check=True, capture_output=True)
    node = subprocess.check_output(['node', '-p', 'process.execPath'], text=True).strip()
    directories = [str(SDK_PYTHON.parent), str(Path(node).parent), '/opt/homebrew/bin',
                   '/usr/bin', '/bin', '/usr/sbin', '/sbin']
    path = ':'.join(dict.fromkeys(directories))
    for tool in ('node', 'npm', 'aws', 'ffmpeg', 'ffprobe'):
        if not shutil.which(tool, path=path):
            raise RuntimeError('Required pipeline executable is unavailable: ' + tool)
    return {'PATH': path, 'PYTHONDONTWRITEBYTECODE': '1'}


def write_supervisor(children, restarts, **fields):
    ownership.write_stage_status('supervisor', fields.pop('phase', 'running'),
        children={name: {'pid': process.pid, 'argv': commands()[name],
                         'birth': getattr(process, 'birth', None)}
                  for name, process in children.items()}, restarts=restarts, **fields)


def process_identity(pid):
    result = subprocess.run(['/bin/ps', '-p', str(pid), '-o', 'lstart=', '-o', 'command='],
                            capture_output=True, text=True)
    if result.returncode:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return None
        raise RuntimeError('Live stage identity cannot be read')
    fields = result.stdout.strip().split(maxsplit=5)
    if len(fields) != 6:
        raise RuntimeError('Stage identity response is incomplete')
    return {'birth': ' '.join(fields[:5]), 'command': fields[5]}


def stop_group(pid, argv=None, birth=None, signum=signal.SIGTERM, allow_orphan=False):
    identity = process_identity(pid)
    if identity is None:
        if allow_orphan and birth:
            try:
                os.killpg(pid, signum)
            except ProcessLookupError:
                pass
        return
    if argv and (identity['command'] != ' '.join(argv) or identity['birth'] != birth):
        raise RuntimeError('Stage PID identity changed; refusing a signal')
    try:
        if os.getpgid(pid) != pid:
            raise RuntimeError('Stage process group ownership is ambiguous')
        os.killpg(pid, signum)
    except ProcessLookupError:
        return


def recover_owned_children():
    """A supervisor crash must not leave an untracked stage beside a new one."""
    if not STATE.is_file():
        return
    retained = json.loads(STATE.read_text()).get('children', {})
    expected = commands()
    verified = []
    for name, record in retained.items():
        pid = record.get('pid')
        if name not in expected or type(pid) is not int or pid < 2 or record.get('argv') != expected[name]:
            raise RuntimeError('Unknown retained stage identity; refusing recovery')
        identity = process_identity(pid)
        if identity is None:
            # A stale PGID alone cannot establish group identity. The stages'
            # parent guard drains orphans; writer children retain the advisory
            # descriptor until they finish, so a new writer cannot overlap.
            continue
        if identity['command'] != ' '.join(expected[name]) or identity['birth'] != record.get('birth'):
            raise RuntimeError('Retained stage PID no longer matches its command')
        stop_group(pid, expected[name], record['birth'])
        verified.append(record)
    for record in verified:
        pid = record['pid']
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                break
            time.sleep(.1)
        else:
            # PID and process-group identity were verified above. Do not allow
            # a second generation owner while its child RPC is still running.
            stop_group(pid, record['argv'], record['birth'], signal.SIGKILL)


def serve():
    environment = os.environ.copy()
    environment.update(pinned_environment())
    environment['SA_PIPELINE_SUPERVISOR_PID'] = str(os.getpid())
    for name in ('ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'OPENAI_API_KEY', 'OPENROUTER_API_KEY'):
        environment.pop(name, None)
    LOGS.mkdir(parents=True, exist_ok=True)
    stop = False

    def request_stop(*_):
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)
    children, streams, restarts, next_start = {}, {}, {}, {}
    with ownership.StageLock('supervisor'):
        recover_owned_children()
        try:
            while not stop:
                desired = json.loads(CONTROL.read_text()).get('desiredState', 'run')
                for stage, argv in commands().items():
                    child = children.get(stage)
                    if child and child.poll() is not None:
                        code = child.returncode
                        stop_group(child.pid, child.args, child.birth, allow_orphan=True)
                        children.pop(stage)
                        streams.pop(stage).close()
                        restarts[stage] = restarts.get(stage, 0) + 1
                        next_start[stage] = time.monotonic() + (10 if code == 0 else 30)
                    if stage not in children and (stage != 'generation' or desired == 'run'):
                        if time.monotonic() >= next_start.get(stage, 0):
                            stream = open(LOGS / ('pipeline-' + stage + '.log'), 'ab', buffering=0)
                            children[stage] = subprocess.Popen(argv, cwd=ROOT, env=environment,
                                stdin=subprocess.DEVNULL, stdout=stream, stderr=stream, start_new_session=True)
                            streams[stage] = stream
                            identity = process_identity(children[stage].pid)
                            if identity is None:
                                children.pop(stage).wait(timeout=1)
                                streams.pop(stage).close()
                                restarts[stage] = restarts.get(stage, 0) + 1
                                next_start[stage] = time.monotonic() + 30
                                continue
                            children[stage].birth = identity['birth']
                            write_supervisor(children, restarts)
                write_supervisor(children, restarts)
                time.sleep(2)
        finally:
            for child in children.values():
                if child.poll() is None:
                    stop_group(child.pid, child.args, child.birth)
            for child in children.values():
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    stop_group(child.pid, child.args, child.birth, signal.SIGKILL)
                    child.wait()
            for stream in streams.values():
                stream.close()
            write_supervisor({}, restarts, phase='stopped')


def install():
    environment = pinned_environment()
    if PLIST.exists() and plistlib.loads(PLIST.read_bytes()).get('WorkingDirectory') != str(ROOT):
        raise RuntimeError('LaunchAgent belongs to another checkout')
    WORK.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    if not CONTROL.exists():
        CONTROL.write_text(json.dumps({'schemaVersion': 1, 'desiredState': 'run',
            'reconcileSeconds': 30, 'probeBackoffSeconds': 60}) + '\n')
    payload = {'Label': LABEL, 'ProgramArguments': [str(SDK_PYTHON), str(Path(__file__).resolve()), '--serve'],
        'WorkingDirectory': str(ROOT), 'EnvironmentVariables': environment,
        'RunAtLoad': True, 'KeepAlive': True, 'ThrottleInterval': 10, 'ProcessType': 'Background',
        'StandardOutPath': str(LOGS / 'pipeline-service.log'),
        'StandardErrorPath': str(LOGS / 'pipeline-service-error.log')}
    PLIST.parent.mkdir(parents=True, exist_ok=True)
    pending = PLIST.with_suffix('.pending')
    pending.write_bytes(plistlib.dumps(payload))
    os.chmod(pending, 0o600)
    pending.replace(PLIST)
    domain = 'gui/' + str(os.getuid())
    existing = subprocess.run(['launchctl', 'print', domain + '/' + LABEL], capture_output=True)
    if existing.returncode == 0:
        subprocess.run(['launchctl', 'bootout', domain + '/' + LABEL], check=True)
    subprocess.run(['launchctl', 'bootstrap', domain, str(PLIST)], check=True)
    subprocess.run(['launchctl', 'kickstart', domain + '/' + LABEL], check=True)
    print(json.dumps({'service': LABEL, 'installed': True, 'launchAgent': str(PLIST)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--serve', action='store_true')
    parser.add_argument('--install', action='store_true')
    args = parser.parse_args()
    if args.serve == args.install:
        parser.error('Select exactly one of --serve or --install')
    try:
        install() if args.install else serve()
    except Exception as error:
        print(json.dumps(ownership.safe_error(error)), flush=True)
        raise SystemExit(1)
