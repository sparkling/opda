import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { safePath } from '../corpus/policy.mjs';
import { verbatimExcerpt } from '../corpus/discovery-review.mjs';

export function validateSources(root, brief, bundles, publication) {
  if (brief.factualSourceIds) {
    const expected = [...new Set(brief.sources.filter(s=>s.admission==='admitted').map(s=>s.notebookSourceId))].sort();
    if (JSON.stringify([...brief.factualSourceIds].sort()) !== JSON.stringify(expected)) throw Error(`Factual source selection differs: ${brief.id}`);
  }
  if (!brief.sources.some(s => s.role === 'primary')) throw Error(`No primary evidence: ${brief.id}`);
  for (const source of brief.sources) {
    if (source.pathScope && !['local','sibling','upstream'].includes(source.pathScope)) throw Error(`Source scope: ${brief.id}`);
    if (source.pathScope === 'sibling' && !/^[a-f0-9]{64}$/.test(source.sha256 ?? '')) throw Error(`Sibling digest missing: ${brief.id}`);
    if (!['primary','supporting'].includes(source.role)) throw Error(`Source role: ${brief.id}`);
    if (!['admitted','reference-only','pending'].includes(source.admission)) throw Error(`Admission state: ${brief.id}`);
    if (!source.path) throw Error(`Missing source path: ${brief.id}`);
    if (source.pathScope === 'sibling') {
      if (!/^\.\.\/(semantic-control|semantic-fabric)\//.test(source.path)) throw Error(`Invalid sibling path: ${brief.id}`);
      safePath(source.path.split('/').slice(2).join('/'));
    } else safePath(source.path);
    const retainedOrigin = source.pathScope === 'local' && source.url === null &&
      ['commit-unavailable-on-visible-repository','working-tree-no-remote-body','git-stash-local-only'].includes(source.urlStatus) &&
      /^[a-f0-9]{64}$/.test(source.sha256 ?? '') && source.repository && source.upstreamPath &&
      ((/^[a-f0-9]{40}$/.test(source.revision ?? '') && /^[a-f0-9]{40}$/.test(source.gitBlob ?? '')) ||
        (source.revision === null && /^[a-f0-9]{40}$/.test(source.sourceCheckoutCommit ?? '') &&
         source.custody === 'Exact reviewed working-tree evidence; no Git-original claim'));
    const retainedExcerpt = source.pathScope === 'local' && source.url === null && source.urlStatus === 'derived-excerpt-of-retained-body' &&
      source.custody === 'Reviewed verbatim excerpt; original preserved separately' && /^[a-f0-9]{64}$/.test(source.sha256 ?? '') && source.derivedFrom;
    if (!/^https:\/\//.test(source.url ?? '') && !retainedOrigin && !retainedExcerpt) throw Error(`Invalid source URL or retained origin: ${brief.id}`);
    if (source.pathScope === 'upstream') {
      if (source.admission === 'admitted' || source.notebookSourceId || !source.url.includes('/blob/') || !decodeURI(source.url).endsWith(source.path)) throw Error(`Invalid pending upstream reference: ${brief.id}`);
    } else {
      if (!fs.existsSync(path.resolve(root, source.path))) throw Error(`Missing local source path: ${source.path}`);
      if (source.admission !== 'reference-only' && !/^[a-f0-9]{64}$/.test(source.sha256 ?? '')) throw Error(`Local source digest missing: ${brief.id}`);
      const bytes = fs.readFileSync(path.resolve(root, source.path));
      if (source.sha256 && crypto.createHash('sha256').update(bytes).digest('hex') !== source.sha256) throw Error(`Source changed since authoring: ${brief.id}: ${source.path}`);
      if (source.gitBlob && crypto.createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex') !== source.gitBlob) throw Error(`Source Git blob differs: ${brief.id}: ${source.path}`);
      if (retainedExcerpt) {
        safePath(source.derivedFrom.file);
        if (!bytes.equals(verbatimExcerpt(fs.readFileSync(path.resolve(root, source.derivedFrom.file)), source.derivedFrom))) throw Error(`Excerpt differs from original: ${brief.id}`);
      }
    }
    if (source.admission === 'admitted') {
      const upload = publication.find(u => u.sourceId === source.notebookSourceId &&
        bundles.some(b => b.key === u.key && b.sha256 === u.sha256 && b.members.some(m => m.file === source.path)));
      const bundle = bundles.find(b => b.key === upload?.key && b.sha256 === upload.sha256);
      const member = bundle?.members.find(m => m.file === source.path);
      const actual = crypto.createHash('sha256').update(fs.readFileSync(path.resolve(root, source.path))).digest('hex');
      if (!upload || member?.sha256 !== actual) throw Error(`Unverified admitted source: ${brief.id}: ${source.path}`);
    } else if (source.notebookSourceId) throw Error(`Unadmitted source carries NotebookLM ID: ${brief.id}`);
  }
  if (brief.factualInput?.state === 'indexed-verified') {
    const selected = new Set(brief.sources.filter(s => s.admission === 'admitted').map(s => s.path));
    const activated = new Set();
    const verification = JSON.parse(fs.readFileSync(path.resolve(root, 'docs/notebooklm/subsections/indexed-verification.json'), 'utf8'));
    for (const sourceId of brief.factualSourceIds) {
      const upload = publication.find(u => u.sourceId === sourceId);
      const bundle = bundles.find(b => b.key === upload?.key && b.sha256 === upload.sha256);
      if (bundle?.subject !== brief.id || bundle.role !== 'factual') throw Error(`Non-isolated factual input: ${brief.id}`);
      if (!verification.checks.some(c => c.sourceId === sourceId && c.key === bundle.key && c.sha256 === bundle.sha256 && c.status === 'success')) throw Error(`Missing indexed factual input: ${brief.id}`);
      for (const member of bundle.members) activated.add(member.file);
    }
    if (JSON.stringify([...activated].sort()) !== JSON.stringify([...selected].sort())) throw Error(`Expanded factual input differs: ${brief.id}`);
    if (!brief.factualSourceIds.length) throw Error(`Missing indexed factual input: ${brief.id}`);
  }
}
