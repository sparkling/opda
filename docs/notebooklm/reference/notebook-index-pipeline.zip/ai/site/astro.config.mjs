import {defineConfig} from 'astro/config';
import react from '@astrojs/react';
import tailwindcss from '@tailwindcss/vite';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {prepareSharedAssets} from '../../semantic-solution-architecture/src/programme/prepare-site.mjs';
const sourceRoot=new URL('../',import.meta.url);
const root=fileURLToPath(sourceRoot);
const renderer=JSON.parse(execFileSync('python3',['-c',`import importlib.util,json,sys
from pathlib import Path
root=Path(sys.argv[1]); spec=importlib.util.spec_from_file_location('renderer',root.parent/'semantic-solution-architecture/src/programme/shared-renderer.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);print(json.dumps(m.resolve_renderer(root)))`,root],{encoding:'utf8'}));
prepareSharedAssets(root,renderer);
const surface=process.env.AI_BA_SITE_SURFACE;
// Separate build surfaces: the stakeholder website (src), the Notebook index and the retained legacy architecture pages.
const surfaceDir={notebooks:{srcDir:'./notebooks',outDir:'./dist-notebooks'},architecture:{srcDir:'./architecture',outDir:'./dist-architecture'}}[surface]??{};
export default defineConfig({site:'https://ba.ai.hm.sparklingideas.co.uk',output:'static',trailingSlash:'always',
  ...surfaceDir,
  integrations:[react()],devToolbar:{enabled:false},server:{host:'127.0.0.1',port:8914},
  vite:{plugins:[tailwindcss()],define:{'import.meta.env.AI_BA_SOURCE_ROOT':JSON.stringify(sourceRoot.href)},resolve:{alias:{'@ea':path.join(renderer.directory,'site/src')},dedupe:['react','react-dom']},server:{strictPort:true,fs:{allow:[path.dirname(root)]}}},
});
