import {readFileSync,existsSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {repositoryRoot} from '../../../scripts/notebooks/inventory.mjs';
const configs=new Map();
export function communicationAt(commit){
  if(!configs.has(commit))configs.set(commit,JSON.parse(commit
    ?execFileSync('git',['show',`${commit}:config/authoring/notebook-communication.json`],{cwd:repositoryRoot,encoding:'utf8'})
    :readFileSync(resolve(repositoryRoot,'config/authoring/notebook-communication.json'),'utf8')));
  return configs.get(commit);
}
const sections=object=>Object.entries(object??{}).map(([name,text])=>`## ${name}\n\n${text}`).join('\n\n');
export function sharedViews(config){return [
  {id:'shared',label:'Shared purpose & audience',text:'# Shared purpose and audience\n\nApplies across chapters, section summaries and the whole collection. This directs communication; it is not factual evidence.\n\n'+config.commonPrompt},
  {id:'formats',label:'Medium & format guidance',text:'# Medium and format guidance\n\nShared instructions combined with the subject’s individual treatment. These are content directions; native settings are recorded with each submitted request.\n\n'+sections(config.mediaSuffixes)+'\n\n'+sections(config.formatCommissions)},
];}
export function instructionViews(record,subject,brief,commit,parent){
  const config=communicationAt(commit);
  const file=resolve(repositoryRoot,`docs/generation/${record.id}.json`);
  const run=existsSync(file)?JSON.parse(readFileSync(file,'utf8')):null;
  const submitted=run?.sourceCommit===commit?run.subjects.find(s=>s.id===record.id):null;
  const basis=`Input source commit: ${commit??'current authoring'}.`;
  const jobs=submitted?run.jobs.filter(j=>j.subject===record.id):[];
  const sourceText=record.sourceBindings.map(binding=>{
    const imported=submitted?.originalSources.find(s=>s.originalId===binding.originalId&&s.sha256===binding.sha256);
    return `## ${binding.title}\n\nRole: ${binding.role}\n\n${binding.contribution}\n\nSelected passage: ${binding.passage}\n\nUse: ${binding.use}\n\nLimits: ${binding.limits}\n\nOriginal: ${binding.originalId}\n\nSHA256: ${binding.sha256}\n\nNotebook title: ${config.sourceTitles?.[binding.sha256]??'No mapped title'}\n\nNotebook source ID: ${imported?.sourceId??'No matching submitted source record in this cut'}`;
  }).join('\n\n');
  const prompts=submitted?Object.entries(submitted.mediaPrompts).map(([key,prompt])=>{
    const matching=jobs.filter(j=>j.medium===key);
    const hash=createHash('sha256').update(prompt).digest('hex');
    if(matching.some(j=>j.promptSha256!==hash))throw Error(`Submitted prompt hash mismatch: ${record.id}/${key}`);
    return `## ${key}\n\n${matching.length?'Recorded requests':'Retained prompt; no matching request'}\n\n${prompt}\n\nSHA256: ${hash}\n\n`+matching.map(j=>`### ${j.editorial?'With matching synthesis':'Without synthesis'}\n\nSettings:\n\n\`\`\`json\n${JSON.stringify(j.settings,null,2)}\n\`\`\`\n\nSelected source IDs: ${(j.sourceIds??[]).join(', ')}\n\nArtefact ID: ${j.id??'Not submitted'}`).join('\n\n');
  }).join('\n\n'):'No matching submitted generation ledger is available for this published input cut. The authoring views describe the retained instructions; they do not establish submission.';
  return [
    ...sharedViews(config),
    {id:'subject',label:`${record.scopeType==='collection'?'Collection':record.scopeType==='section'?'Section':'Chapter'} brief`,text:`# ${record.id} — ${record.title}\n\n${basis}\n\nScope: ${record.scopeType}. ${parent?`Parent section: ${parent.id} — ${parent.title}.`:''}\n\n${subject.scope??''}\n\nSection and collection briefs are separate commissions, not text automatically appended to child prompts.\n\n## Subject commission\n\n${record.basePrompt}`},
    {id:'treatments',label:'Artefact treatments',text:'# Individual artefact treatments\n\n17 distinct treatments, each used with and without the matching synthesis.\n\n'+record.treatments.map(t=>`## ${t.title}\n\n${t.type} / ${t.format} / ${t.ordinal}\n\n${t.prompt}`).join('\n\n')},
    {id:'sources',label:'Evidence & source selection',text:`# Evidence and source selection\n\n${basis}\n\nLocal paths and source identities are provenance, not instructions for NotebookLM to open local files. Factual originals and communication authority are distinct selected source roles.\n\n${sourceText}`},
    {id:'synthesis',label:'Optional synthesis source',text:`# ${record.synthesis.title}\n\nAttributed interpretation, supplied as an additional source only in the with-synthesis condition. The paired prompt, other source selections and native settings remain the same.\n\n${record.synthesis.body}`},
    {id:'submitted',label:'Submitted prompts & settings',text:`# Submitted prompts and settings\n\n${basis}\n\nExact retained prompt text, settings and selected source IDs. This is distinct from the component instructions above.\n\n${prompts}`},
  ];
}
