import {instructionViews,sharedViews,communicationAt} from './instruction-views.mjs';
import {notebookInventory, reviewedAuthoring, repositoryRoot} from '../../../scripts/notebooks/inventory.mjs';
import {existsSync,readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {proposalProgramme} from './proposal-programme.mjs';
const proposal=process.env.AI_BA_NOTEBOOK_COLLECTION?proposalProgramme(repositoryRoot,process.env.AI_BA_NOTEBOOK_COLLECTION):null;
const {artwork,editionAssignments}=JSON.parse(readFileSync(resolve(repositoryRoot,'config/section-card-art.json'),'utf8'));
const raw=proposal?.inventory??notebookInventory(repositoryRoot,'adr025-20261021');
const releaseFile=resolve(repositoryRoot,'docs/generation/releases/notebook-release.json');
export const release=!proposal&&existsSync(releaseFile)?JSON.parse(readFileSync(releaseFile,'utf8')):null;
if(release && release.edition!==raw.edition)throw Error('Media release belongs to another notebook edition');
export const sections=raw.sections.map(item=>({...item,path:`/${item.id.toLowerCase()}/`}));
export const chapters=raw.chapters.map(item=>({...item,path:`/${item.sectionId.toLowerCase()}/#system-${raw.chapters.filter(chapter=>chapter.sectionId===item.sectionId).findIndex(chapter=>chapter.id===item.id)+1}`}));
export const collection=proposal?.collection??{...raw.collection,path:'/collection/',scope:'The complete joined argument across all thirteen sections.'};
export const subjects=[...chapters,...sections,collection];
export const inventory={...raw,sections,chapters,collection,subjects};
export const shell=proposal?.shell??{canonicalOrigin:'https://ba.ai.hm.sparklingideas.co.uk',brandTitle:'AI STRATEGY / BUSINESS ARCHITECTURE',
  bodyClass:'notebook-index collapsible-index',homeHref:'/',notebookUrl:release?.notebookId?`https://notebooklm.google.com/notebook/${release.notebookId}`:'#',comments:false,chat:false,
  description:'AI Strategy and Business Architecture: thirteen sections, 73 chapters and one complete collection.'};
export const pending=proposal?.pending??`${release?.available??0} of 2,958 commissioned media artefacts available across 73 chapters, thirteen section summaries and the complete collection. The accepted instructions are independently reviewed. Completed media appears here as it is published.`;
export function briefFor(subject){
  if(proposal)return proposal.briefFor(subject);
  // Existing media must retain the instructions accepted for its pinned source cut.
  const record=reviewedAuthoring(subject.id,repositoryRoot,release?.subjects?.[subject.id]?.inputSourceCommit??release?.sourceCommit??null);
  if(!record)return null;
  const gaps=release?.subjects?.[subject.id]?.sourceGaps??[];
  const brief={id:subject.id.replace('.','-'),title:`${subject.id} — ${subject.title}`,basePrompt:record.basePrompt,
    mediaPrompts:Object.fromEntries(record.treatments.map(item=>[`${item.medium} / ${item.format} / ${item.ordinal}`,item.prompt])),
    editorialTerm:'Synthesis',editorialVersion:1,editorialNote:record.synthesis.body,
    status:'Independently reviewed accepted instructions. The base prompt, selected-source guidance, shared communication brief, individual treatment and medium suffix form each generation prompt. Provider input verification and generated-media review are separate.',
    sources:record.sourceBindings.map(source=>({title:source.title,role:source.role,status:source.status,
      url:/^https?:\/\//.test(source.locator)?source.locator:undefined,path:/^https?:\/\//.test(source.locator)?undefined:source.locator,
      rationale:[['Owner',source.owner],['Original identity',source.originalId],['Contribution',source.contribution],['Selected passage',source.passage],['Use',source.use],['Limits',source.limits]].map(([key,value])=>`**${key}:** ${value}`).join('\n\n')})),
    sourceGaps:gaps.map(gap=>typeof gap==='string'?gap:gap.reason),
    conditions:'Both conditions use the same complete factual originals, communication authority, prompt and settings. With synthesis adds only this subject’s matching attributed synthesis. No imported sources or completed media are implied by these instructions.'};
  brief.readingViews=instructionViews(record,subject,brief,release?.subjects?.[subject.id]?.inputSourceCommit??release?.sourceCommit??null,sections.find(s=>s.id===subject.sectionId));
  return brief;
}
export function directoryItem(item,children){
  return {id:item.id.toLowerCase().replace('.','-'),title:item.title,path:item.path,question:item.question,
    image:artwork.find(image=>image.id===editionAssignments[item.id]),
    summary:item.scope,chapters:children.map(child=>({title:child.title,href:child.path}))};
}
export function collectionMedia(selected,source=release){
  if(proposal)return proposal.collectionMedia(selected);
  return selected.reduce((result,subject,level)=>{
    const media=source?.subjects?.[subject.id];
    if(!media)return result;
    result.decks.push(...media.decks.map(deck=>({...deck,editorialTerm:'Synthesis',title:deck.title.replace(/with(out)?-editorial/gi,(_,out)=>out?'without synthesis':'with synthesis'),level,slug:`${deck.prefix.replace(/^\/presentations\//,'')}${deck.slug}`})));
    result.multimedia.push(...media.multimedia.map(item=>({...item,editorialTerm:'Synthesis',title:item.title.replace(/with(out)?-editorial/gi,(_,out)=>out?'without synthesis':'with synthesis'),level})));
    result.requested+=media.requested;
    return result;
  },{decks:[],multimedia:[],requested:0});
}

export const globalBrief=proposal?.globalBrief??{id:'global',readingViews:sharedViews(communicationAt(null))};
export const copy=proposal?.copy??{
  title:'AI Strategy and Business Architecture',eyebrow:'AI Strategy and Business Architecture',directoryEyebrow:'Enterprise AI strategy and business architecture',
  directoryIntro:'Explore thirteen sections and 73 chapters, with section summaries and the complete collection.',
  collectionIntro:'The complete joined argument.',
  collectionLink:'presentations, videos and audio bringing the thirteen sections together.',
  subjectStatus:(requested,available,whole)=>`${available} of ${requested} commissioned artefacts published for this ${whole?'collection':'section and its chapters'}. Accepted instructions are available. Completed media appears here as it is published.`,
  subjectInstructions:'Inspect shared purpose, medium guidance, the subject brief, individual treatments, evidence selection, optional synthesis and submitted prompts using the buttons under each subject. Each subject commissions detailed decks, presenter slides, explainer and cinematic videos, three audio formats and ten distinct infographics, with and without its matching synthesis.'
};
