// Opt-in data for the existing shared notebook pages. No media is manufactured.
import {notebookInventory} from '../../../scripts/notebooks/inventory.mjs';
const expected=topic=>({video:2,slide_deck:2,audio:3,infographic:6})[topic.type];
export function proposalProgramme(root,id){
  if(!/^(RU|CA|PD|WD|IT)$/.test(id))throw Error('Unknown proposal collection');
  const raw=notebookInventory(root,`proposals-20261025:${id}`);
  const sections=raw.sections.map(s=>({...s,question:s.scope,path:`/${s.id.toLowerCase()}/`}));
  const chapters=raw.chapters.map(c=>({...c,path:`/${c.sectionId.toLowerCase()}/#system-${raw.chapters.filter(s=>s.sectionId===c.sectionId).findIndex(s=>s.id===c.id)+1}`}));
  const collection={...raw.collection,path:'/collection/'};
  const subjects=[...chapters,...sections,collection];
  const count=selected=>selected.flatMap(s=>s.topics).reduce((n,t)=>n+expected(t),0);
  const nativeText=Object.entries(raw.manifest.nativeDefaults).map(([k,v])=>`- ${k}: ${Array.isArray(v)?v.join('; '):v}`).join('\n');
  const globalBrief={id:`${id.toLowerCase()}-global`,readingViews:[
    {id:'purpose',label:'Purpose & audience',text:'# Purpose and audience\n\n'+raw.manifest.audience},
    {id:'formats',label:'Native formats',text:'# Native output formats\n\n'+nativeText+'\n\nSource preparation only. These output variants have not been requested from NotebookLM.'}
  ]};
  const briefFor=subject=>{
    if(raw.config.status!=='independent-review-passed')return null;
    const reading=raw.config.sources[subject.readingSourceLabel];
    const labels=[...new Set(subject.topics.flatMap(t=>t.sourceLabels))];
    const topics=subject.topics.map(t=>`## ${t.title}\n\nMedium: ${t.type}. ${t.wholeSubject?'Complete subject.':'Focused topic.'}\n\n${t.commission}\n\n${raw.manifest.audience}\n\nSelected reading: ${t.sourceLabels.join(', ')}`).join('\n\n');
    const sources=labels.map(label=>{const s=raw.config.sources[label];return `## ${s.title}\n\n${s.role}\n\n${s.body}\n\nPredecessor passages:\n${s.provenance.map(p=>`- ${p.path}, lines ${p.selection.lines.map(r=>r.join('–')).join(', ')}; SHA256 ${p.sha256}`).join('\n')}`;}).join('\n\n');
    return {id:subject.id.replaceAll('.','-'),title:subject.title,editorialTerm:'Chapter reading',editorialNote:reading.body,
      basePrompt:subject.scope,mediaPrompts:Object.fromEntries(subject.topics.map(t=>[t.id,t.commission+'\n\n'+raw.manifest.audience])),
      status:'Reviewed preparation. No generated media is implied.',readingViews:[
        {id:'topics',label:'Topics & instructions',text:'# Topics and exact instructions\n\n'+topics},
        {id:'sources',label:'Selected readings',text:'# Complete selected readings\n\n'+sources},
        {id:'formats',label:'Native formats',text:'# Native formats\n\n'+nativeText}
      ]};
  };
  return {sections,chapters,collection,subjects,inventory:{...raw,sections,chapters,collection,subjects},
    shell:{canonicalOrigin:'https://ba.ai.hm.sparklingideas.co.uk',brandTitle:'H&M / BUSINESS ARCHITECTURE',bodyClass:'notebook-index collapsible-index',homeHref:'/',comments:false,chat:false,
      description:raw.config.description},
    pending:`${sections.length} sections, ${chapters.length} chapters and ${count(subjects)} prepared output variants. Media generation has not been commissioned.`,
    globalBrief,briefFor,collectionMedia:selected=>({decks:[],multimedia:[],requested:count(selected)}),
    copy:{title:raw.config.title,eyebrow:'H&M business architecture proposal',directoryEyebrow:'H&M business architecture proposal',
      directoryIntro:raw.config.description,collectionIntro:raw.config.description,
      collectionLink:'The collection overview connects the business opportunity, enabling responsibilities and realisation choices.',
      subjectStatus:n=>`${n} output variants prepared. Media generation has not been commissioned.`,
      subjectInstructions:'Read the chapter account, medium-specific topics and selected sources using the controls below. Concise instructions and native format settings are prepared for later generation.'}};
}
