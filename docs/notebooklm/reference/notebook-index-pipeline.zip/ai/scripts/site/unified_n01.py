"""Freeze only the authorised unified N01 page for the existing scoped publisher.

This prepares a fresh build; publication remains scripts/site/publish.py's job.
Private run descriptors stay beside the build, outside its publication scope.
"""
import argparse
import hashlib
import html
import importlib.util
import json
import re
import subprocess
import shutil
import sys
import time
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / '.local/n01-comparison/versions/unified-v1'


def digest(body):
    return hashlib.sha256(body).hexdigest()


def public_source(text):
    """Keep source prose while omitting private filesystem locators."""
    text = re.sub(r'/Users/[^\s`"<>),;]+', '[private local locator omitted]', text)
    return re.sub(r'(?<![\w/])\.local/[^\s`"<>),;]+', '[private local locator omitted]', text)


def copy_missing_assets(source, target):
    for asset in source.rglob('*'):
        destination = target / asset.relative_to(source)
        if asset.is_file() and not destination.exists():
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(asset, destination)


def prepare(output, variant='unified-v1'):
    if variant not in ('unified-v1', 'full-section-v1'):
        raise ValueError('Uncommissioned publication variant')
    source_root = SOURCE if variant=='unified-v1' else ROOT/'.local/n01-comparison/versions'/variant
    route = 'n01'
    expected = 198 if variant=='unified-v1' else 470
    if output.exists():
        raise ValueError('Use a fresh output directory')
    release_bytes = (source_root / 'release.json').read_bytes()
    release = json.loads(release_bytes)
    page_bytes = (source_root / 'n01/index.html').read_bytes()
    if release['requested'] != expected or release['errors']:
        raise ValueError('Unexpected source scope or unverified media')
    if f"{release['available']} of {expected}" not in page_bytes.decode():
        raise ValueError('Page and release descriptor are from different cuts')
    output.mkdir(parents=True)
    files = {}
    scope_path = ROOT.parent / 'semantic-enterprise-architecture/site/scripts/deployment/release_scope.py'
    scope_spec = importlib.util.spec_from_file_location('release_scope', scope_path)
    scope = importlib.util.module_from_spec(scope_spec)
    scope_spec.loader.exec_module(scope)

    def save(key, body):
        if key.startswith('/') or '..' in Path(key).parts:
            raise ValueError('Unsafe publication key')
        target = output / key
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(body)
        files[key] = digest(body)

    def copy(key, expected=None):
        body = (source_root / key).read_bytes()
        if expected and digest(body) != expected:
            raise ValueError('Media differs from verified descriptor: ' + key)
        if key not in files:
            if key.startswith(('custody/','presentations/')):
                target=output/key;target.parent.mkdir(parents=True,exist_ok=True)
                os.link(source_root/key,target);files[key]=digest(body)
            else:save(key,body)
        return body

    def media(value):
        if isinstance(value, dict):
            if isinstance(value.get('path'), str) and value.get('sha256'):
                copy(value['path'].lstrip('/'), value['sha256'])
            for child in value.values():
                media(child)
        elif isinstance(value, list):
            for child in value:
                media(child)

    items = release['catalogue']['decks'] + release['catalogue']['multimedia']
    if len(items) != release['available']:
        raise ValueError('Available count differs from verified catalogue')
    media(items)
    page = page_bytes.decode().replace(f'http://127.0.0.1:8932/v/{variant}/inputs/', '/'+route+'/inputs/')
    if variant=='full-section-v1':
        page = re.sub(r'<p><a href="/">All runs and tested changes</a>.*?</p>', '', page)
        page = re.sub(r'<p><a href="/v/unified-v1/n01/">.*?</p>', '', page)
        page = page.replace('href="/n01/"', 'href="/'+route+'/"')
        page = page.replace('https://ba.ai.hm.sparklingideas.co.uk/n01/', 'https://ba.ai.hm.sparklingideas.co.uk/'+route+'/')
        page = page.replace('Local collection · applied content rules', 'Complete section · applied content rules')
        page = public_source(page)
    page = page.replace('<p><a href="/v/baseline/n01/#system-0">Open published N01 baseline</a></p>', '')
    page = page.replace('LOCAL N01 COLLECTION', 'AI STRATEGY BUSINESS ARCHITECTURE')
    page = page.replace('Local collection · one content package', 'One content package')
    page = page.replace('revised artefacts ready locally', 'revised artefacts available')
    page = page.replace('These complete source texts match the verified indexed hashes.',
        'Private local file locators are omitted from the published source text. Indexed SHA256 identifies the original indexed body.')
    if re.search(r'127\.0\.0\.1|localhost|/v/|/Users/|\.local/', page):
        raise ValueError('Private/local route remains in public page')
    save(route+'/index.html', page.encode())
    inputs = source_root / 'inputs'
    source_receipt = {}
    for source in sorted(inputs.rglob('*')):
        if not source.is_file():
            continue
        key = route+'/inputs/' + source.relative_to(inputs).as_posix()
        if not (source.name == 'request-inputs.json' or re.fullmatch(r'[a-f0-9-]{36}\.txt', source.name)):
            raise ValueError('Unexpected input projection file')
        original = source.read_bytes()
        body = public_source(original.decode()).encode() if source.suffix == '.txt' else original
        if variant=='full-section-v1' and source.name=='request-inputs.json':
            value = json.loads(original)
            fields = ('key','subject','topic','format','take','infographicDetail','promptComponents',
                'consumedCreateMethod','consumedCreateArguments','completeInputSha256')
            value = dict(schema='ai-ba.public-request-projection.v1',counts=value['counts'],
                note='Exact consumed arguments and source identities; private predecessor lineage omitted.',
                requests=[{**{k:r[k] for k in fields if k in r},'selectedSources':[
                    {k:s[k] for k in ('sourceId','title','bodySha256','indexedTextSha256') if k in s}
                    for s in r['selectedSources']]} for r in value['requests']])
            body = json.dumps(value,ensure_ascii=False,indent=2).encode()
        if re.search(rb'/Users/|\.local/|access_token|refresh_token|Bearer\s+[A-Za-z0-9]', body):
            raise ValueError('Private input content remains')
        save(key, body)
        source_receipt[key] = {'originalSha256': digest(original), 'publicSha256': digest(body)}
    # Follow only static resources referenced by the page/bundles, including lazy
    # slide data and CSS fonts. Editorial navigation is not publication authority.
    pending = [route+'/index.html']
    visited = set()
    while pending:
        key = pending.pop()
        if key in visited:
            continue
        visited.add(key)
        if Path(key).suffix not in {'.html', '.js', '.mjs', '.css'}:
            continue
        text = html.unescape((output / key).read_text())
        for match in re.finditer(r'''["'(]((?:/(?:_astro|fonts|type|images|presentations|custody)/)[^\s"'<>)]*)''', text):
            resource = match[1].split('?')[0].split('#')[0].lstrip('/')
            if not Path(resource).suffix:  # Shared slide URL template; slides admitted above.
                continue
            copy(resource)
            pending.append(resource)
        for resource in scope.compiled_dependencies(key, (output / key).read_bytes()):
            copy(resource)
            pending.append(resource)
    if (source_root / 'release.json').read_bytes() != release_bytes or (source_root / 'n01/index.html').read_bytes() != page_bytes:
        raise ValueError('Preview changed during snapshot; retry with a fresh directory')
    receipt = {'sourceCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'sourceReleaseSha256': digest(release_bytes), 'sourcePageSha256': digest(page_bytes),
        'publicPageSha256': files[route+'/index.html'], 'updatedAt': release['updatedAt'],
        'available': len(items), 'requested': release['requested'], 'pending': release['requested'] - len(items),
        'byType': {kind: sum(item['type'] == kind for item in items) for kind in ('video', 'slide_deck', 'audio', 'infographic')},
        'sourceProjection': source_receipt, 'files': files}
    output.with_suffix('.source-release.json').write_bytes(release_bytes)
    output.with_suffix('.source.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return {key: value for key, value in receipt.items() if key not in ('files', 'sourceProjection')}


def publish(variant):
    """Incremental streaming publication through the existing exact-scope owner."""
    if variant!='full-section-v1':raise ValueError('Automatic publication is commissioned only for full-section-v1')
    work = ROOT/'.local/n01-comparison/runs'/variant
    if json.loads((work/'generation-control.json').read_text()).get('publicationState')!='run':
        return dict(publication='held')
    version = ROOT/'.local/n01-comparison/versions'/variant
    state_path = work/'publication.json'
    state = json.loads(state_path.read_text()) if state_path.exists() else dict(files={})
    fingerprint = digest((version/'release.json').read_bytes() + b'\ncanonical-route:/n01/:v1')
    if state.get('fingerprint')==fingerprint:return dict(publication='unchanged',available=state['available'])
    cut = work/'publication-cuts'/str(time.time_ns())
    result = prepare(cut,variant)
    manifest = json.loads(cut.with_suffix('.source.json').read_text())
    changed = [(k,v) for k,v in manifest['files'].items() if state['files'].get(k)!=v]
    # Keep the existing publisher's sealed bytes bounded; assets precede HTML.
    ordered = sorted(changed,key=lambda item:(item[0].endswith('.html'),item[0]))
    batches, batch, size = [], [], 0
    for key,sha in ordered:
        length = (cut/key).stat().st_size
        if batch and size+length>256*1024*1024:batches.append(batch);batch=[];size=0
        batch.append((key,sha));size+=length
    if batch:batches.append(batch)
    for number,batch in enumerate(batches):
        stage = cut.parent/(cut.name+'-batch-'+str(number));stage.mkdir()
        for key,sha in batch:
            target=stage/key;target.parent.mkdir(parents=True,exist_ok=True)
            if key.startswith('fonts/'):shutil.copyfile(cut/key,target)
            else:os.link(cut/key,target)
        # Compiled assets must accompany the HTML scope even if previously published.
        if any(key.endswith('.html') for key,_ in batch) and (cut/'_astro').exists():
            copy_missing_assets(cut/'_astro',stage/'_astro')
        subprocess.run([sys.executable,str(ROOT/'scripts/site/publish.py'),'--site','ai-ba','--build',str(stage)],cwd=ROOT,check=True)
        receipt=json.loads((ROOT/'.local/site/ai-ba-publication.json').read_text())
        assert receipt['bodyHashMismatches']==0 and receipt['outputs']['BucketName']=='hm-website-ai-ba-841291679368'
        assert all(any(f['key']==key and f['sha256']==sha for f in receipt['files']) for key,sha in batch)
        state['files'].update(dict(batch))
        pending=state_path.with_suffix('.pending');pending.write_text(json.dumps(state,indent=2)+'\n');pending.replace(state_path)
        (work/('publication-batch-'+str(time.time_ns())+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
        shutil.rmtree(stage)
    state.update(fingerprint=fingerprint,available=result['available'],requested=result['requested'],
        url='https://ba.ai.hm.sparklingideas.co.uk/n01/',publishedAt=time.time())
    pending=state_path.with_suffix('.pending');pending.write_text(json.dumps(state,indent=2)+'\n');pending.replace(state_path)
    shutil.rmtree(cut)
    return dict(publication='verified',available=result['available'],requested=result['requested'],url=state['url'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--variant', choices=['unified-v1','full-section-v1'],default='unified-v1')
    parser.add_argument('--publish',action='store_true')
    args = parser.parse_args()
    if not args.publish and not args.output:parser.error('--output is required without --publish')
    print(json.dumps(publish(args.variant) if args.publish else prepare(args.output.resolve(),args.variant), indent=2))
