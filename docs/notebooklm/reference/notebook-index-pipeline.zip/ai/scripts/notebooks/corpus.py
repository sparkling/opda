"""Import the fixed substantive collection cut through the existing source owner."""
import json
from pathlib import Path
from prepare import ROOT, WORK, HASH, adapter, import_text, save_receipt, native, literal_presentation
from pipeline import rate_limit_client


def provider_limit(error,progress,receipt,key,title,body):
    if error.get('httpStatus')!=429 and error.get('rpcErrorCode')!=8:
        return False
    progress['providerLimit']={'observedAt':native.NOW(),**error,
        'reset':'not-reported-by-source-operation; no reset time fabricated',
        'disposition':'No further source creates until a provider-reported reset or reviewed source-capacity repair.'}
    reported=WORK/'corpus/http-rate-limit.json'
    if error.get('httpStatus')==429 and reported.exists():
        report=json.loads(reported.read_text())
        if adapter.generation_quota().timestamp(report['resetsAt'])>adapter.generation_quota().timestamp(native.NOW()):
            progress['providerLimit'].update(report)
            progress['providerLimit']['reset']='provider-HTTP-Retry-After; automatic resume at reported time'
    if error.get('httpStatus')==429 and not receipt['sources'].get(key,{}).get('sourceId'):
        receipt['sources'].setdefault(key,{'title':title,'sha256':HASH(body)})['status']='planned'
        save_receipt(receipt)
    return True


def prepare_corpus():
    cut_file = WORK / 'corpus/collection-cut.json'
    if not cut_file.exists():
        return
    owner = adapter.load_module('generation-ownership')
    owner.WORK = WORK
    with owner.StageLock('source-import'):
        cut = json.loads(cut_file.read_text())
        receipt = json.loads((WORK/'source-import.json').read_text())
        assert receipt['notebookId'] == cut['notebookId']
        known = {(r['originalSha256'] if r.get('presentationVersion')=='verbatim-fenced-text-v1' else r['sha256']):r
            for r in receipt['sources'].values() if r['status']=='indexed-verified'}
        progress_file = WORK/'corpus/import-progress.json'
        progress = json.loads(progress_file.read_text()) if progress_file.exists() else {'sources':{}}
        if progress.get('providerLimit'):
            # No speculative reset or repeated create probes. A source-service
            # limit requires a reported reset or an explicit reviewed repair.
            due = progress['providerLimit'].get('resetsAt')
            quota = adapter.generation_quota()
            if not due or quota.timestamp(due)>quota.timestamp(native.NOW()):
                print(json.dumps({'corpus':'provider-limit-held','limit':progress['providerLimit']}),flush=True)
                return
            progress.setdefault('providerLimitHistory',[]).append(progress.pop('providerLimit'))
        client = adapter.worker.get_client()
        client = rate_limit_client(client,client.RPC_ADD_SOURCE,WORK/'corpus/http-rate-limit.json')
        progress.update(cutCapturedAt=cut['capturedAt'],notebookId=cut['notebookId'])
        def priority(row):
            p = row['identity'].get('path','')
            return (0 if '/ADR-020-' in p else 1 if '/website-spec/' in p else 2 if p and '/imports/' not in p else 3, p, row['sha256'])
        for row in sorted(cut['rows'],key=priority):
            assert HASH(row['text']) == row['sha256']
            key = 'corpus:'+row['sha256']
            record = progress['sources'].setdefault(key,{'sha256':row['sha256'],'identity':row['identity'],
                'aliases':row['aliases'],'sourceType':row['sourceType'],'authority':row['authority']})
            record.update(retainedBody=row.get('retainedBody'),selectionRole=row.get('selectionRole'))
            if row['sha256'] in known:
                record.update(status='indexed-verified',sourceId=known[row['sha256']]['sourceId'],exactBodyReuse=True)
                continue
            if record.get('status') in {'indexed-verified','repair-blocked'}:
                continue
            try:
                identity = import_text(client,receipt,key,row['text'],row['title'][:160]+' ['+row['sha256'][:16]+']')
                record.update(status='indexed-verified' if identity else 'needs-reconciliation',sourceId=identity,checkedAt=native.NOW())
            except Exception as error:
                record.update(status='deferred',error=owner.safe_error(error),checkedAt=native.NOW())
                if provider_limit(record['error'],progress,receipt,key,row['title'][:160]+' ['+row['sha256'][:16]+']',row['text']):
                    adapter.generation_quota().atomic_json(progress_file,progress)
                    return
                if record['error'].get('reason')=='notebook-auth-expired':
                    adapter.generation_quota().atomic_json(progress_file,progress)
                    raise
            adapter.generation_quota().atomic_json(progress_file,progress)
        # Final repair lane: an acknowledged original never gets replayed.
        # A distinct literal presentation retains its ID and both byte hashes.
        for row in cut['rows']:
            key='corpus:'+row['sha256'];record=progress['sources'].get(key,{})
            original=receipt['sources'].get(key,{})
            if record.get('status')!='deferred' or record.get('error',{}).get('errorType')!='AssertionError' or not original.get('sourceId'):
                continue
            assert original['sha256']==row['sha256']
            presentation=literal_presentation(row['text']);repair_key=key+':literal-v1'
            record.setdefault('originalReadbackGap',{'sourceId':original['sourceId'],'originalSha256':row['sha256'],
                'status':original['status'],'error':record['error']})
            try:
                identity=import_text(client,receipt,repair_key,presentation,row['title'][:140]+' ['+row['sha256'][:16]+'] — literal text',literal_body=row['text'])
                record.update(status='indexed-verified' if identity else 'needs-reconciliation',sourceId=identity,
                    originalSha256=row['sha256'],uploadedPresentationSha256=HASH(presentation),presentationVersion='verbatim-fenced-text-v1',checkedAt=native.NOW())
            except Exception as error:
                record.update(repairError=owner.safe_error(error),repairCheckedAt=native.NOW())
                if record['repairError'].get('errorType')=='AssertionError':
                    record['status']='repair-blocked'  # Keep both IDs; never relax proof or create another variant.
                if provider_limit(record['repairError'],progress,receipt,repair_key,row['title'][:140]+' ['+row['sha256'][:16]+'] — literal text',presentation):
                    adapter.generation_quota().atomic_json(progress_file,progress)
                    return
                if record['repairError'].get('reason')=='notebook-auth-expired':
                    adapter.generation_quota().atomic_json(progress_file,progress)
                    raise
            adapter.generation_quota().atomic_json(progress_file,progress)
        progress['checkedAt'] = native.NOW()
        progress['counts'] = {state:sum(r['status']==state for r in progress['sources'].values())
            for state in {r['status'] for r in progress['sources'].values()}}
        adapter.generation_quota().atomic_json(progress_file,progress)
        print(json.dumps({'corpus':progress['counts']}),flush=True)


if __name__=='__main__':
    try:
        prepare_corpus()
    except Exception as error:
        safe = adapter.load_module('generation-ownership').safe_error(error)
        print(json.dumps(safe),flush=True)
        raise SystemExit(70 if safe.get('reason')=='notebook-auth-expired' else 1)
