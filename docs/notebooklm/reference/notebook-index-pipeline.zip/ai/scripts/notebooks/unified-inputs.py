"""Declarative ADR052 projection for the existing local generation owner."""
import copy
import json
from collections import Counter


def native_arguments(r, envelope):
    """Capture the existing adapter's real mapping without calling a provider."""
    class Methods:
        def __getattr__(self, name): return name
    create_once = r.native.create_once
    try:
        r.native.create_once = lambda client,method,notebook,**kw: (method,{'notebook_id':notebook,**kw})
        return r.adapter.create(Methods(),envelope)
    finally:
        r.native.create_once = create_once


def configuration(r):
    path = r.ROOT/'config/authoring/N01-unified-v1.json'
    config = r.read(path)
    assert config['schema']=='ai-ba.n01-unified.v1' and config['id']=='unified-v1'
    assert config['status']=='owner-authorised'
    assert r.HASH((r.ROOT/config['topicAuthority']['path']).read_bytes())==config['topicAuthority']['sha256']
    assert [s['id'] for s in config['subjects']]==r.SUBJECTS
    assert config['counts']=={'scopes':6,'topics':93,'outputs':198,
        'byType':{'video':38,'slide_deck':24,'audio':36,'infographic':100}}
    assert config['infographicTakes']==2
    topics = [t for s in config['subjects'] for t in s['topics']]
    assert len(topics)==len({t['id'] for t in topics})==93
    return config, r.HASH(path.read_bytes())


def projection(r):
    config, digest = configuration(r)
    imports = r.read(r.ROOT/'.local/artefact-generation/adr025/source-import.json')['sources']
    s3_imports = r.read(r.ROOT/'.local/n01-comparison/runs/content-confirmation-v2/source-import.json')['sources']
    receipts = {v['sourceId']:v for v in [*imports.values(),*s3_imports.values()] if v.get('sourceId')}
    runs, snapshots = [], []
    for chapter in config['subjects']:
        assert r.HASH((r.ROOT/chapter['baseline']['path']).read_bytes())==chapter['baseline']['sha256']
        baseline = r.read(r.ROOT/'docs/generation'/(chapter['id']+'.json'))
        subject = copy.deepcopy(baseline['subjects'][0])
        assert subject['id']==chapter['id'] and subject['generationReady']
        synth_config = r.read(r.ROOT/chapter['synthesis']['path'])
        if chapter['synthesis']['kind']=='reorganised-chapter-synthesis':
            synthesis = next(s for s in synth_config['subjects'] if s['id']==chapter['id'])
            sync = next(v for v in s3_imports.values() if v['sha256']==synthesis['sha256'])
            assert r.HASH(synthesis['body'])==synthesis['sha256']
            assert set(s['sourceId'] for s in synthesis['sources'])<=set(subject['factualSourceIds']+subject['communicationSourceIds'])
            subject.update(editorialSourceId=sync['sourceId'],editorialSha256=synthesis['sha256'])
        else:
            _, body = r.production.brief.editorial(synth_config)
            assert r.HASH(body)==subject['editorialSha256']
        subject['editorialSync'] = copy.deepcopy(receipts[subject['editorialSourceId']])
        subject.update(mediaPrompts={},promptHashes={},unifiedInput=digest)
        ids = r.production.brief.source_ids(subject, True)
        assert len(ids)==(13 if chapter['id']=='N01.01' else 12)
        assert all(receipts[i]['status']=='indexed-verified' for i in ids)
        jobs = []
        for topic in chapter['topics']:
            for fmt in config['formats'][topic['type']]:
                original = next(j for j in baseline['jobs'] if j['type']==topic['type'] and j['format']==fmt)
                medium = f"{topic['type']}-{fmt}-{topic['ordinal']}"
                components = [dict(role=role,text=text,destination='focus_prompt') for role,text in [
                    ('purposeAndAudience',config['purposeAndAudience']),('subjectCommission',chapter['subjectCommission']),
                    ('topicCommission',topic['commission']),('treatment',config['treatments'][fmt]),
                    ('evidenceContract',config['evidenceContract']),('language',config['language'])] if text]
                for c in components: c['sha256']=r.HASH(c['text'])
                prompt = '\n\n'.join(c['text'] for c in components)
                subject['mediaPrompts'][medium]=prompt
                subject['promptHashes'][medium]=r.HASH(prompt)
                for take in range(1,3) if topic['type']=='infographic' else (1,):
                    settings = copy.deepcopy(original['settings'])
                    key = f"unified-v1-{topic['id']}-{fmt}"+(f'-take-{take}' if topic['type']=='infographic' else '')
                    label = f"Take {take}" if topic['type']=='infographic' else fmt.replace('_',' ')
                    job = dict(key=key,subject=chapter['id'],level=0,type=topic['type'],medium=medium,
                        format=fmt,ordinal=topic['ordinal'],editorial=True,version=7,settings=settings,
                        status='planned',promptSha256=r.HASH(prompt),title=f"{topic['id']} — {topic['title']} — {label}",
                        topicId=topic['id'],topicTitle=topic['title'],take=take)
                    package = dict(settings=settings,notebook_id=baseline['notebookId'],source_ids=ids,focus_prompt=prompt,
                        indexedSourceHashes={i:receipts[i]['indexedTextSha256'] for i in ids})
                    job['completeInputSha256']=r.HASH(json.dumps(package,sort_keys=True,separators=(',',':')))
                    envelope={**settings,'notebook_id':baseline['notebookId'],'title':job['title'],
                        'source_ids':ids,'focus_prompt':prompt}
                    method, arguments = native_arguments(r,envelope)
                    snapshots.append(dict(key=key,subject=chapter['id'],topic=topic,format=fmt,take=take,
                        promptComponents=components,completeInputSha256=job['completeInputSha256'],
                        adapterEnvelope=envelope,consumedCreateMethod='NotebookLMClient.'+method,
                        consumedCreateArguments=arguments,
                        selectedSources=[dict(sourceId=i,**{k:v for k,v in receipts[i].items() if k!='sourceId'}) for i in ids]))
                    jobs.append(job)
        runs.append(dict(schemaVersion=1,edition=baseline['edition'],comparisonVersion='unified-v1',inputVersion=7,
            sectionId=chapter['id'],notebookId=baseline['notebookId'],requested=len(jobs),commissioned=True,publish=False,
            manifestSha256=digest,subjects=[subject],inputSha256=r.HASH(json.dumps([subject],ensure_ascii=False,separators=(',',':'))),jobs=jobs))
    assert [len(x['jobs']) for x in runs]==[36,36,36,30,32,28]
    assert Counter(j['type'] for x in runs for j in x['jobs'])==config['counts']['byType']
    assert len(snapshots)==len({s['key'] for s in snapshots})==198
    for topic in [t for s in config['subjects'] for t in s['topics'] if t['type']=='infographic']:
        pair = [s for s in snapshots if s['topic']['id']==topic['id']]
        assert len(pair)==2 and pair[0]['completeInputSha256']==pair[1]['completeInputSha256']
    return config, runs, snapshots


def prepare(r, dry_run=False):
    config, runs, snapshots = projection(r)
    if dry_run:
        print(json.dumps({'scopes':6,'topics':93,'outputs':len(snapshots),'providerMutations':0}))
        return
    owner = r.production.owner; owner.ROOT = owner.WORK = r.WORK
    with owner.StageLock('supervisor'), owner.StageLock('generation',r.WORK/'worker.lock'):
        control = r.WORK/'generation-control.json'
        assert not control.exists() or r.read(control)['desiredState']=='hold'
        save = r.production.generation_quota().atomic_json
        save(control,{'schemaVersion':1,'desiredState':'hold','reconcileSeconds':30,'probeBackoffSeconds':60})
        client = r.worker.get_client()
        available = {s['id']:s for s in client.get_notebook_sources_with_types(runs[0]['notebookId'])}
        expected = {s['sourceId']:s for row in snapshots for s in row['selectedSources']}
        assert expected.keys()<=available.keys(), 'Previously verified selected source is missing'
        source_proof = {}
        for source_id, source in expected.items():
            target = r.WORK/'source-readbacks'/(source_id+'.json')
            body = r.read(target) if target.exists() else client.get_source_fulltext(source_id)
            assert r.HASH(body['content'])==source['indexedTextSha256'], 'Selected indexed source body changed: '+source_id
            assert body['title']==source['title']==available[source_id]['title']
            save(target,body)
            source_proof[source_id]={'title':body['title'],'indexedTextSha256':r.HASH(body['content']),
                'readbackPath':str(target.relative_to(r.ROOT)),'verifiedAt':r.native.NOW()}
        save(r.WORK/'source-availability.json',{'notebookId':runs[0]['notebookId'],'sources':source_proof,
            'verifiedAt':r.native.NOW(),'bodyProof':'Complete selected indexed texts match retained indexed hashes.'})
        save(r.WORK/'request-inputs.json',dict(schema='ai-ba.unified-request-inputs.v1',manifestSha256=runs[0]['manifestSha256'],
            preparedAt=r.native.NOW(),counts=config['counts'],requests=snapshots))
        r.DIRECTORY.mkdir(parents=True,exist_ok=True)
        for run in runs:
            path=r.DIRECTORY/(run['sectionId']+'.json')
            if path.exists():
                previous=r.read(path)
                assert previous['manifestSha256']==run['manifestSha256'] and previous['inputSha256']==run['inputSha256']
            else: r.native.save(path,run)
    print(json.dumps({'prepared':6,'topics':93,'jobs':198,'selectedSources':len(source_proof),'held':True}),flush=True)


def validate(r, runs):
    _, expected, snapshots = projection(r)
    assert len(runs)==6
    actual_ids=[]
    for run, prior in zip(runs,expected):
        assert all(run[k]==prior[k] for k in ('sectionId','manifestSha256','inputSha256','subjects','requested'))
        assert len(run['jobs'])==len(prior['jobs'])
        for job, wanted in zip(run['jobs'],prior['jobs']):
            assert all(job[k]==wanted[k] for k in (*r.REQUEST_FIELDS,'key','topicId','topicTitle','take','completeInputSha256'))
            r.adapter.brief(run,job)
            if job.get('id'): actual_ids.append(job['id'])
    assert len(actual_ids)==len(set(actual_ids)), 'Provider identity reused across independent requests'
    frozen=r.WORK/'request-inputs.json'
    if frozen.exists(): assert r.read(frozen)['requests']==snapshots
