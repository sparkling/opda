"""Project reviewed reading revisions and explicit prompt/native variants."""
import copy
import json
from collections import Counter
from pathlib import Path


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            assert key not in result, 'Duplicate authored key: '+key
            result[key] = value
        return result
    return json.loads(path.read_text(), object_pairs_hook=unique)


def verified(api, descriptor, external=(), historical_evidence=False):
    relative = Path(descriptor['path'])
    assert '..' not in relative.parts, 'Invalid evidence path'
    retained = (str(relative), descriptor['sha256']) in external
    assert not relative.is_absolute() or retained, 'Invalid evidence path: external original is not retained'
    path = (api.ROOT / relative).resolve()
    assert path.is_relative_to(api.ROOT.resolve()) or retained, 'Evidence path escapes repository'
    if historical_evidence and getattr(api,'prepare',None) and not relative.is_absolute() and api.HASH(path.read_bytes()) != descriptor['sha256']:
        # A later ADR edit must not invalidate an unchanged frozen source pack.
        # Reuse the existing exact-hash history resolver only for provenance;
        # executable configs/revisions still require their current pinned bytes.
        body = api.prepare.original_body({'originalId':'ai-ba:document:'+str(relative),
            'sha256':descriptor['sha256']})
        assert body is not None and api.HASH(body)==descriptor['sha256'], 'Pinned evidence unavailable: '+str(relative)
        return None  # Historical bytes were verified; current path is not that body.
    assert api.HASH(path.read_bytes()) == descriptor['sha256'], 'Pinned input changed: '+str(relative)
    return path


def retained_originals(sources):
    """Retain only exact original bindings from known source-lineage edges."""
    result = set()
    for source in sources:
        provenance = source['provenance']
        if provenance.get('locator') and provenance.get('originalSha256'):
            result.add((provenance['locator'], provenance['originalSha256']))
        previous = [provenance['previousSource']] if provenance.get('previousSource') else []
        result.update(retained_originals(previous + provenance.get('derivedFrom', [])))
    return result


def tailored_requests(api, config, result):
    """Reuse every native format, adding two takes at each infographic detail."""
    assert config['infographicDetails'] == ['concise', 'standard', 'detailed']
    assert type(config['infographicTakes']) is int and config['infographicTakes'] == 2
    assert not config.get('nativeOverrides'), 'Use the explicit infographic detail matrix'
    commissions, media = config.get('topicCommissions', {}), config.get('mediumPrompts', {})
    assert commissions.keys() <= result['topics'].keys(), 'Unknown topic commission'
    assert media.keys() <= {'video', 'slide_deck', 'audio', 'infographic'}, 'Unknown medium prompt'
    text = [*commissions.values(), *media.values()]
    if 'purposeAndAudience' in config: text.append(config['purposeAndAudience'])
    assert all(isinstance(value, str) and value.strip() for value in text), 'Empty authored prompt'
    for tid, commission in commissions.items():
        result['topics'][tid]['topic']['commission'] = commission
    requests = []
    for request in result['requests']:
        topic = result['topics'][request['topicId']]['topic']
        updates = {'topicCommission':topic['commission']}
        if 'purposeAndAudience' in config: updates['purposeAndAudience'] = config['purposeAndAudience']
        for component in request['promptComponents']:
            if component['role'] in updates:
                component.update(text=updates[component['role']], sha256=api.HASH(updates[component['role']]))
        if topic['type'] in media:
            prompt = media[topic['type']]
            request['promptComponents'].append(dict(role='treatment', text=prompt,
                destination='focus_prompt', sha256=api.HASH(prompt)))
        request['providerTemplate']['arguments']['focus_prompt'] = '\n\n'.join(c['text'] for c in request['promptComponents'])
        for detail in config['infographicDetails'] if topic['type']=='infographic' else [None]:
            row = copy.deepcopy(request)
            if detail:
                row.update(key=request['key'].replace('-take-', '-'+detail+'-take-'), infographicDetail=detail)
                row['providerTemplate']['arguments']['detail_level_code'] = config['infographicDetails'].index(detail)+1
            row['planSha256'] = api.HASH(api.canonical(row['providerTemplate']))
            requests.append(row)
    result['requests'] = sorted(requests, key=lambda r:(r['subject'], r['topicId'], r['format'],
        r['providerTemplate']['arguments'].get('detail_level_code', 0), r['take'] or 0))
    result['counts'].update(outputs=len(requests), byType=dict(Counter(
        result['topics'][r['topicId']]['topic']['type'] for r in requests)))


def projection(api, config_path):
    config = read(config_path)
    if config['id'] == 'applied-rules-v1':
        return applied_projection(api, config_path, config)
    if config['id'] == 'tailored-v3':
        assert config['schema'] == 'ai-ba.n01-instruction-successor.v1'
        assert verified(api, config['extends']) == api.TAILORED_CONFIG.resolve()
        prior = api.projection(api.TAILORED_CONFIG)
        result = copy.deepcopy(prior)
        removed = config['removeComponent']
        assert removed == dict(role='treatment', text='A deck for independent reading.')
        for row in result['requests']:
            row['priorRequestKey'] = row['key']
            row['key'] = row['key'].replace('tailored-v2-', 'tailored-v3-', 1)
            if result['topics'][row['topicId']]['topic']['type'] == 'slide_deck':
                matches = [c for c in row['promptComponents'] if c['role'] == removed['role']]
                assert len(matches) == 1 and matches[0]['text'] == removed['text'], 'Unexpected predecessor deck instruction'
                row['promptComponents'].remove(matches[0])
            row['providerTemplate']['arguments']['focus_prompt'] = '\n\n'.join(c['text'] for c in row['promptComponents'])
            row['planSha256'] = api.HASH(api.canonical(row['providerTemplate']))
        result.update(id=config['id'], configSha256=api.HASH(config_path.read_bytes()), status=config['status'],
            instructionRevision=dict(extends=config['extends'], removedComponent=removed),
            boundary='Prospective instruction successor to tailored-v2; sources, topics and native settings retained. '
                'Only the named deck instruction component is removed before request hashing. No upload or generation.')
        return result
    assert config['schema'] == 'ai-ba.n01-business.v1' and config['id'] in ('business-v1', 'tailored-v2')
    tailored = config['id'] == 'tailored-v2'
    assert verified(api, config['extends']) == (api.BUSINESS_CONFIG if tailored else api.MINIMAL_CONFIG).resolve()
    prior = api.projection(api.BUSINESS_CONFIG) if tailored else api.minimal_projection()
    result = copy.deepcopy(prior)
    external = retained_originals(prior['sources'].values())
    revisions, authors = {}, {}
    assert config['revisions']
    for descriptor in config['revisions']:
        revision = read(verified(api, descriptor))
        assert revision['schema'] == 'ai-ba.business-source-revision.v1'
        assert revision['chapter'] in {r['subject'] for r in prior['requests']}
        assert revision['sources'], 'Empty source revision'
        for label, source in revision['sources'].items():
            assert label in prior['sources'], 'Unknown revised source: '+label
            assert label not in revisions, 'Duplicate revised source: '+label
            assert all(isinstance(source[k], str) and source[k].strip() for k in ('title','body','rationale'))
            assert source['evidence'], 'Missing authored evidence: '+label
            for evidence in source['evidence']:
                verified(api, evidence, external, historical_evidence=True)
                assert evidence['sections'] and all(isinstance(s, str) and s.strip() for s in evidence['sections'])
            revisions[label], authors[label] = source, descriptor
    if not tailored:
        assert revisions.keys() == prior['sources'].keys(), 'Every inherited source needs a reviewed revision'
    for label, revision in revisions.items():
        original = prior['sources'][label]
        assert revision['body'] != original['body'], 'Unrevised reading body: '+label
        provenance = dict(authoring=copy.deepcopy(authors[label]), evidence=copy.deepcopy(revision['evidence']),
            rationale=revision['rationale'], previousSource=copy.deepcopy(original),
            transformation='Business-facing reading revision; complete prior source and evidence lineage retained in custody.')
        result['sources'][label] = api.source_record(label, revision['title'], revision['body'],
            provenance, original['role'], True)
    assert len({s['key'] for s in result['sources'].values()}) == len(result['sources']), 'Revised sources share a body'
    overrides = config.get('topicSelections', {})
    assert overrides.keys() <= prior['topics'].keys(), 'Unknown topic selection override'
    if tailored: assert overrides.keys() == prior['topics'].keys(), 'Every tailored topic needs an explicit selection'
    for tid, topic in result['topics'].items():
        labels = overrides.get(tid, topic['sourceLabels'])
        assert isinstance(labels, list) and labels and len(labels) == len(set(labels)), 'Duplicate or empty topic selection'
        assert set(labels) <= result['sources'].keys(), 'Unknown selected source'
        assert all(not label.startswith('synthesis:') or label == 'synthesis:'+tid for label in labels)
        topic.update(sourceLabels=list(labels), sourceKeys=[result['sources'][label]['key'] for label in labels],
            selectedWords=sum(len(result['sources'][label]['body'].split()) for label in labels),
            sourceRevision=dict(variant=config['id'], selectionOverride=tid in overrides,
                previousSourceLabels=prior['topics'][tid]['sourceLabels']))
    for request in result['requests']:
        request['priorRequestKey'] = request['key']
        request['key'] = request['key'].replace(prior['id']+'-', config['id']+'-', 1)
        topic = result['topics'][request['topicId']]
        request['providerTemplate'].update(sourceKeys=topic['sourceKeys'],
            sourceBodyHashes={result['sources'][label]['key']:result['sources'][label]['bodySha256']
                              for label in topic['sourceLabels']})
        request['planSha256'] = api.HASH(api.canonical(request['providerTemplate']))
    assert len({r['key'] for r in result['requests']}) == prior['counts']['outputs']
    if tailored: tailored_requests(api, config, result)
    assert len({r['key'] for r in result['requests']}) == result['counts']['outputs']
    result.update(id=config['id'], configSha256=api.HASH(config_path.read_bytes()), status=config['status'],
        sourceRevision=dict(extends=config['extends'], revisions=config['revisions'], topicSelections=overrides),
        boundary='New local business-facing source run. Minimal prompts, topics and native settings retained; reading bodies revised. No generation or quality outcome asserted.')
    if tailored:
        result['sourceRevision'].update(promptOverrides={key:config[key] for key in
            ('purposeAndAudience', 'topicCommissions', 'mediumPrompts') if key in config},
            infographicDetails=config['infographicDetails'], infographicTakes=config['infographicTakes'])
        result['boundary'] = ('New local holistic source-package and prompt trial, with two infographic takes at each '
            'native concise, standard and detailed level. Other native settings retained; no quality outcome asserted.')
    return result


def applied_projection(api, config_path, config):
    """Apply reviewed source selections to the existing full native request matrix."""
    assert config['schema'] == 'ai-ba.n01-applied-rules.v1'
    assert verified(api, config['extends']) == api.CURRENT_CONFIG.resolve()
    prior = api.projection(api.CURRENT_CONFIG)
    result = copy.deepcopy(prior)
    assert not any(config.get(key) for key in ('topicCommissions','mediumPrompts','removeComponents')), 'This successor retains reviewed prompts'
    if 'purposeAndAudience' in config:
        assert all(c['text'] == config['purposeAndAudience'] for r in prior['requests']
                   for c in r['promptComponents'] if c['role'] == 'purposeAndAudience')
    external = retained_originals(prior['sources'].values())
    changed = set()
    for descriptor in config['revisions']:
        revision = read(verified(api, descriptor))
        assert revision['schema'] == 'ai-ba.business-source-revision.v1'
        chapters = revision.get('chapters', [revision['chapter']])
        assert chapters and set(chapters) <= {r['subject'] for r in prior['requests']}
        for label, source in revision['sources'].items():
            assert label not in changed, 'Duplicate source revision'
            changed.add(label)
            origins = source.get('derivedFromLabels', [label])
            assert origins and len(origins) == len(set(origins)) and set(origins) <= prior['sources'].keys()
            assert all(isinstance(source[k], str) and source[k].strip() for k in ('title','body','rationale'))
            assert source['evidence'], 'Missing authored evidence'
            for evidence in source['evidence']:
                verified(api, evidence, external, historical_evidence=True)
                assert evidence['sections'] and all(isinstance(s, str) and s.strip() for s in evidence['sections'])
            reviewed = source.get('reviewedVariant')
            if reviewed:
                record = read(verified(api, reviewed))
                for key in reviewed['recordPath']: record = record[key]
                assert record == reviewed['record'], 'Reviewed source record differs'
                assert record['key'] == reviewed['sourceKey'] and record['bodySha256'] == reviewed['bodySha256']
                assert record['body'] == source['body'] and api.HASH(source['body']) == reviewed['bodySha256']
            provenance = dict(authoring=copy.deepcopy(descriptor), evidence=copy.deepcopy(source['evidence']),
                rationale=source['rationale'], derivedFrom=[copy.deepcopy(prior['sources'][key]) for key in origins],
                transformation='Reviewed topic-specific source variant; original source records remain in custody.')
            if label in prior['sources']: provenance['previousSource'] = copy.deepcopy(prior['sources'][label])
            if reviewed: provenance['reviewedVariant'] = copy.deepcopy(reviewed)
            role = prior['sources'][origins[0]]['role']
            result['sources'][label] = api.source_record(label, source['title'], source['body'], provenance, role, True)
    assert len({s['key'] for s in result['sources'].values()}) == len(result['sources']), 'Source labels share a body'
    selections = config['topicSelections']
    assert selections.keys() == prior['topics'].keys(), 'Every topic needs an explicit selection'
    for tid, topic in result['topics'].items():
        labels = selections[tid]
        assert isinstance(labels, list) and labels and len(labels) == len(set(labels))
        assert set(labels) <= result['sources'].keys(), 'Unknown selected source'
        assert all(not label.startswith('synthesis:') or label == 'synthesis:'+tid for label in labels)
        topic.update(sourceLabels=labels, sourceKeys=[result['sources'][label]['key'] for label in labels],
            selectedWords=sum(len(result['sources'][label]['body'].split()) for label in labels),
            sourceRevision=dict(variant=config['id'], previousSourceLabels=prior['topics'][tid]['sourceLabels']))
    for row in result['requests']:
        row.update(priorRequestKey=row['key'], key=row['key'].replace(prior['id']+'-', config['id']+'-', 1))
        topic = result['topics'][row['topicId']]
        row['providerTemplate'].update(sourceKeys=topic['sourceKeys'],
            sourceBodyHashes={result['sources'][label]['key']:result['sources'][label]['bodySha256'] for label in topic['sourceLabels']})
        row['planSha256'] = api.HASH(api.canonical(row['providerTemplate']))
    selected = {key for topic in result['topics'].values() for key in topic['sourceKeys']}
    titles = [source['title'] for source in result['sources'].values() if source['key'] in selected]
    assert len(titles) == len(set(titles)), 'Selected source titles must be unique for native import reconciliation'
    assert len({r['key'] for r in result['requests']}) == prior['counts']['outputs']
    result.update(id=config['id'], configSha256=api.HASH(config_path.read_bytes()), status=config['status'],
        sourceRevision=dict(extends=config['extends'], revisions=config['revisions'], topicSelections=selections),
        boundary='Reviewed topic-specific selections and retained source variants. Prompts and the complete native matrix are unchanged from tailored-v3; no generation outcome is asserted.')
    return result
