"""Prepare ADR052's explicit topic sources offline; bind only verified new imports.

No client, notebook, active queue or frozen request is mutated. The existing
prepare.import_text owner imports these literal presentations when commissioned.
"""
import argparse
import copy
import json
import re
import subprocess
from collections import Counter
from pathlib import Path

import prepare

ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT / 'config/authoring/N01-topic-sources-v2.json'
WORK = ROOT / '.local/n01-topic-source-v2'
CONTENT_CONFIG = ROOT / 'config/authoring/N01-content-v3.json'
RECONCILED_CONFIG = ROOT / 'config/authoring/N01-content-v4.json'
WHOLE_CHAPTER_CONFIG = ROOT / 'config/authoring/N01-whole-chapter-v1.json'
MINIMAL_CONFIG = ROOT / 'config/authoring/N01-minimal-v1.json'
BUSINESS_CONFIG = ROOT / 'config/authoring/N01-business-v1.json'
TAILORED_CONFIG = ROOT / 'config/authoring/N01-tailored-v2.json'
CURRENT_CONFIG = ROOT / 'config/authoring/N01-tailored-v3.json'
APPLIED_CONFIG = ROOT / 'config/authoring/N01-applied-rules-v1.json'
FULL_CONFIG = ROOT / 'config/authoring/N01-full-section-v1.json'
# Exact pre-successor authoring cut used by the unchanged frozen topic configs.
FROZEN_AUTHORING_COMMIT = 'bdaae2320bc0b010eac54377f6e471bf299ded34'
HASH = prepare.HASH


def read(path):
    return json.loads(path.read_text())


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def pinned(descriptor, revision=None):
    relative = Path(descriptor['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    path = ROOT / relative
    body = subprocess.check_output(['git','show',revision+':'+str(relative)],cwd=ROOT) if revision else path.read_bytes()
    assert HASH(body) == descriptor['sha256'], 'Pinned input changed: '+str(relative)
    return json.loads(body)


def source_record(label, title, body, provenance, role, plain_title=False):
    presented = prepare.literal_presentation(body)
    digest = HASH(body)
    return dict(key='focused:'+digest, label=label, title=title if plain_title else title+' ['+digest[:16]+']',
                role=role, body=body, bodySha256=digest,
                uploadedPresentationSha256=HASH(presented),
                presentationVersion='verbatim-fenced-text-v1', provenance=provenance)


def evidence_sources(config, chapters):
    originals, sources = {}, {}
    for key, declaration in config['sources'].items():
        chapter = chapters[declaration['bindingSubject']]
        binding = next(b for b in chapter['sourceBindings'] if b['sha256'] == declaration['originalSha256'])
        body = prepare.original_body(binding)
        assert body is not None and HASH(body) == binding['sha256'], 'Original unavailable: '+key
        originals[key] = (binding, body)
    for label, fragment in config['fragments'].items():
        binding, original = originals[fragment['source']]
        parts, ranges = prepare.selected_passages(original, fragment['selection'])
        provenance = dict(originalId=binding['originalId'], originalSha256=binding['sha256'],
            locator=binding['locator'], namespace=binding.get('namespace'), key=binding.get('key'),
            owner=binding['owner'], role=binding['role'], status=binding['status'], date=binding['date'],
            selection=ranges, sourceOriginal=binding.get('sourceOriginal'),
            originalAccess='Immutable complete original through prepare.original_body; locator retained above.')
        body = '\n\n'.join([
            '# '+fragment['title'],
            'Derived selection from '+binding['title']+'. Original owner: '+binding['owner']+'.',
            'Source status: '+binding['status'],
            'This is an attributed documentary selection, not independent evidence or an observed H&M result. '
            'Original source citations retain their provenance; linked or named works are not additional supplied originals.',
            *[(('Original character range '+str(r['characters'])+' within lines '+str(r['lines'])+':\n')
               if 'characters' in fragment['selection'] else
               ('Original lines '+str(r['lines'][0])+'–'+str(r['lines'][1])+':\n') if 'lines' in r
               else 'Original JSON value: ') + p for p, r in zip(parts, ranges)]])
        if config.get('contentRevision'):
            body = '# '+fragment['title']+'\n\n'+fragment['content']
            provenance.update(originalPassages=parts,
                transformation='Reviewed reading derivative; source administration stays in custody. Original evidence and qualifications remain authoritative.')
        sources[label] = source_record(label, 'N01 evidence — '+fragment['title'], body, provenance, binding['role'], bool(config.get('contentRevision')))
    return sources


def synthesis_source(chapter, selection, supports, sources, revision=None):
    if not selection['synthesisParagraphs']:
        return None
    file = ROOT / chapter['synthesis']['path']
    if chapter['synthesis']['kind'] == 'reorganised-chapter-synthesis':
        document = read(file); file_hash = HASH(file.read_bytes())
        original = next(s['body'] for s in document['subjects'] if s['id'] == chapter['id'])
    else:
        assert chapter['synthesis']['path'] == chapter['baseline']['path']
        document = pinned(chapter['baseline'], FROZEN_AUTHORING_COMMIT)
        file_hash = chapter['baseline']['sha256']
        original = document['synthesis']['body']
    paragraphs, retained, provenance = original.split('\n\n'), [], []
    for index in selection['synthesisParagraphs']:
        paragraph = paragraphs[index]
        evidence = supports[str(index)]
        assert evidence and set(evidence) <= set(selection['fragments']), 'Synthesis support was not selected'
        # The original remains immutable. Citation replacement is explicit in custody.
        text = re.sub(r'\s*\[[^\]]+\]', '', paragraph).strip()
        assert not text.startswith(('Attribution:', 'Source basis:', '#'))
        if revision:
            text = revision.get('synthesisParagraphs', {}).get(chapter['id'], {}).get(str(index), text)
        retained.append(text if revision else text+'\n\nSelected support: '+ '; '.join(sources[e]['title'] for e in evidence)+'.')
        provenance.append(dict(paragraph=index, originalText=paragraph, originalSha256=HASH(paragraph),
            selectedSupport=evidence, transformation=('Reviewed prose; original and support mapping retained here.' if revision else
                'Original prose unchanged; legacy bracket citations replaced with selected evidence titles.')))
    body = '\n\n'.join(['# '+selection['topicId']+' — attributed topic interpretation',
        'Derived on 24 October 2026 from the retained '+chapter['id']+' chapter synthesis. '
        'This is interpretation of the selected documentary evidence, not independent corroboration, '
        'an observed customer result or a prescribed presentation sequence.', *retained])
    if revision:
        support = list(dict.fromkeys(e for p in provenance for e in p['selectedSupport']))
        body = '\n\n'.join(['# '+selection['topicTitle'],
            'Authored interpretation of the selected evidence; proposed possibilities, not measured H&M outcomes.',
            *retained, 'Supporting sources: '+ '; '.join(sources[e]['title'] for e in support)+'.'])
    return source_record('synthesis:'+selection['topicId'], 'N01 interpretation — '+selection.get('topicTitle',selection['topicId']), body,
        dict(path=chapter['synthesis']['path'], fileSha256=file_hash,
             originalBodySha256=HASH(original), paragraphs=provenance), 'attributed-synthesis', bool(revision))


def configuration(config_path):
    config = read(config_path)
    if config.get('schema') == 'ai-ba.n01-content.v3':
        assert config['id'] == 'content-v3'
        inherited = pinned(config['extends'])
        assert inherited['id'] == 'topic-sources-v2'
        assert set(config['content']) == set(inherited['fragments'])
        inherited.update(id=config['id'], status=config['status'], contentRevision=config)
        assert config['topicCommissions'].keys() <= inherited['topics'].keys()
        for topic_id, labels in config.get('topicSelections', {}).items():
            assert set(labels) <= set(inherited['topics'][topic_id]['fragments'])
            inherited['topics'][topic_id]['fragments'] = labels
        for label, content in config['content'].items():
            assert content.strip()
            inherited['fragments'][label]['content'] = content
        return inherited
    assert config['schema'] == 'ai-ba.n01-topic-sources.v2' and config['id'] == 'topic-sources-v2'
    return config


def projection(config_path=CONFIG):
    if config_path == FULL_CONFIG:
        from types import SimpleNamespace
        return prepare.module(Path(__file__).with_name('full-section.py')).projection(SimpleNamespace(**globals()), config_path)
    if config_path in (BUSINESS_CONFIG, TAILORED_CONFIG, CURRENT_CONFIG, APPLIED_CONFIG):
        from types import SimpleNamespace
        return prepare.module(Path(__file__).with_name('business-sources.py')).projection(SimpleNamespace(**globals()), config_path)
    if config_path == MINIMAL_CONFIG:
        return minimal_projection()
    if config_path in (RECONCILED_CONFIG, WHOLE_CHAPTER_CONFIG):
        return reconciled_projection(config_path)
    config = configuration(config_path)
    revision = config.get('contentRevision')
    base, frozen = pinned(config['base']), pinned(config['frozenRequests'])
    subjects = {s['id']:s for s in base['subjects']}
    chapters = {s['id']:pinned(s['baseline'], FROZEN_AUTHORING_COMMIT) for s in base['subjects']}
    topics = {t['id']:t for s in base['subjects'] for t in s['topics']}
    assert set(config['topics']) == topics.keys() and len(topics) == 93
    assert Counter(t['type'] for t in topics.values()) == {'video':19,'slide_deck':12,'audio':12,'infographic':50}
    sources = evidence_sources(config, chapters)
    prior_sources, topic_rows, requests = {}, {}, []
    for row in frozen['requests']:
        for source in row['selectedSources']:
            sid = source['sourceId']
            if sid in prior_sources:
                assert source['indexedTextSha256'] == prior_sources[sid]['indexedTextSha256']
                continue
            path = ROOT/'.local/n01-comparison/runs/unified-v1/source-readbacks'/(sid+'.json')
            body = read(path)
            assert HASH(body['content']) == source['indexedTextSha256'] and body['title'] == source['title']
            prior_sources[sid] = {**source, 'readbackPath':str(path.relative_to(ROOT)), 'words':len(body['content'].split())}
    for topic_id, selection in config['topics'].items():
        assert selection['fragments'] and len(selection['fragments']) == len(set(selection['fragments']))
        assert set(selection['fragments']) <= sources.keys()
        subject = topic_id.rsplit('.',1)[0]
        identity = {'topicId':topic_id}
        if revision: identity['topicTitle'] = topics[topic_id]['title']
        synthesis = synthesis_source(subjects[subject], {**selection,**identity},
                                     config['synthesisSupport'][subject], sources, revision)
        labels = list(selection['fragments'])
        if synthesis:
            sources[synthesis['label']] = synthesis
            labels.append(synthesis['label'])
        prior = next(r for r in frozen['requests'] if r['topic']['id'] == topic_id)
        old_ids = prior['consumedCreateArguments']['source_ids']
        topic = copy.deepcopy(topics[topic_id])
        if revision and topic_id in revision['topicCommissions']:
            topic['commission'] = revision['topicCommissions'][topic_id]
        topic_rows[topic_id] = {**selection, 'topic':topic, 'sourceLabels':labels,
            'sourceKeys':[sources[label]['key'] for label in labels], 'priorSourceIds':old_ids,
            'priorWords':sum(prior_sources[s]['words'] for s in old_ids),
            'selectedWords':sum(len(sources[label]['body'].split()) for label in labels)}
        if revision:
            topic_rows[topic_id].update(inheritedReview=selection['review'],
                review='Reviewed 24 October: relevant source meaning retained, production administration removed; lighter commission where warranted.',
                synthesisDecision=('Retain the selected interpretation with reviewed prose and source-title references; complete original paragraphs remain in custody.' if synthesis else
                    'No synthesis: selected evidence supplies this topic.'))
    for old in frozen['requests']:
        topic_id = old['topic']['id']; topic = topic_rows[topic_id]
        assert old['topic'] == topics[topic_id]
        template = copy.deepcopy(old['consumedCreateArguments'])
        del template['source_ids']; del template['notebook_id']
        components = copy.deepcopy(old['promptComponents'])
        if revision:
            updates = {'subjectCommission':revision['subjectCommissions'][old['subject']],
                'topicCommission':topic['topic']['commission'], 'evidenceContract':revision['evidenceContract'],
                'treatment':revision['treatments'][old['format']]}
            for component in components:
                if component['role'] in updates:
                    component['text'] = updates[component['role']]
                    component['sha256'] = HASH(component['text'])
            components = [c for c in components if c['text']]
            assert 'focus_prompt' in template
            template['focus_prompt'] = '\n\n'.join(c['text'] for c in components)
        source_keys = topic['sourceKeys']
        plan = dict(method=old['consumedCreateMethod'], arguments=template, sourceKeys=source_keys,
                    sourceBodyHashes={k:next(s['bodySha256'] for s in sources.values() if s['key']==k) for k in source_keys})
        requests.append(dict(key=old['key'].replace('unified-v1-', config['id']+'-',1),
            priorKey=old['key'], priorCompleteInputSha256=old['completeInputSha256'],
            subject=old['subject'], topicId=topic_id, format=old['format'], take=old['take'],
            promptComponents=components, providerTemplate=plan,
            planSha256=HASH(canonical(plan)), providerReady=False))
    assert len(requests) == len({r['key'] for r in requests}) == 198
    assert Counter(topics[r['topicId']]['type'] for r in requests) == base['counts']['byType']
    for topic_id, topic in topics.items():
        rows = [r for r in requests if r['topicId']==topic_id]
        assert len(rows) == (3 if topic['type']=='audio' else 2)
        if topic['type']=='infographic': assert rows[0]['planSha256']==rows[1]['planSha256']
    assert {label for t in topic_rows.values() for label in t['sourceLabels']} == sources.keys()
    return dict(schema='ai-ba.topic-source-plan.v2', id=config['id'], configSha256=HASH(config_path.read_bytes()),
        status=config['status'], counts=base['counts'], providerReady=False, sources=sources,
        priorSources=prior_sources, topics=topic_rows, requests=requests,
        boundary='Offline source/parameter plan. No upload, provider ID, generation, quality improvement or publication is asserted.')


def reconciled_projection(config_path):
    """ADR054 content in ADR052's unchanged component/source/native channels."""
    config = read(config_path)
    whole = config_path == WHOLE_CHAPTER_CONFIG
    assert (config['schema'], config['id']) == (
        ('ai-ba.n01-whole-chapter.v1', 'whole-chapter-v1') if whole else ('ai-ba.n01-content.v4', 'content-v4'))
    pinned(config['extends'])
    assert config['extends']['path'] == str(CONTENT_CONFIG.relative_to(ROOT))
    prior = projection(CONTENT_CONFIG)
    catalogue = {}
    if whole:
        basis = pinned(config['contentBasis'])
        assert config['contentBasis']['path'] == str(RECONCILED_CONFIG.relative_to(ROOT))
        adopted = {c['subject']: c for c in (pinned(d) for d in basis['chapters'])}
        chapters = copy.deepcopy(config['chapters'])
        descriptors = [dict(path=str(config_path.relative_to(ROOT)), sha256=HASH(config_path.read_bytes()))] * len(chapters)
        for chapter in chapters:
            pinned(chapter['authoringBasis'], FROZEN_AUTHORING_COMMIT)
            assert chapter['title'] == adopted[chapter['subject']]['title']
            assert chapter['subjectCommission'] == adopted[chapter['subject']]['subjectCommission']
            assert Counter(t['type'] for t in chapter['topics']) == dict(video=1, slide_deck=1, audio=1, infographic=1)
            chapter['schema'] = 'ai-ba.topic-reconciliation.v1'
            for topic in chapter['topics']:
                assert topic['title'] == chapter['title']
                catalogue[topic['id']] = (topic['type'], topic['title'])
                topic.update(evidenceLabels=chapter['evidenceLabels'], synthesis=None, priorTopicIds=[], review=chapter['review'])
    else:
        authority = ROOT / config['topicAuthority']['path']
        assert HASH(authority.read_bytes()) == config['topicAuthority']['sha256']
        for line in authority.read_text().splitlines():
            cells = [cell.strip() for cell in line.split('|')[1:-1]]
            if len(cells) == 4 and cells[1] in ('video', 'deck', 'audio', 'infographic'):
                catalogue[cells[0]] = (cells[1].replace('deck', 'slide_deck'), cells[2])
        descriptors = config['chapters']
        chapters = [pinned(descriptor) for descriptor in descriptors]
    subjects = [chapter['subject'] for chapter in chapters]
    assert subjects == ['N01.01', 'N01.02', 'N01.03']
    sources, topics, requests = {}, {}, []
    for chapter, descriptor in zip(chapters, descriptors):
        assert chapter['schema'] == 'ai-ba.topic-reconciliation.v1'
        for topic in chapter['topics']:
            tid = topic['id']; labels = list(topic['evidenceLabels'])
            assert tid.startswith(chapter['subject']+'.') and tid not in topics
            assert catalogue[tid] == (topic['type'], topic['title'])
            assert labels and len(labels) == len(set(labels))
            for label in labels:
                source = prior['sources'][label]
                assert source['role'] != 'attributed-synthesis' and HASH(source['body']) == source['bodySha256']
                sources[label] = copy.deepcopy(source)
            assert (whole or topic['priorTopicIds']) and set(topic['priorTopicIds']) <= prior['topics'].keys()
            if topic['synthesis']:
                synth = topic['synthesis']
                assert synth['supports'] and set(synth['supports']) <= set(labels)
                lineage = []
                for origin in synth['derivedFrom']:
                    original = prior['sources']['synthesis:'+origin['topicId']]
                    assert original['bodySha256'] == origin['bodySha256']
                    lineage.append(copy.deepcopy(original))
                assert lineage and synth['body'].strip()
                label = 'synthesis:'+tid
                sources[label] = source_record(label, 'N01 interpretation — '+topic['title'], synth['body'],
                    dict(authoring=descriptor, derivedFrom=lineage, selectedSupport=synth['supports'],
                         transformation='Topic reconciliation; complete prior interpretation and source lineage retained.'),
                    'attributed-synthesis', True)
                labels.append(label)
            source_keys = [sources[label]['key'] for label in labels]
            topics[tid] = dict(topic={k:topic[k] for k in ('id','type','title','commission')},
                subjectCommission=chapter['subjectCommission'], sourceLabels=labels, sourceKeys=source_keys,
                priorTopicIds=topic['priorTopicIds'], review=topic['review'], authoring=descriptor,
                selectedWords=sum(len(sources[label]['body'].split()) for label in labels))
            if whole:
                topics[tid].update(topicFamily=config['topicFamily'], definition=chapter['definition'],
                    selectionRationale=chapter['selectionRationale'], scopeBoundary=chapter['scopeBoundary'],
                    synthesisDecision=config['instructionStructure']['synthesis'])
            # Select the established format set by media type, never by a reused topic number.
            templates = [r for r in prior['requests'] if r['subject'] == chapter['subject']
                         and prior['topics'][r['topicId']]['topic']['type'] == topic['type']]
            template_topic = next((p for p in topic['priorTopicIds']
                                   if prior['topics'][p]['topic']['type'] == topic['type']), templates[0]['topicId'])
            for old in (r for r in templates if r['topicId'] == template_topic):
                components = copy.deepcopy(old['promptComponents'])
                updates = dict(subjectCommission=chapter['subjectCommission'], topicCommission=topic['commission'])
                for component in components:
                    if component['role'] in updates:
                        component['text'] = updates[component['role']]
                        component['sha256'] = HASH(component['text'])
                template = copy.deepcopy(old['providerTemplate'])
                template['arguments']['focus_prompt'] = '\n\n'.join(c['text'] for c in components)
                template.update(sourceKeys=source_keys,
                    sourceBodyHashes={sources[label]['key']:sources[label]['bodySha256'] for label in labels})
                suffix = '-take-'+str(old['take']) if topic['type'] == 'infographic' else ''
                requests.append(dict(key=f"{config['id']}-{tid}-{old['format']}{suffix}", subject=chapter['subject'],
                    topicId=tid, format=old['format'], take=old['take'], promptComponents=components,
                    nativeSettingsFrom=old['key'], priorTopicIds=topic['priorTopicIds'],
                    providerTemplate=template, planSha256=HASH(canonical(template)), providerReady=False))
    assert set(topics) == {tid for tid in catalogue if tid.rsplit('.',1)[0] in subjects}
    if not whole:
        assert {p for t in topics.values() for p in t['priorTopicIds']} == {
            tid for tid in prior['topics'] if tid.rsplit('.',1)[0] in subjects}
    assert len(topics) == (12 if whole else 47)
    assert len(requests) == len({r['key'] for r in requests}) == (27 if whole else 100)
    return dict(schema='ai-ba.topic-source-plan.v2', id=config['id'], configSha256=HASH(config_path.read_bytes()),
        status=config['status'], counts=dict(scopes=3, topics=len(topics), outputs=len(requests),
            byType=dict(Counter(topics[r['topicId']]['topic']['type'] for r in requests))),
        providerReady=False, sources=sources, priorSources=prior['priorSources'], topics=topics, requests=requests,
        boundary='Offline reconciliation only. Existing runs unchanged; source upload and generation have not occurred.')


def minimal_projection():
    """Keep the prior source/settings packages; commission only subject and audience."""
    config = read(MINIMAL_CONFIG)
    assert (config['schema'], config['id']) == ('ai-ba.n01-minimal.v1', 'minimal-v1')
    assert [ROOT/d['path'] for d in config['extends']] == [RECONCILED_CONFIG, WHOLE_CHAPTER_CONFIG]
    chapters = config['chapters']
    assert [c['subject'] for c in chapters] == ['N01.01','N01.02','N01.03']
    topics = {t['id']:t for c in chapters for t in c['topics']}
    assert len(topics) == sum(len(c['topics']) for c in chapters) == 59
    plans = []
    for descriptor in config['extends']:
        pinned(descriptor)
        plans.append(projection(ROOT/descriptor['path']))
    result = copy.deepcopy(plans[0])
    for field in ('sources','topics','priorSources'):
        for key,value in plans[1][field].items():
            assert key not in result[field] or result[field][key] == value
            result[field][key] = copy.deepcopy(value)
    result['requests'].extend(copy.deepcopy(plans[1]['requests']))
    assert set(topics) == set(result['topics'])
    for tid,definition in topics.items():
        prior = result['topics'][tid]['topic']
        assert all(definition[k] == prior[k] for k in ('id','type','title'))
        assert definition['commission'].strip() and config['purposeAndAudience'].strip()
        result['topics'][tid].update(topic=copy.deepcopy(definition),subjectCommission='')
    for request in result['requests']:
        request['priorRequestKey'] = request['key']
        request['key'] = 'minimal-v1-'+request['key'][request['key'].index(request['subject']):]
        request['promptComponents'] = [dict(role=role,text=text,destination='focus_prompt',sha256=HASH(text))
            for role,text in [('topicCommission',topics[request['topicId']]['commission']),
                              ('purposeAndAudience',config['purposeAndAudience'])]]
        request['providerTemplate']['arguments']['focus_prompt'] = '\n\n'.join(c['text'] for c in request['promptComponents'])
        request['planSha256'] = HASH(canonical(request['providerTemplate']))
    result['requests'].sort(key=lambda r:(r['subject'],r['topicId'],r['format'],r['take'] or 0))
    assert len(result['requests']) == len({r['key'] for r in result['requests']}) == 127
    result.update(id=config['id'],configSha256=HASH(MINIMAL_CONFIG.read_bytes()),status=config.get('status','configured'),
        counts=dict(scopes=3,topics=59,outputs=127,byType=dict(Counter(result['topics'][r['topicId']]['topic']['type'] for r in result['requests']))),
        boundary='New local minimal-instruction run; previous source bodies, selections and native settings retained.')
    return result


def coverage(plan, subjects):
    """Explicit commissioned subset of the unchanged reviewed package."""
    known = list(dict.fromkeys(r['subject'] for r in plan['requests']))
    assert subjects and subjects == [s for s in known if s in subjects]
    requests = [r for r in plan['requests'] if r['subject'] in subjects]
    keys = sorted({k for r in requests for k in r['providerTemplate']['sourceKeys']})
    return dict(subjects=subjects, requestKeys=[r['key'] for r in requests],
        topicIds=list(dict.fromkeys(r['topicId'] for r in requests)), sourceKeys=keys,
        sourcePlanSha256=HASH(canonical(plan)))


def bind_verified(plan, receipt, readbacks, subjects=None):
    """Resolve only the focused bodies; complete readback proof is mandatory.

    A separate receipt/notebook is required. Never treat original whole-source
    IDs, authoring labels or empty selections as provider-ready topic inputs.
    """
    config_path = {'content-v3':CONTENT_CONFIG, 'content-v4':RECONCILED_CONFIG,
                   'whole-chapter-v1':WHOLE_CHAPTER_CONFIG, 'minimal-v1':MINIMAL_CONFIG,
                   'business-v1':BUSINESS_CONFIG, 'tailored-v2':TAILORED_CONFIG, 'tailored-v3':CURRENT_CONFIG, 'applied-rules-v1':APPLIED_CONFIG, 'full-section-v1':FULL_CONFIG}.get(plan['id'], CONFIG)
    assert canonical(plan) == canonical(projection(config_path)), 'Stale or altered source plan'
    assert receipt.get('notebookId') and receipt.get('packageId') == plan['id']
    assert receipt.get('availabilityVerifiedAt') and receipt.get('verifiedNotebookSourceIds')
    selected = coverage(plan, subjects) if subjects is not None else None
    if selected:
        assert receipt.get('coverage') == selected, 'Selected scope lacks exact coverage proof'
        assert set(receipt['sources']) == set(selected['sourceKeys']), 'Imports differ from commissioned scope'
    frozen_notebooks = {r['consumedCreateArguments']['notebook_id'] for r in pinned(read(CONFIG)['frozenRequests'])['requests']}
    if plan['id'] in ('content-v3','content-v4','whole-chapter-v1','minimal-v1','business-v1','tailored-v2','tailored-v3','applied-rules-v1'):
        previous = pinned(read(CONTENT_CONFIG)['priorSubmittedRequests'])
        frozen_notebooks.update(r['consumedCreateArguments']['notebook_id'] for r in previous['requests'])
    if plan['id'] in ('content-v4','whole-chapter-v1','minimal-v1','business-v1','tailored-v2','tailored-v3','applied-rules-v1'):
        previous = read(ROOT/'.local/n01-comparison/runs/content-v3/request-inputs.json')
        frozen_notebooks.update(r['consumedCreateArguments']['notebook_id'] for r in previous['requests'])
    for variant in (['content-v4','whole-chapter-v1','minimal-v1','business-v1','tailored-v2','tailored-v3'] if plan['id']=='applied-rules-v1' else ['content-v4','whole-chapter-v1','minimal-v1','business-v1','tailored-v2'] if plan['id']=='tailored-v3' else ['content-v4','whole-chapter-v1','minimal-v1','business-v1'] if plan['id']=='tailored-v2' else ['content-v4','whole-chapter-v1','minimal-v1'] if plan['id']=='business-v1' else ['content-v4','whole-chapter-v1'] if plan['id']=='minimal-v1' else ['content-v4'] if plan['id']=='whole-chapter-v1' else []):
        previous_path = ROOT/'.local/n01-comparison/runs'/variant/'request-inputs.json'
        if not previous_path.exists(): continue
        previous = read(previous_path)
        frozen_notebooks.update(r['consumedCreateArguments']['notebook_id'] for r in previous['requests'])
    assert receipt['notebookId'] not in frozen_notebooks, 'Do not import into the frozen active notebook'
    verified = {}
    for source in plan['sources'].values():
        if selected and source['key'] not in selected['sourceKeys']: continue
        row = receipt['sources'][source['key']]
        sid = row.get('sourceId')
        assert sid and sid not in plan['priorSources'], 'Whole-source IDs cannot stand in for focused inputs'
        assert sid in receipt['verifiedNotebookSourceIds'], 'Focused source absent from the target notebook'
        assert row['status'] == 'indexed-verified' and row['title'] == source['title']
        assert row['originalSha256'] == source['bodySha256']
        assert row['sha256'] == row['uploadedPresentationSha256'] == source['uploadedPresentationSha256']
        indexed = readbacks[sid]
        assert indexed['title'] == source['title'] and HASH(indexed['content']) == row['indexedTextSha256']
        wanted = re.findall(r'\w+',source['body']); actual = re.findall(r'\w+',indexed['content'])
        assert actual in (wanted, ['text']+wanted, wanted+['text']), 'Focused indexed body changed'
        verified[source['key']] = row
    assert len({s['sourceId'] for s in verified.values()}) == len(verified), 'Focused sources share a provider identity'
    result = []
    for request in plan['requests']:
        if selected and request['key'] not in selected['requestKeys']: continue
        template = request['providerTemplate']; keys = template['sourceKeys']
        assert keys and all(k in verified for k in keys)
        args = {**template['arguments'], 'notebook_id':receipt['notebookId'],
                'source_ids':[verified[k]['sourceId'] for k in keys]}
        package = dict(method=template['method'], arguments=args,
                       indexedSourceHashes={verified[k]['sourceId']:verified[k]['indexedTextSha256'] for k in keys})
        result.append({**request, 'consumedCreateArguments':args, 'consumedCreateMethod':template['method'],
            'selectedSources':[verified[k] for k in keys], 'completeInputSha256':HASH(canonical(package)), 'providerReady':True})
    return result


def save_plan(plan, directory=WORK):
    """Idempotent local preparation with no timestamp churn or runtime writes."""
    directory.mkdir(parents=True, exist_ok=True)
    def save(path, text):
        if path.exists() and path.read_text() == text: return
        prepare.quota.atomic_json(path, json.loads(text))
    for source in plan['sources'].values():
        save(directory/'sources'/(source['bodySha256']+'.json'), json.dumps(source,ensure_ascii=False,indent=2)+'\n')
    save(directory/'source-plan.json', json.dumps(plan,ensure_ascii=False,indent=2)+'\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare', action='store_true', help='Write the isolated offline source plan')
    parser.add_argument('--content-v3', action='store_true', help='Prepare the section-one content correction; never changes a running queue')
    parser.add_argument('--content-v4', action='store_true', help='Prepare ADR054 chapters 1–3 offline with the existing ADR052 structure')
    parser.add_argument('--whole-chapter', action='store_true', help='Prepare the additive whole-chapter sets for chapters 1–3; no provider calls')
    args = parser.parse_args()
    assert sum((args.content_v3, args.content_v4, args.whole_chapter)) <= 1, 'Choose one content version'
    plan = projection(WHOLE_CHAPTER_CONFIG if args.whole_chapter else RECONCILED_CONFIG if args.content_v4 else CONTENT_CONFIG if args.content_v3 else CONFIG)
    directory = ROOT/'.local/n01-whole-chapter-v1' if args.whole_chapter else ROOT/'.local/n01-topic-source-v4' if args.content_v4 else ROOT/'.local/n01-topic-source-v3' if args.content_v3 else WORK
    if args.prepare: save_plan(plan, directory)
    print(json.dumps(dict(scopes=len({r['subject'] for r in plan['requests']}),topics=len(plan['topics']),requests=len(plan['requests']),
        sources=len(plan['sources']),providerReady=False,providerMutations=0,
        sourcePlanSha256=HASH(canonical(plan)))))
