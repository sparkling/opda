"""Rebuild the private matched six-deck history and exact local asset allowlist; no server/jobs."""
import argparse
import hashlib
import html
import json
import os
import re
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import quote, unquote, urlsplit
import markdown

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / '.local'
WORK = LOCAL / 'notebook-deck-next-trial'
RUNS = LOCAL / 'n01-comparison/runs'
VERSIONS = LOCAL / 'n01-comparison/versions'
SHARED_PREVIEW = (ROOT / json.loads((ROOT / 'config/shared-renderer.json').read_text())['checkout'] / 'site/src/scripts/notebooklm-deck-preview.js').resolve()
FORMATS = ('detailed_deck', 'presenter_slides')
PURPOSES = {
    'N01.01': ('What could H&M become capable of?', 'Open a varied landscape of worthwhile business possibilities, with concrete examples and understandable value.'),
    'N01.02': ('What makes this an enterprise strategy?', 'Explain the connected strategic actions and how business change, shared capability and people reinforce one another.'),
    'N01.03': ('How would work and value actually change?', 'Make changed tasks, relationships and outcomes tangible, and explain different kinds of value.'),
}
CHAPTER_LABELS = {'N01.01': 'Possibilities', 'N01.02': 'Enterprise strategy', 'N01.03': 'Work and value'}
EXPECTED = {(c + '.WD01', f) for c in PURPOSES for f in FORMATS}
DESCRIPTIONS = {
    'whole-chapter-v1': ('Original chapter briefs', 'Extended purpose, topic commission, independent-reading treatment and evidence guidance, with the original evidence readings and selected interpretations.'),
    'minimal-v1': ('Shorter prompts', 'Short topic and audience prompts replace the extended commissions. The original selected readings and interpretations remain.'),
    'business-v1': ('Business-facing sources', 'Business-facing source bodies explain useful work, possibilities and value. The shorter prompts remain.'),
    'tailored-v2': ('Tailored topic sources', 'Richer selected readings, narrower selections and no extra synthesis. Deck prompts retain the topic and audience and add independent reading. This is the baseline for the focused tests.'),
    'round-1': ('Add a visual aim', 'Keep the tailored sources and native settings; append only: “Make this an engaging, visually rich explanation of the business possibilities.”'),
    'round-2': ('Strengthen business substance', 'Keep the previous prompts and settings. Remove overlapping sources, foreground Product renewal and local applications, and explain concrete value mechanisms.'),
    'round-3': ('Remove the independent-reading instruction', 'Remove only “A deck for independent reading.” All selected source bodies, other prompt wording and native settings remain unchanged.'),
    'round-4': ('Refine source emphasis by chapter', 'Keep the previous prompts and settings. Chapter 1 develops an illustrative service exchange; chapter 2 removes an overlapping capability reading; chapter 3 reduces repeated setup while retaining concrete value mechanisms.'),
}
ORDER = ('whole-chapter-v1', 'minimal-v1', 'business-v1', 'tailored-v2', 'round-1', 'round-2')
SENSITIVE = re.compile(r'(?i)(x-goog-signature|x-amz-signature|[?&](?:sig|signature|token)=|access_token|refresh_token|authorization["\s:]+bearer)')
FILES = set()
BODIES = {}
USED = {}
SAFE = {}
STYLE = '''*{box-sizing:border-box}:root{color-scheme:light}body{margin:0;background:#f5f3ed;color:#22332e;font:17px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}header,main,footer{width:min(1760px,100% - 64px);margin-inline:auto}header{padding:40px 0 26px;border-bottom:1px solid #c6cec7}h1{font-size:clamp(2rem,4vw,3.4rem);line-height:1.08;letter-spacing:-.035em;max-width:25ch;margin:12px 0 22px}h2,h3,h4{line-height:1.2;margin:0 0 16px}h2{font-size:1.9rem}h3{font-size:1.25rem}h4{font-size:1.1rem}p{margin:0 0 16px}.intro,.purpose{max-width:85ch}.eyebrow{font-size:.78rem;letter-spacing:.08em;text-transform:uppercase;font-weight:700;color:#52675a}.muted,small{color:#52675a;font-size:.84rem}small{display:block;overflow-wrap:anywhere}a{color:#145d49;text-underline-offset:3px}a:focus-visible,summary:focus-visible{outline:3px solid #b67b28;outline-offset:4px}nav{display:flex;flex-wrap:wrap;gap:12px 24px}.chapter,#judgement,#sources,#history{padding:36px 0;border-bottom:1px solid #c6cec7;scroll-margin-top:20px}.comparison{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px;align-items:start}.run{padding:22px;background:#fffefa;border:1px solid #d5dbd2;border-radius:6px;min-width:0;scroll-margin-top:20px}.status{font-weight:650;margin-bottom:8px}.actions{font-size:.9rem;padding:12px 0;border-block:1px solid #d5dbd2;margin:14px 0}details{margin:14px 0;border-top:1px solid #d5dbd2;padding-top:12px}summary{cursor:pointer;font-weight:650}details[open]>summary{margin-bottom:16px}pre{font:.88rem/1.6 ui-monospace,SFMono-Regular,monospace;white-space:pre-wrap;overflow-wrap:anywhere;background:#efeee7;padding:16px;max-height:36rem;overflow:auto}code{overflow-wrap:anywhere}li{margin-bottom:10px}ol{padding-left:22px}figure{margin:18px 0}img{display:block;width:100%;height:auto;background:#e8e9e2}figcaption{font-size:.85rem;margin-top:6px}.source{scroll-margin-top:20px}.source:target,.run:target{outline:2px solid #b67b28;outline-offset:6px}.source[open] pre{max-height:none}.history{padding:22px 0;border-top:1px solid #d5dbd2}.review-body{max-width:110ch;overflow-x:auto}.review-body h1{font-size:1.8rem}.review-body table{border-collapse:collapse;font-size:.86rem}.review-body th,.review-body td{padding:9px;border:1px solid #c6cec7;text-align:left;vertical-align:top}.review-body pre{max-height:none}footer{border-top:1px solid #c6cec7;padding:24px 0 36px;font-size:.88rem;color:#52675a}@media(max-width:1050px){.comparison{grid-template-columns:1fr}.run{padding:20px}}@media(max-width:760px){header,main,footer{width:calc(100% - 32px)}}'''

STYLE += '''.history-layout{display:grid;grid-template-columns:245px minmax(0,1fr);gap:32px;width:min(1760px,100% - 64px);margin-inline:auto}.history-layout>main{width:100%;min-width:0;margin:0}.history-sidebar{align-self:start;position:sticky;top:20px;max-height:calc(100vh - 40px);overflow-y:auto;padding:30px 16px 20px 0}.history-sidebar nav{display:block;font-size:.88rem}.history-sidebar h2{font-size:1.05rem}.history-sidebar details{margin:10px 0;padding-top:10px}.history-sidebar details[open]>summary{margin-bottom:8px}.history-sidebar ul{list-style:none;padding:0;margin:8px 0 12px}.history-sidebar li{margin:7px 0}.history-sidebar a{display:block;padding:2px 0;text-decoration:none}.history-sidebar a:hover{text-decoration:underline}.chapter-links{padding-left:10px;border-left:1px solid #c6cec7}.chapter-links details{border-top:0;padding-top:0}.chapter-links ul{padding-left:10px}.history-sidebar .report-links{border-top:1px solid #c6cec7;padding-top:12px}[id$="-inputs"],[id$="-reviews"],.history{scroll-margin-top:20px}@media(min-width:1101px) and (max-width:1450px){.history-layout .comparison{grid-template-columns:1fr}}@media(max-width:1100px){.history-layout{display:block}.history-sidebar{position:static;max-height:none;overflow:visible;padding:24px 0;border-bottom:1px solid #c6cec7}}@media(max-width:760px){.history-layout{width:calc(100% - 32px)}}'''
STYLE += '''.experiment{margin:20px 0;padding:20px 0;border-top:1px solid #a9b8ad}.experiment>summary{font-size:1.3rem}.experiment>summary small{font-weight:400;margin-top:5px}.history{border:0;padding:16px 0}.chapter>small{margin:-6px 0 20px}.history-sidebar h3{font-size:.9rem;margin:24px 0 10px}.history-sidebar h3>a{color:#52675a}.deck-preview{display:block}.inputs h5{font-size:.95rem;margin:24px 0 12px}.source-group>.source{margin-left:12px;padding-left:12px;border-left:1px solid #c6cec7}#earlier-approaches,#focused-tests,#method{padding:24px 0;scroll-margin-top:20px}#method{border-top:1px solid #c6cec7}.run>h4{font-size:1.3rem}'''
STYLE += '''.deck-preview>a{display:block;aspect-ratio:16/9}.deck-preview>a>img{height:100%;object-fit:contain}.preview-controls{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 0}.preview-position{display:flex;align-items:center;justify-content:center;gap:10px;font-size:.85rem}.slide-action{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;flex:0 0 40px;border:1px solid #a9b8ad;border-radius:4px;background:transparent;color:#145d49;cursor:pointer}.slide-action:disabled{opacity:.35;cursor:default}.slide-action:focus-visible{outline:3px solid #b67b28;outline-offset:3px}.slide-action svg{width:20px;height:20px}'''


def read(path, default=None):
    return json.loads(path.read_text()) if path.is_file() else default


def esc(value):
    return html.escape(str(value), quote=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def safe(path):
    path = path.resolve()
    if path in SAFE:
        return SAFE[path]
    if not path.is_relative_to(ROOT) or not path.is_file() or path.suffix.lower() not in ('.json', '.md', '.txt', '.html', '.pdf', '.webp', '.jpg', '.png', '.jpeg'):
        return False
    SAFE[path] = not (path.suffix.lower() in ('.json', '.md', '.txt', '.html') and SENSITIVE.search(path.read_text()))
    return SAFE[path]


def url(path, absolute=False):
    path = path.resolve()
    if not safe(path):
        raise ValueError('Unsafe/missing local reference: ' + str(path))
    FILES.add(path)
    if path.is_relative_to(LOCAL):
        return '/experiments/' + quote(str(path.relative_to(LOCAL)), safe='/') if absolute else quote(os.path.relpath(path, WORK), safe='/')
    return '/reference/' + quote(str(path.relative_to(ROOT)), safe='/')


def link(path, label):
    return f'<a href="{url(path)}">{esc(label)}</a>' if safe(path) else f'<span class="muted">{esc(label)} unavailable</span>'


def collect(value):
    if isinstance(value, dict):
        body, digest = value.get('body'), value.get('bodySha256')
        if isinstance(body, str) and digest and hashlib.sha256(body.encode()).hexdigest() == digest:
            BODIES[digest] = {'title': value.get('title', 'Reading'), 'body': body, 'hash': digest, 'layer': 'Authored reading body', 'previous': value.get('provenance', {}).get('previousSource', {}).get('bodySha256')}
        for child in value.values():
            if isinstance(child, (dict, list)):
                collect(child)
    elif isinstance(value, list):
        for child in value:
            collect(child)


class ReviewHTML(HTMLParser):
    """Keep rendered Markdown local: rewrite exact file links, disable remote/raw HTML resources."""
    def __init__(self, parent, allowed=None, absolute=False):
        super().__init__(convert_charrefs=False)
        self.parent, self.output = parent, []
        self.allowed, self.absolute = allowed, absolute

    def handle_starttag(self, tag, attrs):
        if tag not in {'p', 'a', 'strong', 'em', 'code', 'pre', 'blockquote', 'ul', 'ol', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'hr', 'br', 'del'}:
            return
        out = []
        for key, value in attrs:
            if tag == 'a' and key == 'href':
                parsed = urlsplit(value)
                if parsed.scheme or parsed.netloc:
                    continue
                if not parsed.path and parsed.fragment and self.absolute:
                    out.append(('href', '#' + quote(unquote(parsed.fragment), safe='-_'))); continue
                p = (self.parent / unquote(parsed.path)).resolve()
                if (self.allowed is None or p in self.allowed) and safe(p):
                    href = url(p, self.absolute)
                    if parsed.fragment:
                        href += '#' + quote(unquote(parsed.fragment), safe='-_')
                    out.append(('href', href))
            elif tag in {'h1', 'h2', 'h3', 'h4', 'h5', 'h6'} and key == 'id':
                out.append(('id', value))
        self.output.append('<' + tag + ''.join(f' {k}="{esc(v)}"' for k, v in out) + '>')

    def handle_endtag(self, tag):
        if tag in {'p', 'a', 'strong', 'em', 'code', 'pre', 'blockquote', 'ul', 'ol', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'del'}:
            self.output.append('</' + tag + '>')

    def handle_data(self, text):
        self.output.append(esc(text))

    def handle_entityref(self, name):
        self.output.append('&' + name + ';')

    def handle_charref(self, name):
        self.output.append('&#' + name + ';')


def rendered_markdown(text, parent, allowed=None, absolute=False):
    parser = ReviewHTML(parent, allowed, absolute)
    parser.feed(markdown.markdown(text, extensions=['tables', 'fenced_code'] + (['toc'] if absolute else [])))
    return f'<div class="review-body">{"".join(parser.output)}</div>'


def reading(text, parent, allowed=None, absolute=False):
    return rendered_markdown(text, parent, allowed, absolute) + f'<details class="exact"><summary>Exact original text</summary><pre>{esc(text)}</pre></details>'


def markdown_document(path, request_path, allowed):
    """Render an already allowlisted document without admitting any new linked file."""
    content = reading(path.read_text(), path.parent, allowed, absolute=True)
    return f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(path.name)}</title><style>{STYLE}</style></head><body><header><p class="eyebrow">Private local reading</p><h1>{esc(path.name)}</h1><nav><a href="/experiments/notebook-deck-next-trial/report.html">Deck history</a><a href="{esc(request_path)}?raw=1" download>Download exact Markdown</a></nav></header><main>{content}</main></body></html>'


def review(path, label=None, expanded=False):
    if not safe(path):
        return ''
    title = label or path.name + ' · ' + path.parent.name
    return f'<details class="review"{" open" if expanded else ""}><summary>{esc(title)}</summary><p>{link(path, "Open formatted review")} · <a href="{url(path)}?raw=1" download>Download exact Markdown</a></p>{reading(path.read_text(), path.parent)}</details>'


def discover():
    found, omitted = [], []
    for input_path in sorted(RUNS.glob('*/request-inputs.json')):
        data = read(input_path)
        rows = data.get('requests', []) if isinstance(data, dict) else data
        selected = [r for r in rows if (r.get('topicId'), r.get('format')) in EXPECTED]
        if {(r['topicId'], r['format']) for r in selected} != EXPECTED or len(selected) != 6:
            omitted.append(input_path.parent.name)
            continue
        jobs = [j for p in sorted((input_path.parent / 'docs/generation').glob('*.json')) for j in read(p).get('jobs', [])]
        sources = {}
        for req in selected:
            collect(req['selectedSources'])
            for s in req['selectedSources']:
                sources[s['key']] = s
        found.append({'id': input_path.parent.name, 'input': input_path, 'directory': input_path.parent, 'requests': selected, 'jobs': jobs, 'sourceInfo': sources, 'total': len(rows), 'private': False})
    for input_path in sorted(WORK.glob('round-*-inputs.json')):
        data = read(input_path)
        selected = [r for r in data['requests'] if (r.get('topicId'), r.get('format')) in EXPECTED]
        if len(selected) != 6 or {(r['topicId'], r['format']) for r in selected} != EXPECTED:
            continue
        collect(data['sources'])
        run_id = input_path.name.removesuffix('-inputs.json')
        directory = WORK / run_id
        info = read(directory / 'source-import.json', {'sources': {}})['sources']
        jobs = read(directory / 'generation.json', {'jobs': []})['jobs']
        for job in jobs:
            for key, source_id in zip(job.get('sourceKeys', []), job.get('sourceIds', [])):
                info.setdefault(key, {'sourceId': source_id})
        found.append({'id': run_id, 'title': data.get('title'), 'input': input_path, 'directory': directory, 'requests': selected, 'jobs': jobs, 'sourceInfo': info, 'authored': data['sources'], 'total': len(data['requests']), 'change': data.get('change'), 'private': True})
    return sorted(found, key=lambda r: (ORDER.index(r['id']) if r['id'] in ORDER else len(ORDER), r['id'])), omitted


def figures(paths, label):
    return ''.join(f'<figure><a href="{url(p)}"><img data-src="{url(p)}" loading="lazy" decoding="async" alt="{esc(label)} {i}"></a><figcaption>{link(p, label + " " + str(i))}</figcaption></figure>' for i, p in enumerate(paths, 1))


def deck_preview(images, pdf, title):
    if not images:
        return ''
    icons = {'previous': 'm15 5-7 7 7 7', 'next': 'm9 5 7 7-7 7', 'download': 'M12 3v12m-5-5 5 5 5-5M5 17v4h14v-4'}
    def icon(kind):
        return f'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="{icons[kind]}"></path></svg>'
    previous = f'<button type="button" class="slide-action" data-preview-previous disabled aria-label="Previous slide" title="Previous slide">{icon("previous")}</button>'
    next_button = f'<button type="button" class="slide-action" data-preview-next disabled aria-label="Next slide" title="Next slide">{icon("next")}</button>'
    download = f'<a class="slide-action" data-preview-download href="{url(images[0])}" download="{esc(images[0].name)}" aria-label="Download current slide" title="Download current slide">{icon("download")}</a>'
    counter = f'<span class="preview-position"><span data-preview-counter aria-live="polite" aria-atomic="true">Slide 1 of {len(images)}</span>{download}</span>'
    return f'<div class="deck-preview" data-deck-preview data-title="{esc(title)}"><a href="{url(pdf) if safe(pdf) else url(images[0])}"><img src="{url(images[0])}" loading="lazy" decoding="async" alt="{esc(title)}, slide 1 of {len(images)}"></a><div class="preview-controls" role="group" aria-label="Slide controls for {esc(title)}">{previous}{counter}{next_button}</div></div>'


def card(run, chapter, fmt):
    req = next(r for r in run['requests'] if (r['topicId'], r['format']) == (chapter + '.WD01', fmt))
    job = next((j for j in run['jobs'] if j.get('key') == req['key']), {})
    directory, rid = run['directory'], run['id']
    if run['private']:
        prompt = req['focus_prompt']
        keys = req['sourceKeys']
        selected = [{**run['authored'][key], **run['sourceInfo'].get(key, {})} for key in keys]
        args = {k: req[k] for k in ('format', 'language', 'length_code')}
    else:
        prompt = req['consumedCreateArguments']['focus_prompt']
        selected = req['selectedSources']
        args = {k: v for k, v in req['consumedCreateArguments'].items() if k not in ('notebook_id', 'source_ids', 'focus_prompt')}
    pdf = directory / f'originals/{req["key"]}.pdf'
    original = job.get('original', {})
    if original.get('path') and (ROOT / original['path']).is_file():
        pdf = ROOT / original['path']
    manifest = read(directory / f'{job.get("id", "missing")}-slides.json', {})
    images = [Path(manifest['directory']) / Path(s['path']).name for s in manifest.get('slides', [])]
    if not images and job.get('id'):
        first = sorted(VERSIONS.glob(f'*/presentations/*/media/{job["id"]}-slide-001.webp'))
        if first:
            images = sorted(first[0].parent.glob(job['id'] + '-slide-*.webp'))
    images = [p for p in images if safe(p)]
    contacts = sorted(directory.glob(req['key'] + '-*-contact.jpg'))
    for p in [directory / f'review-20261025/static/{req["key"]}.jpg', directory / f'review-20261025/decks/{req["topicId"]}-{fmt}.jpg', directory / f'review-20261025/decks/{req["topicId"]}-{fmt}-new.jpg']:
        if safe(p):
            contacts.append(p)
    rows = []
    for source in selected:
        sid = source.get('sourceId', 'unrecorded')
        readback = directory / f'source-readbacks/{sid}.json'
        body_hash = source.get('bodySha256') or source.get('originalSha256')
        record = BODIES.get(body_hash)
        if not record and safe(readback):
            content = read(readback)['content']
            body_hash = hashlib.sha256(content.encode()).hexdigest()
            record = {'title': source['title'], 'body': content, 'hash': body_hash, 'layer': 'Indexed provider text; authored body not recovered in this view'}
        if record:
            USED.setdefault(body_hash, {**record, 'usedBy': set()})['usedBy'].add(rid)
            body_link = f'<a href="#source-{body_hash}">{esc(source["title"])}</a>'
        else:
            body_link = esc(source['title']) + ' · body unavailable'
        rows.append(f'<li>{body_link}<small>Selected source ID <code>{esc(sid)}</code> · {esc(source.get("role", "reading"))}<br>{link(readback, "Exact indexed readback")}</small></li>')
    metadata = directory / ('generation.json' if run['private'] else f'docs/generation/{chapter}.json')
    native = 'Settings/source proof recorded' if job.get('providerProof', {}).get('settingsVerified') else 'No settings/source proof recorded in this view'
    settings = {**args, 'recorded_native_settings': job.get('settings', {}), 'settings_verified': job.get('providerProof', {}).get('settingsVerified', False)}
    title = run_title(run)
    media = ''.join(f'<details class="gallery"{slidable}><summary>{label} ({len(paths)})</summary>{figures(paths, title + " " + label.lower())}</details>' for label, paths, slidable in [('Full slides', images, ' data-deck-slides'), ('Contact sheets', contacts, '')] if paths)
    status = f'{len(images)} rendered slides' if images else 'Rendered slides pending'
    commission = req.get('topic', {}).get('commission')
    commission_html = f'<h5>Retained authoring metadata</h5><p class="muted">This commission is context; it is not additional submitted instruction unless present in the prompt above.</p>{reading(commission, run["input"].parent, allowed=FILES)}' if commission else ''
    preview = deck_preview(images, pdf, f'{title} — {chapter} {fmt.replace("_", " ")}')
    return f'''<article class="run" id="{rid}-{chapter}-{fmt}"><h4>{esc(fmt.replace('_', ' ').title())}</h4><p class="status">{status}</p>{preview}<p class="actions">{link(pdf, 'Open deck PDF')}</p>{media}<details class="inputs"><summary>Inputs and provenance</summary><h5>Submitted prompt</h5>{reading(prompt, run["input"].parent, allowed=FILES)}<h5>Selected sources ({len(selected)})</h5><ol>{''.join(rows)}</ol><p class="muted">These explicit source IDs were selected, not every uploaded notebook source.</p><h5>Native settings and verification</h5><p class="muted">Native status: {esc(job.get('status', 'not recorded'))}. {native}.</p><pre>{esc(json.dumps(settings, indent=2))}</pre><p>{link(metadata, 'Native record')} · {link(run['input'], 'Complete raw input')}</p>{commission_html}</details></article>'''


def run_title(run):
    return run.get('title') or DESCRIPTIONS.get(run['id'], (run['id'].replace('-', ' ').title(), ''))[0]


def chapter_review_path(directory, index):
    filename = f'chapter-{index}-review.md'
    original = directory / filename
    return next((path for path in (original, directory / 'evaluation' / filename) if safe(path)), original)


def run_overview(run, chapters, latest=False):
    rid, directory = run['id'], run['directory']
    description = DESCRIPTIONS.get(rid, ('', run.get('change') or 'No change description recorded.'))[1]
    output_paths = sorted(set([*directory.glob('evaluation*/findings.md'), *directory.glob('review*/findings.md'), *directory.glob('review*/decks/findings.md'), *directory.glob('review*/static/findings.md')]))
    input_paths = sorted(directory.glob('input-review.md'))
    if rid == 'tailored-v2':
        output_paths.append(WORK / 'whole-chapter-review.md')
    if rid == 'round-2':
        input_paths.append(WORK / 'round-2-input-review.md')
    raw = [run['input'], directory / 'source-import.json', directory / 'source-availability.json']
    if run['private']:
        raw.append(directory / 'generation.json')
    scope = 'Six decks: the same three whole-chapter topics in both formats.' if run['private'] else f'Six matched decks extracted from a broader {run["total"]}-request run. Earlier reviews may include other topics and media.'
    results = ''.join(review(path, 'Experiment findings' if run['private'] else 'Historical review — broader scope may apply') for path in output_paths)
    chapter_results = ''.join(f'<a href="#{rid}-{chapter}-review">{esc(PURPOSES[chapter][0])}</a>' for index, chapter in enumerate(PURPOSES, 1) if safe(chapter_review_path(directory, index)))
    results = (f'<nav>{chapter_results}</nav>' if chapter_results else '') + results
    if not results:
        results = '<p>No written output review is available for this experiment.</p>'
    inputs = ''.join(review(path, 'Input review — before generation') for path in input_paths)
    return f'''<details class="experiment"{" open" if latest else ""}><summary>{esc(run_title(run))}<small>{esc(rid)}{" · latest experiment" if latest else ""}</small></summary><section class="history" id="run-{rid}" data-run-id="{esc(rid)}"><h3>What changed</h3><p>{esc(description)}</p>{chapters}<section id="run-{rid}-reviews"><h3>Results for this experiment</h3>{results}</section><details class="inputs" id="run-{rid}-inputs"><summary>Experiment inputs and provenance</summary><p>{scope}</p><p>{" · ".join(link(path, path.name) for path in raw if safe(path))}</p><small>Input SHA256 <code>{sha(run['input'])}</code></small>{inputs}</details></section></details>'''


def run_section(run, latest=False):
    chapters = []
    for index, (chapter, (title, purpose)) in enumerate(PURPOSES.items(), 1):
        decks = ''.join(card(run, chapter, fmt) for fmt in FORMATS)
        alias = f'<span id="{chapter}" aria-hidden="true"></span>' if latest else ''
        assessment = review(chapter_review_path(run['directory'], index), 'Review of this chapter pair')
        assessment = f'<div id="{run["id"]}-{chapter}-review">{assessment}</div>' if assessment else ''
        chapters.append(f'<section class="chapter" id="{run["id"]}-{chapter}" data-chapter="{chapter}">{alias}<h3>{esc(title)}</h3><small>{chapter} · full chapter</small><div class="comparison">{decks}</div>{assessment}</section>')
    return run_overview(run, ''.join(chapters), latest)


def phases(runs):
    return [('focused-tests', 'Focused six-deck tests', [r for r in runs if r['private']]),
            ('earlier-approaches', 'Earlier input approaches', [r for r in runs if not r['private']])]


def sidebar(runs):
    groups = []
    for anchor, heading, group in phases(runs):
        branches = []
        for run in group:
            rid = esc(run['id'])
            expanded = ' open' if run is runs[0] else ''
            chapters = []
            for chapter, (title, _) in PURPOSES.items():
                formats = ''.join(f'<li><a href="#{rid}-{chapter}-{fmt}">{fmt.replace("_", " ").title()}</a></li>' for fmt in FORMATS)
                chapters.append(f'<details data-nav-chapter="{chapter}"{expanded}><summary>{CHAPTER_LABELS[chapter]}</summary><ul><li><a href="#{rid}-{chapter}">Both decks</a></li>{formats}</ul></details>')
            branches.append(f'<details data-nav-run="{rid}"{expanded}><summary>{esc(run_title(run))}</summary><ul class="run-links"><li><a href="#run-{rid}">What changed</a></li><li><a href="#run-{rid}-reviews">Results</a></li><li><a href="#run-{rid}-inputs">Inputs and provenance</a></li></ul><div class="chapter-links">{"".join(chapters)}</div></details>')
        groups.append(f'<h3><a href="#{anchor}">{heading}</a></h3>{"".join(branches)}')
    return '<aside class="history-sidebar"><nav aria-label="Deck experiments"><a href="#judgement">Results and findings</a>' + ''.join(groups) + '<ul class="report-links"><li><a href="#sources">Source library</a></li><li><a href="#method">Method and scope</a></li></ul></nav></aside>'


def source_library(runs):
    groups = {}
    for digest, source in USED.items():
        previous = source.get('previous')
        prior = f'<p>Revises <a href="#source-{previous}">an earlier selected body</a>.</p>' if previous in USED else ''
        consumers = ' · '.join(f'<a href="#run-{r["id"]}">{esc(run_title(r))}</a>' for r in runs if r['id'] in source['usedBy'])
        version = f'<details id="source-{digest}" class="source"><summary>{esc(source["layer"])} · {digest[:10]}</summary><p>Used in: {consumers}</p><small>Body SHA256 <code>{digest}</code></small>{prior}{reading(source["body"], ROOT, allowed=FILES)}</details>'
        groups.setdefault(source['title'], []).append(version)
    return ''.join(f'<details class="source-group"><summary>{esc(title)}<small>{len(versions)} retained version{"s" if len(versions) != 1 else ""}</small></summary>{"".join(versions)}</details>' for title, versions in sorted(groups.items()))


SCRIPT = """function loadGallery(g){if(g.open)g.querySelectorAll('img[data-src]').forEach(i=>{i.src=i.dataset.src;delete i.dataset.src})}
document.querySelectorAll('details.gallery').forEach(g=>g.addEventListener('toggle',()=>loadGallery(g)));
function revealHash(){let id;try{id=decodeURIComponent(location.hash.slice(1))}catch{return}const target=document.getElementById(id);if(!target)return;for(let node=target;node;node=node.parentElement)if(node.tagName==='DETAILS'){node.open=true;if(node.classList.contains('gallery'))loadGallery(node)}target.scrollIntoView({block:'start'})}
window.addEventListener('hashchange',revealHash);revealHash();"""

PREVIEW_SCRIPT = """
// The same EA-owned controller drives public notebooks and these allowlisted local slides.
let releasePreviews;
function bindPreviews(){
 const subscriptions=[], controls=[];
 const on=(target,type,listener)=>{target.addEventListener(type,listener);subscriptions.push(()=>target.removeEventListener(type,listener))};
 for(const card of document.querySelectorAll('[data-deck-preview]')){
  const previous=[...card.querySelectorAll('[data-preview-previous]')],next=[...card.querySelectorAll('[data-preview-next]')];
  const slides=[...card.closest('article').querySelectorAll('[data-deck-slides] img')].map(image=>image.dataset.src||image.getAttribute('src'));
  const download=card.querySelector('[data-preview-download]');
  initDeckPreview({card,image:card.querySelector('img'),previous,next,counters:[...card.querySelectorAll('[data-preview-counter]')],
   slides,title:card.dataset.title,startSlide:Number(card.dataset.startSlide),on,
   onSlide:(current,src)=>{card.dataset.startSlide=String(current);download.setAttribute('href',src);download.setAttribute('download',decodeURIComponent(src.split('/').pop()))}});
  controls.push(...previous,...next);
 }
 releasePreviews=()=>{subscriptions.forEach(remove=>remove());controls.forEach(button=>{button.disabled=true});releasePreviews=null};
}
bindPreviews();
window.addEventListener('pagehide',()=>releasePreviews?.());
window.addEventListener('pageshow',event=>{if(event.persisted&&!releasePreviews)bindPreviews()});
"""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--summary', type=Path, help='Optional final local owner summary to render on-page.')
    args = parser.parse_args()
    runs, omitted = discover()
    runs.reverse()
    experiments = ''.join(f'<section id="{anchor}"><h2>{heading}</h2>' + ''.join(run_section(run, latest=run is runs[0]) for run in group) + '</section>' for anchor, heading, group in phases(runs))
    assessed = next((run for run in runs if safe(run['directory'] / 'evaluation/findings.md')), None)
    current = args.summary or (assessed['directory'] / 'evaluation/findings.md' if assessed else WORK / 'evaluation/findings.md')
    if safe(current):
        first_paragraph = re.search(r'<p>.*?</p>', rendered_markdown(current.read_text(), current.parent), re.S)
        label = 'Latest completed comparison — ' + run_title(assessed) if assessed and not args.summary else 'Current integrated comparison'
        findings = (first_paragraph.group(0) if first_paragraph else '') + review(current.resolve(), label)
        if runs and not safe(runs[0]['directory'] / 'evaluation/findings.md'):
            findings += f'<p>The latest experiment, {esc(run_title(runs[0]))}, is awaiting its integrated assessment.</p>'
    else:
        findings = '<p>The latest integrated assessment is pending. Available chapter reviews remain alongside their decks.</p>'
    if runs:
        findings += f'<p><a href="#run-{runs[0]["id"]}">View the latest six decks: {esc(run_title(runs[0]))}</a></p>'
    findings += review(WORK / 'final-analysis.md', 'Earlier conclusions — R1–R3 only')
    now = datetime.now(timezone.utc).isoformat(timespec='seconds')
    method = f'<p>Each experiment compares the same three full-chapter topics, in Detailed deck and Presenter slides formats. The four earlier approaches are matched extracts from broader multimedia runs; the focused tests generate only these six decks. Native length and language are retained in each input record.</p><p>Reviews describe observed communication and visual tradeoffs, not measured audience response or universal prompt rules. Generation status alone is not a quality rating.</p><p>Other retained runs use different topic scopes: {esc(", ".join(omitted))}. Their original indexes and files remain unchanged.</p><p>{link(ROOT / "docs/adr/ADR-063-iterative-whole-chapter-deck-improvement.md", "Experiment method and decisions (ADR-063)")}</p><small>View updated {now}. Refresh reads existing records; it does not generate media. Full-slide galleries load when opened. Local only; no publication.</small>'
    preview_module = SHARED_PREVIEW.read_text() + PREVIEW_SCRIPT
    output = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Deck experiments</title><style>{STYLE}</style></head><body><header><h1>Deck experiments</h1><p class="intro">Three chapters. Two deck formats. Explore what changed, compare the results, and inspect the exact inputs.</p><nav aria-label="Report sections"><a href="#judgement">Results and findings</a><a href="#history">Experiments</a><a href="#sources">Source library</a></nav></header><div class="history-layout">{sidebar(runs)}<main><section id="judgement"><h2>Results and findings</h2>{findings}</section><section id="history">{experiments}</section><section id="sources"><h2>Source library</h2><p>Readings are grouped by title, with their distinct original versions and the experiments that selected them.</p>{source_library(runs)}</section><section id="method"><h2>Method and scope</h2>{method}</section><noscript><p>Expand an experiment to view its decks. PDF and numbered image links work without JavaScript.</p></noscript></main></div><script>{SCRIPT}</script><script type="module">{preview_module}</script></body></html>'''
    (WORK / 'report.html').write_text(output)
    (WORK / 'referenced-assets.json').write_text(json.dumps({'files': sorted(str(p) for p in FILES)}, indent=2) + '\n')
    print(json.dumps({'report': str(WORK / 'report.html'), 'runs': [r['id'] for r in runs], 'deckCards': len(runs) * 6, 'sourceBodies': len(USED), 'allowedFiles': len(FILES), 'browserVerified': False}))


if __name__ == '__main__':
    main()
