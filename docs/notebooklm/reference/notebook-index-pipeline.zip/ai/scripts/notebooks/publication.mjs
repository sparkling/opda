/** Publish verified completed originals and passive renditions through EA owners. */
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const root=path.resolve(import.meta.dirname,'../..');
if(process.argv.includes('--variant')){
 const variant=process.argv[process.argv.indexOf('--variant')+1];
 if(variant!=='full-section-v1')throw Error('Uncommissioned publication variant');
 execFileSync('git',['diff','--exit-code','HEAD','--','scripts/notebooks','scripts/site/unified_n01.py','config/authoring/N01-full-section-v1.json'],{cwd:root,stdio:'pipe'});
 execFileSync(path.join(process.env.HOME,'.local/share/uv/tools/notebooklm-mcp-cli/bin/python3'),
  ['scripts/site/unified_n01.py','--variant',variant,'--publish'],{cwd:root,stdio:'inherit'});
 process.exit(0);
}
// Publication uses a committed executor and notebook renderer, while unrelated
// website work remains outside this explicit source boundary.
const work=path.join(root,'.local/artefact-generation');
// A persisted owner hold survives worker/supervisor restarts and quota resets.
const control=JSON.parse(await fs.readFile(path.join(work,'generation-control.json'),'utf8'));
const publishCurrent=process.argv.includes('--publish-current-subject');
if(publishCurrent&&!control.scope)throw Error('Explicit publication requires the bounded first-section scope');
if(control.publicationState==='hold'&&!publishCurrent){
  console.log(JSON.stringify({publication:'held',reason:control.holdReason}));
  process.exit(0);
}
execFileSync('git',['diff','--exit-code','HEAD','--','scripts/notebooks','site/notebooks','tests/notebook-generation.test.mjs'],{cwd:root,stdio:'pipe'});
const {verifiedVideoKey}=await import('./video-quality.mjs');
const sdk=path.join(process.env.HOME,'.local/share/uv/tools/notebooklm-mcp-cli/bin/python3');
const read=async file=>JSON.parse(await fs.readFile(file,'utf8'));
const exists=async file=>fs.stat(file).then(()=>true,()=>false);
async function save(file,value){
  const pending=file+'.pending',handle=await fs.open(pending,'w',0o600);
  try{await handle.writeFile(JSON.stringify(value)+'\n');await handle.sync();}finally{await handle.close();}
  await fs.rename(pending,file);
  const directory=await fs.open(path.dirname(file),'r');try{await directory.sync();}finally{await directory.close();}
}
const shared=JSON.parse(execFileSync(sdk,['scripts/notebooks/pipeline.py','--renderer'],{cwd:root,encoding:'utf8'})).directory;
const {details,prepareRenditions,digest,videoInfo}=await import(pathToFileURL(path.join(shared,'site/scripts/media-originals.mjs')));
const {renderPdfSlides}=await import(pathToFileURL(path.join(shared,'site/scripts/pdf-slide-images.mjs')));
const directory=path.join(root,'docs/generation');
if(!await exists(directory))process.exit(0);
const runs=await Promise.all((await fs.readdir(directory)).filter(f=>/^(N\d{2}(?:\.\d{2})?|all)\.json$/.test(f)).map(f=>read(path.join(directory,f))));
if(runs.length!==87||runs.some(run=>run.edition!=='adr025-20261021'))throw Error('Successor input ledgers are incomplete');
const scope=control.scope;
if(scope && (JSON.stringify(scope.subjects)!==JSON.stringify(['N01.01','N01.02','N01.03','N01.04','N01.05','N01']) || !scope.subjects.includes(scope.activeSubject)))throw Error('Invalid bounded publication scope');
const selectedRuns=scope?runs.filter(run=>run.sectionId===scope.activeSubject):runs;
if(scope && (selectedRuns.length!==1 || selectedRuns[0].sourceCommit!==scope.sourceCommit))throw Error('Unreleased scoped inputs');
const ext={infographic:'png',audio:'m4a',video:'mp4',slide_deck:'pdf'};
if(scope){
  const jobs=selectedRuns[0].jobs;
  const ready=await Promise.all(jobs.map(async job=>job.status==='completed'&&job.id&&job.providerProof?.settingsVerified&&
    await fs.stat(path.join(work,'originals',job.key+'.'+ext[job.type])).then(info=>info.isFile()&&info.size>0,()=>false)));
  if(jobs.length!==34||ready.some(value=>!value)){
    console.log(JSON.stringify({publication:'waiting-for-complete-subject',subject:scope.activeSubject,ready:ready.filter(Boolean).length,required:34}));process.exit(0);
  }
}
const stateFile=path.join(work,'adr025/publication.json');
const state=await exists(stateFile)?await read(stateFile):{originals:{},items:{}};
state.renderFailures??={};
const custody=path.join(work,'custody-stage');
await fs.mkdir(custody,{recursive:true});
const videoKeys=new Map();
let newlyStaged=0;
for(const run of selectedRuns)for(const job of run.jobs){
  if(job.status!=='completed'||!job.id||!job.providerProof?.settingsVerified)continue;
  if(!/^[a-f0-9-]{36}$/.test(job.id)||!/^[a-f0-9-]{36}$/.test(run.notebookId))throw Error('Unsafe provider identity');
  const original=path.join(work,'originals',job.key+'.'+ext[job.type]);
  if(!await exists(original))continue;
  let key=`custody/generation/${run.notebookId}/${job.id}.${ext[job.type]}`;
  const hash=await digest(original);
  if(job.type==='video'){
    const info=videoInfo(original),proof=await read(path.join(work,'transfers/video-readiness',job.id+'.json'));
    key=verifiedVideoKey({job,notebookId:run.notebookId,hash,info,proof,originals:state.originals});
    videoKeys.set(job.id,key);
  }
  if(state.originals[key]){if(state.originals[key]!==hash)throw Error('Immutable original changed');continue;}
  const target=path.join(custody,key);await fs.mkdir(path.dirname(target),{recursive:true});
  await fs.copyFile(original,target);if(await digest(target)!==hash)throw Error('Custody copy mismatch');
  newlyStaged++;
}
if(newlyStaged){
  execFileSync(sdk,['scripts/site/publish.py','--site','ai-ba','--build',custody],{cwd:root,stdio:'inherit'});
  const receipt=await read(path.join(root,'.local/site/ai-ba-publication.json'));
  if(receipt.bodyHashMismatches!==0||receipt.outputs.BucketName!=='hm-website-ai-ba-841291679368')throw Error('Custody verification failed');
  for(const file of receipt.files)state.originals[file.key]=file.sha256;
  await save(stateFile,state);
  await fs.rm(custody,{recursive:true});await fs.mkdir(custody,{recursive:true});
}
for(const run of selectedRuns)for(const job of run.jobs){
  const key=videoKeys.get(job.id)??`custody/generation/${run.notebookId}/${job.id}.${ext[job.type]}`;
  if(job.status!=='completed'||!job.providerProof?.settingsVerified||!state.originals[key]||state.items[job.id]?.original?.sha256===state.originals[key])continue;
  if(state.renderFailures[job.id]?.retryAt>Date.now())continue;
  try{
  const originalPath=path.join(work,'originals',job.key+'.'+ext[job.type]);
  if(!await exists(originalPath))continue;
  const prefix=`/presentations/ai-ba-${job.subject.toLowerCase().replace('.','-')}/media/`;
  const destination=path.join(root,'site/public',prefix);await fs.mkdir(destination,{recursive:true});
  const original=await details(originalPath,'/'+key);if(original.sha256!==state.originals[key])throw Error('Original custody mismatch');
  const common={...job,notebook:`https://notebooklm.google.com/notebook/${run.notebookId}?artifactId=${job.id}`,
    sourceIds:job.providerProof.sourceIds,promptSha256:job.providerProof.promptSha256,qualityStatus:'pending',original,prefix};
  if(job.type==='slide_deck'){
    const rendered=await renderPdfSlides({pdf:originalPath,destination,id:job.id,urlPrefix:prefix,width:1376,renderer:'pdfium'});
    state.items[job.id]={...common,slug:job.id,pdf:original.path,slideCount:rendered.slides.length,cover:rendered.slides[0],...rendered};
  }else{
    const rendered=await prepareRenditions({original:originalPath,destination,id:job.id,type:job.type,preview:prefix+job.id+'-preview.webp',poster:prefix+job.id+'-poster.webp'});
    const prior=state.items[job.id];
    const priorRenditions=prior&&prior.original.sha256!==original.sha256?[...(prior.priorRenditions??[]),prior.original]:prior?.priorRenditions;
    state.items[job.id]={...common,...rendered,original:{...original,width:rendered.width,height:rendered.height},...(priorRenditions?{priorRenditions}:{})};
  }
  delete state.renderFailures[job.id];
  await save(stateFile,state);
  }catch(error){
    state.renderFailures[job.id]={key:job.key,errorType:error.name,failedAt:new Date().toISOString(),
      attempts:(state.renderFailures[job.id]?.attempts??0)+1,retryAt:Date.now()+3600000,
      retryPolicy:'Local rendition-repair backoff; not a provider quota reset.'};
    await save(stateFile,state);
    console.log(JSON.stringify({renderDeferred:job.key,errorType:error.name}));
  }
}
const priorReleaseFile=path.join(directory,'releases/notebook-release.json');
const priorRelease=scope&&await exists(priorReleaseFile)?await read(priorReleaseFile):null;
const retainedSubjects=Object.fromEntries(Object.entries(priorRelease?.subjects??{}).map(([id,subject])=>[id,{...subject,inputSourceCommit:subject.inputSourceCommit??priorRelease.sourceCommit}]));
const currentItems=Object.values(state.items).filter(item=>selectedRuns.some(run=>run.jobs.some(job=>job.id===item.id&&job.key===item.key)));
const release={schema:'ai-ba.notebook-media.v2',edition:'adr025-20261021',sourceCommit:scope?.sourceCommit??runs[0].sourceCommit,publicationCommit:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),planned:2958,
  notebookId:runs[0]?.notebookId,qualityStatus:'Derived explanation; factual and editorial quality review is separate from provider completion and verified file custody.',
  subjects:{...retainedSubjects,...Object.fromEntries(selectedRuns.flatMap(run=>run.subjects.map(subject=>[subject.id,{requested:34,inputSourceCommit:run.sourceCommit,
    ready:subject.generationReady,sourceGaps:subject.sourceGaps,
    decks:currentItems.filter(j=>j.subject===subject.id&&j.type==='slide_deck'),
    multimedia:currentItems.filter(j=>j.subject===subject.id&&j.type!=='slide_deck')}])))} };
release.available=Object.values(release.subjects).reduce((sum,subject)=>sum+subject.decks.length+subject.multimedia.length,0);
const fingerprint=createHash('sha256').update(JSON.stringify(release)).digest('hex');
if(state.publishedFingerprint!==fingerprint){
  await fs.mkdir(path.join(directory,'releases'),{recursive:true});
  await save(path.join(directory,'releases/notebook-release.json'),release);
  execFileSync('npm',['--prefix','site','run','build:notebooks'],{cwd:root,stdio:'inherit'});
  execFileSync('npm',['--prefix','site','run','test:notebooks'],{cwd:root,stdio:'inherit'});
  execFileSync(sdk,['scripts/site/publish.py','--site','ai-ba','--build','site/dist-notebooks'],{cwd:root,stdio:'inherit'});
  state.publishedFingerprint=fingerprint;state.publishedAt=new Date().toISOString();
  await save(stateFile,state);
}
console.log(JSON.stringify({available:release.available,planned:release.planned,renderDeferred:Object.keys(state.renderFailures).length,publishedAt:state.publishedAt}));
