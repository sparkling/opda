"""Complete N01 using the existing reviewed source, native queue and renderer owners."""
import copy
from collections import Counter
from pathlib import Path
import prepare


def projection(api, path):
    config = api.read(path)
    assert config['id'] == 'full-section-v1'
    for descriptor in config['baselines']:
        api.pinned(descriptor)
    previous = api.projection(api.APPLIED_CONFIG)
    base = api.projection(api.CONTENT_CONFIG)
    result = copy.deepcopy(previous)
    for label, source in base['sources'].items():
        if label not in result['sources'] and not label.startswith('synthesis:'):
            result['sources'][label] = copy.deepcopy(source)
    for chapter in config['additionalSubjects']:
        for definition in chapter['topics']:
            topic = {k:definition[k] for k in ('id','type','title','commission')}
            labels = definition['sourceLabels']
            assert labels and len(labels) == len(set(labels))
            assert set(labels) <= result['sources'].keys()
            keys = [result['sources'][label]['key'] for label in labels]
            result['topics'][topic['id']] = dict(topic=topic, sourceLabels=labels,
                sourceKeys=keys, subjectCommission='',
                selectedWords=sum(len(result['sources'][l]['body'].split()) for l in labels),
                authoring=dict(path=str(path.relative_to(api.ROOT)),sha256=api.HASH(path.read_bytes())))
            for old in (r for r in base['requests'] if r['topicId']==definition['nativeTopicFrom']):
                row = copy.deepcopy(old)
                row.update(topicId=topic['id'], nativeSettingsFrom=old['key'],
                    key=config['id']+'-'+topic['id']+'-'+old['format']+('-take-'+str(old['take']) if topic['type']=='infographic' else ''))
                row['promptComponents'] = [dict(role=role,text=text,destination='focus_prompt',sha256=api.HASH(text))
                    for role,text in [('topicCommission',topic['commission']),('purposeAndAudience',config['purposeAndAudience'])]]
                row['providerTemplate'].update(sourceKeys=keys,
                    sourceBodyHashes={result['sources'][l]['key']:result['sources'][l]['bodySha256'] for l in labels})
                row['providerTemplate']['arguments']['focus_prompt'] = '\n\n'.join(c['text'] for c in row['promptComponents'])
                for detail in config['infographicDetails'] if topic['type']=='infographic' else [None]:
                    request = copy.deepcopy(row)
                    if detail:
                        request.update(infographicDetail=detail,key=row['key'].replace('-take-','-'+detail+'-take-'))
                        request['providerTemplate']['arguments']['detail_level_code'] = config['infographicDetails'].index(detail)+1
                    result['requests'].append(request)
    for row in result['requests']:
        row['key'] = row['key'].replace('applied-rules-v1-',config['id']+'-',1)
        args = row['providerTemplate']['arguments']
        if row['format']=='explainer': assert args['visual_style_code']==1
        if row['format']=='cinematic': assert args.get('visual_style_code') is None
        row['planSha256'] = api.HASH(api.canonical(row['providerTemplate']))
    result['requests'].sort(key=lambda r:(config['subjects'].index(r['subject']),r['topicId'],r['format'],r.get('infographicDetail',''),r['take'] or 0))
    assert len({r['key'] for r in result['requests']}) == len(result['requests'])
    assert len(result['topics'])==116
    selected = {k for t in result['topics'].values() for k in t['sourceKeys']}
    result['sources'] = {k:v for k,v in result['sources'].items() if v['key'] in selected}
    assert len({s['title'] for s in result['sources'].values()})==len(result['sources'])
    result.update(id=config['id'],configSha256=api.HASH(path.read_bytes()),notebookTitle=config['notebookTitle'],
        status=config['status'],counts=dict(scopes=6,topics=len(result['topics']),outputs=len(result['requests']),
        byType=dict(Counter(result['topics'][r['topicId']]['topic']['type'] for r in result['requests']))),
        boundary='New full-section production. Existing runs remain unchanged. No additional synthesis or production-note layer.')
    return result
