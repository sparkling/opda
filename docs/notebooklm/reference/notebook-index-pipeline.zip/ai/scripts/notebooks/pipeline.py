"""AI BA configuration over the established BA/SA generation and OS supervisor."""
import argparse
import asyncio
import json
import httpx
import os
import re
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace
from functools import wraps
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from notebooklm_tools.core.errors import ResourceExhaustedError, ArtifactNotReadyError, ArtifactDownloadError

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(Path(__file__).parent))
from prepare import adapter, module, WORK, HASH
import brief

SDK = Path.home() / '.local/share/uv/tools/notebooklm-mcp-cli/bin/python3'
owner = adapter.load_module('generation-ownership')
owner.ROOT, owner.WORK = ROOT, WORK
shared_retired_ids = adapter.native.retired_provider_ids
shared_pending_jobs = adapter.native.pending_jobs
shared_sync_titles = adapter.sync_provider_titles
shared_download_original = adapter.worker.download_original
PREFERRED_FORMATS = ('cinematic', 'presenter_slides')


def generation_scope():
    """Owner-authorized first section, with a durable publication frontier."""
    path = WORK / 'generation-control.json'
    value = json.loads(path.read_text()).get('scope') if path.exists() else None
    if value is None:
        return None
    assert value['subjects'] == ['N01.01', 'N01.02', 'N01.03', 'N01.04', 'N01.05', 'N01']
    assert value['activeSubject'] in value['subjects']
    assert re.fullmatch(r'[a-f0-9]{40}', value['sourceCommit'])
    index = value['subjects'].index(value['activeSubject'])
    assert list(value['completed']) == value['subjects'][:index]
    assert all(row['published'] and row['verifiedJobs'] == 34 for row in value['completed'].values())
    return value


def settings(run,job):
    subject=adapter.brief(run,job)
    return {**job['settings'],'notebook_id':run['notebookId'],'title':job['title'],
        'source_ids':brief.source_ids(subject,job['editorial']),
        'focus_prompt':subject['mediaPrompts'][job['medium']]}


def retired_ids(notebook):
    identities=shared_retired_ids(notebook)
    for file in (ROOT/'docs/generation/history').glob('*/manifest.json'):
        receipt=json.loads(file.read_text())
        if receipt.get('schema')=='ai-ba.generation-input-history.v1' and receipt['notebookId']==notebook:
            identities.update(receipt['providerIdentities'])
    return identities


def rate_limit_client(client, rpc_id=None, rate_limit_file=None):
    """Map actual HTTP 429 into the existing quota lane without replaying creates."""
    rpc = client._call_rpc
    fenced_id = rpc_id or client.RPC_CREATE_STUDIO
    @wraps(rpc)
    def call(rpc_id, *args, **kwargs):
        try:
            return rpc(rpc_id,*args,**kwargs)
        except Exception as error:
            response = getattr(error,'response',None)
            if rpc_id != fenced_id or getattr(response,'status_code',None) != 429:
                raise
            value = response.headers.get('Retry-After','')
            now = datetime.now(timezone.utc)
            try:
                due = now + timedelta(seconds=int(value)) if value.isdigit() else parsedate_to_datetime(value)
                if due.tzinfo is not None and due > now:
                    quota = adapter.generation_quota()
                    quota.atomic_json(rate_limit_file or WORK/'http-rate-limit.json',{'observedAt':quota.iso(now),
                        'resetsAt':quota.iso(due),'provenance':'provider-HTTP-Retry-After'})
            except (ValueError,TypeError,OverflowError):
                pass  # No valid reported reset: existing bounded backoff stays labelled as such.
            raise ResourceExhaustedError('Provider HTTP 429 rate limit') from None
    client._call_rpc = call
    return client


shared_quota = adapter.generation_quota


def generation_quota():
    quota = shared_quota()
    quota.KINDS = ('video', 'slide_deck', 'audio', 'infographic')
    shared_config = quota.config
    def config(path):
        value = json.loads(path.read_text())
        assert value.get('publicationState', 'hold') in {'hold', 'run'}
        # Delivery and incident metadata belong to this adapter. Preserve the
        # shared generation owner's validation for every generation control.
        generation = {key:item for key,item in value.items()
            if key not in {'publicationState','holdReason','heldAt','resumeAuthority','scope'}}
        return shared_config(SimpleNamespace(read_text=lambda:json.dumps(generation)))
    quota.config = config
    deadline = quota.deadline
    def reported_deadline(meter,cfg,now,delay):
        file = WORK/'http-rate-limit.json'
        if file.exists():
            receipt = json.loads(file.read_text())
            if quota.timestamp(receipt['resetsAt']) > now:
                return receipt['resetsAt'],receipt['provenance']
        return deadline(meter,cfg,now,delay)
    quota.deadline = reported_deadline
    return quota


def bind():
    adapter.ROOT, adapter.WORK = ROOT, WORK
    adapter.FILES = sorted(p for p in (ROOT / 'docs/generation').glob('*.json') if re.fullmatch(r'(N\d{2}(?:\.\d{2})?|all)\.json',p.name))
    scope = generation_scope()
    if scope:
        adapter.FILES = [ROOT / 'docs/generation' / (subject + '.json') for subject in scope['subjects']]
    adapter.native.ROOT, adapter.native.DIRECTORY = ROOT, ROOT / 'docs/generation'
    adapter.worker.ROOT, adapter.worker.WORK, adapter.worker.FILES = ROOT, WORK, adapter.FILES
    adapter.settings=settings
    adapter.worker.download_original=download_original
    adapter.native.expected_sources=lambda run,job:sorted(brief.source_ids(adapter.brief(run,job),job['editorial']))
    adapter.native.retired_provider_ids=retired_ids
    adapter.native.pending_jobs=pending_jobs


def verify_video_file(client, row, media, target):
    metadata = json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries',
        'format=duration:stream=codec_type,width,height,bit_rate','-of','json',str(target)]))
    video = next(item for item in metadata['streams'] if item['codec_type']=='video')
    if min(video['width'],video['height']) < 720:
        raise ArtifactNotReadyError('video',row[0])
    manifest = next((item for item in media if len(item)>1 and item[1]==2),None)
    sizes = []
    if manifest:
        with httpx.Client(cookies=client._get_httpx_cookies(),follow_redirects=True,timeout=30) as http:
            response = http.get(manifest[0]); response.raise_for_status()
        sizes = [(int(w),int(h)) for w,h in re.findall(r'RESOLUTION=(\d+)x(\d+)',response.text)]
        if not sizes:
            raise ArtifactNotReadyError('video',row[0])
        if sizes and video['width']*video['height'] < max(w*h for w,h in sizes):
            raise ArtifactNotReadyError('video',row[0])
    assert float(metadata['format']['duration'])>0 and {'audio','video'} <= {item['codec_type'] for item in metadata['streams']}
    decoded = subprocess.run(['ffmpeg','-v','error','-threads','1','-i',str(target),'-f','null','-'],capture_output=True)
    assert decoded.returncode==0 and not decoded.stderr, 'Provider video failed complete decode'
    return metadata,sizes


def download_original(client, run, job, target):
    if job['type'] != 'video':
        return shared_download_original(client,run,job,target)
    row = client.get_artifact(run['notebookId'],job['id'])
    assert row and row[0] == job['id'], 'Provider video identity mismatch'
    proof = adapter.native.settings_proof(run,job,row)
    media = next((items for items in row[8] if isinstance(items,list) and items
        and isinstance(items[0],list) and items[0] and isinstance(items[0][0],str)
        and items[0][0].startswith('https://')),[])
    # Prefer the playback rendition and verify it against advertised HLS sizes.
    # Completed provider jobs can initially expose a lower-resolution download.
    variants = {item[1]:item for item in media if len(item)>2 and item[2]=='video/mp4'}
    variant = variants.get(1) or variants.get(4)
    if row[4] not in (2,3) or not variant:
        raise ArtifactNotReadyError('video',job['id'])
    try:
        client._download_url_sync(variant[0],str(target))
    except ArtifactDownloadError:
        if variant[1]!=1 or 4 not in variants: raise
        variant=variants[4]
        client._download_url_sync(variant[0],str(target))
    metadata,sizes = verify_video_file(client,row,media,target)
    receipt = {'id':job['id'],'key':job['key'],'providerRawStatus':row[4],'providerProof':proof,
        'downloadMethod':'provider playback MP4 preferred; complete decode verified; no transcoding',
        'providerVariant':variant[1],'qualityVersion':1,'completeDecodePassed':True,
        'advertisedSizes':[list(size) for size in sizes],
        'bytes':Path(target).stat().st_size,'sha256':HASH(Path(target).read_bytes()),'metadata':metadata,
        'verifiedAt':adapter.native.NOW()}
    directory = WORK/'transfers/video-readiness';directory.mkdir(parents=True,exist_ok=True)
    (directory/(job['id']+'.json')).write_text(json.dumps(receipt)+'\n')
    adapter.worker.event(videoReadinessVerified=job['key'],id=job['id'],providerRawStatus=row[4])
    return str(target)


def pending_jobs(runs, kind):
    # Admission advances after all submissions, never after completion/publication.
    if generation_scope():
        runs = next(([run] for run in runs if any(job['status'] == 'planned' for job in run['jobs'])), [])
    yield from shared_pending_jobs(runs,kind,preferred_formats=PREFERRED_FORMATS)


def sync_titles(client):
    # Catalogue naming must not delay provider submission or completion reconciliation.
    if generation_scope() and any(job['status'] != 'completed' for run in adapter.reads() for job in run['jobs']):
        return {'titleMaintenanceDeferred': True}
    return shared_sync_titles(client)


def recover_interrupted_intents():
    """Called by the sole locked writer before its next provider census."""
    for file in adapter.FILES:
        run = json.loads(file.read_text()); changed = False
        for job in run['jobs']:
            if job['status'] != 'submitting' or job.get('id') or job.get('errorAt'):
                continue
            observed = adapter.native.NOW()
            job['submissionInterruption'] = {'observedAt': observed, 'previousStatus': 'submitting',
                'timestampMeaning': 'New sole writer observed an unfinished durable intent; upper bound, not a provider error timestamp.'}
            job.update(status='needs-reconciliation',errorType='InterruptedSubmission',errorAt=observed)
            for candidate in job.get('reconciliationCandidates', []):
                if not candidate.get('errorAt'): candidate['errorAt'] = observed
            changed = True
        if changed: adapter.native.save(file,run)


def validate(runs):
    scope = generation_scope()
    if scope:
        assert [run['sectionId'] for run in runs] == scope['subjects']
        for run in runs:
            assert run['sourceCommit'] == scope['sourceCommit']
            assert run['requested'] == len(run['jobs']) == 34
            assert run.get('inputVersion', 0) >= 4
            assert all(subject['generationReady'] for subject in run['subjects'])
            for job in run['jobs']:
                adapter.brief(run, job)
        return
    assert len(runs) == 87 and all(r.get('edition')=='adr025-20261021' for r in runs)
    assert sum(len(r['subjects']) for r in runs) == 87
    assert len({s['id'] for r in runs for s in r['subjects']}) == 87
    assert sum(r['requested'] for r in runs) == sum(len(r['jobs']) for r in runs) == 2958
    assert len({j['key'] for r in runs for j in r['jobs']}) == 2958
    for run in runs:
        assert run['commissioned'] and run['publish']
        for subject in run['subjects']:
            if subject['generationReady']:
                assert subject['editorialSync']['status'] == 'indexed-verified'
                assert subject['editorialSourceId'] not in subject['factualSourceIds']
                assert subject['communicationSourceIds']
                assert not set(subject['factualSourceIds'])&set(subject['communicationSourceIds'])
        for job in run['jobs']:
            adapter.brief(run, job)


def reported_wait(last, meter, runs, quota, now):
    """Defer exhausted generation reads while independent delivery keeps running."""
    if not last or last.get('phase') != 'quota_wait' or not meter or any(meter['actions'].values()):
        return None
    if any(adapter.native.active_counts(runs).values()):
        return None
    future = [quota.timestamp(window['resetsAt']) for window in meter['windows'].values()
        if window['remainingPercent'] == 0 and quota.timestamp(window['resetsAt']) > now]
    return quota.iso(max(future)) if future else None


def proof_mismatch(run,job,row,error):
    job.update(status='provider-proof-mismatch',verificationProblem=type(error).__name__,
        providerRawStatus=row[4],checkedAt=adapter.native.NOW())


def quota_initialization_pending(job, state):
    association = job.get('reconciliationAssociation', {})
    return (bool(job.get('id')) and job.get('status') == 'submitted' and state == 'pending' and job.get('errorType') == 'ResourceExhaustedError'
        and job.get('providerProof', {}).get('settingsVerified') is True
        and association.get('returnedAcknowledgement') is False
        and association.get('selectedId') == job.get('id')
        and association.get('candidateIds') == [job.get('id')]
        and not job.get('providerProcessingFirstSeenAt') and not job.get('restartHistory'))


def activity(runs, now):
    """Queue age is not processing time; no API signal proves quota-paused work."""
    rows = []
    for run in runs:
        for job in run['jobs']:
            if not job.get('id'):
                continue
            state = job.get('providerObservedState', 'unknown')
            original = WORK / 'originals' / (job['key'] + '.' + adapter.native.EXT[job['type']])
            awaiting_file = job['status'] == 'completed' and state in {'pending', 'in_progress'} and not original.exists()
            if job['status'] != 'submitted' and not awaiting_file:
                continue
            created = job.get('providerCreationTimestamp')
            created_at = datetime.fromtimestamp(created[0], timezone.utc) if created else None
            processing = job.get('providerProcessingFirstSeenAt')
            since = datetime.fromisoformat(processing) if state == 'in_progress' and processing else created_at
            retries = [attempt for attempt in job.get('restartHistory',[]) if attempt['outcome']=='acknowledged']
            if retries:
                resumed = datetime.fromisoformat(retries[-1]['intentAt'])
                since = max(since,resumed) if since else resumed
            age = max(0, (now-since).total_seconds()) if since else None
            # Recovery policy thresholds, not provider SLAs or proof of failure.
            timeout = 3600 if job.get('format') == 'cinematic' else 1800
            overdue = age is not None and age >= timeout and state in {'pending', 'in_progress'}
            rows.append({'key':job['key'],'id':job['id'],'medium':job['type'],'format':job.get('format'),
                'state':state,'createdAt':created_at.isoformat() if created_at else None,
                'processingFirstSeenAt':processing,'ageSeconds':age,'suspectedStalled':overdue,
                'quotaInitializationPending':quota_initialization_pending(job,state),
                'lastStateChangeAt':job.get('providerStateChangedAt'),
                'restartAttempts':len(job.get('restartHistory',[]))})
    return {'counts':{state:sum(row['state']==state for row in rows)
            for state in ('pending','in_progress','scheduled','pending-review','unknown')},'jobs':rows,
        'interpretation':'Provider state1 is initialized/pending; state2 is processing. Elapsed-time suspicion is not a terminal failure or proof of quota pause.'}


def restart_stalled(client, runs, quota, meter, cfg, now):
    """Retry the same provider identity; never delete or create a replacement."""
    observed_jobs = activity(runs,now)['jobs']
    observed_jobs += [{'key':job['key'],'state':'failed','terminalFailure':True,
        'suspectedStalled':False,'quotaInitializationPending':False}
        for run in runs for job in run['jobs'] if job['status']=='failed' and job.get('id')
        and job.get('providerProof',{}).get('settingsVerified') is True
        and not (WORK/'originals'/(job['key']+'.'+adapter.native.EXT[job['type']])).exists()]
    for observed in observed_jobs:
        if not (observed['suspectedStalled'] or observed['quotaInitializationPending'] or observed.get('terminalFailure')) or not owner.supervisor_alive():
            continue
        run,job = next((run,job) for run in runs for job in run['jobs'] if job['key']==observed['key'])
        if not quota.available(meter,job) or quota.config(WORK/'generation-control.json')['desiredState']!='run':
            continue
        history = job.setdefault('restartHistory',[])
        if history and quota.timestamp(history[-1]['intentAt'])+timedelta(minutes=30)>now:
            continue
        row = client.get_artifact(run['notebookId'],job['id'])
        adapter.native.settings_proof(run,job,row)
        if adapter.native.provider_status(client,row) != observed['state']:
            continue
        record = {'intentAt':quota.iso(now),'id':job['id'],'observedState':observed['state'],
            'reason':'provider-declared terminal failure; same-identity retry' if observed.get('terminalFailure') else 'quota-initialized record never started; provider availability restored' if observed['quotaInitializationPending'] else 'elapsed-time recovery policy; not provider-declared failure','operation':'Rytqqe','outcome':'intent'}
        history.append(record)
        file = next(file for file in adapter.FILES if file.stem==run['sectionId'])
        adapter.native.save(file,run)
        # Upstream retry_failed RPC reference; no source/options rewrite.
        options = [2,None,None,[1]+[None]*9+[[1]],[[1,4,8,2,3,6]]]
        try:
            result = adapter.native.create_once(client,lambda:client._call_rpc(client.RPC_START_ARTIFACT,
                [options,job['id']],path='/notebook/'+run['notebookId']),fenced_rpc=client.RPC_START_ARTIFACT)
            assert result and result[0][0]==job['id'], 'Retry did not acknowledge the same identity'
            record.update(outcome='acknowledged',returnedId=result[0][0],rawState=result[0][4])
            record['previousProcessingFirstSeenAt'] = job.pop('providerProcessingFirstSeenAt',None)
            job['status'] = 'submitted'
        except Exception as error:
            record.update(outcome='error',errorType=type(error).__name__,errorCode=getattr(error,'error_code',None))
            adapter.native.save(file,run)
            break  # Never turn a backend refusal into an account-wide retry burst.
        adapter.native.save(file,run)


def generation():
    bind()
    receipt = WORK / 'adr025/source-import.json'
    if len(adapter.FILES) != (6 if generation_scope() else 87) or not receipt.exists():
        owner.write_stage_status('generation', 'input_wait')
        time.sleep(30)
        return
    adapter.validate = validate
    adapter.sync_provider_titles = sync_titles
    adapter.generation_quota = generation_quota
    adapter.worker.recover_stalled = lambda client,runs,meter,cfg,now:restart_stalled(
        client,runs,generation_quota(),meter,cfg,now)
    get_client = adapter.worker.get_client
    adapter.worker.get_client = lambda:rate_limit_client(get_client())
    submit = adapter.worker.persistent_submit
    reconciled = time.monotonic()
    census = adapter.native.reconcile
    def reconcile(client, files, **kwargs):
        return census(client,files,on_proof_mismatch=proof_mismatch,**kwargs)
    adapter.native.reconcile = reconcile
    def submit_and_poll(client,run,job,state,state_file,quota,cfg,meter,*args,**kwargs):
        nonlocal reconciled
        result = submit(client,run,job,state,state_file,quota,cfg,meter,*args,**kwargs)
        if time.monotonic()-reconciled >= cfg['reconcileSeconds']:
            # Sole ledger writer, between acknowledged calls: completion and
            # download/publication never wait for an entire medium's burst.
            adapter.native.reconcile(client,adapter.FILES)
            reconciled = time.monotonic()
        return result
    adapter.worker.persistent_submit = submit_and_poll
    shared_cycle = adapter.worker.persistent_cycle
    last = None

    def refresh_cycle(client, state, state_file, quota, ownership, control):
        nonlocal last
        bind()
        recover_interrupted_intents()
        runs = [json.loads(file.read_text()) for file in adapter.FILES]
        due = reported_wait(last,state.get('meter'),runs,quota,quota.timestamp(adapter.native.NOW()))
        if due:
            return {**last,'nextProbeAt':due,'deferredUntilReportedReset':True}
        last = {**shared_cycle(client,state,state_file,quota,ownership,control),
            'dispatchPriority':list(PREFERRED_FORMATS),'deferredUntilReportedReset':False}
        current = [json.loads(file.read_text()) for file in adapter.FILES]
        last['providerActivity'] = activity(current,datetime.now(timezone.utc))
        return last

    adapter.worker.persistent_cycle = refresh_cycle
    adapter.persistent()


def prepare_loop():
    while owner.supervisor_alive():
        if generation_scope():
            owner.write_stage_status('sources', 'verified_scope_frozen')
            time.sleep(60)
            continue
        environment = {**os.environ, 'SA_PIPELINE_SUPERVISOR_PID':str(os.getpid())}
        result = subprocess.run([str(SDK), str(ROOT / 'scripts/notebooks/edition.py')], cwd=ROOT, env=environment)
        preparation_code=result.returncode
        owner.write_stage_status('sources', 'auth_wait' if result.returncode == 70 else 'input_review_wait' if preparation_code else 'waiting',
            exitCode=result.returncode,preparationExitCode=preparation_code)
        time.sleep(60)


def delivery_loop():
    bind()
    with owner.StageLock('delivery'):
        while owner.supervisor_alive():
            try:
                bind()
                control = json.loads((WORK/'generation-control.json').read_text())
                if control['desiredState'] != 'run':
                    try:
                        with owner.StageLock('generation',WORK/'worker.lock'):
                            adapter.native.reconcile(adapter.worker.get_client(),adapter.FILES,on_proof_mismatch=proof_mismatch)
                    except BlockingIOError:
                        pass  # An in-flight create is still draining; preserve its sole writer.
                runs = [json.loads(p.read_text()) for p in adapter.FILES]
                asyncio.run(adapter.worker.downloads(adapter.worker.get_client(), runs, concurrency=16))
                control = json.loads((WORK/'generation-control.json').read_text())
                if control.get('publicationState') != 'hold':
                    subprocess.run(['node','scripts/notebooks/publication.mjs'], cwd=ROOT, check=True)
                owner.write_stage_status('delivery', 'publication_held' if control.get('publicationState') == 'hold' else 'waiting', lastError=None)
            except Exception as error:
                owner.write_stage_status('delivery', 'retry', lastError=owner.safe_error(error))
                print(json.dumps(owner.safe_error(error)), flush=True)
            time.sleep(45)


def supervisor(install):
    pipeline = adapter.load_module('generation-pipeline')
    pipeline.ROOT, pipeline.WORK = ROOT, WORK
    pipeline.LABEL = 'co.uk.sparklingideas.ai-ba-artefacts'
    pipeline.PLIST = Path.home() / 'Library/LaunchAgents' / (pipeline.LABEL + '.plist')
    pipeline.LOGS, pipeline.CONTROL, pipeline.STATE = WORK / 'transfers', WORK / 'generation-control.json', WORK / 'pipeline/supervisor-status.json'
    pipeline.ownership = owner
    pipeline.__file__ = str(Path(__file__).resolve())
    pipeline.commands = lambda: {name:[str(SDK),str(Path(__file__).resolve()),'--'+name]
        for name in ('generation','sources','delivery')}
    return pipeline.install() if install else pipeline.serve()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    for name in ('install','serve','generation','sources','delivery','renderer'):
        modes.add_argument('--'+name, action='store_true')
    args = parser.parse_args()
    if args.renderer:
        print(json.dumps(adapter.load_module('shared-renderer').resolve_renderer(ROOT)))
    elif args.install or args.serve:
        supervisor(args.install)
    elif args.generation:
        generation()
    elif args.sources:
        prepare_loop()
    else:
        delivery_loop()
