"""AI configuration of shared generation: communication roles and input custody."""
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess

HASH = lambda value: hashlib.sha256(value.encode() if isinstance(value,str) else value).hexdigest()
CONFIG = 'config/authoring/notebook-communication.json'


def communication(root):
    body = (root/CONFIG).read_bytes()
    config = json.loads(body)
    assert config['schema']=='ai-ba.notebook-communication.v1'
    authority = config['authority']
    assert authority['role']=='communication-authority' and authority['empiricalCorroboration'] is False
    assert authority['path'].startswith('docs/adr/') and '..' not in Path(authority['path']).parts
    original = subprocess.check_output(['git','show',authority['commit']+':'+authority['path']],cwd=root)
    assert HASH(original)==authority['sha256'], 'Pinned communication authority changed'
    assert set(config['mediaSuffixes'])=={'deck','audio','video','infographic'}
    return {**config,'sha256':HASH(body)},original.decode()


def editorial(record):
    synthesis = record.get('synthesis')
    heading, text = (synthesis['title'], synthesis['body']) if synthesis else (record['editorialHeading'],record['editorial'])
    body = '# '+record['id']+' '+heading+'\n\n'+text
    prefix = record['edition']+'-synthesis-' if synthesis else 'editorial-'
    return prefix+record['id']+':'+HASH(body),body


def source_ids(subject,with_editorial):
    factual = subject['factualSourceIds']
    authority = subject.get('communicationSourceIds',[])
    assert not set(factual)&set(authority), 'Communication authority is not empirical corroboration'
    assert subject['editorialSourceId'] not in factual+authority
    return list(dict.fromkeys(factual+authority+([subject['editorialSourceId']] if with_editorial else [])))


def chapter_prompt(record,sources):
    """Commission the output; full source-use notes remain in the authoring record."""
    base = record['basePrompt']
    windows = [s['resolvedWindow']['scope'] for s in sources if s.get('resolvedWindow')]
    if windows:
        base += '\n\nImported-window coverage: '+'\n'.join(windows)
    return base


def source_references(record,config):
    """Resolve local author labels to actual imported titles, never local paths."""
    lines=[]
    for binding in record['sourceBindings']:
        title=config.get('sourceTitles',{}).get(binding.get('sha256'))
        if not title:
            continue  # Missing admission is a readiness gap, not an invented upload.
        labels=[str(binding[k]) for k in ('id','label','bindingKey','bindingId','citationKey','citationLabel') if binding.get(k)]
        bracket=re.match(r'^\[([^\]]+)\]',binding['title'])
        if bracket:
            labels.append(bracket[1])
        labels=list(dict.fromkeys(labels))
        description=', '.join(labels) if labels else binding['title']
        lines.append(description+' → '+title)
    return ('\n\nSelected document reference key (use document titles for audience attribution; '
        'section codes refer inside these documents, not to separately supplied sources):\n'+'\n'.join(lines)) if lines else ''


def selected_bindings(record, entries):
    selected = {(b['originalId'], b.get('sha256')) for entry in entries
        for b in entry['factualSelection'] + entry['communicationSelection']}
    return [b for b in record['sourceBindings'] if (b['originalId'], b.get('sha256')) in selected]


def prompts(record,sources,config):
    if config.get('promptAssembly') == 'topic-and-audience-v1':
        text = record['basePrompt'].strip()+'\n\n'+config['commonPrompt'].strip()
        return {medium:text for medium in config['mediaSuffixes']}
    base = chapter_prompt(record,sources)+'\n\nShared communication brief (ADR020; not empirical evidence):\n'+config['commonPrompt']
    return {medium:base+'\n\n'+suffix for medium,suffix in config['mediaSuffixes'].items()}


def format_settings(matrix,format):
    field={'slide_deck':'slide_format','video':'video_format','audio':'audio_format'}.get(matrix['artifactType'])
    return {'artifact_type':matrix['artifactType'],**matrix['settings'],**matrix.get('formatSettings',{}).get(format,{}),**({field:format} if field else {})}


def instruction_entries(record,config,commission):
    """Resolve paired instructions only; provider imports and jobs remain separate."""
    assert record['schema']=='ai-ba.subject-authoring.v2' and record['edition']=='adr025-20261021'
    assert record['scopeType'] in {'chapter','section','collection'}
    assert record['sourceBindings'] and record['synthesis']['body'].strip()
    expected={}
    for row in commission['matrix']:
        for format in row['formats']:
            for ordinal in range(1,row['perFormatPerCondition']+1):
                expected[(row['artifactType'],format,ordinal)]=row
    treatments={(item['type'],item['format'],item['ordinal']):item for item in record['treatments']}
    assert len(treatments)==len(record['treatments'])==17 and treatments.keys()==expected.keys(), 'Treatment set differs from commission'
    assert set(commission['conditions'])=={'with-editorial','without-editorial'} and len(commission['conditions'])==2
    synthesis_id,synthesis_body=editorial(record)
    def selections(authority):
        return [{'originalId':b['originalId'],'sha256':b.get('sha256'),'locator':b['locator'],
            'namespace':b.get('namespace'),'key':b.get('key'),'store':b.get('store')} for b in record['sourceBindings']
            if (b['role']=='communication-authority')==authority]
    baseline=selections(False)
    concise = config.get('promptAssembly') == 'topic-and-audience-v1'
    base=config['commonPrompt']+'\n\nSubject commission:\n'+chapter_prompt(record,[])
    entries=[]
    for key,row in expected.items():
        item=treatments[key]
        assert item['medium']==row['medium'] and item['prompt'].strip()
        treatment=' '.join(filter(None,[config.get('formatCommissions',{}).get(key[1]),item['prompt']]))
        prompt=(item['prompt'].strip()+'\n\n'+config['commonPrompt'].strip()) if concise else (
            base+'\n\n'+treatment+'\n\n'+config['mediaSuffixes'][row['medium']]+source_references(record,config))
        settings=format_settings(row,key[1])
        for condition in commission['conditions']:
            entries.append({'key':f"{record['edition']}-{record['scopeType']}-{record['id']}-{key[0]}-{key[1]}-{key[2]}-{condition}",
                'subject':record['id'],'scopeType':record['scopeType'],'type':key[0],'format':key[1],'ordinal':key[2],
                'condition':condition,'prompt':prompt,'promptSha256':HASH(prompt),'factualSelection':baseline,'communicationSelection':[] if concise else selections(True),
                'synthesis':{'id':synthesis_id,'sha256':HASH(synthesis_body)} if condition=='with-editorial' else None,
                'settings':settings,'settingsReference':item['settingsReference'],'nativeOperation':'studio_create',
                'dependencies':['Exact selected-original import and full input verification','Current native format/settings support verification'],
                'readiness':'instruction-resolved; source upload and provider support not verified'})
    return entries


def released_cut(root,release,records,config):
    """Only an explicitly supplied reviewed whole-package cut can refresh inputs."""
    assert release['schema']=='ai-ba.notebook-input-release.v1'
    assert release['authorisation']=='verified-input-cut'
    assert release['communicationSha256']==config['sha256']
    assert release['authoritySha256']==config['authority']['sha256']
    assert len(records)==87 and set(release['chapters'])=={r['id'] for r in records}
    for record in records:
        path='config/authoring/chapters/'+record['id']+'.json'
        original=subprocess.check_output(['git','show',release['sourceCommit']+':'+path],cwd=root)
        assert HASH(original)==release['chapters'][record['id']]==HASH((root/path).read_bytes()), 'Unreleased chapter bytes'
        assert record.get('review',{}).get('adr020Alignment',{}).get('status') in {'reviewed','repaired'}, 'Chapter alignment is not parent-integrated'
    return HASH(json.dumps({'chapters':release['chapters'],'communicationSha256':release['communicationSha256'],
        'authoritySha256':release['authoritySha256']},sort_keys=True,separators=(',',':')))


def require_hold(work):
    control=json.loads((work/'generation-control.json').read_text())
    assert control['desiredState']!='run' and control.get('publicationState')=='hold', 'Input revision requires generation/publication hold'


def archive_inputs(root,files,cut_sha,atomic):
    """Archive complete old ledgers once, before replacing any active section."""
    directory=root/'docs/generation/history'/cut_sha
    manifest_file=directory/'manifest.json'
    if manifest_file.exists():
        manifest=json.loads(manifest_file.read_text())
        assert manifest['replacementCutSha256']==cut_sha
        for name,digest in manifest['ledgerHashes'].items():
            assert HASH((directory/name).read_bytes())==digest, 'Archived complete ledger changed'
        return manifest['replacementVersion']
    runs=[json.loads(file.read_text()) for file in files]
    assert all(j['status'] in {'completed','planned','source-blocked'} and (not j.get('id') or j['status']=='completed')
        for run in runs for j in run['jobs']), 'Reconcile uncertainty and drain every acknowledged job first'
    version=max(run.get('inputVersion',1) for run in runs)+1
    directory.mkdir(parents=True,exist_ok=True)
    hashes={}
    for file in files:
        body=file.read_bytes();target=directory/file.name
        if target.exists():
            assert target.read_bytes()==body, 'Incomplete archive differs from still-current ledger'
        else:
            with target.open('xb') as stream:
                stream.write(body);stream.flush();os.fsync(stream.fileno())
        hashes[file.name]=HASH(body)
    descriptor=os.open(directory,os.O_RDONLY)
    try:os.fsync(descriptor)
    finally:os.close(descriptor)
    atomic(manifest_file,{'schema':'ai-ba.generation-input-history.v1','replacementCutSha256':cut_sha,
        'replacementVersion':version,'ledgerHashes':hashes,'notebookId':runs[0]['notebookId'],
        'providerIdentities':sorted({j['id'] for run in runs for j in run['jobs'] if j.get('id')}),
        'preservation':'Complete subjects, prompts, source roles, settings, job states, original hashes and acknowledged provider IDs retained independently; no historical hash rewritten.'})
    return version
