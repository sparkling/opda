"""Freeze reviewed chapter inputs and import exact originals; never replay uncertain adds."""
import hashlib
import difflib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import argparse
import brief

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / '.local/artefact-generation'
BA = ROOT.parent / 'semantic-business-architecture'


def module(file):
    spec = importlib.util.spec_from_file_location(file.stem.replace('-', '_'), file)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


adapter = module(BA / 'scripts/research/ba-media-worker.py')
native = adapter.native
quota = adapter.load_module('generation-quota')
HASH = lambda body: hashlib.sha256(body.encode() if isinstance(body, str) else body).hexdigest()


def original_body(binding):
    """Resolve selected bytes, preserving historical versions and null-hash gaps."""
    identity, digest = binding['originalId'], binding.get('sha256')
    cached = WORK / 'sources' / (HASH(identity + ':' + str(digest)) + '.txt')
    if cached.exists():
        body = cached.read_text()
        assert digest is None or HASH(body) == digest
        return body
    if ':document:docs/' not in identity or not digest:
        return None
    owner, relative = identity.split(':document:', 1)
    roots = [ROOT, ROOT.parent / {'ba':'semantic-business-architecture', 'sa':'semantic-solution-architecture',
        'ea':'semantic-enterprise-architecture', 'product':'semantic-product',
        'semantic-query':'semantic-query'}.get(owner, ROOT.name)]
    for root in dict.fromkeys(roots):
        candidate = root / relative
        if candidate.is_file() and HASH(candidate.read_bytes()) == digest:
            body = candidate.read_text()
            assert HASH(body) == digest
            cached.parent.mkdir(parents=True,exist_ok=True)
            cached.write_text(body)
            return body
        history = subprocess.run(['git','log','--format=%H','--',relative], cwd=root, capture_output=True, text=True)
        for revision in history.stdout.splitlines():
            result = subprocess.run(['git','show',revision+':'+relative], cwd=root, capture_output=True)
            if result.returncode == 0 and HASH(result.stdout) == digest:
                body = result.stdout.decode()
                cached.parent.mkdir(parents=True,exist_ok=True)
                cached.write_text(body)
                return body
    return None


def literal_presentation(body):
    fence='`'*max(3,max((len(run) for run in re.findall(r'`+',body)),default=0)+1)
    return fence+'text\n'+body+'\n'+fence


def selected_passages(body, selection):
    """Derive explicit source windows without changing or silently widening originals.

    Lines are one-based/inclusive. JSON pointers preserve complete parsed values;
    their serialisation is a projection, never claimed to be original file bytes.
    The caller retains original identity/hash and supplies these texts to import_text.
    """
    assert set(selection) in ({'lines'}, {'characters'}, {'pointers'}), 'Choose explicit ranges or JSON pointers'
    parts, provenance = [], []
    if 'lines' in selection:
        lines = body.splitlines(keepends=True)
        previous = 0
        for first, last in selection['lines']:
            assert type(first) is int and type(last) is int
            assert previous < first <= last <= len(lines), 'Invalid/overlapping source window'
            start = sum(map(len, lines[:first-1])); end = start + sum(map(len, lines[first-1:last]))
            text = body[start:end]
            parts.append(text)
            provenance.append({'lines':[first,last], 'characters':[start,end], 'sha256':HASH(text)})
            previous = last
    elif 'characters' in selection:
        previous = 0
        for start, end in selection['characters']:
            assert type(start) is int and type(end) is int
            assert previous <= start < end <= len(body), 'Invalid/overlapping character range'
            text = body[start:end]
            parts.append(text)
            provenance.append({'characters':[start,end],
                'lines':[body.count('\n',0,start)+1,body.count('\n',0,end-1)+1], 'sha256':HASH(text)})
            previous = end
    else:
        document = json.loads(body)
        pointers = selection['pointers']
        assert pointers and len(pointers) == len(set(pointers))
        for pointer in pointers:
            assert pointer.startswith('/') and pointer != '/', 'Explicit JSON value required'
            value = document
            for part in pointer[1:].split('/'):
                assert not re.search(r'~(?![01])', part), 'Invalid JSON pointer escape'
                part = part.replace('~1','/').replace('~0','~')
                if isinstance(value, list):
                    assert re.fullmatch(r'0|[1-9][0-9]*', part) and int(part) < len(value), 'Invalid array pointer'
                    value = value[int(part)]
                else:
                    value = value[part]
            text = json.dumps(value, ensure_ascii=False, indent=2)
            parts.append(pointer+'\n'+text)
            provenance.append({'pointer':pointer, 'sha256':HASH(text), 'representation':'complete-parsed-value'})
    assert parts and all(part.strip() for part in parts), 'Empty source selection'
    return parts, provenance


def import_text(client, receipt, key, body, title, literal_body=None):
    row = receipt['sources'].setdefault(key, {'title':title, 'sha256':HASH(body), 'status':'planned'})
    assert row['sha256'] == HASH(body)
    if literal_body is not None:
        assert body==literal_presentation(literal_body), 'Presentation must contain the original verbatim'
        row.update(originalSha256=HASH(literal_body),uploadedPresentationSha256=HASH(body),presentationVersion='verbatim-fenced-text-v1')
    title = row['title']  # One original can have different chapter display labels.
    if row['status'] == 'indexed-verified':
        return row['sourceId']
    notebook = receipt['notebookId']
    if not row.get('sourceId'):
        matches = [s for s in client.get_notebook_sources_with_types(notebook) if s.get('title') == title]
        if len(matches) == 1:
            row.update(sourceId=matches[0]['id'],status='submitted',reconciledAt=native.NOW())
            save_receipt(receipt)
        elif matches:
            return None
    if not row.get('sourceId'):
        if row['status'] != 'planned':
            matches = [s for s in client.get_notebook_sources_with_types(notebook) if s.get('title') == title]
            if len(matches) != 1:
                return None
            row['sourceId'] = matches[0]['id']
        else:
            row.update(status='submitting', attemptedAt=native.NOW())
            save_receipt(receipt)
            result = native.create_once(client, client.add_text_source, notebook, body, title=title, fenced_rpc=client.RPC_ADD_SOURCE)
            assert result and result.get('id'), 'Uncertain source add retained; reconcile instead of replay'
            row.update(status='submitted', sourceId=result['id'])
            save_receipt(receipt)
    client.wait_for_source_ready(notebook, row['sourceId'], 30)
    indexed = client.get_source_fulltext(row['sourceId'])
    if literal_body is not None:
        wanted,actual=re.findall(r'\w+',literal_body),re.findall(r'\w+',indexed['content'])
        assert indexed['title']==title and actual in (wanted, ['text']+wanted, wanted+['text']), 'Literal original vocabulary differs'
        row.update(status='indexed-verified',indexedTextSha256=HASH(indexed['content']),verifiedAt=native.NOW(),
            verification='complete-case-sensitive-ordered-original-vocabulary-in-verbatim-text-presentation',
            verificationLimits='Every original word, identifier and number retained in order; only an optional leading or trailing text code-language label is presentation metadata. Punctuation/layout fidelity of indexed text is not asserted; exact original and uploaded presentation bytes have separate hashes.')
        save_receipt(receipt)
        return row['sourceId']
    # NotebookLM expands Markdown into separately spaced text spans and omits
    # list counters. Verify the complete ordered vocabulary, retaining case and
    # every substantive number; punctuation/layout fidelity is not claimed.
    references = dict(re.findall(r'^\[([^\]]+)\]:\s*(\S+)\s*$',body,flags=re.MULTILINE))
    expected = re.sub(r'<!--[\s\S]*?-->', '', body)
    expected = re.sub(r'^\[[^\]]+\]:\s*\S+\s*$', '', expected, flags=re.MULTILINE)
    expected = re.sub(r'\[([^\]]+)\]\[([^\]]+)\]', lambda m:m[1]+' '+references.get(m[2],m[2]), expected)
    expected = re.sub(r'^\s*\d+\.\s+', '', expected, flags=re.MULTILINE)
    wanted, actual = re.findall(r'\w+', expected), re.findall(r'\w+', indexed['content'])
    languages = set(re.findall(r'^```(\w+)\s*$', body, flags=re.MULTILINE))
    changes = [op for op in difflib.SequenceMatcher(None, wanted, actual, autojunk=False).get_opcodes() if op[0] != 'equal'] if wanted != actual else []
    urls = [re.findall(r'\w+',url) for url in [*references.values(),*re.findall(r'\]\(([^)]+)\)',body)]]
    def metadata_only(words):
        while words:
            if words[0] in languages:
                words = words[1:]
                continue
            match = next((url for url in urls if url and words[:len(url)] == url),None)
            if match is None:
                return False
            words = words[len(match):]
        return True
    assert indexed['title'] == title and all(metadata_only(wanted[i:j]) and metadata_only(actual[k:l])
        for _, i, j, k, l in changes), 'Indexed source vocabulary differs'
    row.update(status='indexed-verified', indexedTextSha256=HASH(indexed['content']), verifiedAt=native.NOW(),
        verification='complete-case-sensitive-ordered-vocabulary-with-explicit-markdown-transformations',
        verificationLimits='HTML comments are not indexed. Markdown list counters, code-language labels and repeated source link destinations are presentation metadata. Punctuation/layout fidelity is not asserted; exact uploaded-byte hash retained separately.')
    save_receipt(receipt)
    return row['sourceId']


def save_receipt(receipt):
    quota.atomic_json(WORK / 'source-import.json', receipt)


def prepare(release_file=None):
    WORK.mkdir(parents=True, exist_ok=True)
    owner = adapter.load_module('generation-ownership')
    owner.WORK = WORK
    with owner.StageLock('source-import'):
        receipt_path = WORK / 'source-import.json'
        receipt = json.loads(receipt_path.read_text()) if receipt_path.exists() else {'schema':'ai-ba.notebook-inputs.v1','sources':{}}
        accepted = WORK/'released-chapter-cut.json'
        release_path = Path(release_file) if release_file else accepted if accepted.exists() else None
        if receipt.get('preparationComplete') and release_path is None:
            return  # Author drafts cannot become provider inputs automatically.
        inventory = json.loads(subprocess.check_output(['node','--input-type=module','-e',
            "import {notebookInventory} from './scripts/notebooks/inventory.mjs'; console.log(JSON.stringify(notebookInventory()));"],cwd=ROOT))
        records = [json.loads((ROOT / 'config/authoring/chapters' / (chapter['id']+'.json')).read_text())
            for chapter in inventory['chapters']]
        assert len(records) == 87 and {r['id'] for r in records} == {c['id'] for c in inventory['chapters']}
        assert all(r['review']['status'] in ('reviewed','repaired') for r in records)
        release = json.loads(release_path.read_text()) if release_path else None
        communication, authority_body, cut_sha = None, None, None
        if release:
            communication,authority_body = brief.communication(ROOT)
            cut_sha = brief.released_cut(ROOT,release,records,communication)
            if receipt.get('preparedCutSha256')==cut_sha:
                return
            brief.require_hold(WORK)
            quota.atomic_json(accepted,release)
        client = adapter.worker.get_client()
        title = 'AI Strategy and Business Architecture — 87 reviewed chapters — 2026-10-20'
        if not receipt.get('notebookId'):
            matches = [n for n in client.list_notebooks() if n.title == title]
            assert len(matches) <= 1, 'Ambiguous collection notebook'
            if not matches:
                assert not receipt.get('notebookIntentAt'), 'Uncertain notebook creation requires reconciliation'
                receipt['notebookIntentAt'] = native.NOW()
                save_receipt(receipt)
                notebook = native.create_once(client, client.create_notebook, title, fenced_rpc=client.RPC_CREATE_NOTEBOOK)
            else:
                notebook = matches[0]
            receipt.update(notebookId=notebook.id, title=title)
            save_receipt(receipt)
        configuration = json.loads((BA / 'config/authoring/ba-chapters.json').read_text())
        frozen = WORK / ('subjects-'+cut_sha+'.json' if release else 'subjects.json')
        subjects = json.loads(frozen.read_text()) if frozen.exists() else {}
        previous = json.loads((WORK/'subjects.json').read_text()) if (WORK/'subjects.json').exists() else {}
        authority_id = None
        if release:
            title = re.search(r'^#\s+(.+)$',authority_body,re.MULTILINE)[1]
            authority_id = import_text(client,receipt,'corpus:'+HASH(authority_body),authority_body,title[:160]+' ['+HASH(authority_body)[:16]+']')
        deferred = set()
        for record in records:
            id = record['id']
            if subjects.get(id, {}).get('generationReady'):
                continue
            sources, gaps = [], []
            for binding in record['sourceBindings']:
                key = HASH(binding['originalId'] + ':' + str(binding.get('sha256')))
                if key in deferred:
                    gaps.append({'originalId':binding['originalId'],'errorType':receipt['sources'].get(key,{}).get('lastErrorType','deferred-input')})
                    continue
                body = original_body(binding)
                if body is None:
                    gaps.append({'originalId':binding['originalId'],'reason':'Selected original bytes unavailable; no substitute admitted'})
                    continue
                try:
                    source_id = import_text(client, receipt, key, body, binding['title'] + ' [' + HASH(body)[:12] + ']')
                    assert source_id, 'Uncertain source upload'
                    provenance = WORK/'sources'/(key+'.provenance.json')
                    sources.append({**binding, 'sourceId':source_id, 'uploadedSha256':HASH(body),
                        **({'resolvedWindow':json.loads(provenance.read_text())} if provenance.exists() else {})})
                except Exception as error:
                    if adapter.load_module('generation-ownership').safe_error(error).get('reason') == 'notebook-auth-expired':
                        raise RuntimeError('NotebookLM authentication expired') from None
                    deferred.add(key)
                    if key in receipt['sources']:
                        receipt['sources'][key]['lastErrorType'] = type(error).__name__
                        save_receipt(receipt)
                    gaps.append({'originalId':binding['originalId'],'errorType':type(error).__name__})
                    print(json.dumps({'sourceDeferred':binding['originalId'],'errorType':type(error).__name__}),flush=True)
            editorial_id = None
            editorial_key,editorial = brief.editorial(record)
            try:
                editorial_id = import_text(client, receipt, editorial_key, editorial, 'AI BA — '+id+' — reviewed editorial ['+HASH(editorial)[:12]+']')
            except Exception as error:
                if adapter.load_module('generation-ownership').safe_error(error).get('reason') == 'notebook-auth-expired':
                    raise RuntimeError('NotebookLM authentication expired') from None
                gaps.append({'editorial':id,'errorType':type(error).__name__})
            prompt = brief.chapter_prompt(record,sources)
            prompts = {medium:prompt+'\n\n'+suffix for medium,suffix in configuration['mediaSuffixes'].items()}
            if release:
                prompts = brief.prompts(record,sources,communication)
                if not authority_id:
                    gaps.append({'communicationAuthority':'ADR020','reason':'Pinned full communication authority not indexed-verified'})
                if authority_id and authority_id in [s['sourceId'] for s in sources]:
                    gaps.append({'communicationAuthority':'ADR020','reason':'Communication authority cannot also be selected as empirical chapter evidence'})
            chapter = next(c for c in inventory['chapters'] if c['id'] == id)
            subjects[id] = {**chapter, 'level':0, 'factualSourceIds':list(dict.fromkeys(s['sourceId'] for s in sources)),
                'originalSources':sources,'editorialSourceId':editorial_id,'editorialSha256':HASH(editorial),
                'editorialVersion':previous.get(id,{}).get('editorialVersion',1)+(1 if id in previous and previous[id]['editorialSha256']!=HASH(editorial) else 0),
                'editorialSync':{'status':'indexed-verified' if editorial_id else 'unavailable'},'mediaPrompts':prompts,
                'promptHashes':{medium:HASH(text) for medium,text in prompts.items()},'generationReady':not gaps and bool(editorial_id),
                'sourceGaps':gaps,'authoringSha256':HASH(json.dumps(record,ensure_ascii=False,separators=(',',':')))}
            if release:
                subjects[id].update(communicationSourceIds=[authority_id] if authority_id else [],
                    communicationAuthority={**communication['authority'],'sourceId':authority_id},
                    communicationConfigSha256=communication['sha256'],inputCutSha256=cut_sha)
            quota.atomic_json(frozen, subjects)
            print(json.dumps({'chapter':id,'ready':subjects[id]['generationReady'],'gaps':len(gaps)}),flush=True)
            freeze(inventory, subjects, receipt, configuration, release, cut_sha)
        freeze(inventory, subjects, receipt, configuration, release, cut_sha)
        # Final source-repair lane: a rejected/uncertain add without an ID is
        # reconciled against the full provider census after every chapter has
        # had its first pass. Retry at most once, preserving the original intent.
        # No remotely identified processing source or running artefact is retried.
        available = client.get_notebook_sources_with_types(receipt['notebookId'])
        originals = {HASH(b['originalId']+':'+str(b.get('sha256'))):b for r in records for b in r['sourceBindings']}
        repaired = False
        for key, row in list(receipt['sources'].items()):
            if row.get('sourceId') or row.get('finalRepairCount') or row['status'] == 'indexed-verified':
                continue
            matches = [s for s in available if s.get('title') == row['title']]
            if matches:
                continue  # Normal next-pass reconciliation verifies its body.
            body = original_body(originals[key]) if key in originals else None
            if body is None:
                continue
            row['attemptHistory'] = row.get('attemptHistory',[]) + [{**row,'providerAbsenceVerifiedAt':native.NOW(),
                'providerSourceCount':len(available),'repairPolicy':'one-final-repair-after-all-chapter-inputs-attempted'}]
            row.update(status='planned',finalRepairCount=1)
            save_receipt(receipt)
            try:
                repaired = bool(import_text(client,receipt,key,body,row['title'])) or repaired
            except Exception as error:
                row['repairErrorType'] = type(error).__name__
                save_receipt(receipt)
        receipt['preparationComplete'] = not repaired
        receipt['preparedAt'] = native.NOW()
        if release and len(subjects)==87 and all(s['generationReady'] for s in subjects.values()):
            receipt['preparedCutSha256']=cut_sha
            quota.atomic_json(WORK/'subjects.json',subjects)
        save_receipt(receipt)


def freeze(inventory, subjects, receipt, configuration, release=None, cut_sha=None):
    owner = adapter.load_module('generation-ownership')
    owner.WORK = WORK
    with owner.StageLock('generation',WORK/'worker.lock'):
        if release:
            brief.require_hold(WORK)
            if len(subjects)!=87 or not all(s['generationReady'] for s in subjects.values()):
                return
        _freeze(inventory,subjects,receipt,configuration,release,cut_sha)


def _freeze(inventory, subjects, receipt, configuration, release=None, cut_sha=None):
    directory = ROOT / 'docs/generation'
    directory.mkdir(parents=True, exist_ok=True)
    commit = release['sourceCommit'] if release else subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    version = 1
    if release:
        files = [directory/(s['id']+'.json') for s in inventory['sections']]
        current = [json.loads(file.read_text()) for file in files]
        if all(run.get('inputCutSha256')==cut_sha for run in current):
            return
        version = brief.archive_inputs(ROOT,files,cut_sha,quota.atomic_json)
        commit = release['sourceCommit']
    for section in inventory['sections']:
        file = directory / (section['id']+'.json')
        if file.exists() and (not release or json.loads(file.read_text()).get('inputCutSha256')==cut_sha):
            run = json.loads(file.read_text())
            changed = False
            for i, subject in enumerate(run['subjects']):
                replacement = subjects.get(subject['id'])
                if not subject['generationReady'] and replacement and replacement['generationReady']:
                    pending = [j for j in run['jobs'] if j['subject'] == subject['id']]
                    assert all(j['status'] == 'source-blocked' and not j.get('id') for j in pending)
                    run['subjects'][i] = replacement
                    for job in pending:
                        job['status'] = 'planned'
                    changed = True
            if changed:
                run.setdefault('inputRevisionHistory',[]).append({'inputSha256':run['inputSha256'],
                    'revisedAt':native.NOW(),'reason':'Previously blocked selected inputs became verified; existing generated-subject inputs and provider identities are unchanged.'})
                run['inputSha256'] = HASH(json.dumps(run['subjects'],ensure_ascii=False,separators=(',',':')))
                native.save(file, run)
            continue
        chapters = [c for c in inventory['chapters'] if c['sectionId'] == section['id']]
        if not all(c['id'] in subjects for c in chapters):
            continue
        selected = [subjects[c['id']] for c in chapters]
        jobs = []
        for subject in selected:
            for matrix in configuration['matrix']:
                for format in matrix['formats']:
                    for condition in configuration['conditions']:
                        for ordinal in range(1,matrix['perFormatPerCondition']+1):
                            editorial = condition == 'with-editorial'
                            settings = brief.format_settings(matrix,format)
                            jobs.append({'key':f"v{version}-{subject['id']}-{matrix['artifactType']}-{format}-{condition}-{ordinal}",
                                'subject':subject['id'],'level':0,'type':matrix['artifactType'],'medium':matrix['medium'],'format':format,
                                'ordinal':ordinal,'editorial':editorial,'version':version,'settings':settings,'id':None,
                                'title':f"{subject['id']} {subject['title']} — {format.replace('_',' ')} {ordinal} — {condition}",
                                'status':'planned' if subject['generationReady'] else 'source-blocked'})
        run = {'schemaVersion':1,'sourceCommit':commit,'sectionId':section['id'],'notebookId':receipt['notebookId'],
            'requested':len(jobs),'commissioned':True,'publish':True,'subjects':selected,
            'inputSha256':HASH(json.dumps(selected,ensure_ascii=False,separators=(',',':'))),'jobs':jobs}
        if release:
            run.update(inputVersion=version,inputCutSha256=cut_sha,communicationConfigSha256=subjects[selected[0]['id']]['communicationConfigSha256'])
        native.save(file, run)


if __name__ == '__main__':
    try:
        parser=argparse.ArgumentParser(description=__doc__)
        parser.add_argument('--release-cut',help='Explicit parent-verified whole87chapter cut; generation/publication remain held')
        prepare(parser.parse_args().release_cut)
    except Exception as error:
        safe = adapter.load_module('generation-ownership').safe_error(error)
        print(json.dumps(safe),flush=True)
        raise SystemExit(70 if safe.get('reason') == 'notebook-auth-expired' else 1)
