"""Resolve the authorised ADR049 second-round data through the existing runner."""
import copy
import json


def projection(r):
    config = r.read(r.SCREEN)
    assert config['schema'] == 'ai-ba.content-confirmation-inputs.v1'
    assert config['id'] == 'content-confirmation-v2'
    assert config['counts'] == {'cells':48,'reusedArtifacts':0,'newRequests':48}
    assert config['review']['status'] == 'reviewed-and-frozen'
    for cut in config['sourceCut']:
        assert r.HASH((r.ROOT/cut['path']).read_bytes()) == cut['sha256'], cut['path']
    assert r.HASH(json.dumps(config['rubric'],sort_keys=True,separators=(',',':'))) == config['rubricSha256']
    design = r.read(r.ROOT/'config/authoring/experiments/N01-content-confirmation-v2.json')
    original = r.read(r.ROOT/'config/authoring/experiments/N01-content-screen-v1.json')
    conditions = {c['id']:c for c in design['conditions']}
    chapters = {c['id']:c for c in config['chapters']}
    sources = {s['sourceId']:s for s in config['sources']}
    for s in sources.values():
        assert r.HASH((r.ROOT/s['indexedPath']).read_bytes()) == s['indexedTextSha256']
        receipt = next(x for x in r.read(r.ROOT/s['importReceiptPath'])['sources'].values() if x.get('sourceId') == s['sourceId'])
        assert receipt['status'] == 'indexed-verified' and receipt['indexedTextSha256'] == s['indexedTextSha256']
        assert receipt['sha256'] == s['uploadedSha256']
        if s.get('bodyPath'): assert r.HASH((r.ROOT/s['bodyPath']).read_bytes()) == s['bodySha256']
        if s.get('bodyConfigPath'):
            body = next(x for x in r.read(r.ROOT/s['bodyConfigPath'])['subjects'] if x['id']==s['bodySubject'])
            assert r.HASH(body['body']) == s['bodySha256']
            assert [x['sourceId'] for x in body['sources']] == s['citedSourceIds']
    assert len(config['cells']) == len({c['id'] for c in config['cells']}) == 48
    runs, snapshots = [], []
    for cell in config['cells']:
        chapter = chapters[cell['chapter']]
        first = next(c for c in original['chapters'] if c['id']==cell['chapter'])
        condition = conditions[cell['condition']]
        assert all(cell[k]==condition[k] for k in ('P','F','S','V'))
        assert cell['replicate'] in (1,2) and not cell['reuse']
        baseline = r.read(r.ROOT/chapter['baselineLedger'])
        assert r.HASH((r.ROOT/chapter['baselineLedger']).read_bytes()) == chapter['baselineLedgerSha256']
        subject, original_job = copy.deepcopy(baseline['subjects'][0]), baseline['jobs'][0]
        profile = copy.deepcopy(first['profiles'][cell['P']])
        if cell['F']=='F1':
            profile['components'][-2]['text'] = design['candidateInstructions']['fidelityShared']+' '+design['candidateInstructions']['fidelityByChapter'][chapter['id']]
        if cell['V']=='V1': profile['components'][2]['text'] = design['candidateInstructions']['visualTreatments'][chapter['id']]
        for component in profile['components']: component['sha256'] = r.HASH(component['text'])
        prompt = '\n\n'.join(c['text'] for c in profile['components'])
        ids = list(chapter['sourceSets']['C0'])
        assert ids == first['sourceSets']['C0']
        synthesis = chapter['syntheses'].get(cell['S'])
        if synthesis:
            assert set(synthesis['citedSourceIds']) <= set(ids)
            source = sources[synthesis['sourceId']]; ids.append(source['sourceId'])
            receipt = next(x for x in r.read(r.ROOT/source['importReceiptPath'])['sources'].values() if x.get('sourceId')==source['sourceId'])
            subject.update(editorialSourceId=source['sourceId'],editorialSha256=source['bodySha256'],editorialSync=copy.deepcopy(receipt))
        else: subject.update(editorialSourceId=None,editorialSha256=None,editorialSync={'status':'not-selected'})
        subject.update(synthesisVariant=cell['S'],mediaPrompts={chapter['medium']:prompt},promptHashes={chapter['medium']:r.HASH(prompt)})
        settings = copy.deepcopy(original_job['settings'])
        assert all(settings[k]==config['fixedNative'][k] for k in ('artifact_type','slide_length','language'))
        assert settings['slide_format']==chapter['format']
        arguments = dict(notebook_id=baseline['notebookId'],source_ids=ids,format_code=r.native.constants.SLIDE_DECK_FORMATS.get_code(chapter['format']),length_code=4,language=settings['language'],focus_prompt=prompt)
        digest = r.HASH(json.dumps({'createArguments':arguments,'indexedSourceHashes':{i:sources[i]['indexedTextSha256'] for i in ids}},sort_keys=True,separators=(',',':')))
        job = {k:copy.deepcopy(original_job[k]) for k in r.REQUEST_FIELDS if k not in ('editorial','version','promptSha256')}
        job.update(status='planned',key=config['id']+'-'+cell['id'],version=6,editorial=bool(synthesis),promptSha256=r.HASH(prompt),title=f"ADR049 round two — {cell['id']}",experimentCell=cell['id'],condition=cell['condition'],conditionLabel='Round two '+cell['condition'],completeInputSha256=digest,replicate=cell['replicate'])
        run = dict(schemaVersion=1,edition=baseline['edition'],comparisonVersion=config['id'],sectionId=cell['id'],chapterId=chapter['id'],notebookId=baseline['notebookId'],requested=1,commissioned=True,publish=False,manifestSha256=r.HASH(r.SCREEN.read_bytes()),subjects=[subject],inputSha256=r.HASH(json.dumps([subject],ensure_ascii=False,separators=(',',':'))),jobs=[job])
        snapshots.append(dict(cell=cell,completeInputSha256=digest,promptComponents=profile['components'],adapterEnvelope={**settings,'notebook_id':run['notebookId'],'title':job['title'],'source_ids':ids,'focus_prompt':prompt},consumedCreateMethod='NotebookLMClient.create_slide_deck',consumedCreateArguments=arguments,selectedSources=[sources[i] for i in ids],reuse=None,evaluationStatus='awaiting-independent-review'))
        runs.append(run)
    assert len({s['completeInputSha256'] for s in snapshots}) == 24
    for chapter in chapters:
        assert {(c['condition'],c['replicate']) for c in config['cells'] if c['chapter']==chapter} == {(c,n) for c in conditions for n in (1,2)}
    return config, runs, snapshots


def handoff(r):
    """Project verified renditions into the independent evaluator's neutral subtree."""
    import os
    from pathlib import Path
    mapping = r.read(r.WORK/'neutral-condition-map.json')['entries']
    state_path = r.ROOT/'.local/n01-comparison/concise-build/renditions.json'
    state = r.read(state_path) if state_path.exists() else {}
    references = r.read(r.WORK/'evaluation/reference-inventory.json')['sources']
    originals = {s['sourceId']:s for s in references}
    snapshots = {x['cell']['id']:x for x in r.read(r.WORK/'request-inputs.json')['requests']}
    ledgers = {x['sectionId']:x for x in r.adapter.reads()}
    entries = []
    for neutral in mapping:
        run = ledgers[neutral['cellId']]; job = run['jobs'][0]
        item = state.get(job.get('id'))
        if job['status']!='completed' or not job.get('providerProof',{}).get('settingsVerified') or not item:
            continue
        folder = r.WORK/'evaluation/outputs'/neutral['neutralId']; folder.mkdir(parents=True,exist_ok=True)
        def retain(source, target, digest):
            assert r.HASH(source.read_bytes())==digest
            if not target.exists():
                try: os.link(source,target)
                except OSError:
                    import shutil
                    shutil.copyfile(source,target)
            assert r.HASH(target.read_bytes())==digest
            return str(target.relative_to(r.ROOT))
        pdf = r.WORK/'originals'/(job['key']+'.pdf')
        pdf_path = retain(pdf,folder/'deck.pdf',item['original']['sha256'])
        slides=[]
        for index,slide in enumerate(item['slides'],1):
            source = r.ROOT/'.local/n01-comparison/concise-build/public'/slide['path'].lstrip('/')
            slides.append(dict(slide=index,path=retain(source,folder/f'slide-{index:03d}.webp',slide['sha256']),sha256=slide['sha256'],width=slide['width'],height=slide['height']))
        import pypdfium2
        document=pypdfium2.PdfDocument(pdf)
        try: assert len(document)==len(slides)
        finally: document.close()
        ids=snapshots[neutral['cellId']]['consumedCreateArguments']['source_ids']
        entries.append(dict(neutralId=neutral['neutralId'],chapter=neutral['chapter'],order=neutral['order'],artifactId=job['id'],notebookId=run['notebookId'],pdfPath=pdf_path,pdfSha256=item['original']['sha256'],pageCount=len(slides),slides=slides,originalSourceWhitelist=[originals[i] for i in ids if i in originals],generationStartedAt=job.get('attemptedAt'),acknowledgedAt=job.get('acknowledgedAt'),deliveryObservedAt=job.get('checkedAt'),reviewStatus='ready-for-independent-review'))
    r.production.generation_quota().atomic_json(r.WORK/'evaluation/neutral-handoffs.json',dict(schema='ai-ba.neutral-handoffs.v1',updatedAt=r.native.NOW(),plannedMainDecks=48,readyDecks=len(entries),entries=sorted(entries,key=lambda x:x['order'])))
    return len(entries)
