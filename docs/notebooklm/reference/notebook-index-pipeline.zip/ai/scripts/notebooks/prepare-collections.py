"""Prepare configured collections using the existing import and native mapping owners.

This adapter has no media-create, queue, renderer, publication or model route.
"""
import argparse
from collections import Counter
import copy
import json
from pathlib import Path
import re
from types import SimpleNamespace

import prepare

ROOT = prepare.ROOT
CONFIG = ROOT / 'config/authoring/proposals/manifest.json'
WORK = ROOT / '.local/five-proposal-notebooks-20261025'
HASH = prepare.HASH
native = prepare.native
adapter = prepare.adapter
unified = prepare.module(Path(__file__).with_name('unified-inputs.py'))
source_api = prepare.module(Path(__file__).with_name('topic-sources.py'))
save = prepare.quota.atomic_json
FORBIDDEN = re.compile(r'standalone presentation|independent reading|self-contained (?:deck|presentation)|without a presenter|read independently|read alone', re.I)


def read(path):
    return json.loads(path.read_text())


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def safe_file(relative):
    path = Path(relative)
    assert not path.is_absolute() and '..' not in path.parts
    assert path.parts[0] in ('docs', 'config'), 'Source outside documentary owners'
    resolved = (ROOT / path).resolve()
    assert resolved.is_relative_to(ROOT)
    return resolved


def configuration(identity):
    manifest = read(CONFIG)
    assert manifest['schema'] == 'ai-ba.proposal-collections.v1'
    entry = next(c for c in manifest['collections'] if c['id'] == identity)
    config = read(safe_file(entry['path']))
    assert config['schema'] == 'ai-ba.proposal-collection.v1' and config['id'] == identity
    assert config['status'] in ('draft', 'independent-review-passed')
    if config['status'] == 'independent-review-passed':
        review = config.get('review', {})
        assert review.get('disposition') == 'pass' and review.get('reviewer')
        assert review['reviewedContentSha256'] == HASH(canonical({k:v for k,v in config.items() if k not in ('status','review')})), 'Reviewed content changed'
        assert review['sharedManifestSha256'] == HASH(canonical(manifest)), 'Reviewed shared inputs changed'
    ids = [s['id'] for s in config['subjects']]
    assert len(ids) == len(set(ids))
    assert all(re.fullmatch(r'[A-Z]{2}(?:\d{2}(?:\.\d{2})?)?', i) for i in ids)
    section_ids = {s['id'] for s in config['subjects'] if s['scopeType'] == 'section'}
    assert all(s['sectionId'] in section_ids for s in config['subjects'] if s['scopeType'] == 'chapter')
    assert sum(s['scopeType'] == 'collection' for s in config['subjects']) == 1
    for cut in config['sourceCut']:
        assert HASH(safe_file(cut['path']).read_bytes()) == cut['sha256'], 'Source cut changed: ' + cut['path']
    matrix = read(ROOT.parent / 'semantic-business-architecture/config/authoring/ba-chapters.json')['matrix']
    if config['status'] == 'independent-review-passed':
        assert config['review']['nativeMatrixSha256'] == HASH(canonical(matrix)), 'Reviewed native matrix changed'
    return manifest, config, matrix


def sources_for(config):
    result = {}
    for label, definition in config['sources'].items():
        provenance = []
        parts = []
        for selection in definition['provenance']:
            original = safe_file(selection['path']).read_text()
            assert HASH(original) == selection['sha256']
            selected, ranges = prepare.selected_passages(original, selection['selection'])
            parts.extend(selected)
            provenance.append({**selection, 'resolvedRanges': ranges})
        body = definition.get('body')
        if body is None:
            body = '# ' + definition['title'] + '\n\n' + '\n\n'.join(parts)
        assert body.strip() and not FORBIDDEN.search(body), 'Prohibited or empty source direction: ' + label
        derivation = definition.get('derivedFrom')
        if derivation:
            parent = config['sources'][derivation['label']]['body']
            assert HASH(parent) == derivation['bodySha256']
            selected, _ = prepare.selected_passages(parent,derivation['selection'])
            assert all(text in body for text in selected), 'Derived paragraph changed'
        result[label] = source_api.source_record(label, definition['title'], body,
            dict(predecessors=provenance, transformation=definition['transformation'],derivation=derivation), definition['role'], True)
    assert len({s['title'] for s in result.values()}) == len(result)
    assert len({s['key'] for s in result.values()}) == len(result), 'Duplicate source bodies'
    return result


def projection(identity, receipt=None):
    manifest, config, matrix = configuration(identity)
    sources = sources_for(config)
    requests = []
    topic_ids = []
    for subject in config['subjects']:
        whole = {t['type'] for t in subject['topics'] if t.get('wholeSubject')}
        assert whole == {'video', 'slide_deck', 'audio', 'infographic'}
        for topic in subject['topics']:
            topic_ids.append(topic['id'])
            selected = topic['sourceLabels']
            assert selected and len(selected) == len(set(selected)) and set(selected) <= sources.keys()
            assert len(selected) < len(sources), 'Default-all selection prohibited'
            components = [dict(role=role, text=text, sha256=HASH(text), destination='focus_prompt')
                for role, text in [('topicCommission', topic['commission']), ('purposeAndAudience', manifest['audience'])]]
            prompt = '\n\n'.join(c['text'] for c in components)
            assert not FORBIDDEN.search(prompt)
            row = next(m for m in matrix if m['artifactType'] == topic['type'])
            for fmt in row['formats']:
                settings = prepare.brief.format_settings(row, fmt)
                for detail in manifest['infographicDetails'] if topic['type'] == 'infographic' else [None]:
                    for take in (1, 2) if detail else (1,):
                        current = copy.deepcopy(settings)
                        if detail:
                            current['detail_level'] = detail
                        ids = [receipt['sources'][sources[label]['key']]['sourceId'] for label in selected] if receipt else selected
                        notebook = receipt['notebookId'] if receipt else '<not-yet-bound>'
                        envelope = {**current, 'notebook_id': notebook, 'source_ids': ids, 'focus_prompt': prompt}
                        method, args = unified.native_arguments(SimpleNamespace(native=native, adapter=adapter), envelope)
                        key = f"{config['runId']}-{topic['id']}-{fmt}" + (f'-{detail}-take-{take}' if detail else '')
                        request = dict(key=key, subject=subject['id'], topic=topic, format=fmt, take=take,
                            infographicDetail=detail, promptComponents=components, promptSha256=HASH(prompt),
                            adapterEnvelope=envelope, consumedCreateMethod='NotebookLMClient.'+method,
                            consumedCreateArguments=args, sourceLabels=selected,
                            selectedSources=[{**sources[label], **({'sourceId':sid,
                                'indexedTextSha256':receipt['sources'][sources[label]['key']]['indexedTextSha256']} if receipt else {})}
                                for label, sid in zip(selected, ids)])
                        request['completeInputSha256'] = HASH(canonical(dict(arguments=args,
                            sourceHashes={label:sources[label]['bodySha256'] for label in selected},
                            indexedHashes={s['sourceId']:s['indexedTextSha256'] for s in request['selectedSources']} if receipt else {})))
                        requests.append(request)
    assert len(topic_ids) == len(set(topic_ids)) and len({r['key'] for r in requests}) == len(requests)
    used = {label for r in requests for label in r['sourceLabels']}
    assert used == set(sources), 'Unused source would widen notebook unnecessarily'
    counts = dict(sections=len([s for s in config['subjects'] if s['scopeType']=='section']),
        chapters=len([s for s in config['subjects'] if s['scopeType']=='chapter']), subjects=len(config['subjects']),
        topics=len(topic_ids), outputs=len(requests), sources=len(sources),
        byType=dict(Counter(r['topic']['type'] for r in requests)))
    return dict(schema='ai-ba.unified-request-inputs.v2', collection=identity, runId=config['runId'],
        configSha256=HASH(canonical(config)), status=config['status'], counts=counts,
        subjects=config['subjects'], sources=sources, requests=requests, mediaCreates=0,
        boundary='Reviewed preparation only; request arguments are resolved, not submitted.')


def verify(identity, live=False):
    work = WORK / identity
    receipt = read(work / 'source-import.json')
    plan = projection(identity, receipt)
    assert set(receipt['sources']) == {s['key'] for s in plan['sources'].values()}, 'Receipt differs from reviewed source set'
    assert receipt['preparedConfigSha256'] == plan['configSha256'], 'Reviewed config changed'
    assert receipt['preparedPlanSha256'] == HASH(canonical(projection(identity))), 'Reviewed unbound plan changed'
    assert len({s['sourceId'] for s in receipt['sources'].values()}) == len(receipt['sources'])
    assert plan['status'] == 'independent-review-passed'
    frozen = read(work / 'request-inputs.json')
    assert canonical(plan) == canonical(frozen), 'Frozen request inputs changed'
    client = adapter.worker.get_client() if live else None
    for source in plan['sources'].values():
        row = receipt['sources'][source['key']]
        assert row['status'] == 'indexed-verified'
        indexed = client.get_source_fulltext(row['sourceId']) if live else read(work/'source-readbacks'/(row['sourceId']+'.json'))
        assert HASH(indexed['content']) == row['indexedTextSha256'] and indexed['title'] == source['title']
        wanted, actual = re.findall(r'\w+',source['body']), re.findall(r'\w+',indexed['content'])
        assert actual in (wanted, ['text']+wanted, wanted+['text']), 'Complete indexed vocabulary changed'
    if live:
        available = client.get_notebook_sources_with_types(receipt['notebookId'])
        assert {s['id'] for s in available} == {s['sourceId'] for s in receipt['sources'].values()}
    result = dict(collection=identity, verifiedAt=native.NOW(), notebookId=receipt['notebookId'],
        counts=plan['counts'], liveReadback=live, completeVocabularyVerified=True,
        verificationLimits='Complete ordered case-sensitive vocabulary; punctuation and layout fidelity not asserted.',
        mediaCreates=0, requestSha256=HASH(canonical(plan)))
    save(work/'validation.json',result)
    return result


def import_collection(identity):
    _, config, _ = configuration(identity)
    assert config['status'] == 'independent-review-passed', 'Complete input review required'
    plan = projection(identity)
    work = WORK / identity
    prepare.WORK = work
    owner = adapter.load_module('generation-ownership')
    owner.ROOT = owner.WORK = work
    with owner.StageLock('source-import'):
        file = work/'source-import.json'
        receipt = read(file) if file.exists() else dict(schema='ai-ba.topic-source-import.v2',packageId=config['runId'],sources={})
        keys = sorted(s['key'] for s in plan['sources'].values())
        plan_hash = HASH(canonical(plan))
        if 'preparedConfigSha256' in receipt:
            assert receipt['preparedConfigSha256'] == plan['configSha256'], 'Refuse changed config before provider mutation'
            assert receipt['preparedSourceKeys'] == keys, 'Refuse changed source set before provider mutation'
            assert receipt['preparedPlanSha256'] == plan_hash, 'Refuse changed resolved plan before provider mutation'
        else:
            assert not receipt['sources'] and not receipt.get('notebookId'), 'Unpinned existing imports require explicit reconciliation'
            receipt.update(preparedConfigSha256=plan['configSha256'],preparedSourceKeys=keys,preparedPlanSha256=plan_hash)
            save(file,receipt)
        assert set(receipt['sources']) <= set(keys), 'Unexpected receipt source retained; stop without mutation'
        target = work/'request-inputs.json'
        if target.exists():
            assert set(receipt['sources']) == set(keys), 'Incomplete receipt cannot supply frozen inputs'
            assert canonical(read(target)) == canonical(projection(identity,receipt)), 'Frozen inputs changed before provider mutation'
        client = adapter.worker.get_client()
        if not receipt.get('notebookId'):
            census = client.list_notebooks()
            matches = [n for n in census if n.title == config['notebookTitle']]
            assert len(matches) <= 1, 'Ambiguous notebook title'
            if matches:
                assert receipt.get('notebookIntentAt') and matches[0].id not in receipt['beforeNotebookIds'], 'Existing notebook lacks this task create intent'
                notebook = matches[0]
            else:
                assert not receipt.get('notebookIntentAt'), 'Uncertain notebook create requires reconciliation'
                receipt.update(notebookIntentAt=native.NOW(),beforeNotebookIds=[n.id for n in census])
                save(file,receipt)
                notebook = native.create_once(client,client.create_notebook,config['notebookTitle'],fenced_rpc=client.RPC_CREATE_NOTEBOOK)
            receipt.update(notebookId=notebook.id,title=config['notebookTitle'],notebookAcknowledgedAt=native.NOW())
            save(file,receipt)
        for source in plan['sources'].values():
            sid = prepare.import_text(client,receipt,source['key'],prepare.literal_presentation(source['body']),source['title'],literal_body=source['body'])
            assert sid, 'Uncertain source import retained; no replay'
            indexed = client.get_source_fulltext(sid)
            assert HASH(indexed['content']) == receipt['sources'][source['key']]['indexedTextSha256']
            save(work/'source-readbacks'/(sid+'.json'),indexed)
            print(json.dumps(dict(collection=identity,source=source['label'],verified=True)),flush=True)
        available = client.get_notebook_sources_with_types(receipt['notebookId'])
        assert set(receipt['sources']) == set(keys)
        assert {s['id'] for s in available} == {s['sourceId'] for s in receipt['sources'].values()}
        receipt.update(availabilityVerifiedAt=native.NOW(),verifiedNotebookSourceIds=[s['id'] for s in available])
        save(file,receipt)
        bound = projection(identity,receipt)
        if target.exists():
            assert canonical(read(target)) == canonical(bound), 'Never replace frozen inputs'
        else:
            save(target,bound)
        save(work/'generation-control.json',dict(schemaVersion=1,desiredState='hold',commission='preparation-only',mediaCreates=0))
    return verify(identity)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collection', choices=['all','RU','CA','PD','WD','IT'], default='all')
    parser.add_argument('--action', choices=['dry-run','prepare','validate'], default='dry-run')
    parser.add_argument('--live',action='store_true',help='Fresh complete readbacks during validation')
    args = parser.parse_args()
    identities = [c['id'] for c in read(CONFIG)['collections']] if args.collection == 'all' else [args.collection]
    for identity in identities:
        if args.action == 'prepare':
            result = import_collection(identity)
        elif args.action == 'validate':
            result = verify(identity,args.live)
        else:
            plan = projection(identity)
            save(WORK/identity/'source-plan.json',plan)
            result = dict(collection=identity,counts=plan['counts'],providerMutations=0,configSha256=plan['configSha256'])
        print(json.dumps(result),flush=True)
