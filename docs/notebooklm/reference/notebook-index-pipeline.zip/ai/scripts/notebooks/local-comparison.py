"""Local N01 version snapshots and read-only comparison server; never publishes.

python3 scripts/notebooks/local-comparison.py add baseline --label 'Published baseline'
python3 scripts/notebooks/local-comparison.py serve --port 8932
Future tests: add test-01 --build /absolute/prepared-build --release /absolute/release.json
  --instructions /absolute/test-instructions.md --label 'Test 01'
A prepared build uses the existing notebook renderer, not a new page design.
"""
import argparse
import importlib.util
import hashlib
import json
import mimetypes
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Lock
from urllib.parse import parse_qs, quote, unquote, urlsplit

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / '.local/n01-comparison'
PREFIXES = ('_astro', 'fonts', 'images', 'type', 'presentations', 'custody')
ID = re.compile(r'[a-z0-9][a-z0-9-]{0,47}\Z')
HISTORY = ROOT / '.local/notebook-deck-next-trial'
HISTORY_ROUTE = '/experiments/notebook-deck-next-trial/report.html'
HISTORY_LOCK = Lock()
HISTORY_SPEC = importlib.util.spec_from_file_location('deck_history', ROOT / 'scripts/notebooks/deck-history.py')
HISTORY_RENDERER = importlib.util.module_from_spec(HISTORY_SPEC)
HISTORY_SPEC.loader.exec_module(HISTORY_RENDERER)


def history_file(path):
    """Refresh the read-only history view; expose only its exact linked assets."""
    if path == HISTORY_ROUTE:
        with HISTORY_LOCK:
            subprocess.run([sys.executable, str(ROOT / 'scripts/notebooks/deck-history.py')],
                           cwd=ROOT, check=True, timeout=30, capture_output=True)
        return HISTORY / 'report.html'
    if path.startswith('/experiments/'):
        target = (ROOT / '.local' / path.removeprefix('/experiments/')).resolve()
        if not target.is_relative_to((ROOT / '.local').resolve()):
            return None
    elif path.startswith('/reference/'):
        target = (ROOT / path.removeprefix('/reference/')).resolve()
        if not target.is_relative_to(ROOT):
            return None
    else:
        return None
    manifest = HISTORY / 'referenced-assets.json'
    if not manifest.is_file():
        return None
    allowed = {Path(p).resolve() for p in json.loads(manifest.read_text())['files']}
    return target if target in allowed and target.is_file() else None


def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def clone(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    # APFS copy-on-write preserves a separate immutable baseline without duplicating blocks.
    if sys.platform == 'darwin':
        subprocess.run(['cp', '-c', str(source), str(target)], check=True)
    else:
        shutil.copy2(source, target)


def snapshot(args):
    if not ID.fullmatch(args.id):
        raise ValueError('Use a lowercase version ID containing letters, numbers or hyphens')
    destination = WORK / 'versions' / args.id
    if destination.exists():
        raise ValueError('Version already exists; use a new ID to preserve its baseline')
    if args.id != 'baseline' and not args.instructions:
        raise ValueError('Test versions require --instructions to preserve the tested input')
    if args.instructions and Path(args.instructions).suffix.lower() not in ('.md', '.txt', '.json'):
        raise ValueError('Instructions must be Markdown, text or JSON')
    build = Path(args.build).resolve()
    release_path = Path(args.release).resolve()
    release = json.loads(release_path.read_text())
    page = build / 'n01/index.html'
    page_hash = sha(page)
    selected = {k: v for k, v in release['subjects'].items() if k == 'N01' or k.startswith('N01.')}
    artefacts = [item for subject in selected.values() for kind in ('decks', 'multimedia') for item in subject[kind]]
    receipt = ROOT / '.local/site/ai-ba-publication.json'
    published = None
    if args.id == 'baseline':
        proof = json.loads(receipt.read_text())
        entry = next(x for x in proof['files'] if x['key'] == 'n01/index.html')
        if entry['sha256'] != page_hash:
            raise ValueError('Baseline build differs from retained published N01 receipt')
        published = {'sourceCommit': proof['sourceCommit'], 'verifiedAt': proof['verifiedAt'], 'pageSha256': page_hash}
    # Resolve and validate custody originals before creating anything.
    originals = []
    for item in artefacts:
        original = item['original']
        relative = original['path'].lstrip('/')
        if not relative.startswith('custody/') or '..' in Path(relative).parts:
            raise ValueError('Unsafe custody path')
        source = build / relative
        if not source.is_file():
            source = Path(args.originals).resolve() / (item['key'] + Path(relative).suffix)
        if sha(source) != original['sha256']:
            raise ValueError('Original hash mismatch: ' + relative)
        originals.append((source, relative))
    destination.mkdir(parents=True)
    clone(page, destination / 'n01/index.html')
    for directory in PREFIXES[:-1]:
        for source in (build / directory).rglob('*'):
            if source.is_file():
                relative = source.relative_to(build)
                if directory == 'presentations' and not relative.parts[1].startswith('ai-ba-n01'):
                    continue
                clone(source, destination / relative)
    for source, relative in originals:
        clone(source, destination / relative)
    release_copy = {**release, 'subjects': selected, 'available': len(artefacts)}
    (destination / 'release.json').write_text(json.dumps(release_copy, indent=2))
    instructions = None
    if args.instructions:
        source = Path(args.instructions).resolve()
        if source.suffix.lower() not in ('.md', '.txt', '.json'):
            raise ValueError('Instructions must be Markdown, text or JSON')
        instructions = 'instructions' + source.suffix.lower()
        clone(source, destination / instructions)
    files = {str(p.relative_to(destination)): sha(p) for p in destination.rglob('*') if p.is_file()}
    metadata = {'id': args.id, 'label': args.label, 'createdAt': datetime.now(timezone.utc).isoformat(),
                'sourceBuild': str(build), 'pageSha256': page_hash, 'publishedBaseline': published,
                'inputSourceCommit': release.get('sourceCommit'), 'artefacts': len(artefacts),
                'instructions': instructions, 'instructionsSha256': files.get(instructions),
                'note': args.note or 'Instructions and source layers remain inspectable in the original reading dialogs.',
                'files': files}
    (destination / 'version.json').write_text(json.dumps(metadata, indent=2))
    print(json.dumps({'version': args.id, 'artefacts': len(artefacts), 'files': len(files), 'pageSha256': page_hash}))


def versions():
    return [json.loads(p.read_text()) for p in sorted((WORK / 'versions').glob('*/version.json'))]


def rewrite(text, version):
    prefix = '/v/' + version
    for part in PREFIXES:
        text = text.replace('/' + part + '/', prefix + '/' + part + '/')
        # Shared deck validation uses anchored escaped URL patterns; retain its checks.
        text = text.replace(r'^\/' + part + r'\/', '^' + prefix.replace('/', r'\/') + r'\/' + part + r'\/')
    # Keep the retained page itself intact on disk; only local route prefixes change in transit.
    text = text.replace('href="/n01/', 'href="' + prefix + '/n01/')
    text = text.replace('href="/"', 'href="/n01/"')
    return text


def byte_range(header, size):
    if header is None:
        return 0, size - 1, False
    match = re.fullmatch(r'bytes=(\d*)-(\d*)', header)
    if not match or not any(match.groups()) or size == 0:
        raise ValueError('Unsupported range')
    first, last = match.groups()
    start = int(first) if first else max(0, size - int(last))
    end = min(size - 1, int(last)) if first and last else size - 1
    if start > end or start >= size:
        raise ValueError('Unsatisfiable range')
    return start, end, True


class Handler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.respond(False)

    def do_GET(self):
        self.respond(True)

    def respond(self, body):
        path = unquote(urlsplit(self.path).path)
        if path in ('/', '/n01', '/n01/'):
            payload = (ROOT / 'scripts/notebooks/local-comparison.html').read_bytes()
            return self.send_bytes(payload, 'text/html; charset=utf-8', body)
        if path == '/versions.json':
            records = [{k: v for k, v in item.items() if k not in ('files', 'sourceBuild')} for item in versions()]
            return self.send_bytes(json.dumps(records).encode(), 'application/json', body)
        if path.startswith(('/experiments/', '/reference/')):
            try:
                target = history_file(path)
            except (OSError, ValueError, subprocess.SubprocessError):
                return self.send_error(503, 'Deck history could not be refreshed')
            if target is None:
                return self.send_error(404)
            raw = parse_qs(urlsplit(self.path).query).get('raw') == ['1']
            if target.suffix.lower() == '.md' and not raw:
                allowed = {Path(p).resolve() for p in json.loads((HISTORY / 'referenced-assets.json').read_text())['files']}
                payload = HISTORY_RENDERER.markdown_document(target, path, allowed).encode()
                return self.send_bytes(payload, 'text/html; charset=utf-8', body)
            return self.send_file(target, body, attachment=raw and target.suffix.lower() == '.md')
        parts = path.split('/')
        if len(parts) < 4 or parts[1] != 'v' or not ID.fullmatch(parts[2]):
            return self.send_error(404)
        directory = (WORK / 'versions' / parts[2]).resolve()
        target = (directory / '/'.join(parts[3:])).resolve()
        if not target.is_relative_to(directory) or not (directory / 'version.json').exists():
            return self.send_error(404)
        if target.is_dir():
            target /= 'index.html'
        if not target.is_file():
            return self.send_error(404)
        content_type = mimetypes.guess_type(target.name)[0] or 'application/octet-stream'
        if target.suffix in ('.html', '.css', '.js'):
            return self.send_bytes(rewrite(target.read_text(), parts[2]).encode(), content_type + '; charset=utf-8', body)
        return self.send_file(target, body)

    def send_file(self, target, body, attachment=False):
        content_type = mimetypes.guess_type(target.name)[0] or 'application/octet-stream'
        size = target.stat().st_size
        try:
            start, end, partial = byte_range(self.headers.get('Range'), size)
        except ValueError:
            self.send_response(416); self.send_header('Content-Range', f'bytes */{size}'); self.end_headers(); return
        self.send_response(206 if partial else 200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(end - start + 1))
        self.send_header('Accept-Ranges', 'bytes')
        if attachment:
            self.send_header('Content-Disposition', "attachment; filename*=UTF-8''" + quote(target.name, safe=''))
        self.send_header('Cache-Control', 'no-cache')
        if partial:
            self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
        self.end_headers()
        if body:
            try:
                with target.open('rb') as file:
                    file.seek(start); remaining = end - start + 1
                    while remaining > 0:
                        chunk = file.read(min(262144, remaining))
                        if not chunk: break
                        self.wfile.write(chunk); remaining -= len(chunk)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def send_bytes(self, payload, content_type, body):
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        if body:
            self.wfile.write(payload)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest='command', required=True)
    add = commands.add_parser('add')
    add.add_argument('id'); add.add_argument('--label', required=True)
    add.add_argument('--build', default=str(ROOT / 'site/dist-notebooks'))
    add.add_argument('--release', default=str(ROOT / 'docs/generation/releases/notebook-release.json'))
    add.add_argument('--originals', default=str(ROOT / '.local/artefact-generation/originals'))
    add.add_argument('--instructions'); add.add_argument('--note')
    serve = commands.add_parser('serve'); serve.add_argument('--port', type=int, default=8932)
    args = parser.parse_args()
    if args.command == 'add':
        snapshot(args)
    else:
        if not versions(): parser.error('Add a baseline snapshot first')
        server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
        print(f'Local N01 comparison: http://127.0.0.1:{args.port}/n01/', flush=True)
        server.serve_forever()


if __name__ == '__main__':
    main()
