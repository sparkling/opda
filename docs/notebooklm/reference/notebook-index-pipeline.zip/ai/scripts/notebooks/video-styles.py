"""Finite style matrix over frozen inputs; reuse the existing import/queue/delivery."""
import copy
import json
from pathlib import Path
import prepare as inputs

topics = inputs.module(Path(__file__).with_name('topic-inputs.py'))
CONFIG = inputs.ROOT/'config/authoring/experiments/N01-video-styles-v1.json'


def definition(r):
    config = r.read(CONFIG)
    frozen = {}
    for name, ref in config['baseline'].items():
        body = (r.ROOT/ref['path']).read_bytes()
        assert r.HASH(body) == ref['sha256'], 'Frozen style baseline changed'
        frozen[name] = json.loads(body)
    rows = [row for row in frozen['requests']['requests']
            if row['subject'] in config['subjects'] and row['format']=='explainer']
    assert len(rows)==config['topics']==9
    from notebooklm_tools.core import constants
    assert len(config['styles'])==len(set(config['styles']))==9
    assert set(config['nativeStyleCodes'])==set(config['styles']) and 'custom' not in config['styles']
    ref = config['mappingEvidence']
    body = (r.ROOT/ref['path']).read_bytes()
    assert r.HASH(body)==ref['sha256'] and json.loads(body)['nativeStyleCodes']==config['nativeStyleCodes']
    # Verified live UI values; scope this thin SDK binding to this worker process.
    constants.VIDEO_STYLES = type(constants.VIDEO_STYLES)(config['nativeStyleCodes'])
    return config, frozen['sourcePlan'], rows


def plan(r):
    config, parent, rows = definition(r)
    result = copy.deepcopy(parent)
    keys = {row['key'] for row in rows}
    result.update(id=config['id'], configSha256=r.HASH(CONFIG.read_bytes()),
                  notebookTitle=config['notebookTitle'])
    result['requests'] = [row for row in result['requests'] if row['key'] in keys]
    result['topics'] = {k:v for k,v in result['topics'].items() if k in {row['topicId'] for row in rows}}
    return result


def projection(r):
    config, _, prior = definition(r)
    receipt = r.read(r.WORK/'source-import.json')
    by_key = receipt['sources']
    runs, snapshots = [], []
    native_args = topics.unified.native_arguments
    for identity in config['subjects']:
        parent = r.read(r.ROOT/'.local/n01-comparison/runs/applied-rules-v1/docs/generation'/(identity+'.json'))
        subject = copy.deepcopy(parent['subjects'][0])
        subject.update(mediaPrompts={}, promptHashes={}, topicSources={})
        jobs = []
        for row in [item for item in prior if item['subject']==identity]:
            original = next(j for j in parent['jobs'] if j['key']==row['key'])
            selected = [{**source, **by_key[source['key']]} for source in row['selectedSources']]
            ids = [source['sourceId'] for source in selected]
            assert all(s['indexedTextSha256']==old['indexedTextSha256'] for s,old in zip(selected,row['selectedSources'])), 'New notebook altered source text'
            for style in config['styles']:
                key = f"video-styles-v1-{row['topicId']}-{style}"
                medium = original['medium']+'-'+style
                prompt = row['consumedCreateArguments']['focus_prompt']
                settings = {**original['settings'], 'visual_style':style}
                subject['mediaPrompts'][medium] = prompt
                subject['promptHashes'][medium] = r.HASH(prompt)
                job = {k:copy.deepcopy(original[k]) for k in r.REQUEST_FIELDS}
                job.update(key=key, medium=medium, settings=settings, version=11, status='planned',
                    topicId=row['topicId'], topicTitle=row['topic']['title'], style=style, take=1,
                    sourceIds=ids, title=f"{row['topicId']} — {row['topic']['title']} — {style.replace('_',' ')}")
                envelope = {**settings, 'notebook_id':receipt['notebookId'], 'title':job['title'],
                            'source_ids':ids, 'focus_prompt':prompt}
                method, arguments = native_args(r,envelope)
                assert method=='create_video_overview' and arguments['format_code']==1
                assert {k:v for k,v in arguments.items() if k not in ('notebook_id','source_ids','visual_style_code')} == {k:v for k,v in row['consumedCreateArguments'].items() if k not in ('notebook_id','source_ids','visual_style_code')}
                job['completeInputSha256'] = r.HASH(json.dumps(arguments,sort_keys=True,separators=(',',':')))
                snapshots.append({**row, 'key':key, 'style':style, 'adapterEnvelope':envelope,
                    'consumedCreateArguments':arguments, 'selectedSources':selected,
                    'completeInputSha256':job['completeInputSha256'], 'baselineKey':row['key']})
                jobs.append(job)
        runs.append({**{k:v for k,v in parent.items() if k not in ('jobs','subjects','inputSha256')},
            'notebookId':receipt['notebookId'], 'comparisonVersion':config['id'], 'inputVersion':11,
            'manifestSha256':r.HASH(CONFIG.read_bytes()), 'requested':len(jobs), 'publish':False,
            'subjects':[subject], 'jobs':jobs,
            'inputSha256':r.HASH(json.dumps([subject],ensure_ascii=False,separators=(',',':')))})
    assert sum(run['requested'] for run in runs)==config['outputs']==81
    return runs, snapshots


def prepare(r, dry_run=False):
    config, _, rows = definition(r)
    if dry_run:
        print(json.dumps(dict(topics=len(rows),styles=len(config['styles']),outputs=config['outputs'],providerMutations=0)))
        return
    owner = r.production.owner
    owner.ROOT = owner.WORK = r.WORK
    with owner.StageLock('supervisor'), owner.StageLock('generation',r.WORK/'worker.lock'), owner.StageLock('source-import'):
        save = r.production.generation_quota().atomic_json
        control = r.WORK/'generation-control.json'
        assert not control.exists() or r.read(control)['desiredState']=='hold'
        save(control,dict(schemaVersion=1,desiredState='hold',publicationState='hold',reconcileSeconds=30,probeBackoffSeconds=60))
        topics.SUBJECTS = r.SUBJECTS
        topics.import_sources(r,plan(r))
        runs, snapshots = projection(r)
        frozen = dict(schema='ai-ba.video-style-requests.v1',manifestSha256=r.HASH(CONFIG.read_bytes()),
                      counts=dict(scopes=2,topics=9,outputs=81),requests=snapshots)
        file = r.WORK/'request-inputs.json'
        if file.exists(): assert r.read(file)==frozen
        else: save(file,frozen)
        r.DIRECTORY.mkdir(parents=True,exist_ok=True)
        for run in runs:
            file = r.DIRECTORY/(run['sectionId']+'.json')
            if file.exists(): assert r.read(file)['inputSha256']==run['inputSha256']
            else: r.native.save(file,run)
    print(json.dumps(dict(topics=9,styles=9,jobs=81,held=True)),flush=True)


def bind(r):
    definition(r)
    topics.bind(r)
    r.adapter.close_deferred_uncertainty = lambda *args,**kwargs: []


def validate(r, runs):
    expected, snapshots = projection(r)
    assert len(runs)==len(expected)==2
    for run, wanted in zip(runs,expected):
        for field in ('sectionId','notebookId','manifestSha256','inputSha256','subjects','requested'):
            assert run[field]==wanted[field],field
        assert len(run['jobs'])==len(wanted['jobs'])
        for job, prior in zip(run['jobs'],wanted['jobs']):
            assert all(job[k]==prior[k] for k in (*r.REQUEST_FIELDS,'key','sourceIds','style','topicId','completeInputSha256'))
    assert r.read(r.WORK/'request-inputs.json')['requests']==snapshots
