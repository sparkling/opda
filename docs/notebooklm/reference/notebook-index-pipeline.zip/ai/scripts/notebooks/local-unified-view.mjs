/** One input projection and hierarchy over the existing shared notebook renderer. */
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {parse,h,renderSync} from '../../site/node_modules/ultrahtml/dist/index.js';
import {querySelector as one,querySelectorAll as all} from '../../site/node_modules/ultrahtml/dist/selector.js';
const read=async p=>JSON.parse(await fs.readFile(p,'utf8'));
const labels={video:'Videos',slide_deck:'Slide decks',audio:'Audio',infographic:'Infographics'};
const formats={explainer:'Explainer',cinematic:'Cinematic',detailed_deck:'Detailed deck',presenter_slides:'Presenter slides',deep_dive:'Deep dive',brief:'Brief',debate:'Debate'};
const hash=value=>createHash('sha256').update(value).digest('hex');
const wholeChapter=topic=>/\.W[VDAI]\d+$/.test(topic.id);
const topicAnchor=topic=>topic.id.toLowerCase().replaceAll('.','-');
function iconAction(node,label,kind='download'){
 const paths={download:'M12 3v12m-5-5 5 5 5-5M5 17v4h14v-4',open:'M14 3h7v7m0-7L10 14M10 3H3v18h18v-7',previous:'m15 5-7 7 7 7',next:'m9 5 7 7-7 7'};
 Object.assign(node.attributes,{class:((node.attributes.class??'')+' media-icon-action').trim(),'aria-label':label,title:label});
 node.children=[h('svg',{viewBox:'0 0 24 24',width:'20',height:'20',fill:'none',stroke:'currentColor','stroke-width':'1.8','stroke-linecap':'round','stroke-linejoin':'round','aria-hidden':'true',focusable:'false'},h('path',{d:paths[kind]}))];
 return node;
}

export async function unifiedInputs(root,variant='unified-v1'){
 if(!['unified-v1','topic-sources-v2','content-v3','content-v4','whole-chapter-v1','minimal-v1','business-v1','tailored-v2','tailored-v3','applied-rules-v1','full-section-v1'].includes(variant))throw Error('Unknown unified input variant');
 const full=variant==='full-section-v1',applied=full||variant==='applied-rules-v1',current=variant==='tailored-v3',tailored=applied||current||variant==='tailored-v2',business=variant==='business-v1',minimal=tailored||business||variant==='minimal-v1',whole=variant==='whole-chapter-v1',reconciled=minimal||variant==='content-v4'||whole,revised=reconciled||variant==='content-v3',focused=revised||variant==='topic-sources-v2';
 const config=await read(path.join(root,'config/authoring/N01-unified-v1.json'));
 const runRoot=path.join(root,'.local/n01-comparison/runs',variant);
 const snapshot=await read(path.join(runRoot,'request-inputs.json'));
 const sourceProof=await read(path.join(runRoot,'source-availability.json'));
 // Input dialogs describe the frozen submitted package, never a newer authoring overlay.
 if(revised){
  const component=(request,role)=>request.promptComponents.find(part=>part.role===role)?.text??'';
  for(const role of ['purposeAndAudience','evidenceContract','language']){
   const values=new Set(snapshot.requests.map(request=>component(request,role)));
   if(values.size!==1)throw Error('Shared frozen component differs: '+role);
   config[role]=values.values().next().value;
  }
  for(const [format] of Object.entries(config.treatments)){
   const values=new Set(snapshot.requests.filter(request=>request.format===format||format==='infographic'&&request.topic.type==='infographic').map(request=>component(request,'treatment')));
   if(values.size!==1)throw Error('Frozen format treatment differs: '+format);
   config.treatments[format]=values.values().next().value;
  }
  for(const subject of config.subjects){
   const rows=snapshot.requests.filter(request=>request.subject===subject.id);
   if(!rows.length)continue;
   const commissions=new Set(rows.map(request=>component(request,'subjectCommission')));
   if(commissions.size!==1)throw Error('Frozen subject commission differs: '+subject.id);
   subject.subjectCommission=minimal?subject.title:commissions.values().next().value;
   const topics=reconciled?[...new Map(rows.map(request=>[request.topic.id,request.topic])).values()]:subject.topics;
   subject.topics=topics.map(topic=>{
    const matching=rows.filter(request=>request.topic.id===topic.id);
    if(!matching.length||new Set(matching.map(request=>JSON.stringify(request.topic))).size!==1)throw Error('Frozen topic differs: '+topic.id);
    const frozen=matching[0].topic;
    if(matching.some(request=>component(request,'topicCommission')!==frozen.commission))throw Error('Frozen topic commission differs: '+topic.id);
    return reconciled?{...frozen,ordinal:wholeChapter(frozen)?1000+Number(frozen.id.split('.').at(-1).slice(2)):Number(frozen.id.split('.').at(-1).slice(1))}:frozen;
   });
  }
 }
 const selectedSubjects=new Set(snapshot.requests.map(r=>r.subject));
 const requests=new Map(snapshot.requests.map(r=>[r.key,r]));
 const sourceBodies={};
 for(const request of snapshot.requests){
  for(const source of request.selectedSources){
   const id=source.sourceId,proof=sourceProof.sources[id];
   if(!proof||proof.title!==source.title||proof.indexedTextSha256!==source.indexedTextSha256)throw Error('Selected source proof differs: '+id);
   if(!sourceBodies[id]){
    const body=await read(path.join(runRoot,'source-readbacks',id+'.json'));
    if(body.title!==proof.title||hash(body.content)!==proof.indexedTextSha256)throw Error('Selected indexed body differs: '+id);
    sourceBodies[id]=body.content;
   }
   sourceProof.sources[id]={...source,...proof};
  }
 }
 const subjects=[],syntheses=[],prompts=[];
 for(const row of config.subjects.filter(row=>selectedSubjects.has(row.id))){
  const treatmentRows=row.topics.flatMap(topic=>config.formats[topic.type].map(format=>({
   ...topic,id:topic.id+'-'+format,format,prompt:[topic.commission,config.treatments[format]].filter(Boolean).join('\n\n')})));
  subjects.push({...row,basePrompt:row.subjectCommission,treatments:treatmentRows});
  if(!focused){
   const authored=await read(path.join(root,row.synthesis.path));
   const synthesis=authored.subjects?.find(s=>s.id===row.id)??authored.synthesis;
   syntheses.push({...synthesis,id:row.id,title:synthesis.title??row.title,baseline:row.baseline});
  }
  for(const treatment of treatmentRows){
   const request=snapshot.requests.find(r=>r.subject===row.id&&r.topic.id===treatment.id.slice(0,-treatment.format.length-1)&&r.format===treatment.format);
   if(!request)throw Error('Missing frozen unified request: '+treatment.id);
   prompts.push({chapter:row.id,treatmentId:treatment.id,prompt:request.consumedCreateArguments.focus_prompt,sha256:createHash('sha256').update(request.consumedCreateArguments.focus_prompt).digest('hex')});
  }
 }
 const shared={...config,title:subjects[0].title,evidenceInstruction:config.evidenceContract};
 const result={config,shared,subjects,syntheses,prompts,sourceProof,sourceBodies,requests,snapshot,runRoot,variant,focused,
  instructions:'# '+(full?'N01 complete section':tailored?'N01 tailored sources and infographic detail — chapters 1–3':business?'N01 business-facing sources — chapters 1–3':minimal?'N01 minimal steering — chapters 1–3':reconciled?'N01 content v4 — chapters 1–3':revised?'N01 content v3':focused?'N01 topic sources v2':'Unified N01')+' content parameters\n\n'+config.purposeAndAudience+'\n\n'+config.evidenceContract+'\n\n'+
   snapshot.requests.map(r=>'## '+r.key+'\n\n'+r.consumedCreateArguments.focus_prompt+'\n\n```json\n'+JSON.stringify(r.consumedCreateArguments,null,2)+'\n```').join('\n\n')};
 // The owner requested the new sets on the latest existing page, not a new index.
 const addition=path.join(root,'.local/n01-comparison/runs/whole-chapter-v1/request-inputs.json');
 if(variant==='content-v4'&&await fs.stat(addition).then(()=>true,()=>false)){
  const extra=await unifiedInputs(root,'whole-chapter-v1');
  for(const subject of result.subjects){
   const added=extra.subjects.find(s=>s.id===subject.id);
   if(!added)throw Error('Whole-chapter subject missing: '+subject.id);
   subject.topics.push(...added.topics);subject.treatments.push(...added.treatments);
  }
  for(const [key,value] of extra.requests){if(result.requests.has(key))throw Error('Duplicate added request');result.requests.set(key,value);}
  Object.assign(result.sourceProof.sources,extra.sourceProof.sources);
  Object.assign(result.sourceBodies,extra.sourceBodies);
  result.prompts.push(...extra.prompts);result.snapshot.requests.push(...extra.snapshot.requests);
  result.snapshot.additionalPackages=[{id:extra.variant,manifestSha256:extra.snapshot.manifestSha256,requestKeys:[...extra.requests.keys()]}];
  result.snapshot.counts={...result.snapshot.counts,topics:new Set(result.snapshot.requests.map(r=>r.topic.id)).size,outputs:result.snapshot.requests.length,
   byType:Object.fromEntries(Object.keys(labels).map(type=>[type,result.snapshot.requests.filter(r=>r.topic.type===type).length]))};
  result.instructions+='\n\n# The complete chapter — additional sets\n\n'+extra.instructions;
 }
 return result;
}

export async function copyUnifiedInputs(input,version){
 await fs.mkdir(path.join(version,'inputs/sources'),{recursive:true});
 for(const [id,body] of Object.entries(input.sourceBodies))await fs.writeFile(path.join(version,'inputs/sources',id+'.txt'),body);
 await fs.writeFile(path.join(version,'inputs/request-inputs.json'),JSON.stringify(input.snapshot,null,2));
}

export function focusedInputViews(input,chapter,jobs){
 if(['applied-rules-v1','full-section-v1'].includes(input.variant)){
  const requests=[...input.requests.values()].filter(r=>r.subject===chapter.id);
  return [...appliedInputViews(input,requests),...chapter.topics.flatMap(topic=>
   appliedInputViews(input,requests.filter(r=>r.topic.id===topic.id),'topic-'+topicAnchor(topic)+'-'))];
 }
 const current=input.variant==='tailored-v3',tailored=current||input.variant==='tailored-v2',business=input.variant==='business-v1',minimal=tailored||business||input.variant==='minimal-v1';
 const requests=[...input.requests.values()].filter(r=>r.subject===chapter.id);
 const byTopic=chapter.topics.map(topic=>({topic,requests:requests.filter(r=>r.topic.id===topic.id)}));
 const sourceText=(id)=>{const source=input.sourceProof.sources[id];return `### ${source.title}\n\nRole: ${source.role}; native source ID: ${id}; indexed SHA256: ${source.indexedTextSha256}.\n\n${input.sourceBodies[id]}`;};
 const sources=byTopic.map(({topic,requests})=>`## ${topic.id} — ${topic.title}\n\n`+requests[0].consumedCreateArguments.source_ids.map(sourceText).join('\n\n')).join('\n\n');
 const syntheses=byTopic.map(({topic,requests})=>{
  const selected=requests[0].consumedCreateArguments.source_ids.filter(id=>input.sourceProof.sources[id].role==='attributed-synthesis');
  return `## ${topic.id} — ${topic.title}\n\n`+(selected.length?selected.map(sourceText).join('\n\n'):'No synthesis source selected for this topic.');
 }).join('\n\n');
 return [
  {id:'shared',label:minimal?'Shared audience':'Shared purpose & evidence',text:`# Shared instructions\n\n${input.shared.purposeAndAudience}\n\n${input.shared.evidenceInstruction}\n\n${input.shared.language}`},
  {id:'formats',label:'Format & assembly',text:'# Actual assembly\n\n'+(current?'Instruction successor to tailored-v2: the same topic commissions, audience, selected source bodies and native settings, with the independent-reading deck component removed before request freezing. All 59 topics and the three-level infographic matrix are retained. Historical requests remain unchanged.':tailored?'A holistic revision of selected readings and source selections. Existing concise topic commissions are retained, with a shared audience sentence and one independent-reading sentence for decks. No extra synthesis sources are selected. Every infographic topic receives two takes at each native concise, standard and detailed level, using the same prompt and sources across all six. Other native settings are retained. This compares the complete input package with previous runs; it does not isolate a single cause or choose a winning detail level.':minimal?'Only the topic subject and shared audience are sent as written instructions. No chapter commission, evidence rule, medium treatment, creative directions or language prose are appended. '+(business?'The minimal prompts and native settings are unchanged. The selected evidence and interpretation bodies have been revised for business readers; their current texts and source lineage appear in the input controls.':'Native settings, selected source bodies and topic interpretations match the earlier run.'): ['content-v3','content-v4'].includes(input.variant)?'A shared purpose, shorter chapter commission, topic and concise evidence rule form the prompt. Decks add that they are for independent reading; other formats add no treatment prose. Layout, story, examples, order and pacing remain NotebookLM’s choices. Native formats and settings are unchanged. Each request consumes its own focused-source selection. Local custody metadata is not sent as a production instruction.':'The purpose, chapter commission, topic, format treatment, evidence contract, language and native settings remain as commissioned in v1. Each request below consumes its own explicit focused-source selection. Local metadata is not a privileged provider role.')},
  {id:'subject',label:chapter.id==='N01'?'Section brief':'Chapter brief',text:`# ${chapter.id} — ${chapter.title}\n\n${chapter.basePrompt}${minimal?'\n\nChapter identity for browsing; no separate chapter instruction is appended to each prompt.':''}`},
  {id:'treatments',label:'Topics & format treatments',text:chapter.treatments.map(t=>`## ${t.id}\n\n${t.prompt}`).join('\n\n')},
  {id:'sources',label:'Evidence & source selection',text:'# Actual topic source selections\n\nEach topic below selects only the listed complete focused bodies. The chapter-wide union is not submitted to each request.'+(['content-v3','content-v4'].includes(input.variant)?' Evidence bodies retain substantive claims and qualifications while research bookkeeping and production directions stay in custody metadata.':'')+'\n\n'+sources},
  {id:'actual-inputs',label:'Selected source bodies & parameters',text:'# Actual topic source data'},
  ...((business||tailored)?[{id:'source-revision',label:'Source revision & provenance',text:(current?'# Retained tailored source package\n\nThe source bodies and full lineage are unchanged from tailored-v2. This successor changes only the named deck instruction component; it does not repeat the earlier source experiment.\n\n':tailored?'# Tailored source package and retained lineage\n\nRevised readings and deliberately retained readings form this package. Full source lineage is retained below. The prompt and source changes are assessed together with the three-level infographic comparison.\n\n':'# Business-facing reading revisions\n\nThese are the current sources submitted for this run. Prior source bodies and lineage remain in custody; they are not additional selected sources. The experiment retains the minimal prompts and native settings.\n\n')+[...new Set(requests.flatMap(r=>r.consumedCreateArguments.source_ids))].map(id=>{const source=input.sourceProof.sources[id],p=source.provenance;return `## ${source.title}\n\n${p.rationale}\n\nCurrent body SHA256: ${source.bodySha256}. Prior body SHA256: ${p.previousSource.bodySha256}.\n\n\`\`\`json\n${JSON.stringify(tailored?p:{authoring:p.authoring,evidence:p.evidence,previousSource:{title:p.previousSource.title,bodySha256:p.previousSource.bodySha256},transformation:p.transformation},null,2)}\n\`\`\``;}).join('\n\n')}]:[]),
  {id:'synthesis-0',label:'Selected topic interpretations',text:'# Actual topic interpretations\n\nThese attributed interpretations are optional selected content, not independent corroboration or additional production instructions.\n\n'+syntheses},
  {id:'submitted',label:'Exact prompts & run status',text:'# Exact prompts and request records\n\n'+requests.map(request=>{
   const job=jobs.find(j=>j.key===request.key);
   return `## ${request.key}\n\nStatus: ${job?.status??'planned'}; artefact: ${job?.id??'not submitted'}.\n\nComplete input SHA256: ${request.completeInputSha256}.\n\n`+(request.promptComponents??[]).map(c=>`### ${c.role}\n\n${c.text}`).join('\n\n')+`\n\n\`\`\`json\n${JSON.stringify({components:request.promptComponents,method:request.consumedCreateMethod,arguments:request.consumedCreateArguments},null,2)}\n\`\`\``;
  }).join('\n\n')}
 ];
}

function appliedInputViews(input,requests,prefix=''){
 const ids=[...new Set(requests.flatMap(r=>r.consumedCreateArguments.source_ids))];
 const byTopic=[...new Map(requests.map(r=>[r.topic.id,r])).values()];
 const references=provenance=>{
  const records=[];
  if(provenance.locator)records.push({locator:provenance.locator,sha256:provenance.originalSha256,selection:provenance.selection});
  records.push(...(provenance.evidence??[]));
  for(const source of [provenance.previousSource,...(provenance.derivedFrom??[])].filter(Boolean))records.push(...references(source.provenance??{}));
  if(provenance.reviewedVariant)records.push({path:provenance.reviewedVariant.path,sha256:provenance.reviewedVariant.sha256,sourceKey:provenance.reviewedVariant.sourceKey,bodySha256:provenance.reviewedVariant.bodySha256});
  return [...new Map(records.map(record=>[JSON.stringify(record),record])).values()];
 };
 const selections=byTopic.map(r=>`## ${r.topic.title}\n\nSelected complete writings:\n\n`+r.consumedCreateArguments.source_ids.map(id=>'- '+input.sourceProof.sources[id].title).join('\n')).join('\n\n');
 const extra=ids.some(id=>input.sourceProof.sources[id].role==='attributed-synthesis')?
  'Selected synthesis is included in the complete writings below. No additional hidden direction is appended.':
  'No separate synthesis, framing document, editorial or producer notes are supplied. The selected writings below and the exact Prompt are the complete written inputs.';
 return [
  {id:prefix+'prompt',label:'Prompt',text:'# Prompt\n\nThese are the exact assembled prompts, including every submitted instruction layer. Native settings are metadata, not additional prose.\n\n'+requests.map(r=>{
   const {focus_prompt,source_ids,notebook_id,...settings}=r.consumedCreateArguments;
   return `## ${r.topic.title} — ${r.format.replaceAll('_',' ')}${r.infographicDetail?' — '+r.infographicDetail:''}${r.take?' — take '+r.take:''}\n\n${focus_prompt}\n\nNative settings:\n\n\`\`\`json\n${JSON.stringify(settings,null,2)}\n\`\`\``;
  }).join('\n\n')},
  {id:prefix+'material',label:'Source material / direction',text:'# Source material / direction\n\n'+extra+'\n\n'+selections+'\n\n'+ids.map(id=>`## ${input.sourceProof.sources[id].title}\n\n${input.sourceBodies[id]}`).join('\n\n')},
  {id:prefix+'data',label:'Data sources',text:'# Data sources\n\nNative source IDs below select the complete writings supplied to NotebookLM. Original research references explain their provenance; those references are not separately uploaded or automatically opened by NotebookLM.\n\n'+selections+'\n\n'+ids.map(id=>{
   const source=input.sourceProof.sources[id];
   return `## ${source.title}\n\nNative ID: ${id}\n\nBody SHA256: ${source.bodySha256}\n\nIndexed readback SHA256: ${source.indexedTextSha256}\n\nReadback: ${source.readbackPath}\n\nOriginal research and retained variant provenance:\n\n\`\`\`json\n${JSON.stringify(references(source.provenance??{}),null,2)}\n\`\`\``;
  }).join('\n\n')},
 ];
}

function infographicDetailCarousel(card,jobs,topic,detail){
 // Reproject the approved carousel shell; its shared script still owns navigation.
 const carousel=parse(renderSync(card)).children[0],ids=new Set(jobs.map(job=>'media-'+job.id));
 for(const figure of all(carousel,'[data-carousel-item]'))if(!ids.has(figure.attributes.id))figure.parent.children=figure.parent.children.filter(child=>child!==figure);
 const figures=all(carousel,'[data-carousel-item]'),id=(card.attributes.id??topicAnchor(topic)+'-carousel')+(detail==='concise'?'':'-'+detail),label=detail[0].toUpperCase()+detail.slice(1);
 carousel.attributes.id=id;
 for(const node of [carousel,...all(carousel,'[aria-label]')])if(node.attributes['aria-label'])node.attributes['aria-label']+=' — '+label;
 figures.forEach((figure,i)=>{if(i)figure.attributes.hidden='';else delete figure.attributes.hidden;});
 for(const link of all(carousel,'[data-gallery]'))link.attributes['data-gallery']=id;
 for(const counter of all(carousel,'[data-carousel-counter]'))counter.children=[h('span',{},`1 of ${figures.length}`)];
 const open=one(carousel,'[data-carousel-open]');
 if(open){open.attributes.href=one(figures[0],'[data-lightbox]').attributes.href;open.children=[h('span',{},`Open gallery · ${figures.length} previews ↗`)];}
 return carousel;
}

export function unifiedHierarchy(html,data){
 const tree=parse(html),sections=all(tree,'.cognitive-level');
 if(sections.length!==data.subjects.length||!sections.length)throw Error('Unified hierarchy scope coverage differs');
 const baseUrl=`http://127.0.0.1:8932/v/${data.variant??'unified-v1'}`;
 const sourceLinks=ids=>h('ul',{},...ids.map(id=>h('li',{},h('a',{href:`${baseUrl}/inputs/sources/${id}.txt`,target:'_blank',rel:'noopener noreferrer'},data.sourceProof[id].title),` — ${id}; indexed SHA256 ${data.sourceProof[id].indexedTextSha256}`)));
 const renderedById=new Map(all(tree,'[id]').map(node=>[node.attributes.id,node]));
 const cards=new Map();
 for(const item of [...data.catalogue.decks,...data.catalogue.multimedia]){
  const node=renderedById.get(`media-${item.id}`)??renderedById.get(item.slug);
  if(!node)throw Error('Rendered card missing: '+item.id);
  let card=node;
  if(item.type==='infographic'){
   while(card&&!('data-infographic-carousel' in (card.attributes??{})))card=card.parent;
   if(!card)throw Error('Shared infographic carousel missing');
  }else{
   const heading=one(card,item.type==='slide_deck'?'.card-body h4':'h5');
   if(heading)heading.children=[h('span',{},formats[item.format]??item.format)];
  }
  const download=iconAction(h('a',{href:item.original.path,download:path.posix.basename(item.original.path),'data-original-download':item.type}),item.type==='slide_deck'?'Download PDF':`Download ${item.type}`);
  const links=one(node,item.type==='infographic'?'figcaption':item.type==='slide_deck'?'.deck-links':'.artefact-meta');
  // Shared scripts own navigation; this preview only places and styles actions.
  for(const link of all(node,'a'))if((link.attributes.href??'').startsWith('https://notebooklm.google.com/')||
    link.parent===links&&(item.type==='slide_deck'||item.type==='audio'))link.parent.children=link.parent.children.filter(child=>child!==link);
  const actions=h('span',{class:'media-card-actions'});
  for(const link of links?all(links,'a'):[]){links.children=links.children.filter(child=>child!==link);actions.children.push(iconAction(link,'Open video','open'));}
  actions.children.push(download);
  if(item.infographicDetail){
   const label='Detail: '+item.infographicDetail[0].toUpperCase()+item.infographicDetail.slice(1)+' — Take '+item.take;
   const heading=one(node,'.infographic-heading');
   if(heading)heading.children=[h('span',{},label)];else if(links)links.children.unshift(h('strong',{},label));
  }
  const heading=['slide_deck','audio'].includes(item.type)?one(node,item.type==='slide_deck'?'.card-body h4':'h5'):null;
  if(heading){
   const parent=heading.parent;
   parent.children=parent.children.map(child=>child===heading?h('div',{class:'media-card-heading'},heading,actions):child);
   if(item.type==='slide_deck'&&links)links.parent.children=links.parent.children.filter(child=>child!==links);
  }else if(links)links.children.push(actions);else node.children.push(h('p',{class:'deck-links'},actions));
  if(item.type==='slide_deck'){
   const image=one(node,'[data-deck-player] img'),counter=one(node,'.preview-controls [data-preview-counter]');
   if(image&&counter){
    image.attributes.id='download-slide-'+item.id;
    const downloadSlide=iconAction(h('a',{href:item.slides[0].path,download:path.posix.basename(item.slides[0].path),'data-download-image-id':image.attributes.id}),'Download current slide (WebP)');
    counter.parent.children=counter.parent.children.map(child=>child===counter?h('span',{class:'media-slide-position'},counter,downloadSlide):child);
   }
  }
  cards.set(item.id,card);
 }
 for(const [level,section] of sections.entries()){
  const subject=data.subjects[level],header=one(section,'.level-heading');
  if(data.inspectionModel==='three-views'){
   const scopes=[['',subject.selectedSourceIds],...(subject.topicInputs??[]).map(t=>['topic-'+t.topicId.toLowerCase().replaceAll('.','-')+'-',t.sourceIds])];
   for(const [scope,ids] of scopes){
    const prefix=`input-${subject.id.replace('.','-')}-${scope}`;
    for(const kind of ['prompt','material','data']){
     const view=one(tree,`#${prefix+kind} .editorial-prose`);
     if(!view)throw Error('Missing shared input reader: '+prefix+kind);
     view.children.push(h('h2',{},'Exact raw inputs'),kind==='prompt'?
      h('p',{},h('a',{href:`${baseUrl}/inputs/request-inputs.json`,target:'_blank',rel:'noopener noreferrer'},'Full frozen request records (JSON)')):sourceLinks(ids));
     if(kind==='data')view.children.push(h('p',{},h('a',{href:`${baseUrl}/inputs/request-inputs.json`,target:'_blank',rel:'noopener noreferrer'},'Full request and provenance archive (JSON)')));
    }
   }
  }
  // The shared research reader deliberately labels non-HTTPS repository links.
  // This local consumer owns these verified same-server downloads explicitly.
  const sourceView=one(tree,`#input-${subject.id.replace('.','-')}-actual-inputs .editorial-prose`);
  if(sourceView)sourceView.children=[h('h1',{},'Actual selected source data'),
   h('p',{},'Each source ID selects its entire indexed body. These complete source texts match the verified indexed hashes.'),
   ...(subject.topicInputs?subject.topicInputs.flatMap(topic=>[h('h2',{},topic.topicId),sourceLinks(topic.sourceIds)]):[sourceLinks(subject.selectedSourceIds)]),
   h('p',{},h('a',{href:`${baseUrl}/inputs/request-inputs.json`,target:'_blank',rel:'noopener noreferrer'},data.archiveRequested>data.requested?`Frozen source-run archive (${data.archiveRequested} parameter packages; this page shows ${data.requested})`:`All ${data.requested??198} resolved parameter packages`))];
  const scripts=all(section,'script');
  // Keep the original chapter/header markup: the shared shell owns collapse controls.
  section.attributes.class+=' unified-subject';
  const mediaAttributes=one(section,'.media-conditions')?.attributes??{class:'media-conditions'};
  const children=[header];
  for(const [type,label] of Object.entries(labels)){
   const jobs=subject.jobs.filter(j=>j.type===type),topics=subject.topics.filter(t=>t.type===type).sort((a,b)=>Number(wholeChapter(b))-Number(wholeChapter(a)));
   const kind=h('details',{class:'artefact-type unified-type',id:`system-${level}-${type}`,name:'unified-types-'+subject.id,'data-artefact-type':''},h('summary',{},h('h3',{class:'artefact-type-title'},label)));
   const body=h('div',{class:'artefact-type-body'});kind.children.push(body);
   for(const topic of topics){
    const requested=jobs.filter(j=>j.topicId===topic.id);
    const group=h('details',{class:'artefact-type unified-topic','data-artefact-type':'',id:topicAnchor(topic)},
     h('summary',{},h('span',{class:'topic-id'},topic.id),h('h4',{},(wholeChapter(topic)?'The complete chapter — ':'')+topic.title)),
     h('p',{class:'topic-purpose'},topic.commission));
    const topicInput=subject.topicInputs?.find(row=>row.topicId===topic.id);
    if(topicInput&&data.inspectionModel==='three-views'){
     const actions=h('div',{class:'authoring-actions'});
     for(const kind of ['prompt','material','data']){
      const id=`input-${subject.id.replace('.','-')}-topic-${topicAnchor(topic)}-${kind}`;
      const button=one(header,`[data-editorial-open="${id}"]`);
      if(!button||!one(tree,`#${id}`))throw Error('Missing shared topic reading view: '+id);
      button.parent.children=button.parent.children.filter(child=>child!==button);actions.children.push(button);
     }
     group.children.push(actions);
    }else if(topicInput){
     const id='input-topic-'+topic.id.toLowerCase().replaceAll('.','-');
     group.children.push(h('button',{...one(header,'button[data-editorial-open]')?.attributes,class:'authoring-action',type:'button','data-editorial-open':id,'data-editorial-title':topic.id+' — Selected sources & parameters','aria-haspopup':'dialog','aria-controls':'editorial-overlay'},'Selected sources & parameters'));
     one(tree,'body').children.push(h('template',{id},h('div',{...sourceView?.attributes,class:'editorial-prose'},h('h1',{},topic.id+' — '+topic.title),sourceLinks(topicInput.sourceIds),...topicInput.requests.flatMap(request=>[
      h('h2',{},request.key),h('p',{},'Complete input SHA256: '+request.completeInputSha256),h('pre',{},h('code',{},JSON.stringify({components:request.promptComponents,method:request.consumedCreateMethod,arguments:request.consumedCreateArguments},null,2)))]))));
    }
    const details=type==='infographic'&&requested.some(j=>j.infographicDetail)?['concise','standard','detailed']:[null];
    for(const detail of details){
     const entries=detail?requested.filter(j=>j.infographicDetail===detail):requested,available=entries.filter(j=>cards.has(j.id));
     const target=detail?h('details',{class:'artefact-type unified-detail','data-artefact-type':'',id:topicAnchor(topic)+'-'+detail},
      h('summary',{},h('h5',{},detail[0].toUpperCase()+detail.slice(1)))):group;
     const delivered=h('div',type==='slide_deck'?{class:'cognitive-decks'}:type==='infographic'?{}:{...mediaAttributes});
     for(const card of new Set(available.map(j=>cards.get(j.id))))delivered.children.push(detail?infographicDetailCarousel(card,available,topic,detail):card);
     if(available.length)target.children.push(delivered);
     for(const job of entries.filter(j=>!cards.has(j.id)))target.children.push(h('p',{class:'unified-pending'},
      `${type==='infographic'?(job.infographicDetail?'Detail: '+job.infographicDetail[0].toUpperCase()+job.infographicDetail.slice(1)+' — ':'')+'Take '+job.take:formats[job.format]} — ${job.status==='completed'?'awaiting local delivery':job.status==='planned'?'pending':job.status.replaceAll('-',' ')}`));
     if(detail)group.children.push(target);
    }
    body.children.push(group);
   }
   children.push(kind);
  }
  section.children=[...children,...scripts];
 }
 const pdfLink=one(tree,'#deck-player-pdf');
 if(pdfLink){pdfLink.attributes.download='';delete pdfLink.attributes.target;iconAction(pdfLink,'Download PDF')}
 const pptxLink=one(tree,'#deck-player-pptx');if(pptxLink)iconAction(pptxLink,'Download PowerPoint');
 for(const [selector,imageId,label] of [['.deck-player-files','deck-player-image','Download current slide (WebP)'],['.lightbox-header','lightbox-image','Download infographic']]){
  const container=one(tree,selector);
  if(container)container.children.push(iconAction(h('a',{hidden:'',download:'','data-download-image-id':imageId}),label));
 }
 // Retain the shared initializer's required anchor without exposing a duplicate action.
 for(const link of all(tree,'[data-carousel-open]')){
  link.attributes.hidden='';
  if(link.parent.attributes?.class?.split(' ').includes('carousel-footer'))link.parent.attributes.hidden='';
 }
 for(const [selector,kind] of [['.preview-controls [data-preview-previous]','previous'],['.preview-controls [data-preview-next]','next'],['.carousel-controls [data-carousel-previous]','previous'],['.carousel-controls [data-carousel-next]','next']])
  for(const button of all(tree,selector))iconAction(button,button.attributes['aria-label'],kind);
 const downloads=parse(`<script>(()=>{
 const images=new Map();
 const update=image=>{const src=image.getAttribute('src')||'';for(const link of images.get(image)||[]){const valid=src.startsWith('/')&&!src.startsWith('//');link.hidden=!valid;if(valid){link.href=src;link.download=src.split('/').pop()}}};
 const observer=new MutationObserver(records=>{for(const image of new Set(records.map(record=>record.target)))update(image)});
 const connect=()=>{for(const image of images.keys()){observer.observe(image,{attributes:true,attributeFilter:['src']});update(image)}};
 for(const link of document.querySelectorAll('[data-download-image-id]')){const image=document.getElementById(link.dataset.downloadImageId);if(image){images.set(image,[...(images.get(image)||[]),link])}}
 connect();addEventListener('pagehide',()=>observer.disconnect());addEventListener('pageshow',connect);
 })()</script>`).children[0];
 one(tree,'body').children.push(downloads);
 const nav=one(tree,'.nav-overview')?.parent;
 if(nav)nav.children=[h('a',{class:'nav-overview',href:'#main'},'The case for an AI-enabled H&M'),...data.subjects.map((s,i)=>h('details',{},h('summary',{},s.id+' · '+s.title),h('a',{href:`#system-${i}`},'Overview and inputs'),...Object.entries(labels).map(([type,label])=>h('a',{class:'nav-format',href:`#system-${i}-${type}`},label))))];
 const style=h('style',{});
 style.children=parse(`<style>
 .unified-topic{margin-top:24px;padding-top:0}.unified-topic>summary h4{font-size:18px;margin:0}.unified-topic .topic-id{font-size:13px;color:var(--muted);flex:none}.topic-purpose{line-height:1.65}.unified-pending{color:var(--muted)}
 .unified-detail{margin-top:18px;padding-top:0}.unified-detail>summary h5{font-size:16px;margin:0}
 .unified-type>.artefact-type-body,.unified-topic>.unified-detail{margin-left:12px}
 .unified-subject .level-heading .index-branch-toggle{display:none}
 .media-card-actions{display:flex;justify-content:flex-end;gap:8px;margin-left:auto;flex-shrink:0}
 .media-card-heading{display:flex;align-items:center;justify-content:space-between;gap:16px}.media-card-heading h4,.media-card-heading h5{margin:0;min-width:0}
 .media-slide-position{display:inline-flex;align-items:center;justify-content:center;gap:12px}
 .unified-topic .deck-links,.unified-topic .artefact-meta,.unified-topic figcaption{display:flex;align-items:center;flex-wrap:wrap;gap:12px}
 .unified-topic .carousel-footer,.deck-player-files{display:flex;justify-content:flex-end;gap:8px}
 a.media-icon-action,button.media-icon-action{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;padding:0;border:1px solid var(--line,#ccc);border-radius:6px;color:inherit;background:transparent;text-decoration:none;flex-shrink:0}
 .media-icon-action[hidden]{display:none}.media-icon-action:hover{background:var(--surface,#eee)}.media-icon-action:focus-visible{outline:2px solid currentColor;outline-offset:3px}
 .unified-topic [data-carousel-open][hidden],.unified-topic .carousel-footer[hidden]{display:none}
 @media(max-width:700px){.unified-topic>summary{flex-wrap:wrap}.unified-topic>summary h4{white-space:normal}}
 </style>`).children[0].children;
 one(tree,'head').children.push(style);
 const behavior=parse(`<script>(()=>{const reveal=()=>{let t;try{t=document.getElementById(decodeURIComponent(location.hash.slice(1)))}catch{};for(let p=t;p;p=p.parentElement)if(p.tagName==='DETAILS')p.open=true};addEventListener('hashchange',reveal);if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',reveal,{once:true});else reveal()})()</script>`).children[0];
 one(tree,'body').children.push(behavior);
 return renderSync(tree).replace(/Explore each subject through decks, videos, audio and infographics, with and without synthesis guidance\./i,'Explore one complete content package through its topic-led videos, decks, audio and infographics.');
}
