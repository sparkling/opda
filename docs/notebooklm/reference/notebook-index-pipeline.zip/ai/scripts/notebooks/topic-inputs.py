"""Activate reviewed focused-source runs through the existing native owner."""
import copy
import json
from collections import Counter
from pathlib import Path

import prepare as inputs

sources = inputs.module(Path(__file__).with_name('topic-sources.py'))
unified = inputs.module(Path(__file__).with_name('unified-inputs.py'))
SUBJECTS = ['N01', 'N01.01', 'N01.02']
COUNTS = dict(scopes=3, topics=51, outputs=108,
              byType=dict(video=20, slide_deck=12, audio=18, infographic=58))


def reviewed_plan(r=None):
    variant = r.VARIANT if r is not None else 'topic-sources-v2'
    if variant in ('minimal-v1','business-v1','tailored-v2','tailored-v3','applied-rules-v1','full-section-v1'):
        return sources.projection({'full-section-v1':sources.FULL_CONFIG,'applied-rules-v1':sources.APPLIED_CONFIG,'tailored-v3':sources.CURRENT_CONFIG,'tailored-v2':sources.TAILORED_CONFIG,'business-v1':sources.BUSINESS_CONFIG,
                                   'minimal-v1':sources.MINIMAL_CONFIG}[variant])
    revised = variant in ('content-v3','content-v4','whole-chapter-v1')
    plan = sources.projection({'content-v3':sources.CONTENT_CONFIG,'content-v4':sources.RECONCILED_CONFIG,
                              'whole-chapter-v1':sources.WHOLE_CHAPTER_CONFIG}.get(variant,sources.CONFIG))
    if revised:
        folder = '.local/n01-whole-chapter-v1' if variant=='whole-chapter-v1' else '.local/n01-topic-source-'+('v4' if variant=='content-v4' else 'v3')
        frozen = sources.read(sources.ROOT/folder/'source-plan.json')
        assert sources.canonical(plan) == sources.canonical(frozen), 'Reviewed content plan changed'
        if variant == 'content-v4':
            review = sources.read(sources.ROOT/'.local/n01-topic-source-v4/review.json')
            assert sources.HASH(sources.canonical(plan)) == review['sourcePlanSha256']
    else:
        review = sources.read(sources.WORK/'review.json')
        assert sources.HASH(sources.canonical(plan)) == review['sourcePlanCanonicalSha256']
    return plan


def scope(plan):
    subjects = list(dict.fromkeys(r['subject'] for r in plan['requests'])) if plan['id'] in ('content-v3','content-v4','whole-chapter-v1','minimal-v1','business-v1','tailored-v2','tailored-v3','applied-rules-v1','full-section-v1') else SUBJECTS
    coverage = sources.coverage(plan, subjects)
    requests = [r for r in plan['requests'] if r['subject'] in subjects]
    counts = dict(scopes=len(subjects),topics=len(coverage['topicIds']),outputs=len(requests),
        byType=dict(Counter(plan['topics'][r['topicId']]['topic']['type'] for r in requests)))
    return subjects, coverage, counts


def import_sources(r, plan):
    """Reuse idempotent native creation, uncertain-add custody and full readback."""
    inputs.WORK = r.WORK
    save = r.production.generation_quota().atomic_json
    _, coverage, _ = scope(plan)
    receipt_path = r.WORK/'source-import.json'
    receipt = r.read(receipt_path) if receipt_path.exists() else dict(
        schema='ai-ba.topic-source-import.v2', packageId=plan['id'], coverage=coverage, sources={})
    assert receipt['coverage'] == coverage
    client = r.worker.get_client()
    title = plan.get('notebookTitle') or ('AI BA — N01 chapters 1–3 applied content rules v1 — 2026-10-25' if plan['id']=='applied-rules-v1' else
             'AI BA — N01 chapters 1–3 current topic instructions v3 — 2026-10-25' if plan['id']=='tailored-v3' else
             'AI BA — N01 chapters 1–3 tailored sources and infographic detail v2 — 2026-10-25' if plan['id']=='tailored-v2' else
             'AI BA — N01 chapters 1–3 business-facing sources v1 — 2026-10-25' if plan['id']=='business-v1' else
             'AI BA — N01 chapters 1–3 minimal instructions v1 — 2026-10-24' if plan['id']=='minimal-v1' else
             'AI BA — N01 chapters 1–3 complete chapter sets — 2026-10-24' if plan['id']=='whole-chapter-v1' else
             'AI BA — N01 chapters 1–3 reconciled topics content v4 — 2026-10-24' if plan['id']=='content-v4' else
             'AI BA — Section N01 lighter instructions and focused sources v3 — 2026-10-24'
             if plan['id']=='content-v3' else 'AI BA — N0–N2 reviewed topic sources v2 — 2026-10-24')
    if not receipt.get('notebookId'):
        matches = [n for n in client.list_notebooks() if n.title == title]
        assert len(matches) <= 1, 'Ambiguous focused-source notebook'
        if matches:
            notebook = matches[0]
        else:
            assert not receipt.get('notebookIntentAt'), 'Uncertain notebook creation needs reconciliation'
            receipt['notebookIntentAt'] = r.native.NOW(); save(receipt_path,receipt)
            notebook = r.native.create_once(client,client.create_notebook,title,fenced_rpc=client.RPC_CREATE_NOTEBOOK)
        receipt.update(notebookId=notebook.id,title=title); save(receipt_path,receipt)
    for source in plan['sources'].values():
        if source['key'] not in coverage['sourceKeys']: continue
        sid = inputs.import_text(client,receipt,source['key'],inputs.literal_presentation(source['body']),
            source['title'],literal_body=source['body'])
        assert sid, 'Uncertain source import retained; no replay permitted'
        path = r.WORK/'source-readbacks'/(sid+'.json')
        indexed = r.read(path) if path.exists() else client.get_source_fulltext(sid)
        assert r.HASH(indexed['content']) == receipt['sources'][source['key']]['indexedTextSha256']
        save(path,indexed)
        print(json.dumps(dict(sourceImported=source['label'],verifiedSources=len(list((r.WORK/'source-readbacks').glob('*.json'))),
            requestedSources=len(coverage['sourceKeys']),notebookId=receipt['notebookId'])),flush=True)
    available = client.get_notebook_sources_with_types(receipt['notebookId'])
    receipt.update(availabilityVerifiedAt=r.native.NOW(),verifiedNotebookSourceIds=[s['id'] for s in available])
    expected = {s['sourceId']:s for s in receipt['sources'].values()}
    assert set(expected) == set(receipt['verifiedNotebookSourceIds']), 'Separate notebook membership differs'
    assert all(expected[s['id']]['title']==s['title'] for s in available)
    save(receipt_path,receipt)
    save(r.WORK/'source-availability.json',dict(notebookId=receipt['notebookId'],verifiedAt=receipt['availabilityVerifiedAt'],
        coverage=coverage,sources={sid:dict(title=s['title'],indexedTextSha256=s['indexedTextSha256'],
        readbackPath=str((r.WORK/'source-readbacks'/(sid+'.json')).relative_to(r.ROOT))) for sid,s in expected.items()},
        bodyProof=f"All {len(expected)} complete indexed bodies verified against exact literal presentations; observed notebook membership equals the commissioned source set."))


def projection(r, plan=None):
    plan = plan or reviewed_plan(r)
    subjects, _, counts = scope(plan)
    revised = plan['id'] in ('content-v3','content-v4','whole-chapter-v1','minimal-v1','business-v1','tailored-v2','tailored-v3','applied-rules-v1','full-section-v1')
    reconciled = plan['id'] in ('content-v4','whole-chapter-v1','minimal-v1','business-v1','tailored-v2','tailored-v3','applied-rules-v1','full-section-v1')
    receipt = r.read(r.WORK/'source-import.json')
    readbacks = {s['sourceId']:r.read(r.WORK/'source-readbacks'/(s['sourceId']+'.json')) for s in receipt['sources'].values()}
    bound = sources.bind_verified(plan,receipt,readbacks,subjects)
    prior = sources.pinned(sources.read(sources.CONFIG)['frozenRequests'])
    original_requests = {row['key']:row for row in prior['requests']}
    templates = {row['key']:row for row in sources.projection(sources.CONTENT_CONFIG)['requests']} if reconciled else {}
    originals = {j['key']:j for subject in subjects for j in r.read(r.ROOT/'.local/n01-comparison/runs/unified-v1/docs/generation'/(subject+'.json'))['jobs']}
    definitions = {s['key']:s for s in plan['sources'].values()}
    snapshots, runs = [], []
    for subject_id in subjects:
        old = r.read(r.ROOT/'.local/n01-comparison/runs/unified-v1/docs/generation'/(subject_id+'.json'))
        subject = copy.deepcopy(old['subjects'][0])
        subject.update(factualSourceIds=[],communicationSourceIds=[],editorialSourceId=None,editorialSha256=None,
            editorialSync={'status':'topic-specific'},originalSources=[],topicSources={},unifiedInput=plan['configSha256'])
        jobs = []
        for row in [x for x in bound if x['subject']==subject_id]:
            template_key = templates[row['nativeSettingsFrom']]['priorKey'] if reconciled else row['priorKey']
            prior_request = original_requests[template_key]; original = originals[template_key]
            topic = plan['topics'][row['topicId']]['topic']
            assert original['type'] == topic['type'] and original['format'] == row['format']
            selected = [{**source,'key':key, 'role':definitions[key]['role'],
                'bodySha256':definitions[key]['bodySha256'],'provenance':definitions[key]['provenance']}
                for key,source in zip(row['providerTemplate']['sourceKeys'],row['selectedSources'])]
            args = row['consumedCreateArguments']; ids = args['source_ids']
            suffix = row['topicId'].rsplit('.',1)[1]
            ordinal = (1000+int(suffix[2:]) if suffix.startswith('W') else int(suffix[1:])) if reconciled else original['ordinal']
            medium = f"{topic['type']}-{row['format']}-{ordinal}" if reconciled else original['medium']
            subject['mediaPrompts'][medium] = args['focus_prompt']
            subject['promptHashes'][medium] = r.HASH(args['focus_prompt'])
            editorial = [s['sourceId'] for s in selected if s['role']=='attributed-synthesis']
            assert len(editorial)<=1
            subject['topicSources'][row['topicId']] = dict(sourceIds=ids,editorialSourceId=editorial[0] if editorial else None)
            job = {k:copy.deepcopy(original[k]) for k in (*r.REQUEST_FIELDS,'topicId','topicTitle','take','title')}
            job.update(key=row['key'],version=9 if revised else 8,status='planned',editorial=bool(editorial),sourceIds=ids,
                promptSha256=subject['promptHashes'][medium],completeInputSha256=row['completeInputSha256'])
            if reconciled:
                label = 'Take '+str(row['take']) if topic['type']=='infographic' else row['format'].replace('_',' ')
                if row.get('infographicDetail'):
                    label = 'Detail: '+row['infographicDetail'].capitalize()+' — '+label
                    job.update(infographicDetail=row['infographicDetail'])
                    job['settings']['detail_level'] = row['infographicDetail']
                job.update(version=10,topicId=topic['id'],topicTitle=topic['title'],ordinal=ordinal,medium=medium,
                    take=row['take'],title=f"{topic['id']} — {topic['title']} — {label}")
            envelope = {**prior_request['adapterEnvelope'],**job['settings'],'notebook_id':receipt['notebookId'],'title':job['title'],'source_ids':ids,'focus_prompt':args['focus_prompt']}
            method,actual = unified.native_arguments(r,envelope)
            assert 'NotebookLMClient.'+method == row['consumedCreateMethod'] and actual == args
            snapshots.append({**row,'topic':plan['topics'][row['topicId']]['topic'],'adapterEnvelope':envelope,'selectedSources':selected})
            jobs.append(job)
        runs.append(dict(schemaVersion=1,edition=old['edition'],comparisonVersion=plan['id'],inputVersion=9 if revised else 8,
            sectionId=subject_id,notebookId=receipt['notebookId'],requested=len(jobs),commissioned=True,publish=False,
            manifestSha256=plan['configSha256'],subjects=[subject],inputSha256=r.HASH(json.dumps([subject],ensure_ascii=False,separators=(',',':'))),jobs=jobs))
    assert len(snapshots)==len({row['key'] for row in snapshots})==counts['outputs']
    assert Counter(j['type'] for run in runs for j in run['jobs']) == counts['byType']
    return runs,snapshots


def prepare(r, dry_run=False):
    plan = reviewed_plan(r)
    subjects, coverage, counts = scope(plan)
    if dry_run:
        print(json.dumps(dict(**counts,selectedSources=len(coverage['sourceKeys']),providerMutations=0)))
        return
    owner = r.production.owner; owner.ROOT = owner.WORK = r.WORK
    with owner.StageLock('supervisor'), owner.StageLock('generation',r.WORK/'worker.lock'), owner.StageLock('source-import'):
        save = r.production.generation_quota().atomic_json
        control = r.WORK/'generation-control.json'
        assert not control.exists() or r.read(control)['desiredState']=='hold'
        save(control,dict(schemaVersion=1,desiredState='hold',reconcileSeconds=30,probeBackoffSeconds=60))
        import_sources(r,plan)
        runs,snapshots = projection(r,plan)
        frozen = r.WORK/'request-inputs.json'
        if frozen.exists(): assert r.read(frozen)['requests']==snapshots
        else: save(frozen,dict(schema='ai-ba.unified-request-inputs.v2',manifestSha256=plan['configSha256'],
            preparedAt=r.native.NOW(),counts=counts,coverage=coverage,requests=snapshots))
        r.DIRECTORY.mkdir(parents=True,exist_ok=True)
        for run in runs:
            path = r.DIRECTORY/(run['sectionId']+'.json')
            if path.exists(): assert r.read(path)['inputSha256']==run['inputSha256']
            else: r.native.save(path,run)
    print(json.dumps(dict(prepared=len(subjects),topics=counts['topics'],jobs=counts['outputs'],selectedSources=len(coverage['sourceKeys']),held=True)),flush=True)


def settings(r, run, job):
    return {**job['settings'],'notebook_id':run['notebookId'],'title':job['title'],
        'source_ids':job['sourceIds'],'focus_prompt':r.adapter.brief(run,job)['mediaPrompts'][job['medium']]}


def bind(r):
    r.adapter.settings = lambda run,job: settings(r,run,job)
    r.native.expected_sources = lambda run,job: sorted(job['sourceIds'])
    if r.VARIANT in ('applied-rules-v1','full-section-v1'):
        r.adapter.close_deferred_uncertainty = lambda *args,**kwargs: []
    # This commission forbids replacing terminal failures; retain their identities.
    r.native.retryable_failure = lambda job: False
    r.native.failure_retry_at = lambda job: None


def validate(r, runs):
    expected,snapshots = projection(r)
    assert len(runs)==len(expected)
    ids=[]
    for run,prior in zip(runs,expected):
        assert all(run[k]==prior[k] for k in ('sectionId','notebookId','manifestSha256','inputSha256','subjects','requested'))
        assert len(run['jobs'])==len(prior['jobs'])
        for job,wanted in zip(run['jobs'],prior['jobs']):
            assert all(job[k]==wanted[k] for k in (*r.REQUEST_FIELDS,'key','sourceIds','topicId','topicTitle','take','completeInputSha256'))
            assert job.get('infographicDetail') == wanted.get('infographicDetail')
            assert settings(r,run,job)==next(s['adapterEnvelope'] for s in snapshots if s['key']==job['key'])
            if job.get('id'): ids.append(job['id'])
    assert len(ids)==len(set(ids)), 'Provider identity reused'
    assert r.read(r.WORK/'request-inputs.json')['requests']==snapshots
