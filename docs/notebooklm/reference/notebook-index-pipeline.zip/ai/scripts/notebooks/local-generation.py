"""Local N01 concise comparison using the existing BA/SA queue and AI video checks.

No production ledger or cloud publisher is used. --prepare freezes inputs.
--serve supervises generation and local delivery; desiredState hold drains creates.
"""
import argparse
import asyncio
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import pipeline as production
import prepare as inputs

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / '.local/n01-comparison/runs/concise-v1'
DIRECTORY = WORK / 'docs/generation'
CANDIDATE = ROOT / 'config/authoring/experiments/N01-chapters-concise-v1.json'
OVERVIEW = ROOT / 'config/authoring/experiments/N01-concise-v1.json'
SYNTHESIS = ROOT / 'config/authoring/experiments/N01-synthesis-refactored-v1.json'
SUBJECTS = ['N01'] + [f'N01.{n:02d}' for n in range(1, 6)]
MATCHED_MEDIA = {'N01.02':'slide_deck-detailed_deck-1', 'N01.03':'slide_deck-detailed_deck-1',
    'N01.05':'slide_deck-presenter_slides-1'}
MATCHED_VARIANTS = ('edited-full-synthesis-v1', 'chapter-focused-synthesis-v1')
VARIANT = 'concise-v1'
INPUT_MODULES = {'unified-v1':'unified-inputs.py','video-styles-v1':'video-styles.py', **{v:'topic-inputs.py' for v in ('topic-sources-v2','content-v3','content-v4','whole-chapter-v1','minimal-v1','business-v1','tailored-v2','tailored-v3','applied-rules-v1','full-section-v1')}}
SCREEN = ROOT / 'config/authoring/experiments/N01-content-screen-v1.json'
adapter = production.adapter
native = adapter.native
worker = adapter.worker
HASH = production.HASH
REQUEST_FIELDS = ('subject', 'level', 'type', 'medium', 'format', 'ordinal',
    'editorial', 'settings', 'version', 'promptSha256')

def read(file):
    return json.loads(file.read_text())

def selection():
    file = WORK / 'job-selection.json'
    if not file.exists():
        return None
    value = read(file)
    assert value['schema'] == 'ai-ba.local-job-selection.v1' and value['commission']
    assert value['jobKeys'] and len(value['jobKeys']) == len(set(value['jobKeys']))
    return value

def pending_jobs(runs, kind):
    selected = selection()
    keys = set(selected['jobKeys']) if selected else None
    if VARIANT in ('content-screen-v1','content-confirmation-v2'):
        for run in runs:
            for job in run['jobs']:
                if job['type']==kind and job['status']=='planned' and (keys is None or job['key'] in keys):
                    yield run, job
        return
    # A held medium must not hide another medium's quota probe or available work.
    eligible = next(([r] for r in runs if any(j['status']=='planned' and
        (VARIANT not in INPUT_MODULES or j['type']==kind) and
        (keys is None or j['key'] in keys) for j in r['jobs'])), [])
    for run, job in production.shared_pending_jobs(eligible, kind, preferred_formats=production.PREFERRED_FORMATS):
        if keys is None or job['key'] in keys:
            yield run, job

def generation_quota():
    quota = production.generation_quota()
    selected = selection()
    if selected:
        eligibility = quota.eligibility
        # Only the read-only request projection narrows; census/capacity stay global.
        quota.eligibility = lambda state,runs,*args: eligibility(state,
            [{**r, 'jobs':[j for j in r['jobs'] if j['key'] in selected['jobKeys']]} for r in runs], *args)
    return quota

def input_overrides(candidate):
    value = candidate.get('inputOverrides', {}) if candidate else {}
    assert not value or VARIANT=='chapter-focused-synthesis-v1'
    assert set(value) <= {'excludedSourceIds', 'treatmentPrompts'}
    if VARIANT=='chapter-focused-synthesis-v1':
        assert set(value)=={'excludedSourceIds', 'treatmentPrompts'}
    excluded = value.get('excludedSourceIds', [])
    assert len(excluded)==len(set(excluded)) and all(isinstance(i,str) for i in excluded)
    for subject, prompts in value.get('treatmentPrompts', {}).items():
        assert subject in MATCHED_MEDIA and set(prompts)=={MATCHED_MEDIA[subject]}
        assert all(isinstance(p,str) and p.strip() for p in prompts.values())
    return value

def assembled_prompt(shared, chapter, treatment, overrides):
    medium = f"{treatment['type']}-{treatment['format']}-{treatment['ordinal']}"
    prompt = overrides.get('treatmentPrompts', {}).get(chapter['id'], {}).get(medium, treatment['prompt'])
    return '\n\n'.join([shared['purposeAndAudience'], chapter['basePrompt'],
        prompt, shared['evidenceInstruction'], shared['language']])

def screen_projection():
    """Resolve the finite ADR049 content screen without provider access."""
    if VARIANT == 'content-confirmation-v2':
        return inputs.module(Path(__file__).with_name('content-confirmation.py')).projection(sys.modules[__name__])
    config = read(SCREEN)
    assert config['schema']=='ai-ba.content-screen.v1' and config['id']=='content-screen-v1'
    assert config['counts']=={'cells':36,'reusedArtifacts':3,'newRequests':33}
    assert config['c1Deselections']==['0e310d77-f27f-455f-8051-eb6831c3a183','d3ddb033-f1f5-4504-b336-87f239f1eb5e']
    assert config['c1Retains']=='4f049810-6381-447a-a2f2-330d127b570b'
    assert HASH(json.dumps(config['rubric'],sort_keys=True,separators=(',',':')))==config['rubricSha256']
    for cut in config['sourceCut']:
        assert HASH((ROOT/cut['path']).read_bytes())==cut['sha256']
    sources = {s['sourceId']:s for s in config['sources']}
    assert len(sources)==len(config['sources'])
    for source in sources.values():
        imported = next(s for s in read(ROOT/source['importReceiptPath'])['sources'].values() if s.get('sourceId')==source['sourceId'])
        assert imported['status']=='indexed-verified' and imported['sha256']==source['uploadedSha256'] and imported['indexedTextSha256']==source['indexedTextSha256']
        assert HASH((ROOT/source['indexedPath']).read_bytes())==source['indexedTextSha256']
        if source.get('bodyPath'):
            assert HASH((ROOT/source['bodyPath']).read_bytes())==source['bodySha256']
        if source.get('bodyConfigPath'):
            body = next(s for s in read(ROOT/source['bodyConfigPath'])['subjects'] if s['id']==source['bodySubject'])
            assert HASH(body['body'])==source['bodySha256']
            assert source['citedSourceIds']==[s['sourceId'] for s in body['sources']]
    chapters = {c['id']:c for c in config['chapters']}
    assert list(chapters)==list(MATCHED_MEDIA) and len(config['cells'])==36
    assert len({c['id'] for c in config['cells']})==36 and sum(c['reuse'] for c in config['cells'])==3
    for chapter in chapters.values():
        assert HASH((ROOT/chapter['baselineLedger']).read_bytes())==chapter['baselineLedgerSha256']
        baseline = read(ROOT/chapter['baselineLedger']); subject = baseline['subjects'][0]
        assert chapter['sourceSets']['C0']==subject['factualSourceIds']+subject['communicationSourceIds']
        assert chapter['sourceSets']['C1']==[i for i in chapter['sourceSets']['C0'] if i not in config['c1Deselections']]
        assert config['c1Retains'] in chapter['sourceSets']['C1']
        for profile in chapter['profiles'].values():
            assert all(HASH(c['text'])==c['sha256'] and c['destination']=='focus_prompt' for c in profile['components'])
            assert profile['text']=='\n\n'.join(c['text'] for c in profile['components']) and HASH(profile['text'])==profile['sha256']
        assert chapter['profiles']['P0']['text']==subject['mediaPrompts'][chapter['medium']]
        assert chapter['profiles']['P1']['components'][-2:]==chapter['profiles']['P0']['components'][-2:]
        assert {(c['P'],c['S'],c['C']) for c in config['cells'] if c['chapter']==chapter['id']}=={
            (p,s,c) for p in ('P0','P1') for s in ('S0','S1','S2') for c in ('C0','C1')}
    runs, snapshots = [], []
    for cell in config['cells']:
        chapter = chapters[cell['chapter']]; baseline = read(ROOT/chapter['baselineLedger'])
        subject, original = copy.deepcopy(baseline['subjects'][0]), copy.deepcopy(baseline['jobs'][0])
        profile, condition = chapter['profiles'][cell['P']], '-'.join(cell[k] for k in ('P','S','C'))
        assert cell['replicate']==1 and cell['id']==chapter['id']+'-'+condition+'-r1'
        ids = list(chapter['sourceSets'][cell['C']]); synthesis = chapter['syntheses'].get(cell['S'])
        if synthesis:
            assert set(synthesis['citedSourceIds'])<=set(ids)
            source = sources[synthesis['sourceId']]; ids.append(source['sourceId'])
            subject.update(editorialSourceId=source['sourceId'],editorialSha256=source['bodySha256'],
                editorialSync=copy.deepcopy(next(s for s in read(ROOT/source['importReceiptPath'])['sources'].values() if s.get('sourceId')==source['sourceId'])))
        else: subject.update(editorialSourceId=None,editorialSha256=None,editorialSync={'status':'not-selected'})
        subject['synthesisVariant'] = cell['S']
        assert ids and len(ids)==len(set(ids)) and set(ids)<=sources.keys()
        assert not set(ids)&set(config['permanentDeselections'])
        subject.update(communicationSourceIds=[i for i in subject['communicationSourceIds'] if i in ids],
            mediaPrompts={chapter['medium']:profile['text']},promptHashes={chapter['medium']:profile['sha256']})
        settings = original['settings']
        assert all(settings[k]==config['fixedNative'][k] for k in ('artifact_type','slide_length','language'))
        assert settings['slide_format']==chapter['format'] and original['medium']==chapter['medium']
        arguments = dict(notebook_id=baseline['notebookId'],source_ids=ids,format_code=native.constants.SLIDE_DECK_FORMATS.get_code(chapter['format']),length_code=4,language=settings['language'],focus_prompt=profile['text'])
        input_hash = HASH(json.dumps({'createArguments':arguments,'indexedSourceHashes':{i:sources[i]['indexedTextSha256'] for i in ids}},sort_keys=True,separators=(',',':')))
        assert cell['reuse']==(condition=='P0-S2-C0')
        if cell['reuse']:
            assert original['status']=='completed' and original['id']==chapter['reuse']['artifactId']
            assert original['providerProof']['settingsVerified'] and original['providerProof']['promptSha256']==profile['sha256']
            assert sorted(original['sourceIds'])==sorted(original['providerProof']['sourceIds'])==sorted(ids)
            assert HASH((ROOT/chapter['reuse']['originalPath']).read_bytes())==chapter['reuse']['originalSha256']
            job = original
        else:
            job = {k:original[k] for k in REQUEST_FIELDS if k not in ('editorial','version','promptSha256')}
            job.update(status='planned')
        job.update(key=config['id']+'-'+cell['id'],version=5,editorial=bool(synthesis),promptSha256=profile['sha256'],
            title=f"ADR049 — {chapter['id']} — {condition} — repeat 1",experimentCell=cell['id'],condition=condition,
            conditionLabel=condition,completeInputSha256=input_hash)
        job.pop('synthesisVariant',None)
        if cell['reuse']: job['reusedFrom']=chapter['reuse']
        run = dict(schemaVersion=1,edition=baseline['edition'],comparisonVersion=config['id'],sectionId=cell['id'],chapterId=chapter['id'],
            notebookId=baseline['notebookId'],requested=1,commissioned=True,publish=False,manifestSha256=HASH(SCREEN.read_bytes()),
            subjects=[subject],inputSha256=HASH(json.dumps([subject],ensure_ascii=False,separators=(',',':'))),jobs=[job])
        envelope = {**settings,'notebook_id':run['notebookId'],'title':job['title'],'source_ids':ids,'focus_prompt':profile['text']}
        snapshots.append(dict(cell=cell,completeInputSha256=input_hash,promptComponents=profile['components'],adapterEnvelope=envelope,
            consumedCreateMethod='NotebookLMClient.create_slide_deck',consumedCreateArguments=arguments,selectedSources=[sources[i] for i in ids],
            reuse=chapter['reuse'] if cell['reuse'] else None,evaluationStatus='awaiting-new-screen-review'))
        runs.append(run)
    assert len({r['completeInputSha256'] for r in snapshots})==36
    return config, runs, snapshots

def prepare_screen(dry_run=False):
    config, runs, snapshots = screen_projection()
    owner = production.owner; owner.ROOT = owner.WORK = WORK
    with owner.StageLock('supervisor'), owner.StageLock('generation', WORK/'worker.lock'):
        control = WORK/'generation-control.json'
        assert not control.exists() or read(control)['desiredState']=='hold'
        production.generation_quota().atomic_json(control,{'schemaVersion':1,'desiredState':'hold','reconcileSeconds':30,'probeBackoffSeconds':60})
        production.generation_quota().atomic_json(WORK/'request-inputs.json',dict(schema='ai-ba.content-screen-inputs.v1',
            manifestSha256=HASH(SCREEN.read_bytes()),review=config['review'],preparedAt=native.NOW(),providerMutations=0,requests=snapshots))
        production.generation_quota().atomic_json(WORK/'rubric.json',config['rubric'])
        frozen = config['review']['status']=='reviewed-and-frozen' and not dry_run
        if frozen:
            available = {s['id']:s['title'] for s in worker.get_client().get_notebook_sources_with_types(runs[0]['notebookId'])}
            assert {i for row in snapshots for i in row['consumedCreateArguments']['source_ids']}<=available.keys()
            assert all(available[s['sourceId']]==s['title'] for s in config['sources'])
            production.generation_quota().atomic_json(WORK/'source-availability.json',dict(verifiedAt=native.NOW(),notebookId=runs[0]['notebookId'],
                selectedSources={s['sourceId']:available[s['sourceId']] for s in config['sources']},bodyProof='Retained complete indexed readback hashes; this live check verifies presence and titles, not a fresh full-body audit.'))
            DIRECTORY.mkdir(parents=True,exist_ok=True)
            for run in runs:
                file = DIRECTORY/(run['sectionId']+'.json')
                if file.exists():
                    assert read(file)['manifestSha256']==run['manifestSha256'] and read(file)['inputSha256']==run['inputSha256']
                else: native.save(file,run)
                job = run['jobs'][0]
                if job.get('reusedFrom'):
                    target = WORK/'originals'/(job['key']+'.pdf'); target.parent.mkdir(parents=True,exist_ok=True)
                    if not target.exists(): target.symlink_to(ROOT/job['reusedFrom']['originalPath'])
            production.generation_quota().atomic_json(WORK/'job-selection.json',dict(schema='ai-ba.local-job-selection.v1',
                commission=config['id'],jobKeys=[r['jobs'][0]['key'] for r in runs if not r['jobs'][0].get('reusedFrom')],repeats={}))
    print(json.dumps(dict(cells=config['counts']['cells'],reused=config['counts']['reusedArtifacts'],newRequests=config['counts']['newRequests'],held=True,preparedOnly=not frozen)))

def prepare():
    if VARIANT in INPUT_MODULES:
        return inputs.module(Path(__file__).with_name(INPUT_MODULES[VARIANT])).prepare(sys.modules[__name__])
    candidate = read(CANDIDATE)
    shared_path = ROOT / candidate['sharedInstructions']['path']
    assert HASH(shared_path.read_bytes()) == candidate['sharedInstructions']['sha256']
    shared = read(shared_path)
    assert [c['id'] for c in candidate['chapters']] == [f'N01.{n:02d}' for n in range(1, 6)]
    overview = read(OVERVIEW)
    chapters = [{'id':'N01', 'title':overview['title'], 'basePrompt':overview['subjectBrief'],
        'baseline':{'path':overview['baseline']['subjectPath'], 'sha256':overview['baseline']['subjectSha256']},
        'treatments':overview['treatments']}, *candidate['chapters']]
    matched = VARIANT in MATCHED_VARIANTS
    revised = read(SYNTHESIS) if VARIANT != 'concise-v1' else None
    overrides = input_overrides(revised)
    synthesis_kind = VARIANT.removesuffix('-synthesis-v1') if matched else 'refactored'
    if matched:
        assert revised['review']['status']=='reviewed-and-frozen', 'Matched synthesis is not frozen'
        assert [s['id'] for s in revised['subjects']]==list(MATCHED_MEDIA)
        for source in revised['subjects']:
            baseline = next(c['baseline'] for c in chapters if c['id']==source['id'])
            assert source['baseline']['path']==baseline['path'] and source['baseline']['sha256']==baseline['sha256']
            assert HASH(source['body'])==source['sha256'] and HASH((ROOT/baseline['path']).read_bytes())==baseline['sha256']
            frozen = read(ROOT / '.local/n01-comparison/runs/concise-v1/docs/generation' / (source['id']+'.json'))
            assert set(overrides.get('excludedSourceIds', [])) <= set(frozen['subjects'][0]['factualSourceIds'])
    DIRECTORY.mkdir(parents=True, exist_ok=True)
    commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    client = worker.get_client()
    receipt_file = WORK / 'source-import.json'
    receipt = read(receipt_file) if receipt_file.exists() else {'schema':'ai-ba.local-synthesis.v1', 'sources':{}}
    for chapter in chapters:
        if chapter['id'] not in SUBJECTS:
            continue
        assert HASH((ROOT / chapter['baseline']['path']).read_bytes()) == chapter['baseline']['sha256']
        baseline = ROOT / '.local/n01-comparison/runs/concise-v1' if matched else ROOT
        old = read(baseline / 'docs/generation' / (chapter['id'] + '.json'))
        subject = copy.deepcopy(old['subjects'][0])
        assert subject['id'] == chapter['id'] and subject['generationReady']
        excluded = set(overrides.get('excludedSourceIds', []))
        assert excluded <= set(subject['factualSourceIds'])
        subject['factualSourceIds'] = [i for i in subject['factualSourceIds'] if i not in excluded]
        if revised:
            synthesis = next(s for s in revised['subjects'] if s['id'] == chapter['id'])
            assert HASH(synthesis['body']) == synthesis['sha256']
            assert synthesis['baseline']['sha256'] == chapter['baseline']['sha256']
            receipt['notebookId'] = old['notebookId']
            inputs.WORK = WORK
            key = chapter['id'] + ':' + synthesis['sha256']
            title = f"AI BA — {chapter['id']} — {synthesis_kind.replace('-', ' ')} synthesis [{synthesis['sha256'][:16]}]"
            source_id = inputs.import_text(client, receipt, key, synthesis['body'], title)
            assert source_id and receipt['sources'][key]['status'] == 'indexed-verified'
            subject.update(editorialSourceId=source_id, editorialSha256=synthesis['sha256'],
                editorialSync=copy.deepcopy(receipt['sources'][key]), synthesisVariant=synthesis_kind)
        for treatment in chapter['treatments']:
            medium = f"{treatment['type']}-{treatment['format']}-{treatment['ordinal']}"
            assert medium in subject['mediaPrompts']
            prompt = assembled_prompt(shared, chapter, treatment, overrides)
            subject['mediaPrompts'][medium] = prompt
            subject['promptHashes'][medium] = HASH(prompt)
        jobs = []
        for original in old['jobs']:
            if revised and not original['editorial']:
                continue
            if matched and original['medium'] != MATCHED_MEDIA[chapter['id']]:
                continue
            job = {key:copy.deepcopy(original[key]) for key in
                ('subject', 'level', 'type', 'medium', 'format', 'ordinal', 'editorial', 'settings')}
            condition = synthesis_kind+'-synthesis' if revised else 'with-synthesis' if job['editorial'] else 'without-synthesis'
            job.update(key=VARIANT + '-' + chapter['id'] + '-' + job['medium'] + '-' + condition,
                version=4 if synthesis_kind=='chapter-focused' else 3 if matched else 2 if revised else 5, status='planned', promptSha256=subject['promptHashes'][job['medium']],
                title=f"{VARIANT} — {chapter['id']} {chapter['title']} — {job['format']} {job['ordinal']} — {condition}")
            if revised:
                job.update(condition=condition, synthesisVariant=synthesis_kind)
            jobs.append(job)
        run = {'schemaVersion':1, 'edition':old['edition'], 'comparisonVersion':VARIANT,
            'inputVersion':5, 'sourceCommit':commit, 'sectionId':chapter['id'],
            'notebookId':old['notebookId'], 'requested':len(jobs), 'commissioned':True, 'publish':False,
            'candidateSha256':HASH((OVERVIEW if chapter['id']=='N01' else CANDIDATE).read_bytes()), 'subjects':[subject],
            'inputSha256':HASH(json.dumps([subject], ensure_ascii=False, separators=(',', ':'))), 'jobs':jobs}
        if revised:
            run['synthesisCandidateSha256'] = HASH(SYNTHESIS.read_bytes())
        if overrides:
            run['inputOverrides'] = copy.deepcopy(overrides)
        file = DIRECTORY / (chapter['id'] + '.json')
        if file.exists():
            existing = read(file)
            assert existing['candidateSha256'] == run['candidateSha256']
            assert existing['inputSha256'] == run['inputSha256']
        else:
            native.save(file, run)
    control = WORK / 'generation-control.json'
    if not control.exists():
        production.generation_quota().atomic_json(control, {'schemaVersion':1, 'desiredState':'hold', 'reconcileSeconds':30, 'probeBackoffSeconds':60})
    # Read-only live availability check; original source-body proofs remain in each freeze.
    notebook = old['notebookId']
    available = {row['id']:row['title'] for row in client.get_notebook_sources_with_types(notebook)}
    selected = set()
    for file in sorted(DIRECTORY.glob('*.json')):
        for s in read(file)['subjects']:
            ids = set(s['factualSourceIds'] + s['communicationSourceIds'] + [s['editorialSourceId']])
            assert ids <= set(available), 'Previously verified source missing from notebook'
            assert s['editorialSync']['status'] == 'indexed-verified'
            selected.update(ids)
    production.generation_quota().atomic_json(WORK / 'source-availability.json', {'verifiedAt':native.NOW(), 'notebookId':notebook,
        'candidateSha256':HASH(CANDIDATE.read_bytes()), 'sources':{key:available[key] for key in sorted(selected)},
        'bodyProof':'Reused exact frozen source/synthesis receipts; this check verifies current presence, not a new full-body audit.'})
    print(json.dumps({'prepared':len(SUBJECTS), 'jobs':sum(read(f)['requested'] for f in DIRECTORY.glob('*.json')),
        'availableSelectedSources':len(selected)}), flush=True)

def bind():
    if VARIANT in ('content-screen-v1','content-confirmation-v2'): assert read(SCREEN)['review']['status']=='reviewed-and-frozen'
    production.WORK = WORK
    adapter.ROOT, adapter.WORK = WORK, WORK
    adapter.FILES = [DIRECTORY / (subject + '.json') for subject in SUBJECTS]
    native.ROOT, native.DIRECTORY = ROOT, DIRECTORY
    worker.ROOT, worker.WORK, worker.FILES = WORK, WORK, adapter.FILES
    adapter.settings = production.settings
    native.expected_sources = lambda run,job: sorted(production.brief.source_ids(adapter.brief(run,job), job['editorial']))
    if INPUT_MODULES.get(VARIANT) in ('topic-inputs.py','video-styles.py'): inputs.module(Path(__file__).with_name(INPUT_MODULES[VARIANT])).bind(sys.modules[__name__])
    worker.download_original = production.download_original
    adapter.validate = lambda runs: validate(adapter.reads())
    adapter.generation_quota = generation_quota
    adapter.sync_provider_titles = lambda client: {'titleMaintenanceDeferred':True}
    # Preserve the existing chapter-order submission policy without a completion barrier.
    native.pending_jobs = pending_jobs
    selected = selection()
    if selected:
        # Preserve unrelated uncertain identities and the native uncertainty rules.
        worker.FILES = [f for f in adapter.FILES if any(j['key'] in selected['jobKeys'] for j in read(f)['jobs'])]
    owner = production.owner
    owner.ROOT, owner.WORK = WORK, WORK
    worker.recover_stalled = lambda client,runs,meter,cfg,now: production.restart_stalled(
        client,runs,adapter.generation_quota(),meter,cfg,now)
    return owner
def validate(runs):
    if VARIANT in INPUT_MODULES:
        return inputs.module(Path(__file__).with_name(INPUT_MODULES[VARIANT])).validate(sys.modules[__name__],runs)
    if VARIANT in ('content-screen-v1','content-confirmation-v2'):
        _, expected, _ = screen_projection()
        assert len(runs)==len(expected)
        for run, prior in zip(runs,expected):
            assert all(run[k]==prior[k] for k in ('sectionId','manifestSha256','inputSha256','subjects','requested'))
            assert len(run['jobs'])==1 and all(run['jobs'][0][k]==prior['jobs'][0][k] for k in (*REQUEST_FIELDS,'key','completeInputSha256'))
            adapter.brief(run,run['jobs'][0])
        return
    assert [r['sectionId'] for r in runs] == SUBJECTS
    count = 1 if VARIANT in MATCHED_VARIANTS else 17 if VARIANT == 'refactored-synthesis-v1' else 34
    selected = selection()
    repeats = selected.get('repeats', {}) if selected else {}
    assert all(r['requested']==len(r['jobs']) and not r['publish'] and
        len([j for j in r['jobs'] if not j.get('repeatOf')])==count for r in runs)
    assert all(r['candidateSha256']==HASH((OVERVIEW if r['sectionId']=='N01' else CANDIDATE).read_bytes()) for r in runs)
    jobs = {j['key']:j for r in runs for j in r['jobs']}
    assert len(jobs) == sum(len(r['jobs']) for r in runs) == count*len(SUBJECTS)+len(repeats)
    if selected:
        assert set(selected['jobKeys']) <= jobs.keys()
    assert {j['key'] for j in jobs.values() if j.get('repeatOf')} == set(repeats)
    for key, original_key in repeats.items():
        job, original = jobs[key], jobs[original_key]
        assert VARIANT=='concise-v1' and not original['editorial'] and not original.get('repeatOf')
        assert job['repeatOf']==original_key and job['repeatCommission']==selected['commission']
        assert key in selected['jobKeys'] and job['repeatNumber']==2
        assert all(job[field]==original[field] for field in REQUEST_FIELDS)
    if VARIANT != 'concise-v1':
        assert all(r['synthesisCandidateSha256']==HASH(SYNTHESIS.read_bytes()) for r in runs)
    overrides = input_overrides(read(SYNTHESIS)) if VARIANT in MATCHED_VARIANTS else {}
    candidate = read(CANDIDATE)
    shared = read(ROOT / candidate['sharedInstructions']['path'])
    for run in runs:
        for job in run['jobs']:
            adapter.brief(run, job)
            if VARIANT in MATCHED_VARIANTS:
                baseline = read(ROOT / '.local/n01-comparison/runs/concise-v1/docs/generation' / (run['sectionId']+'.json'))
                original = next(j for j in baseline['jobs'] if j['editorial'] and j['medium']==MATCHED_MEDIA[run['sectionId']])
                assert job['editorial'] and job['synthesisVariant']==VARIANT.removesuffix('-synthesis-v1')
                assert all(job[k]==original[k] for k in REQUEST_FIELDS if k not in ('version','promptSha256'))
                chapter = next(c for c in candidate['chapters'] if c['id']==run['sectionId'])
                expected = {f"{t['type']}-{t['format']}-{t['ordinal']}":assembled_prompt(shared,chapter,t,overrides) for t in chapter['treatments']}
                subject, prior = run['subjects'][0], baseline['subjects'][0]
                assert subject['mediaPrompts']==expected and job['promptSha256']==HASH(expected[job['medium']])
                assert subject['communicationSourceIds']==prior['communicationSourceIds']
                assert subject['factualSourceIds']==[i for i in prior['factualSourceIds'] if i not in overrides.get('excludedSourceIds', [])]
                assert run.get('inputOverrides', {})==overrides

def generation():
    bind()
    production.recover_interrupted_intents()
    get_client = worker.get_client
    worker.get_client = lambda: production.rate_limit_client(get_client())
    # Poll during a submission burst so completion is visible to the separate downloader.
    submit = worker.persistent_submit
    last = time.monotonic()
    def submit_and_poll(*args, **kwargs):
        nonlocal last
        result = submit(*args, **kwargs)
        if time.monotonic()-last >= 30:
            native.reconcile(args[0], worker.FILES, on_proof_mismatch=production.proof_mismatch)
            last = time.monotonic()
        return result
    worker.persistent_submit = submit_and_poll
    selected = selection()
    cycle = worker.persistent_cycle
    def selected_cycle(*args, **kwargs):
        result = cycle(*args, **kwargs)
        jobs = [j for r in adapter.reads() for j in r['jobs'] if j['key'] in selected['jobKeys']]
        if all(j['status']=='completed' and j.get('providerProof', {}).get('settingsVerified') for j in jobs):
            result['phase'] = 'complete'
        return result
    if selected:
        worker.persistent_cycle = selected_cycle
    adapter.persistent()
    if all(j['status']=='completed' for r in adapter.reads() for j in r['jobs']
           if not selected or j['key'] in selected['jobKeys']):
        control = read(WORK/'generation-control.json'); control['desiredState']='hold'
        production.generation_quota().atomic_json(WORK/'generation-control.json', control)

def delivery():
    owner = bind()
    async def download_stream():
        pending = asyncio.create_task(worker.downloads(worker.get_client(), adapter.reads(), concurrency=8, refresh_runs=adapter.reads))
        while True:
            done, _ = await asyncio.wait({pending}, timeout=30)
            try:
                await asyncio.to_thread(subprocess.run, ['node', str(ROOT/'scripts/notebooks/local-comparison-refresh.mjs'), 'content-v4' if VARIANT=='whole-chapter-v1' else VARIANT], cwd=ROOT, check=True)
            except Exception as error:
                if done: raise
                owner.write_stage_status('delivery', 'retry', lastError=owner.safe_error(error))
            if done: return await pending
    with owner.StageLock('delivery'):
        while owner.supervisor_alive():
            try:
                asyncio.run(download_stream())
                if VARIANT == 'content-confirmation-v2':
                    inputs.module(Path(__file__).with_name('content-confirmation.py')).handoff(sys.modules[__name__])
                owner.write_stage_status('delivery', 'waiting', lastError=None)
            except Exception as error:
                owner.write_stage_status('delivery', 'retry', lastError=owner.safe_error(error))
            time.sleep(30)

def serve():
    owner = bind()
    supervisor = adapter.load_module('generation-pipeline')
    supervisor.ROOT, supervisor.WORK = ROOT, WORK
    supervisor.LOGS = WORK/'transfers'
    supervisor.CONTROL = WORK/'generation-control.json'
    supervisor.STATE = WORK/'pipeline/supervisor-status.json'
    supervisor.ownership = owner
    supervisor.commands = lambda:{stage:[str(production.SDK), str(Path(__file__).resolve()), '--variant',VARIANT,'--'+stage]
        for stage in ('generation','delivery')}
    supervisor.serve()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--variant', choices=['concise-v1','refactored-synthesis-v1',*MATCHED_VARIANTS,'content-screen-v1','content-confirmation-v2',*INPUT_MODULES], default='concise-v1')
    modes = parser.add_mutually_exclusive_group(required=True)
    for mode in ('prepare','serve','generation','delivery','validate','dry-run'):
        modes.add_argument('--'+mode, action='store_true')
    args = parser.parse_args()
    VARIANT = args.variant
    if VARIANT == 'topic-sources-v2': SUBJECTS = ['N01','N01.01','N01.02']
    if VARIANT == 'video-styles-v1': SUBJECTS = ['N01.01','N01.02']
    if VARIANT in ('content-v4','whole-chapter-v1','minimal-v1','business-v1','tailored-v2','tailored-v3','applied-rules-v1'): SUBJECTS = ['N01.01','N01.02','N01.03']
    if VARIANT == 'content-confirmation-v2': SCREEN = ROOT/'config/authoring/experiments/N01-content-confirmation-inputs-v2.json'
    if VARIANT in ('content-screen-v1','content-confirmation-v2'): SUBJECTS = [c['id'] for c in read(SCREEN)['cells']]
    if VARIANT in MATCHED_VARIANTS:
        SUBJECTS = list(MATCHED_MEDIA)
        SYNTHESIS = ROOT / ('config/authoring/experiments/N01-synthesis-'+VARIANT.removesuffix('-synthesis-v1')+'-v1.json')
    WORK = ROOT / '.local/n01-comparison/runs' / VARIANT
    DIRECTORY = WORK / 'docs/generation'
    if args.dry_run:
        if VARIANT in INPUT_MODULES: inputs.module(Path(__file__).with_name(INPUT_MODULES[VARIANT])).prepare(sys.modules[__name__],dry_run=True)
        else:
            assert VARIANT in ('content-screen-v1','content-confirmation-v2'); prepare_screen(dry_run=True)
    elif args.prepare: prepare_screen() if VARIANT in ('content-screen-v1','content-confirmation-v2') else prepare()
    elif args.validate and VARIANT in ('content-screen-v1','content-confirmation-v2') and not DIRECTORY.exists():
        screen_projection(); print(str(len(SUBJECTS))+' draft content cells verified; no runnable ledgers.')
    elif args.validate:
        bind(); validate(adapter.reads()); print(str(len(SUBJECTS))+' subject freezes verified; '+str(sum(r['requested'] for r in adapter.reads()))+' distinct jobs.')
    elif args.serve: serve()
    elif args.generation: generation()
    elif args.delivery: delivery()
