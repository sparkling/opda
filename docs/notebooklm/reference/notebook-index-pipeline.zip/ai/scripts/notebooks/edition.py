"""Opt-in ADR025 inputs over the existing import and generation owners."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

import prepare
import brief

ROOT, WORK, HASH = prepare.ROOT, prepare.WORK / 'adr025', prepare.HASH
EDITION = 'adr025-20261021'
HANDOFF = ROOT / '.local/adr025-claude-improvement-20261022/generation-handoff.json'
QUERY = 'semantic-query:document:docs/research/agentic-query-application/opportunity-discovery/ruvector-opportunity-addendum.md'


def inputs():
    handoff = json.loads(HANDOFF.read_text())
    cut_file = ROOT / handoff['instructionCut']['expectedVersusActual']['path']
    assert HASH(cut_file.read_bytes()) == handoff['instructionCut']['expectedVersusActual']['sha256']
    cut = json.loads(cut_file.read_text())
    assert cut['sourceCommit'] == '6494ef84a66b90c6e9188d6aafa7078ff7872766'
    assert HASH((ROOT / cut['sharedResolver']).read_bytes()) == cut['sharedResolverSha256']
    communication = json.loads((ROOT / brief.CONFIG).read_text())
    assert HASH((ROOT / brief.CONFIG).read_bytes()) == cut['communicationSha256']
    commission_file = Path(handoff['instructionCut']['commission']['path'])
    assert HASH(commission_file.read_bytes()) == cut['commissionSha256']
    commission = json.loads(commission_file.read_text())
    records = []
    for selected in cut['subjects']:
        body = (ROOT / selected['path']).read_bytes()
        assert HASH(body) == selected['sha256'], 'Accepted authoring bytes changed'
        assert subprocess.check_output(['git', 'show', cut['sourceCommit'] + ':' + selected['path']], cwd=ROOT) == body
        record = json.loads(body)
        entries = brief.instruction_entries(record, communication, commission)
        expected = {entry['key']:entry for entry in selected['entries']}
        assert len(entries) == len(expected) == 34
        for entry in entries:
            assert entry['promptSha256'] == expected[entry['key']]['promptSha256']
            assert HASH(json.dumps(entry, ensure_ascii=False, sort_keys=True, separators=(',', ':'))) == expected[entry['key']]['bodySha256']
        records.append((record, entries))
    assert len(records) == 87 and sum(len(entries) for _, entries in records) == 2958
    return cut, records


def exact_body(binding):
    """Resolve only the selected complete bytes, never a newer replacement."""
    if binding['originalId'] == QUERY:
        admissions=json.loads((ROOT/brief.CONFIG).read_text()).get('sourceAdmissions',[])
        if not any(row['originalId']==QUERY and row['sha256']==binding.get('sha256') for row in admissions):
            raise ValueError('Query original requires an exact current NotebookLM admission')
    digest = binding['sha256']
    locator = binding['locator']
    candidates = []
    if locator.startswith('/'):
        candidates.append(Path(locator))
    elif locator.startswith('repo:') and '+' in locator:
        repository, relative = locator[5:].split('+', 1)
        assert '..' not in Path(relative).parts
        candidates.append(ROOT.parent / repository / relative)
        revision = binding.get('revision')
        if revision and len(revision) >= 7:
            result = subprocess.run(['git', 'show', revision + ':' + relative], cwd=ROOT.parent / repository, capture_output=True)
            if result.returncode == 0 and HASH(result.stdout) == digest:
                return result.stdout.decode()
    for path in candidates:
        if path.is_file() and HASH(path.read_bytes()) == digest:
            return path.read_bytes().decode()
    for path in (WORK / 'native').glob('*.json'):
        captured = json.loads(path.read_text())
        if not captured.get('found') or captured.get('key') != binding.get('key'):
            continue
        value = captured['value']
        bodies = [value] if isinstance(value, str) else [value.get('content'), value.get('markdown'),
            json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))]
        for body in bodies:
            if isinstance(body, str) and HASH(body) == digest:
                return body
    for path in (WORK / 'native').glob('*.txt'):
        if HASH(path.read_bytes()) == digest:
            return path.read_bytes().decode()
    body = prepare.original_body(binding)
    if body is not None and HASH(body) == digest:
        return body
    raise ValueError('Exact whole selected original unavailable: ' + binding['originalId'])


def preflight(records):
    bodies, gaps, subjects = {}, {}, {}
    for record, entries in records:
        missing = []
        for binding in brief.selected_bindings(record, entries):
            key = HASH(binding['originalId'] + ':' + binding['sha256'])
            if key not in bodies and key not in gaps:
                try:
                    bodies[key] = exact_body(binding)
                except ValueError as error:
                    gaps[key] = str(error)
            if key in gaps:
                missing.append({'originalId':binding['originalId'], 'reason':gaps[key]})
        subjects[record['id']] = missing
    return bodies, subjects


def freeze(cut, records, receipt, bodies, source_gaps):
    """One immutable subject per ledger; all treatment prompts stay distinct."""
    owner = prepare.adapter.load_module('generation-ownership')
    owner.WORK = prepare.WORK
    with owner.StageLock('generation', prepare.WORK / 'worker.lock'):
        for record, entries in records:
            file = ROOT / 'docs/generation' / (record['id'] + '.json')
            if file.exists():
                existing = json.loads(file.read_text())
                assert existing['edition'] == EDITION
                if existing['sourceCommit'] == cut['sourceCommit']:
                    if existing['subjects'][0]['generationReady']:
                        continue
                    assert not any(job.get('id') or job['status'] not in {'source-blocked', 'planned'} for job in existing['jobs'])
                else:
                    archive = ROOT / cut['history'] / file.name
                    assert archive.read_bytes() == file.read_bytes(), 'Unarchived prior ledger'
            originals, factual, authorities = [], [], []
            gaps = source_gaps[record['id']][:]
            for binding in brief.selected_bindings(record, entries):
                key = HASH(binding['originalId'] + ':' + binding['sha256'])
                row = receipt['sources'].get(key, {})
                if row.get('status') != 'indexed-verified':
                    if key in bodies:
                        gaps.append({'originalId':binding['originalId'], 'reason':row.get('lastErrorType', 'Exact original upload not yet verified')})
                    continue
                originals.append({**binding, 'sourceId':row['sourceId'], 'uploadedSha256':row['sha256']})
                (authorities if binding['role'] == 'communication-authority' else factual).append(row['sourceId'])
            synthesis_key, synthesis_body = brief.editorial(record)
            synthesis = receipt['sources'].get(synthesis_key, {})
            if synthesis.get('status') != 'indexed-verified':
                gaps.append({'synthesis':record['id'], 'reason':'Matching synthesis not indexed-verified'})
            prompts = {f"{entry['type']}-{entry['format']}-{entry['ordinal']}":entry['prompt'] for entry in entries}
            subject = {'id':record['id'], 'title':record['title'], 'scopeType':record['scopeType'], 'level':0,
                'factualSourceIds':list(dict.fromkeys(factual)), 'communicationSourceIds':list(dict.fromkeys(authorities)),
                'originalSources':originals, 'editorialSourceId':synthesis.get('sourceId'), 'editorialSha256':HASH(synthesis_body),
                'editorialSync':{'status':synthesis.get('status', 'unavailable')},
                'mediaPrompts':prompts, 'promptHashes':{key:HASH(body) for key,body in prompts.items()},
                'sourceGaps':gaps, 'generationReady':not gaps}
            version = cut.get('inputVersion', 3)
            jobs = [{'key':(('v'+str(version)+'-') if version > 3 else '')+entry['key'], 'subject':record['id'], 'level':0, 'type':entry['type'],
                'medium':f"{entry['type']}-{entry['format']}-{entry['ordinal']}", 'format':entry['format'],
                'ordinal':entry['ordinal'], 'editorial':entry['condition']=='with-editorial', 'version':version,
                'settings':entry['settings'], 'id':None, 'promptSha256':entry['promptSha256'],
                'title':f"{record['id']} {record['title']} — {entry['format'].replace('_', ' ')} {entry['ordinal']} — {entry['condition']}",
                'status':'planned' if subject['generationReady'] else 'source-blocked'} for entry in entries]
            run = {'schemaVersion':1, 'edition':EDITION, 'inputVersion':version, 'sourceCommit':cut['sourceCommit'],
                'sectionId':record['id'], 'notebookId':receipt['notebookId'], 'requested':34, 'commissioned':True,
                'publish':True, 'subjects':[subject], 'jobs':jobs,
                'inputSha256':HASH(json.dumps([subject], ensure_ascii=False, separators=(',', ':')))}
            prepare.native.save(file, run)


def prepare_reviewed_section(source_commit, audit_file):
    """Reuse verified uploaded bodies for the explicitly authorized N01 successor."""
    brief.require_hold(prepare.WORK)
    review = prepare.module(ROOT / 'scripts/notebooks/review-instructions.py')
    audit = json.loads(Path(audit_file).read_text())
    config = json.loads((ROOT / brief.CONFIG).read_text())
    assert subprocess.check_output(['git', 'show', source_commit+':'+brief.CONFIG], cwd=ROOT) == (ROOT / brief.CONFIG).read_bytes()
    assert subprocess.check_output(['git', 'show', source_commit+':scripts/notebooks/brief.py'], cwd=ROOT) == (ROOT / 'scripts/notebooks/brief.py').read_bytes()
    handoff = json.loads(HANDOFF.read_text())['instructionCut']
    commission_file = Path(handoff['commission']['path'])
    assert HASH(commission_file.read_bytes()) == handoff['commission']['sha256']
    commission = json.loads(commission_file.read_text())
    ids = ['N01.01', 'N01.02', 'N01.03', 'N01.04', 'N01.05', 'N01']
    records, receipt, hashes = [], {'notebookId':audit['notebookId'], 'sources':{}}, {}
    for identity in ids:
        relative = 'config/authoring/'+('chapters' if '.' in identity else 'sections')+'/'+identity+'.json'
        body = (ROOT / relative).read_bytes()
        assert subprocess.check_output(['git', 'show', source_commit+':'+relative], cwd=ROOT) == body
        record = json.loads(body)
        assert record['review']['readiness']['instructions'] == 'fresh-final-reviewed'
        selected, _ = review.selection(record, config, audit)
        assert selected['generationReady']
        entries = brief.instruction_entries(record, config, commission)
        records.append((record, entries)); hashes[identity] = HASH(body)
        for binding in brief.selected_bindings(record, entries):
            key = HASH(binding['originalId']+':'+binding['sha256'])
            row = audit['sources'][key]
            receipt['sources'][key] = {**row, 'status':'indexed-verified', 'sha256':binding['sha256']}
        key, synthesis = brief.editorial(record)
        receipt['sources'][key] = {**audit['sources'][key], 'status':'indexed-verified', 'sha256':HASH(synthesis)}
    cut_sha = HASH(json.dumps({'sourceCommit':source_commit, 'subjects':hashes}, sort_keys=True))
    files = [ROOT / 'docs/generation' / (identity+'.json') for identity in ids]
    version = brief.archive_inputs(ROOT, files, cut_sha, prepare.quota.atomic_json)
    cut = {'sourceCommit':source_commit, 'inputVersion':version, 'history':'docs/generation/history/'+cut_sha}
    freeze(cut, records, receipt, {}, {identity:[] for identity in ids})
    proof = {'sourceCommit':source_commit, 'subjects':ids, 'subjectHashes':hashes, 'jobs':204,
        'inputVersion':version, 'history':cut['history'], 'sourceAuditSha256':HASH(Path(audit_file).read_bytes()),
        'authorization':'Owner: first section only; complete and publish each chapter before the next, then section outputs.'}
    prepare.quota.atomic_json(prepare.WORK / 'first-section-release.json', proof)
    print(json.dumps(proof))


def prepare_inputs(check_only=False):
    cut, records = inputs()
    bodies, gaps = preflight(records)
    WORK.mkdir(parents=True, exist_ok=True)
    summary = {'edition':EDITION, 'sourceCommit':cut['sourceCommit'], 'subjects':87, 'instructions':2958,
        'exactOriginalsAvailable':len(bodies), 'sourceReadySubjects':sum(not rows for rows in gaps.values()),
        'sourceGaps':{key:rows for key,rows in gaps.items() if rows}}
    prepare.quota.atomic_json(WORK / 'preflight.json', summary)
    print(json.dumps({key:value for key,value in summary.items() if key!='sourceGaps'}), flush=True)
    if check_only:
        return
    owner = prepare.adapter.load_module('generation-ownership')
    owner.WORK = WORK
    with owner.StageLock('source-import'):
        path = WORK / 'source-import.json'
        receipt = json.loads(path.read_text()) if path.exists() else {'schema':'ai-ba.adr025-inputs.v1', 'sources':{}}
        if receipt.get('preparationComplete'):
            return  # A changed input cut requires the existing coordinated hold.
        client = prepare.adapter.worker.get_client()
        title = 'AI Strategy and Business Architecture — N edition — balanced 2026-10-22'
        prepare.save_receipt = lambda value:prepare.quota.atomic_json(path, value)
        if not receipt.get('notebookId'):
            matches = [notebook for notebook in client.list_notebooks() if notebook.title == title]
            assert len(matches) <= 1, 'Ambiguous edition notebook'
            if not matches:
                assert not receipt.get('notebookIntentAt'), 'Uncertain notebook creation retained for reconciliation'
                receipt['notebookIntentAt'] = prepare.native.NOW()
                prepare.save_receipt(receipt)
                notebook = prepare.native.create_once(client, client.create_notebook, title, fenced_rpc=client.RPC_CREATE_NOTEBOOK)
            else:
                notebook = matches[0]
            receipt.update(notebookId=notebook.id, title=title, sourceCommit=cut['sourceCommit'])
            prepare.save_receipt(receipt)
        freeze(cut, records, receipt, bodies, gaps)
        # One attempt per unique source per pass. Uncertain imports retain their
        # durable intent and reconcile through the shared import owner.
        attempted = set()
        for record, entries in records:
            for binding in brief.selected_bindings(record, entries):
                key = HASH(binding['originalId'] + ':' + binding['sha256'])
                if key in attempted or key not in bodies:
                    continue
                attempted.add(key)
                try:
                    body = bodies[key]
                    prepare.import_text(client, receipt, key, prepare.literal_presentation(body),
                        binding['title'][:120] + ' [' + HASH(body)[:16] + ']', literal_body=body)
                except Exception as error:
                    if owner.safe_error(error).get('reason') == 'notebook-auth-expired':
                        raise
                    receipt['sources'].setdefault(key, {})['lastErrorType'] = type(error).__name__
                    prepare.save_receipt(receipt)
                    print(json.dumps({'originalDeferred':binding['originalId'], 'errorType':type(error).__name__}), flush=True)
            key, body = brief.editorial(record)
            try:
                prepare.import_text(client, receipt, key, prepare.literal_presentation(body),
                    'AI BA — ' + record['id'] + ' — matching synthesis [' + HASH(body)[:16] + ']', literal_body=body)
            except Exception as error:
                if owner.safe_error(error).get('reason') == 'notebook-auth-expired':
                    raise
                receipt['sources'].setdefault(key, {})['lastErrorType'] = type(error).__name__
                prepare.save_receipt(receipt)
            freeze(cut, [(record, entries)], receipt, bodies, gaps)
            print(json.dumps({'subjectInputsProcessed':record['id'], 'verifiedSources':sum(row.get('status')=='indexed-verified' for row in receipt['sources'].values())}), flush=True)
        freeze(cut, records, receipt, bodies, gaps)
        required = set(bodies) | {brief.editorial(record)[0] for record, _ in records}
        complete = all(receipt['sources'].get(key, {}).get('status') == 'indexed-verified' for key in required)
        receipt.update(preparationComplete=complete, preparedAt=prepare.native.NOW())
        prepare.save_receipt(receipt)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--reviewed-section-cut')
    parser.add_argument('--source-audit', type=Path)
    args = parser.parse_args()
    if args.reviewed_section_cut:
        assert args.source_audit and not args.check_only
        prepare_reviewed_section(args.reviewed_section_cut, args.source_audit)
    else:
        prepare_inputs(args.check_only)
