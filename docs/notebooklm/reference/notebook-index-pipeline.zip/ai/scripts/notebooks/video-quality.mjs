/** File-bound provider video admission; old custody bytes remain immutable. */
export function verifiedVideoKey({job,notebookId,hash,info,proof,originals}) {
  const sameSources=JSON.stringify([...(proof?.providerProof?.sourceIds??[])].sort())===JSON.stringify([...(job.providerProof?.sourceIds??[])].sort());
  const stream=proof?.metadata?.streams?.find(item=>item.codec_type==='video');
  if(Math.min(info.width,info.height)<720 || proof?.qualityVersion!==1 || proof.sha256!==hash ||
     proof.id!==job.id || proof.key!==job.key || !proof.providerProof?.settingsVerified || !proof.completeDecodePassed ||
     proof.providerProof.promptSha256!==job.providerProof?.promptSha256 || !sameSources ||
     stream?.width!==info.width || stream?.height!==info.height ||
     (proof.advertisedSizes??[]).some(([w,h])=>w*h>info.width*info.height)) {
    throw Error(`Video quality proof missing or mismatched: ${job.id}`);
  }
  const key=`custody/generation/${notebookId}/${job.id}.mp4`;
  return originals[key] && originals[key]!==hash?`custody/generation/${notebookId}/${job.id}-${hash.slice(0,16)}.mp4`:key;
}
