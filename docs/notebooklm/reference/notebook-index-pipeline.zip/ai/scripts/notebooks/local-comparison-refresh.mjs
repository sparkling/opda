/** Render the isolated concise N01 run through the existing EA notebook components. No provider/cloud writes. */
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
import {verifiedVideoKey} from './video-quality.mjs';
import {unifiedInputs,copyUnifiedInputs,unifiedHierarchy,focusedInputViews} from './local-unified-view.mjs';
const root=path.resolve(import.meta.dirname,'../..');
const requestedVariant=process.argv[2]??'concise-v1';
if(requestedVariant==='video-styles-v1'){await import('./video-styles-index.mjs');process.exit(0);}
const full=requestedVariant==='full-section-v1',applied=full||requestedVariant==='applied-rules-v1',current=requestedVariant==='tailored-v3',tailored=applied||current||requestedVariant==='tailored-v2',business=requestedVariant==='business-v1',minimal=tailored||business||requestedVariant==='minimal-v1',reconciledContent=minimal||requestedVariant==='content-v4',revisedContent=reconciledContent||requestedVariant==='content-v3',focusedSources=revisedContent||requestedVariant==='topic-sources-v2',unified=focusedSources||requestedVariant==='unified-v1';
const variant=unified?requestedVariant:'concise-v1';
// The narrowed trial gets its own page; never overwrite the retained six-scope index.
const viewId=full?'full-section-v1':applied?'applied-rules-v1-chapters-1-3':current?'tailored-v3-chapters-1-3':tailored?'tailored-v2-chapters-1-3':business?'business-v1-chapters-1-3':minimal?'minimal-v1-chapters-1-3':reconciledContent?'content-v4-chapters-1-3':revisedContent?'content-v3-chapters-1-2':variant;
if(!['concise-v1','refactored-synthesis-v1','edited-full-synthesis-v1','chapter-focused-synthesis-v1','content-screen-v1','content-confirmation-v2','unified-v1','topic-sources-v2','content-v3','content-v4','minimal-v1','business-v1','tailored-v2','tailored-v3','applied-rules-v1','full-section-v1'].includes(requestedVariant))throw Error('Unknown local comparison variant');
const work=path.join(root,'.local/n01-comparison');
const build=path.join(work,focusedSources?variant+'-build':unified?'unified-build':'concise-build'),version=path.join(work,'versions',viewId);
const read=async p=>JSON.parse(await fs.readFile(p,'utf8'));
const exists=async p=>fs.stat(p).then(()=>true,()=>false);
const hash=b=>createHash('sha256').update(b).digest('hex');
const save=async(p,value)=>{await fs.mkdir(path.dirname(p),{recursive:true});await fs.writeFile(p+'.pending',JSON.stringify(value,null,2));await fs.rename(p+'.pending',p);};
// Older delivery workers can remain alive; their retained indexes are now read-only.
if(!tailored&&await exists(path.join(version,'n01/index.html'))){
 console.log(JSON.stringify({retained:true,version:variant}));process.exit(0);
}
await fs.mkdir(build,{recursive:true});
const lockFile=path.join(build,'refresh.lock');
let lock;
for(let attempt=0;attempt<2;attempt++){
 try{lock=await fs.open(lockFile,'wx');await lock.writeFile(String(process.pid));break;}
 catch(e){
  if(e.code!=='EEXIST')throw e;
  const pid=Number(await fs.readFile(lockFile,'utf8'));let dead=false;
  if(Number.isSafeInteger(pid)&&pid>0){try{process.kill(pid,0);}catch(e){if(e.code==='ESRCH')dead=true;}}
  else dead=Date.now()-(await fs.stat(lockFile)).mtimeMs>60000;
  if(!dead){console.log('Local preview refresh already active');process.exit(0);}
  await fs.unlink(lockFile);
 }
}
if(!lock)throw Error('Could not recover local preview lock');
try{
const unifiedInput=unified?await unifiedInputs(root,variant):null;
const candidateFile=path.join(root,full?'config/authoring/N01-full-section-v1.json':applied?'config/authoring/N01-applied-rules-v1.json':current?'config/authoring/N01-tailored-v3.json':tailored?'config/authoring/N01-tailored-v2.json':business?'config/authoring/N01-business-v1.json':minimal?'config/authoring/N01-minimal-v1.json':reconciledContent?'config/authoring/N01-content-v4.json':revisedContent?'config/authoring/N01-content-v3.json':focusedSources?'config/authoring/N01-topic-sources-v2.json':unified?'config/authoring/N01-unified-v1.json':'config/authoring/experiments/N01-chapters-concise-v1.json');
const candidate=await read(candidateFile),sharedBytes=await fs.readFile(unified?candidateFile:path.join(root,candidate.sharedInstructions.path));
if(!unified&&hash(sharedBytes)!==candidate.sharedInstructions.sha256)throw Error('Shared instruction hash changed');
const sourceTitles=focusedSources?null:(await read(path.join(root,'config/authoring/notebook-communication.json'))).sourceTitles;
const shared=unifiedInput?.shared??JSON.parse(sharedBytes);
const chapterPromptsInput=unifiedInput?.prompts??await read(path.join(work,'candidates/N01-chapters-concise-v1/prompts.json'));
const overviewPrompts=unified?[]:await read(path.join(work,'candidates/N01-concise-v1/prompts.json'));
const prompts=[...overviewPrompts.map(p=>({...p,chapter:'N01'})),...chapterPromptsInput];
const synthesisFile=path.join(root,'config/authoring/experiments/N01-synthesis-refactored-v1.json');
const synthesisCandidate=unified?{subjects:unifiedInput.syntheses}:await read(synthesisFile);
const editedFile=path.join(root,'config/authoring/experiments/N01-synthesis-edited-full-v1.json');
const editedInput=!unified&&await exists(editedFile)?await read(editedFile):null;
const editedCandidate=editedInput?.review?.status==='reviewed-and-frozen'?editedInput:null;
const focusedFile=path.join(root,'config/authoring/experiments/N01-synthesis-chapter-focused-v1.json');
const focusedInput=!unified&&await exists(focusedFile)?await read(focusedFile):null;
const focusedCandidate=focusedInput?.review?.status==='reviewed-and-frozen'?focusedInput:null;
const screenInputs=[];const screenRequests=new Map();const screenRuns=new Map();
for(const id of unified?[]:['content-screen-v1','content-confirmation-v2']){
 const file=path.join(root,'config/authoring/experiments/N01-'+(id==='content-screen-v1'?'content-screen-v1':'content-confirmation-inputs-v2')+'.json'),runRoot=path.join(work,'runs',id);
 if(!await exists(file)||!await exists(path.join(runRoot,'request-inputs.json')))continue;
 const input=await read(file),snapshots=await read(path.join(runRoot,'request-inputs.json'));
 if(input.review?.status!=='reviewed-and-frozen')continue;
 if(snapshots.manifestSha256!==hash(await fs.readFile(file)))throw Error('Content snapshot differs from frozen manifest: '+id);
 screenInputs.push(input);
 for(const request of snapshots.requests){screenRequests.set(request.cell.id,request);screenRuns.set(request.cell.id,{runRoot,manifestSha256:snapshots.manifestSha256});}
}
const screen=screenInputs.length?{...screenInputs[0],cells:screenInputs.flatMap(x=>x.cells),factors:Object.fromEntries(screenInputs.map(x=>[x.id,x.factors]))}:null;
const conditions={without:{id:'without',label:'Without synthesis',version:1},original:{id:'original',label:'Original synthesis',version:1},refactored:{id:'refactored',label:'Refactored synthesis',version:2},'edited-full':{id:'edited-full',label:'Edited full synthesis',version:3},'chapter-focused':{id:'chapter-focused',label:'Chapter-focused package',version:4}};
const conditionFor=job=>unified?{id:job.topicId,label:job.topicTitle,version:job.version}:job.experimentCell?{id:job.version===6?job.experimentCell:job.condition,label:job.version===6?'Round two '+job.condition+' — repeat '+job.replicate:'Content screen '+job.condition,version:job.version}:conditions[job.synthesisVariant??(job.editorial?'original':'without')];
const focusedPrompt=(chapter,treatment)=>[shared.purposeAndAudience,chapter.basePrompt,focusedCandidate?.inputOverrides?.treatmentPrompts?.[chapter.id]?.[`${treatment.type}-${treatment.format}-${treatment.ordinal}`]??treatment.prompt,shared.evidenceInstruction,shared.language].join('\n\n');
const plannedSubjects=(unifiedInput?.subjects??[{id:'N01',title:shared.title,baseline:{path:shared.baseline.subjectPath,sha256:shared.baseline.subjectSha256},basePrompt:shared.subjectBrief,treatments:shared.treatments},...candidate.chapters]).filter(chapter=>full||!revisedContent||(reconciledContent?['N01.01','N01.02','N01.03']:['N01.01','N01.02']).includes(chapter.id));
const sdk=path.join(process.env.HOME,'.local/share/uv/tools/notebooklm-mcp-cli/bin/python3');
// Local preview alone opts into the verified shared condition-grouping revision.
const previewPin={...(await read(path.join(root,'config/shared-renderer.json'))),revision:'1d07ebb18543f76b65586550c728b63cdb40c6f5'};
previewPin.checkout=path.resolve(root,previewPin.checkout);
const rendererRoot=path.join(work,'renderer');await save(path.join(rendererRoot,'config/shared-renderer.json'),previewPin);
const rendererProof=JSON.parse(execFileSync(sdk,['-c',`import importlib.util,json,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('shared_renderer',sys.argv[1])
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
print(json.dumps(m.resolve_renderer(Path(sys.argv[2]))))`,path.resolve(root,'../semantic-solution-architecture/src/programme/shared-renderer.py'),rendererRoot],{encoding:'utf8'}));
const renderer=rendererProof.directory;
rendererProof.conditionComponentSha256=hash(await fs.readFile(path.join(renderer,'site/src/components/CognitiveMultimedia.astro')));
const {details,prepareRenditions,digest,videoInfo}=await import(pathToFileURL(path.join(renderer,'site/scripts/media-originals.mjs')));
const {renderPdfSlides}=await import(pathToFileURL(path.join(renderer,'site/scripts/pdf-slide-images.mjs')));
const stateFile=path.join(build,'renditions.json'),state=await exists(stateFile)?await read(stateFile):{};
const publicDir=path.join(build,'public');await fs.mkdir(publicDir,{recursive:true});
for(const folder of ['fonts','type','images']){
 const source=path.join(work,'versions/baseline',folder),dest=path.join(publicDir,folder);
 if(await exists(source)&&!await exists(dest))await fs.symlink(source,dest,'dir');
}
if(!await exists(path.join(build,'node_modules')))await fs.symlink(path.join(root,'site/node_modules'),path.join(build,'node_modules'),'dir');
const subjects=[],allItems=[],errors=[];let requested=0;
const same=(a,b)=>JSON.stringify([...(a??[])].sort())===JSON.stringify([...(b??[])].sort());
for(const chapter of plannedSubjects){
 // Focused views use their frozen native source readbacks, never today's legacy chapter.
 let original=null;
 if(!focusedSources){const bytes=await fs.readFile(path.join(root,chapter.baseline.path));if(hash(bytes)!==chapter.baseline.sha256)throw Error('Chapter source changed: '+chapter.id);original=JSON.parse(bytes);}
 const newSynthesis=synthesisCandidate?.subjects.find(s=>s.id===chapter.id),editedSynthesis=editedCandidate?.subjects.find(s=>s.id===chapter.id),focusedSynthesis=focusedCandidate?.subjects.find(s=>s.id===chapter.id);
 if(focusedSynthesis&&(hash(focusedSynthesis.body)!==focusedSynthesis.sha256||focusedSynthesis.baseline.sha256!==chapter.baseline.sha256))throw Error('Chapter-focused synthesis identity mismatch: '+chapter.id);
 if(editedSynthesis&&(hash(editedSynthesis.body)!==editedSynthesis.sha256||editedSynthesis.baseline.sha256!==chapter.baseline.sha256))throw Error('Edited full synthesis identity mismatch: '+chapter.id);
 if(!unified&&(!newSynthesis||hash(newSynthesis.body)!==newSynthesis.sha256||newSynthesis.baseline.sha256!==chapter.baseline.sha256))throw Error('Refactored synthesis identity mismatch: '+chapter.id);
 const runs=await Promise.all((unified?(requestedVariant==='content-v4'&&await exists(path.join(work,'runs/whole-chapter-v1/request-inputs.json'))?[variant,'whole-chapter-v1']:[variant]):['concise-v1','refactored-synthesis-v1','edited-full-synthesis-v1','chapter-focused-synthesis-v1']).map(async id=>{const runRoot=path.join(work,'runs',id),ledgerPath=path.join(runRoot,'docs/generation',chapter.id+'.json');const run=await exists(ledgerPath)?await read(ledgerPath):null;return {runRoot,run,selection:run?.subjects?.find(s=>s.id===chapter.id)};}));
 const selection=runs[0].selection,refactoredSelection=runs[1]?.selection,editedSelection=runs[2]?.selection,focusedSelection=runs[3]?.selection;
 for(const cell of screen?.cells.filter(c=>c.chapter===chapter.id)??[]){
  const {runRoot,manifestSha256}=screenRuns.get(cell.id);const file=path.join(runRoot,'docs/generation',cell.id+'.json');if(!await exists(file))continue;
  const run=await read(file);if(run.manifestSha256!==manifestSha256)throw Error('Content-screen ledger cut changed');
  runs.push({runRoot,run,selection:run.subjects[0]});
 }
 const jobs=runs.flatMap(context=>(context.run?.jobs??[]).map(job=>({...job,context})));
 const perSubject=jobs.filter(j=>!j.reusedFrom).length;requested+=perSubject;
 const chapterPrompts=prompts.filter(p=>p.chapter===chapter.id),items=[];
 for(const job of jobs){
  const {runRoot,run,selection}=job.context,replacement=job.synthesisVariant==='chapter-focused'?focusedSynthesis:job.synthesisVariant==='edited-full'?editedSynthesis:job.synthesisVariant==='refactored'?newSynthesis:null;
  if(job.reusedFrom||job.status!=='completed'||!job.id||!job.providerProof?.settingsVerified)continue;
  try{
   if(job.synthesisVariant&&(!replacement||!job.editorial||!selection?.editorialSourceId||selection.editorialSourceId===replacement.baseline.uploadedSourceId||selection.editorialSha256!==replacement.sha256))throw Error('Wrong replacement synthesis condition');
   const snapshot=unified?unifiedInput.requests.get(job.key):screenRequests.get(job.experimentCell);
   if(unified&&(!snapshot||snapshot.completeInputSha256!==job.completeInputSha256||snapshot.consumedCreateArguments.notebook_id!==run.notebookId))throw Error('Unified request differs from frozen snapshot');
   const expectedSources=unified?snapshot.consumedCreateArguments.source_ids:[...(selection?.factualSourceIds??[]),...(selection?.communicationSourceIds??[]),...(job.editorial?[selection?.editorialSourceId]:[])];
   if(!same(job.sourceIds,expectedSources))throw Error('Selected sources differ from the experiment ledger');
   if(job.synthesisVariant==='chapter-focused'&&(!same(selection.factualSourceIds,runs[0].selection.factualSourceIds.filter(id=>!focusedCandidate.inputOverrides.excludedSourceIds.includes(id)))||!same(selection.communicationSourceIds,runs[0].selection.communicationSourceIds)))throw Error('Chapter-focused source exclusions differ from the frozen package');
   const treatment=chapter.treatments.find(t=>t.type===job.type&&t.format===job.format&&t.ordinal===job.ordinal);
   const p=chapterPrompts.find(p=>p.treatmentId===treatment?.id);
   if(job.experimentCell&&(!snapshot||job.completeInputSha256!==snapshot.completeInputSha256||!same(expectedSources,snapshot.consumedCreateArguments.source_ids)||JSON.stringify(job.settings)!==JSON.stringify({...snapshot.adapterEnvelope,notebook_id:undefined,title:undefined,source_ids:undefined,focus_prompt:undefined})))throw Error('Content-screen request differs from submitted snapshot');
   const expectedPrompt=snapshot?.consumedCreateArguments.focus_prompt??(p&&(job.synthesisVariant==='chapter-focused'?focusedPrompt(chapter,treatment):p.prompt));
   if(!p||selection.mediaPrompts[job.medium]!==expectedPrompt||hash(expectedPrompt)!==job.promptSha256||job.providerProof.promptSha256!==job.promptSha256||!same(job.sourceIds,job.providerProof.sourceIds))throw Error('Input proof does not match the frozen commission');
   if(!/^[a-f0-9-]{36}$/.test(job.id)||!/^[a-f0-9-]{36}$/.test(run.notebookId)||!/^[-\w.]+$/.test(job.key))throw Error('Unsafe media identity');
   const ext={slide_deck:'pdf',video:'mp4',audio:'m4a',infographic:'png'}[job.type];
   const source=path.join(runRoot,'originals',job.key+'.'+ext);if(!await exists(source))continue;
   const sha=await digest(source);let custody=`custody/generation/${run.notebookId}/${job.id}.${ext}`;
   if(job.type==='video')custody=verifiedVideoKey({job,notebookId:run.notebookId,hash:sha,info:videoInfo(source),proof:await read(path.join(runRoot,'transfers/video-readiness',job.id+'.json')),originals:{}});
   const prefix=`/presentations/ai-ba-${chapter.id.toLowerCase().replace('.','-')}/media/`,destination=path.join(publicDir,prefix);
   await fs.mkdir(destination,{recursive:true});await fs.mkdir(path.dirname(path.join(publicDir,custody)),{recursive:true});
   if(!await exists(path.join(publicDir,custody)))await fs.copyFile(source,path.join(publicDir,custody));
   if(await digest(path.join(publicDir,custody))!==sha)throw Error('Original custody changed');
   let item=state[job.id];
   if(!item||item.original.sha256!==sha){
    const origin=await details(source,'/'+custody);
    const {context,...request}=job;
    const common={...request,original:origin,prefix,editorialTerm:'Synthesis',version:conditionFor(job).version,qualityStatus:unified?'Owner-authorised production; provider and file verified; content available for review':'Local experiment; provider/file verified, content quality not yet reviewed',notebook:`https://notebooklm.google.com/notebook/${run.notebookId}?artifactId=${job.id}`};
    if(job.type==='slide_deck'){
     const rendered=await renderPdfSlides({pdf:source,destination,id:job.id,urlPrefix:prefix,width:1376,renderer:'pdfium'});
     item={...common,slug:job.id,pdf:origin.path,slideCount:rendered.slides.length,cover:rendered.slides[0],...rendered};
    }else item={...common,...await prepareRenditions({original:source,destination,id:job.id,type:job.type,preview:prefix+job.id+'-preview.webp',poster:prefix+job.id+'-poster.webp'})};
    state[job.id]=item;await save(stateFile,state);
   }
   items.push({...item,conditionId:conditionFor(job).id,conditionLabel:conditionFor(job).label,level:subjects.length,title:job.title.replace(/with(out)?-editorial/gi,(_,out)=>out?'without synthesis':'with synthesis')});
  }catch(e){errors.push({subject:chapter.id,key:job.key,error:e.message});}
 }
 const sourceText=(original?.sourceBindings??[]).map(s=>{
  const actual=selection?.originalSources?.find(a=>a.originalId===s.originalId&&a.sha256===s.sha256);
  return `## ${s.title}\n\nRole: ${s.role}; owner: ${s.owner}; status: ${s.status}\n\n${s.contribution}\n\nSelected passage: ${s.passage}\n\nUse: ${s.use}\n\nLimits: ${s.limits}\n\nOriginal: ${s.originalId}\n\nSHA256: ${s.sha256}\n\nUploaded title: ${sourceTitles?.[s.sha256]??actual?.title??'Not recorded'}\n\nUploaded source ID: ${actual?.sourceId??'Not yet recorded in this experiment'}\n\n`;
 }).join('\n');
 const submitted=chapterPrompts.map(p=>{
  const t=chapter.treatments.find(t=>t.id===p.treatmentId),matching=jobs.filter(j=>!j.experimentCell&&j.type===t.type&&j.format===t.format&&j.ordinal===t.ordinal);
  const actualPrompt=selection?.mediaPrompts?.[`${t.type}-${t.format}-${t.ordinal}`]??p.prompt;
  if(hash(actualPrompt)!==p.sha256)throw Error('Ledger prompt differs from concise candidate: '+p.treatmentId);
  return `## ${p.treatmentId} — ${t.format} ${t.ordinal}\n\n${actualPrompt}\n\nSHA256: ${p.sha256}\n\n`+(matching.length?matching.map(j=>`### ${conditionFor(j).label}${j.repeatOf?' — repeat '+j.repeatNumber:''}\n\n${j.repeatOf?'Repeat of request: '+j.repeatOf+'; commission: '+j.repeatCommission+'\n\n':''}Status: ${j.status}; artefact: ${j.id??'not submitted'}; submitted: ${j.attemptedAt??'not yet'}.\n\n${j.synthesisVariant==='chapter-focused'?'Exact submitted package prompt:\n\n'+j.context.selection.mediaPrompts[j.medium]+'\n\nPrompt SHA256: '+j.promptSha256+'\n\n':''}Prompt matches frozen condition: ${j.promptSha256===hash(j.synthesisVariant==='chapter-focused'?focusedPrompt(chapter,t):p.prompt)}\n\nSettings:\n\n\`\`\`json\n${JSON.stringify(j.settings,null,2)}\n\`\`\`\n\nSource IDs: ${(j.sourceIds??[]).join(', ')}`).join('\n\n'):'Prepared candidate, not yet submitted.');
 }).join('\n\n');
 const views=focusedSources?focusedInputViews(unifiedInput,chapter,jobs):[
  {id:'shared',label:'Shared purpose & evidence',text:`# Shared instructions\n\n${shared.purposeAndAudience}\n\n${shared.evidenceInstruction}\n\n${shared.language}`},
  {id:'formats',label:'Format & assembly',text:`# Actual assembly\n\n${unified?'One shared purpose, subject commission, topic, useful format delta, evidence contract and language. Local metadata is not a privileged provider role.':candidate.assembly}\n\nNative settings are retained per request below. No old format paragraphs, media suffixes or section overview brief are appended.`},
  {id:'subject',label:chapter.id==='N01'?'Section brief':'Chapter brief',text:`# ${chapter.id} — ${chapter.title}\n\n${chapter.basePrompt}\n\nEdited from ${chapter.baseline.path}; original SHA256 ${chapter.baseline.sha256}.`},
  {id:'treatments',label:unified?'Topics & format treatments':'Concise artefact treatments',text:chapter.treatments.map(t=>`## ${t.id} — ${t.format} ${t.ordinal}\n\n${t.prompt}`).join('\n\n')},
  {id:'sources',label:'Evidence & source selection',text:'# Retained source selection\n\nThese identities describe actual selected source custody, not instructions to open local files.\n\n'+sourceText},
  ...(unified?[{id:'actual-inputs',label:'Selected source bodies & parameters',text:'# Actual selected source data\n\nOne source ID selects its entire indexed body. The complete readbacks match the retained indexed hashes; original-byte and indexed-text identities remain distinct.\n\n'+[...selection.factualSourceIds,...selection.communicationSourceIds,selection.editorialSourceId].map(id=>`- [${unifiedInput.sourceProof.sources[id].title}](http://127.0.0.1:8932/v/unified-v1/inputs/sources/${id}.txt) — ${id}; indexed SHA256 ${unifiedInput.sourceProof.sources[id].indexedTextSha256}`).join('\n')+'\n\n[All 198 resolved parameter packages](http://127.0.0.1:8932/v/unified-v1/inputs/request-inputs.json)'}]:[]),
  ...(unified?[[newSynthesis,selection,'Synthesis source']]:[[original.synthesis,selection,'Original synthesis source'],[newSynthesis,refactoredSelection,'Refactored synthesis source'],...(editedSynthesis?[[editedSynthesis,editedSelection,'Edited full synthesis source']]:[]),...(focusedSynthesis?[[focusedSynthesis,focusedSelection,'Chapter-focused synthesis source']]:[])]).map(([source,binding,label],i)=>({id:'synthesis-'+i,label,text:`# ${source.title}\n\n${unified?'The selected subject-specific attributed interpretation. It is content, not independent corroboration or another production prompt.':source===focusedSynthesis?'This source is part of the Chapter-focused package: synthesis, two source deselections and the N01.05 reading clarification. See package inputs and exact submitted prompts.':i?'Only this source replaces the original synthesis; concise prompts, other sources and settings stay the same.':'Original attributed interpretation, added only in the original-synthesis condition.'}\n\nUploaded synthesis source ID: ${binding?.editorialSourceId??'Not yet recorded'}; SHA256: ${binding?.editorialSha256??'Not yet recorded'}.\n\n${source.body}`})),
  ...(focusedSynthesis?[{id:'focused-package',label:'Chapter-focused package inputs',text:'# Revised input package\n\nThis comparison changes the synthesis, deselects two historical BA/EA sources and clarifies independent reading in the N01.05 treatment. Previous source selections and outputs are retained.\n\nDeclared changes:\n\n```json\n'+JSON.stringify(focusedCandidate.inputOverrides,null,2)+'\n```\n\n'+(runs[3].run?.jobs??[]).map(j=>'## '+j.title+'\n\n```json\n'+JSON.stringify({...j.settings,notebook_id:runs[3].run.notebookId,title:j.title,source_ids:[...focusedSelection.factualSourceIds,...focusedSelection.communicationSourceIds,focusedSelection.editorialSourceId],focus_prompt:focusedSelection.mediaPrompts[j.medium]},null,2)+'\n```').join('\n\n')}]:[]),
  {id:'submitted',label:'Exact prompts & run status',text:'# Exact prompts and request records\n\n'+submitted},
  ...(screen?.chapters.some(c=>c.id===chapter.id)?[{id:'content-screen',label:'Content screen: exact inputs & status',text:'# ADR049 content screen\n\n'+JSON.stringify(screen.factors,null,2)+'\n\n'+screen.c1Rationale+'\n\nFirst-screen cells and fresh round-two repeats retain separate identities. Reused artifacts are earlier observations, not new replications. Native settings stay fixed. Source role/use/limits below are inspection metadata; the provider receives selected whole source bodies and the focus prompt. Title is in the adapter envelope but absent from the consumed create arguments.\n\n'+screen.cells.filter(c=>c.chapter===chapter.id).map(c=>{
   const snapshot=screenRequests.get(c.id),job=jobs.find(j=>j.experimentCell===c.id);
   return '## '+c.id+'\n\nStatus: '+(job?.status??'prepared, unsubmitted')+'; artifact: '+(job?.id??'none')+(c.reuse?' — reused earlier artifact; rescore required':'')+'.\n\n'+(job?.id?'[Open deck](http://127.0.0.1:8932/v/concise-v1/n01/#ai-ba-'+chapter.id.toLowerCase().replace('.','-')+'/media/'+job.id+')\n\n':'')+'```json\n'+JSON.stringify(snapshot,null,2)+'\n```';
  }).join('\n\n')}]:[]),
 ];
 const topicInputs=focusedSources?chapter.topics.map(topic=>{
  const requests=[...unifiedInput.requests.values()].filter(r=>r.topic.id===topic.id);
  const sourceIds=requests[0].consumedCreateArguments.source_ids;
  if(!requests.every(r=>same(r.consumedCreateArguments.source_ids,sourceIds)))throw Error('Topic formats select different focused sources: '+topic.id);
  return {topicId:topic.id,sourceIds,requests:requests.map(({key,completeInputSha256,promptComponents,consumedCreateMethod,consumedCreateArguments})=>({key,completeInputSha256,promptComponents,consumedCreateMethod,consumedCreateArguments}))};
 }):null;
 subjects.push({id:chapter.id,title:chapter.title,...(unified?{topics:chapter.topics,selectedSourceIds:focusedSources?[...new Set(topicInputs.flatMap(t=>t.sourceIds))]:[...selection.factualSourceIds,...selection.communicationSourceIds,selection.editorialSourceId],...(topicInputs?{topicInputs}:{}),jobs:jobs.map(({context,...job})=>job)}:{}),description:unified?chapter.basePrompt:`${items.length} of ${perSubject} revised artefacts ready locally. ${perSubject-items.length} pending. No old chapter media is substituted.`,brief:{id:chapter.id.replace('.','-'),editorialTerm:'Synthesis',editorialVersion:1,readingViews:views}});
 allItems.push(...items);
}
const data={unified,...(applied?{inspectionModel:'three-views'}:{}),...(unified?{sourceProof:unifiedInput.sourceProof.sources}:{}),renderer:rendererProof,subjects,requested,variant:viewId,archiveRequested:unifiedInput?.snapshot.requests.length,conditionLabel:applied?(candidate.title??'Applied content rules · chapters 1–3'):current?'Current topic instructions v3 · chapters 1–3':tailored?'Tailored sources and infographic detail · chapters 1–3':business?'Business-facing sources · chapters 1–3':minimal?'Minimal steering · chapters 1–3':reconciledContent?'Content v4 · chapters 1–3':revisedContent?'Content v3 · chapters 1–2 only':focusedSources?'Topic sources v2 · overview and chapters 1–2':unified?'Unified content package':'Without synthesis · Original synthesis · Refactored synthesis'+(editedCandidate?' · Edited full synthesis':'')+(focusedCandidate?' · Chapter-focused package':'')+(screen?' · Content screen':''),available:allItems.length,updatedAt:new Date().toISOString(),errors,catalogue:{decks:allItems.filter(i=>i.type==='slide_deck').map(i=>({...i,slug:i.prefix.replace(/^\/presentations\//,'')+i.slug})),multimedia:allItems.filter(i=>i.type!=='slide_deck')}};
const signature=hash(JSON.stringify({...data,updatedAt:null,rendererCode:hash(await fs.readFile(import.meta.filename)),unifiedCode:unified?hash(await fs.readFile(new URL('./local-unified-view.mjs',import.meta.url))):null}));
if(await exists(path.join(version,'version.json'))&&(await read(path.join(version,'version.json'))).fingerprint===signature){console.log(JSON.stringify({unchanged:true,available:data.available,errors}));process.exitCode=0;}
else{
await save(path.join(build,'data.json'),data);await fs.mkdir(path.join(build,'src/pages/n01'),{recursive:true});
await fs.writeFile(path.join(build,'astro.config.mjs'),`import {defineConfig} from 'astro/config';import react from '@astrojs/react';export default defineConfig({integrations:[react()],cacheDir:'./.astro-cache',output:'static',trailingSlash:'always',devToolbar:{enabled:false},vite:{environments:{prerender:{resolve:{noExternal:['@astrojs/react']}}},resolve:{dedupe:['react','react-dom'],alias:{'@ea':${JSON.stringify(path.join(renderer,'site/src'))}}}},server:{host:'127.0.0.1'}});`);
await fs.writeFile(path.join(build,'src/pages/n01/index.astro'),`---\nimport NotebookSubjectCollection from ${JSON.stringify(path.join(renderer,'site/src/components/NotebookSubjectCollection.astro'))};\nimport data from '../../../data.json';\nconst shell={canonicalOrigin:'https://ba.ai.hm.sparklingideas.co.uk',brandTitle:${JSON.stringify(unified?'LOCAL N01 COLLECTION':'LOCAL N01 COMPARISON')},bodyClass:${JSON.stringify(unified?'notebook-index collapsible-index unified-index':'notebook-index collapsible-index')},homeHref:'/n01/',comments:false,chat:false};\n---\n<NotebookSubjectCollection levels={data.subjects.map(s=>[s.title])} descriptions={data.subjects.map(s=>s.description)} subjectIds={data.subjects.map(s=>s.id)} briefs={data.subjects.map(s=>s.brief)} catalogue={data.catalogue} multimedia={data.catalogue.multimedia} prefix="/presentations/" configured heading={data.unified?"The case for an AI-enabled H&M":"The case for an AI-enabled H&M — "+data.conditionLabel} title={"N01 — "+data.conditionLabel} eyebrow=${JSON.stringify(applied?"Local collection · applied content rules":current?"Local comparison · current topic instructions v3":tailored?"Local comparison · tailored sources and infographic detail":business?"Local comparison · business-facing sources":minimal?"Local comparison · minimal steering":reconciledContent?"Local collection · content v4":revisedContent?"Local collection · content v3":focusedSources?"Local collection · topic sources v2":unified?"Local collection · one content package":"Local comparison · revised instructions")} intro=${JSON.stringify(applied?candidate.description:current?"The tailored-v2 sources, selections, 59 topics and native settings are retained. The independent-reading deck component is removed before request freezing. Earlier runs remain available with their original instructions.":tailored?"Tailored source readings and selections, with the existing concise topic commissions, a shared audience sentence and one independent-reading sentence for decks. No extra synthesis sources are selected. Chapters 1–3 retain focused topics and complete chapter sets. Every infographic topic has two takes at each native concise, standard and detailed level; other native settings are retained. This is a holistic package comparison with no selected winning detail level. Earlier runs remain available.":business?"Business-facing sources; the same light prompts. Chapters 1–3, focused topics and complete chapter sets. Tests whether clearer accounts of work, opportunity and value improve understanding and appeal. Earlier runs remain available for comparison.":minimal?"The same topics, sources and native settings as the previous run, with only a short subject and audience instruction. Fresh artefacts for chapters 1–3, including each complete chapter. Earlier runs remain available for comparison.":reconciledContent?"Explore the first three numbered chapters with the reviewed ADR054 topics, complete focused evidence and optional interpretations. The ADR052 instruction structure and native settings are unchanged. The section overview and chapters 4–5 are excluded.":revisedContent?"Explore chapters 1 and 2 with lighter instructions, cleaned topic evidence and selected interpretations. The section overview and chapters 3–5 are excluded from this page. Native formats and settings are unchanged.":focusedSources?"Explore the overview and chapters 1–2 with reviewed sources selected for each topic. Prompts and native settings are unchanged from v1.":unified?"Explore the overview and five chapters by media type, topic and format. Every topic belongs to one complete content package.":"Revised section overview and five chapters. Compare the available synthesis conditions together within each subject.")} path="/n01/" label="Chapter" shell={shell}><div slot="intro"><p>{data.available} of {data.requested} revised artefacts ready locally. Pending work is not represented by old media. Content quality is for owner review.</p><p><a href="/">All runs and tested changes</a> · <a href="/v/baseline/n01/#system-0">Open published N01 baseline</a></p>${focusedSources?'<p><a href="/v/unified-v1/n01/">Open retained unified v1</a></p>':''}<p>Updated {data.updatedAt}. ${unified?"Refresh to see new completed downloads. Open a subject’s input controls to inspect the exact commissioned package.":"Refresh the comparison to see completed downloads. All inspection buttons describe this experiment."}</p>{data.errors.length>0&&<p>{data.errors.length} media files await local rendition/proof repair; other completed artefacts remain available.</p>}</div></NotebookSubjectCollection>`);
// The page imports data relative to its location three levels below build/src.
await fs.copyFile(path.join(build,'data.json'),path.join(build,'src/data.json'));
execFileSync(path.join(root,'site/node_modules/.bin/astro'),['build','--root',build],{cwd:root,stdio:'pipe'});
await fs.mkdir(version,{recursive:true});
// Copy static assets first; install the new HTML last so a refresh never sees missing new assets.
for(const folder of ['_astro','fonts','type','images','presentations','custody'])if(await exists(path.join(build,'dist',folder)))await fs.cp(path.join(build,'dist',folder),path.join(version,folder),{recursive:true,force:false});
await fs.mkdir(path.join(version,'n01'),{recursive:true});
const builtHtml=await fs.readFile(path.join(build,'dist/n01/index.html'),'utf8');
const renderedHtml=unified?unifiedHierarchy(builtHtml,data):builtHtml.replaceAll('With Synthesis v1','Original synthesis').replaceAll('With Synthesis v2','Refactored synthesis').replaceAll('With Synthesis v3','Edited full synthesis').replaceAll('With Synthesis v4','Chapter-focused package').replaceAll('Without Synthesis','Without synthesis');
await fs.writeFile(path.join(version,'n01/index.html.pending'),renderedHtml);await fs.rename(path.join(version,'n01/index.html.pending'),path.join(version,'n01/index.html'));
if(unified){await fs.writeFile(path.join(version,'instructions.md'),unifiedInput.instructions);await copyUnifiedInputs(unifiedInput,version);}
else{
await fs.writeFile(path.join(version,'instructions.md'),await fs.readFile(path.join(work,'candidates/N01-concise-v1/instructions.md'),'utf8')+'\n\n'+await fs.readFile(path.join(work,'candidates/N01-chapters-concise-v1/instructions.md'),'utf8'));
await fs.appendFile(path.join(version,'instructions.md'),'\n\n# Refactored synthesis sources\n\n'+synthesisCandidate.subjects.map(s=>'## '+s.id+' — '+s.title+'\n\n'+s.body+'\n\nBody SHA256: '+s.sha256).join('\n\n'));
if(editedCandidate)await fs.appendFile(path.join(version,'instructions.md'),'\n\n# Edited full synthesis sources\n\n'+editedCandidate.subjects.map(s=>'## '+s.id+' — '+s.title+'\n\n'+s.body+'\n\nBody SHA256: '+s.sha256).join('\n\n'));
if(focusedCandidate)await fs.appendFile(path.join(version,'instructions.md'),'\n\n# Chapter-focused synthesis sources\n\n'+focusedCandidate.subjects.map(s=>'## '+s.id+' — '+s.title+'\n\n'+s.body+'\n\nBody SHA256: '+s.sha256).join('\n\n'));
}
await save(path.join(version,'release.json'),data);
await save(path.join(version,'version.json'),{id:viewId,label:(applied?(candidate.title??'Applied content rules · chapters 1–3'):current?'Current topic instructions v3 · chapters 1–3':tailored?'Tailored sources and infographic detail · chapters 1–3':business?'Business-facing sources · chapters 1–3':minimal?'Minimal steering · chapters 1–3':reconciledContent?'N01 content v4 · chapters 1–3':revisedContent?'N01 content v3 · chapters 1–2':focusedSources?'N01 topic sources v2':unified?'Unified N01':'Concise: all synthesis conditions')+(data.available===data.requested?' — all media ready':' — in progress'),artefacts:data.available,instructions:'instructions.md',createdAt:data.updatedAt,updatedAt:data.updatedAt,experimentSha256:hash(await fs.readFile(candidateFile)),synthesisCandidateSha256:unified?null:hash(await fs.readFile(synthesisFile)),editedFullSynthesisCandidateSha256:editedCandidate?hash(await fs.readFile(editedFile)):null,chapterFocusedSynthesisCandidateSha256:focusedCandidate?hash(await fs.readFile(focusedFile)):null,fingerprint:signature,note:applied?candidate.description:current?'Instruction-only successor to tailored-v2: 59 topics and 239 request packages, with exact sources, selections and native settings retained. Only the named deck instruction component is removed. Historical requests stay frozen; media counts report actual delivery.':tailored?'Holistic source-package and prompt trial with the same 59 topics. Two infographic takes at each native concise, standard and detailed level: 168 infographics plus 26 videos, 18 decks and 27 audio recordings, 239 fresh artefacts in total. Other native settings are retained. No single causal attribution or winning detail level is asserted. Exact sources, prompts and settings are inspectable; prior runs stay frozen.':business?'Tests business-facing evidence and interpretation bodies with the same minimal prompts, 59 topics, native formats and settings as minimal-v1. Each request shows its current source selection, full revised bodies and retained provenance. 127 fresh artefacts requested; quality remains for owner review.':minimal?'Tests removing written steering. Every prompt contains only the topic subject and audience (15–24 words). Removes repeated chapter framing, required talking points, evidence-rule boilerplate and medium treatment. The 47 focused topics plus 12 complete-chapter topics, all 37 source bodies, per-topic selections, selected interpretations and native formats/settings are unchanged. Fresh generation of 127 artefacts; no old media substituted.':`${data.available} / ${data.requested} revised artefacts ready; ${data.subjects.length} scopes. ${data.conditionLabel}.`,publishedBaseline:null});
console.log(JSON.stringify({available:data.available,pending:data.requested-data.available,url:unified?`http://127.0.0.1:8932/v/${viewId}/n01/`:'http://127.0.0.1:8932/n01/',errors}));
}
const oldPage=path.join(work,'versions/refactored-synthesis-v1/n01/index.html');
if(!unified&&await exists(oldPage)){
 if(!await exists(oldPage+'.archived'))await fs.copyFile(oldPage,oldPage+'.archived');
 await fs.writeFile(oldPage+'.pending','<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=/v/concise-v1/n01/"><title>N01 comparison moved</title><a href="/v/concise-v1/n01/">Open all three conditions in the concise comparison</a>');
 await fs.rename(oldPage+'.pending',oldPage);
}
// The existing delivery worker invokes refresh continuously; publication needs no agent loop.
if(full)execFileSync(process.execPath,[path.join(root,'scripts/notebooks/publication.mjs'),'--variant',variant],{cwd:root,stdio:'inherit'});
}finally{await lock.close();await fs.unlink(path.join(build,'refresh.lock'));}
