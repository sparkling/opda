"""Review frozen generation inputs or explicitly revised, unsubmitted inputs."""
import argparse
import hashlib
import json
import subprocess
import types
from pathlib import Path
from markdown_it import MarkdownIt
import brief

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.local/notebook-instructions-review'
SOURCE_AUDIT = ROOT / '.local/adr030-creative-improvement-20261022/source-audit.json'
md = MarkdownIt('commonmark', {'html': False}).enable('table')


def read(path):
    return json.loads(Path(path).read_text())


def verified(path, digest):
    body = Path(path).read_bytes()
    assert brief.HASH(body) == digest, str(path)
    return json.loads(body)


def historical_bytes(commit, path, digest):
    body = subprocess.check_output(['git', 'show', commit + ':' + path], cwd=ROOT)
    assert brief.HASH(body) == digest, path
    return body


def historical_run(identity, commit):
    current = ROOT / 'docs/generation' / (identity+'.json')
    run = read(current)
    if run['sourceCommit'] == commit:
        return run
    for manifest_path in sorted((ROOT / 'docs/generation/history').glob('*/manifest.json')):
        manifest = read(manifest_path)
        digest = manifest.get('ledgerHashes', {}).get(current.name)
        if digest:
            candidate = verified(manifest_path.parent / current.name, digest)
            if candidate['sourceCommit'] == commit:
                return candidate
    raise AssertionError('Complete historical generation ledger unavailable: '+identity)


def selection(record, config, audit):
    """Bind fresh body-read proof to these exact originals and matching synthesis."""
    assert audit['complete'] and audit['jobsCreated'] == 0
    actual = audit['subjects'][record['id']]
    expected = {'factualSourceIds': [], 'communicationSourceIds': []}
    documents = []
    titles = {}
    for binding in record['sourceBindings']:
        if config.get('promptAssembly') == 'topic-and-audience-v1' and binding['role'] == 'communication-authority':
            documents.append({'label':binding['title'], 'title':binding['title'], 'sourceId':None,
                'role':binding['role'], 'sha256':binding['sha256'], 'completeReadVerified':False, 'selected':False})
            continue
        row = audit['sources'][brief.HASH(binding['originalId'] + ':' + binding['sha256'])]
        assert row['kind'] == 'original' and row['originalSha256'] == binding['sha256']
        assert row['completeOrderedVocabulary'] and row['indexedTextSha256']
        assert config['sourceTitles'][binding['sha256']] == row['title']
        assert row['title'] not in titles or titles[row['title']] == row['sourceId'], 'Ambiguous imported title'
        titles[row['title']] = row['sourceId']
        role = 'communicationSourceIds' if binding['role'] == 'communication-authority' else 'factualSourceIds'
        if row['sourceId'] not in expected[role]:
            expected[role].append(row['sourceId'])
        documents.append({'label': binding['title'], 'title': row['title'], 'sourceId': row['sourceId'],
            'role': binding['role'], 'sha256': binding['sha256'], 'completeReadVerified': True})
    key, body = brief.editorial(record)
    synthesis = audit['sources'][key]
    assert synthesis['kind'] == 'synthesis' and synthesis['originalSha256'] == brief.HASH(body)
    assert synthesis['completeOrderedVocabulary'] and synthesis['indexedTextSha256']
    expected.update(editorialSourceId=synthesis['sourceId'], generationReady=True, sourceGaps=[])
    required = {**actual, 'communicationSourceIds':[]} if config.get('promptAssembly') == 'topic-and-audience-v1' else actual
    assert expected == required, 'Source proof differs from current selection'
    return expected, documents


def build(current=False, source_audit=None, output=OUT):
    handoff = read(ROOT / '.local/adr025-claude-improvement-20261022/generation-handoff.json')['instructionCut']
    cut = verified(ROOT / handoff['expectedVersusActual']['path'], handoff['expectedVersusActual']['sha256'])
    old_config = json.loads(historical_bytes(cut['sourceCommit'], brief.CONFIG, cut['communicationSha256']))
    old_resolver = types.ModuleType('frozen_brief')
    exec(compile(historical_bytes(cut['sourceCommit'], cut['sharedResolver'], cut['sharedResolverSha256']),
        cut['sharedResolver'], 'exec'), old_resolver.__dict__)
    config = read(ROOT / brief.CONFIG) if current else old_config
    commission = verified(handoff['commission']['path'], handoff['commission']['sha256'])
    audit = read(source_audit) if current else None
    if current:
        brief.require_hold(ROOT / '.local/artefact-generation')
    output = Path(output)
    def write(name, value):
        path = output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, ensure_ascii=False))
    subjects = []
    reviewed_subjects = 0
    for selected in cut['subjects']:
        old_record = json.loads(historical_bytes(cut['sourceCommit'], selected['path'], selected['sha256']))
        old_entries = old_resolver.instruction_entries(old_record, old_config, commission)
        run = historical_run(selected['id'], cut['sourceCommit'])
        previous = run['subjects'][0]
        expected = {entry['key']: entry for entry in selected['entries']}
        for entry in old_entries:
            assert entry['promptSha256'] == expected[entry['key']]['promptSha256']
            assert brief.HASH(json.dumps(entry, ensure_ascii=False, sort_keys=True, separators=(',', ':'))) == expected[entry['key']]['bodySha256']
            assert entry['prompt'] == previous['mediaPrompts'][f"{entry['type']}-{entry['format']}-{entry['ordinal']}"]
        record = read(ROOT / selected['path']) if current else old_record
        revision = record.get('review', {}).get('collectionInstructionRevision')
        reviewed = record.get('review', {}).get('status') in ('creative-reviewed','owner-directed-reviewed')
        if revision:
            verdict = revision.get('independentReview')
            reviewed = isinstance(verdict, dict) and verdict.get('disposition') == 'pass'
        if current and reviewed:
            reviewed_subjects += 1
        entries = brief.instruction_entries(record, config, commission) if current else old_entries
        selected_sources, documents = selection(record, config, audit) if current else (previous, [])
        if current and config.get('promptAssembly') == 'topic-and-audience-v1':
            selected_sources = {**selected_sources, 'communicationSourceIds':[]}
            documents = [{**d, 'selected':d['role']!='communication-authority'} for d in documents]
        treatments = []
        for treatment in record['treatments']:
            pair = [entry for entry in entries if (entry['type'], entry['format'], entry['ordinal']) ==
                    (treatment['type'], treatment['format'], treatment['ordinal'])]
            assert len(pair) == 2 and pair[0]['prompt'] == pair[1]['prompt'] and pair[0]['settings'] == pair[1]['settings']
            variants = []
            for entry in pair:
                variants.append({**{k: v for k, v in entry.items() if k != 'prompt'},
                    'selectedSourceIds': brief.source_ids(selected_sources, entry['condition'] == 'with-editorial'),
                    'readiness': 'Instruction resolved; selected source bodies verified; provider format support not rechecked; generation held' if current else entry['readiness'],
                    'previousPromptSha256': expected[entry['key']]['promptSha256']})
            treatments.append({'treatment': treatment, 'prompt': pair[0]['prompt'],
                'promptHtml': md.render(pair[0]['prompt']), 'settings': pair[0]['settings'], 'variants': variants})
        assert len(treatments) == 17
        # Preserve the complete verified earlier inputs as creative foundations.
        # They are reference material, never the current NotebookLM commission.
        foundation = {'sourceCommit': cut['sourceCommit'], 'source': selected['path'],
            'sha256': selected['sha256'], 'inputStatus': 'legacy-foundation',
            'record': old_record, 'baseHtml': md.render(old_record['basePrompt']),
            'synthesisHtml': md.render(old_record['synthesis']['body']), 'treatments': []}
        for treatment in old_record['treatments']:
            entry = next(entry for entry in old_entries if
                (entry['type'], entry['format'], entry['ordinal']) ==
                (treatment['type'], treatment['format'], treatment['ordinal']))
            foundation['treatments'].append({'treatment': treatment, 'prompt': entry['prompt'],
                'promptHtml': md.render(entry['prompt']), 'settings': entry['settings'],
                'variants': [{'condition': item['condition'], 'promptSha256': item['promptSha256']}
                    for item in old_entries if (item['type'], item['format'], item['ordinal']) ==
                    (treatment['type'], treatment['format'], treatment['ordinal'])]})
        subject = {'id': record['id'], 'title': record['title'], 'scope': record['scopeType'],
            'source': selected['path'], 'sha256': brief.HASH((ROOT / selected['path']).read_bytes()) if current else selected['sha256'],
            'ready': selected_sources.get('generationReady'), 'gaps': selected_sources.get('sourceGaps', []),
            'inputStatus': 'revised-unsubmitted' if current else 'previous-generation-input'}
        subjects.append(subject)
        write(f"data/{record['id']}.json", {**subject, 'record': record, 'treatments': treatments,
            'foundation': foundation,
            'baseHtml': md.render(record['basePrompt']), 'synthesisHtml': md.render(record['synthesis']['body']),
            'documents': documents, 'sourceReferenceHtml': md.render(brief.source_references(record, config)) if current and config.get('promptAssembly') != 'topic-and-audience-v1' else '',
            'previousGeneration': {'sourceCommit': run['sourceCommit'], 'recordSha256': selected['sha256'],
                'sourceReady': previous.get('generationReady'), 'instructionComparison': 'changed, not submitted' if current else 'exact ledger match'},
            'selection': {key: selected_sources.get(key) for key in ('factualSourceIds', 'communicationSourceIds',
                'editorialSourceId', 'generationReady', 'sourceGaps')}})
    assert len(subjects) == 87
    write('catalogue.json', {'subjects': subjects, 'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() if current else cut['sourceCommit'],
        'previousCommit': cut['sourceCommit'], 'mode': 'current' if current else 'historical',
        'inputStatus': 'Revised inputs; not submitted or approved by the previous review' if current else 'Frozen previous generation inputs',
        'creativeReview': {'independentlyReviewedSubjects': reviewed_subjects,
            'remainingSubjects': len(subjects) - reviewed_subjects,
            'scope': 'Complete subject packages, all 17 treatments and both conditions',
            'release': 'Collection review and source verification remain separate from media generation'} if current else None,
        'shared': config, 'sharedHtml': md.render(config['commonPrompt']),
        'suffixHtml': {key: md.render(value) for key, value in config['mediaSuffixes'].items()},
        'formatHtml': {key: md.render(value) for key, value in config.get('formatCommissions', {}).items()},
        'sourceAvailability': {'checkedAt': audit['completedAt'], 'originals': audit['originals'], 'syntheses': audit['syntheses'],
            'sourceReadySubjects': sum(bool(subject['ready']) for subject in subjects),
            'completeIndexedReadsVerified': len(audit['sources']),
            'chatRetrieval': 'Not rechecked for this input cut; the earlier chat check returned no answer. Full indexed source reads are verified separately.'} if current else None,
        'commission': commission, 'subjectsCount': 87, 'treatmentsCount': 1479, 'variantsCount': 2958,
        'previousLedgerPromptsVerified': 2958, 'exactLedgerPromptsVerified': 0 if current else 2958})
    (output / 'index.html').write_bytes(Path(__file__).with_suffix('.html').read_bytes())
    result = {'directory': str(output), 'mode': 'current' if current else 'historical', 'subjects': 87,
        'treatments': 1479, 'variants': 2958, 'previousLedgerPromptsVerified': 2958}
    print(json.dumps(result))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--current', action='store_true')
    parser.add_argument('--source-audit', type=Path, default=SOURCE_AUDIT)
    parser.add_argument('--output', type=Path, default=OUT)
    args = parser.parse_args()
    build(args.current, args.source_audit, args.output)
