/** Notebook-only corpus cut; reuse Product's exact-body document admission. */
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createProductDocuments,substantiveExclusion,digest} from '../../../../semantic-product/scripts/product-knowledge-documents.mjs';
const root=fileURLToPath(new URL('../../',import.meta.url));
const work=path.join(root,'.local/artefact-generation');
const refresh=process.argv[2]==='--refresh-commit'?execFileSync('git',['rev-parse','--verify',process.argv[3]+'^{commit}'],{cwd:root,encoding:'utf8'}).trim():null;
if(process.argv.length>2&&!refresh)throw Error('Use --refresh-commit <commit> or no arguments');
const prior=refresh?JSON.parse(await fs.readFile(path.join(work,'corpus/collection-cut.json'),'utf8')):null;
const changed=refresh?new Set(execFileSync('git',['diff-tree','--no-commit-id','--name-only','-r',refresh],{cwd:root,encoding:'utf8'}).trim().split('\n')):null;
const admitted=p=>p==='README.md'||p==='docs/scope-handover.md'
  ||/^docs\/(?:adr|research|ba|website-spec)\/.+\.(?:md|json)$/.test(p)
  ||/^docs\/imports\/.+\/(?:docs\/(?:adr|research)\/.+\.(?:md|json)|README.md|reading-guide.md|source-dependencies.json|source-manifest.json|learning-selection.json|native-selection.json)$/.test(p)
  ||/^config\/authoring\/chapters\/(?:AI|BA)\d{2}\.\d{2}\.json$/.test(p);
const excluded=prior?[...prior.excluded]:[];
const tracked=execFileSync('git',['ls-files','-z','--','README.md','docs','config/authoring/chapters'],{cwd:root,encoding:'utf8'}).split('\0').filter(Boolean);
for(const p of tracked.filter(p=>!refresh&&/\.(?:md|json)$/.test(p)&&!admitted(p))){
  excluded.push({path:p,reason:p.startsWith('docs/generation/')?'NotebookLM generated job/release ledger; excluded as knowledge'
    :p.includes('/native/')?'Retained native archive; exact admitted native owner values enumerated separately, mixed parents/runtime archives excluded'
    :'Runtime, migration or verification receipt; provenance reference only, not substantive source body'});
}
const documents=createProductDocuments(root,{project:'ai-ba',label:'AI Strategy and Business Architecture',paths:['README.md','docs','config/authoring/chapters'],admitPath:p=>admitted(p)&&(!changed||changed.has(p)),
  admitValue:(ns,key,value)=>{const reason=substantiveExclusion(ns,key,value);if(reason)excluded.push({path:key,reason});return !reason;}});
const records=await documents.list();
for(const record of records)if(refresh){
  const committed=execFileSync('git',['show',refresh+':'+record.identity.path],{cwd:root,encoding:'utf8'});
  if(digest(committed)!==record.sha256)throw Error('Changed source differs from the authorised commit: '+record.identity.path);
  record.identity={...record.identity,revision:refresh,workingCopy:false};
}
const receipt=JSON.parse(await fs.readFile(path.join(work,'source-import.json'),'utf8'));
const verified=Object.entries(receipt.sources).filter(([,r])=>r.status==='indexed-verified');
const byHash=new Map(verified.map(([key,r])=>[r.presentationVersion==='verbatim-fenced-text-v1'?r.originalSha256:r.sha256,
  {key,sourceId:r.sourceId,...(r.presentationVersion&&{presentationVersion:r.presentationVersion,uploadedPresentationSha256:r.sha256})}]));
const unique=new Map(),represented=prior?[...prior.represented]:[];
function add(record){
  const hash=record.sha256??digest(record.text);
  const prior=unique.get(hash);
  if(prior){prior.aliases.push(record.identity,...(record.aliases??[]));return;}
  const row={...record,sha256:hash,aliases:[...(record.aliases??[])],uploaded:byHash.get(hash)??null};
  unique.set(hash,row);
}
if(prior)for(const row of prior.rows){
  const identities=[row.identity,...row.aliases].filter(identity=>!changed.has(identity.path));
  if(identities.length)add({...row,identity:identities[0],aliases:identities.slice(1)});
}
for(const record of records){
  const p=record.identity.path;
  if(p.startsWith('config/authoring/chapters/')){
    // Packages mix factual selection, editorial and prompts. Keep those roles
    // separate; the existing chapter/editorial sources represent their content.
    represented.push({path:p,sha256:record.sha256,disposition:'authoring-package represented by separate chapter factual bindings, editorial and prompt custody; never an automatically selected factual source'});
    continue;
  }
  add({...record,sourceType:p.includes('/imports/')?'retained-source-document':p.includes('/website-spec/')?'website-specification':p.includes('/adr/')?'architecture-decision':'repository-document',
    authority:p.includes('/ADR-020-')?'Canonical shared communication brief; substantive requirements govern all87 media, expressed appropriately per medium.':p.includes('/website-spec/')?'Derived or supporting projection subordinate to ADR020; private collection inclusion does not authorise website publication.':record.authority});
}
const nativePages=prior?[...prior.nativePages]:[];
for(const file of (refresh?[]:await fs.readdir(path.join(work,'corpus'))).filter(f=>/^native-.+\.json$/.test(f))){
  const page=JSON.parse(await fs.readFile(path.join(work,'corpus',file),'utf8'));
  nativePages.push({file,namespace:page.namespace,admission:page._admission});
  for(const row of page.entries??[]){
    const reason=substantiveExclusion(row.namespace,row.key,row.value);
    if(reason){excluded.push({namespace:row.namespace,key:row.key,reason});continue;}
    if(row.namespace==='patterns'&&row.key.startsWith('routing-decision:')){
      excluded.push({namespace:row.namespace,key:row.key,reason:'runtime routing-decision metadata; not substantive research or learned method'});continue;
    }
    const text=typeof row.value==='string'?row.value:JSON.stringify(row.value);
    add({text,sha256:digest(text),title:`${row.namespace}/${row.key}`,sourceType:/learning|patterns|feedback|reasoningBank|hierarchical/.test(row.namespace)?'native-learning':'native-research',
      identity:{project:'ai-ba',namespace:row.namespace,key:row.key,storedAt:row.storedAt,updatedAt:row.updatedAt,...(row.controllerIdentity&&{controllerIdentity:row.controllerIdentity})},
      authority:row.key==='ai-ba-website-strategy-and-experience-20261020'?'Retained website research/projection subordinate to canonical ADR020; preserve proposal, source and date qualifications.'
        :'Exact substantive native owner value; retain original status, source ownership, caveats and historical/advisory qualifications. Runtime list metadata is not evidence of effectiveness.',
      selectionRole:/adr019-(?:section|authoring)|ai-ba-website-strategy-and-experience/.test(row.key)?'Mixed editorial/review or projected authoring body; collection availability only. Never automatically select as factual source for editorial comparisons.':'Collection availability; chapter relevance and complete source admission must be reviewed before explicit selection.'});
  }
}
const rows=[...unique.values()];
const bodies=path.join(work,'corpus/bodies');
await fs.mkdir(bodies,{recursive:true});
for(const row of rows){
  row.retainedBody=`corpus/bodies/${row.sha256}.txt`;
  const file=path.join(work,row.retainedBody);
  try{await fs.writeFile(file,row.text,{flag:'wx',mode:0o600});}
  catch(error){if(error.code!=='EEXIST')throw error;if(digest(await fs.readFile(file,'utf8'))!==row.sha256)throw Error('Immutable corpus body changed');}
}
const summary={};for(const row of rows){const c=summary[row.sourceType]??={eligible:0,uploaded:0};c.eligible++;if(row.uploaded)c.uploaded++;}
const history=[...(prior?.refreshHistory??[])];
if(prior){
  const previousBody=JSON.stringify(prior),previousFile=`collection-cut-${digest(previousBody)}.json`;
  await fs.writeFile(path.join(work,'corpus',previousFile),previousBody,{mode:0o600});
  history.push({commit:refresh,previousCut:previousFile,previousCapturedAt:prior.capturedAt,changedPaths:[...changed],
    changedAdmittedBodies:records.map(r=>({path:r.identity.path,sha256:r.sha256,
      priorVersions:prior.rows.filter(old=>[old.identity,...old.aliases].some(i=>i.path===r.identity.path))
        .map(old=>({sha256:old.sha256,retainedBody:old.retainedBody,sourceId:byHash.get(old.sha256)?.sourceId??old.uploaded?.sourceId??null}))}))});
}
const cut={schema:'ai-ba.notebook-corpus.v1',capturedAt:new Date().toISOString(),sourceCommit:refresh??execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),
  scope:'Current tracked substantive repository documents and exact admitted native records; source enumeration/controller gaps remain explicit. Generation and publication remain held for all87 ADR020 alignment.',
  notebookId:receipt.notebookId,summary,nativePages,represented,excluded:[...new Map(excluded.map(r=>[r.path??`${r.namespace}/${r.key}`,r])).values()],rows,refreshHistory:history};
await fs.writeFile(path.join(work,'corpus/collection-cut.json.pending'),JSON.stringify(cut,null,2),{mode:0o600});
await fs.rename(path.join(work,'corpus/collection-cut.json.pending'),path.join(work,'corpus/collection-cut.json'));
console.log(JSON.stringify({summary,uniqueBodies:rows.length,represented:represented.length,excluded:cut.excluded.length,nativePageCount:nativePages.length}));
