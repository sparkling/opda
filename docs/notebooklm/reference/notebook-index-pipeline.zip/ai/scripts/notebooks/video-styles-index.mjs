/** Local style comparison. Generation/download/quality remain with existing owners. */
import fs from 'node:fs/promises';
import {createReadStream,constants} from 'node:fs';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {verifiedVideoKey} from './video-quality.mjs';
const root=path.resolve(import.meta.dirname,'../..'),work=path.join(root,'.local/n01-comparison');
const run=path.join(work,'runs/video-styles-v1'),out=path.join(work,'versions/video-styles-v1');
const read=async p=>JSON.parse(await fs.readFile(p,'utf8'));
const exists=p=>fs.stat(p).then(()=>true,()=>false);
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const label=s=>({auto_select:'Auto-select',watercolor:'Watercolour',paper_craft:'Paper-craft'}[s]??s.split('_').map(v=>v[0].toUpperCase()+v.slice(1)).join(' '));
const digest=async file=>{const h=createHash('sha256');for await(const b of createReadStream(file))h.update(b);return h.digest('hex');};
const config=await read(path.join(root,'config/authoring/experiments/N01-video-styles-v1.json'));
const snapshot=await read(path.join(run,'request-inputs.json'));
const ledgers=await Promise.all(config.subjects.map(id=>read(path.join(run,'docs/generation',id+'.json'))));
await fs.mkdir(path.join(out,'n01'),{recursive:true});
await fs.mkdir(path.join(out,'media'),{recursive:true});
await fs.mkdir(path.join(out,'inputs'),{recursive:true});
const cacheFile=path.join(out,'delivery.json'),cache=await exists(cacheFile)?await read(cacheFile):{};
let ready=0;const errors=[];const chapters=[];
for(const ledger of ledgers){
 const topics=[...new Map(snapshot.requests.filter(r=>r.subject===ledger.sectionId).map(r=>[r.topicId,r])).values()];
 const sections=[];
 for(const topic of topics){
  const cards=[];
  for(const style of config.styles){
   const job=ledger.jobs.find(j=>j.topicId===topic.topicId&&j.style===style);
   if(job.id&&!/^[a-f0-9-]{36}$/.test(job.id))throw Error('Invalid native media identity');
   const file=path.join(run,'originals',job.key+'.mp4'),target=path.join(out,'media',job.id+'.mp4');
   let media='';
   if(job.status==='completed'&&job.id&&await exists(file))try{
    const proof=await read(path.join(run,'transfers/video-readiness',job.id+'.json'));
    const stat=await fs.stat(file),stamp=stat.size+':'+stat.mtimeMs;
    if(cache[job.id]?.stamp!==stamp||!await exists(target)){
     const sha=await digest(file),info=proof.metadata.streams.find(s=>s.codec_type==='video');
     verifiedVideoKey({job,notebookId:ledger.notebookId,hash:sha,info,proof,originals:{}});
     await fs.copyFile(file,target,constants.COPYFILE_FICLONE);
     if(await digest(target)!==sha)throw Error('Local video copy differs');
     cache[job.id]={stamp,sha256:sha,width:info.width,height:info.height};
    }
    const poster=path.join(out,'media',job.id+'.jpg');
    if(!await exists(poster))execFileSync('ffmpeg',['-v','error','-threads','1','-ss','5','-i',target,'-frames:v','1','-vf','scale=640:-2','-threads','1','-y',poster],{timeout:30000});
    media=`<video controls preload="none" poster="../media/${job.id}.jpg" src="../media/${job.id}.mp4"></video><p class="actions"><span>${cache[job.id].width} × ${cache[job.id].height}</span><a href="../media/${job.id}.mp4" download>Download video</a></p>`;
    ready++;
   }catch(error){errors.push({key:job.key,error:error.message});}
   cards.push(`<article><h4>${escape(label(style))}</h4>${media||`<p class="pending">${escape(({completed:'Awaiting verified download',submitted:'Generating',planned:'Queued',submitting:'Submitting'})[job.status]??job.status.replaceAll('-',' '))}</p>`}</article>`);
  }
  const sources=[];
  for(const source of topic.selectedSources){
   if(!/^[a-f0-9-]{36}$/.test(source.sourceId))throw Error('Invalid native source identity');
   const body=await read(path.join(run,'source-readbacks',source.sourceId+'.json'));
   if(createHash('sha256').update(body.content).digest('hex')!==source.indexedTextSha256)throw Error('Source display mismatch');
   await fs.writeFile(path.join(out,'inputs',source.sourceId+'.txt'),body.content);
   sources.push(`<li><a href="../inputs/${source.sourceId}.txt">${escape(source.title)}</a></li>`);
  }
  sections.push(`<section id="${escape(topic.topicId)}"><h3>${escape(topic.topicId)} · ${escape(topic.topic.title)}</h3><details><summary>Prompt and selected sources</summary><pre>${escape(topic.consumedCreateArguments.focus_prompt)}</pre><ul>${sources.join('')}</ul><p>The source texts and prompt are identical across these styles. Format: Explainer; language: en-GB.</p></details><div class="styles">${cards.join('')}</div></section>`);
 }
 chapters.push(`<section id="${ledger.sectionId}"><h2>${escape(ledger.sectionId)} · ${escape(ledger.subjects[0].title)}</h2>${sections.join('')}</section>`);
}
const html=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Explainer video styles · Chapters 1–2</title><style>
:root{font:18px/1.5 system-ui,sans-serif;color:#173033;background:#f4f5f0}*{box-sizing:border-box}body{margin:0}main{max-width:1700px;margin:auto;padding:32px}h1{font-size:clamp(32px,4vw,54px);line-height:1.1}h2{margin-top:64px}h3{margin:44px 0 14px}h4{margin:0 0 12px}a{color:#096b70}nav{display:flex;gap:24px;flex-wrap:wrap}.styles{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,360px),1fr));gap:20px}article{background:white;border:1px solid #ccd8d7;border-radius:8px;padding:16px;min-width:0}video{display:block;width:100%;aspect-ratio:16/9;background:#10272c}details{margin:12px 0 22px}summary{cursor:pointer}pre{white-space:pre-wrap;overflow-wrap:anywhere}.pending{aspect-ratio:16/9;display:grid;place-items:center;color:#52666c;background:#e8efec}.actions{display:flex;justify-content:space-between;gap:12px;font-size:14px}section{scroll-margin-top:20px}button{font:inherit;padding:6px 16px;cursor:pointer}a:focus-visible,button:focus-visible,summary:focus-visible{outline:3px solid #b36f28;outline-offset:3px}
</style></head><body><main><p><a href="http://127.0.0.1:8932/n01/">All notebook experiments</a></p><h1>Explainer video styles</h1><p>Chapters 1 and 2 · 9 topics × 9 styles · ${ready} of 81 verified videos ready.</p><p>Each style uses the same topic prompt and complete source texts. Compare visual appeal, clarity and how well the style communicates the subject. These fresh generations may also vary in narration and sequence.</p><nav><a href="#N01.01">Chapter 1</a><a href="#N01.02">Chapter 2</a><button type="button" onclick="location.reload()">Refresh completed videos</button></nav>${chapters.join('')}<p><a href="../inputs/request-inputs.json">Full frozen input records</a></p></main></body></html>`;
await fs.writeFile(path.join(out,'n01/index.html.pending'),html);await fs.rename(path.join(out,'n01/index.html.pending'),path.join(out,'n01/index.html'));
await fs.writeFile(path.join(out,'inputs/request-inputs.json'),JSON.stringify(snapshot,null,2));
await fs.writeFile(cacheFile,JSON.stringify(cache));
const result={id:'video-styles-v1',label:'Explainer visual styles · Chapters 1–2',note:'Nine topics in Auto-select and eight named styles; identical prompts and source texts. Fresh local-only preset comparison.',artefacts:ready,requested:81,updatedAt:new Date().toISOString(),errors};
await fs.writeFile(path.join(out,'version.json'),JSON.stringify(result,null,2));
await fs.writeFile(path.join(out,'release.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify({...result,url:'http://127.0.0.1:8932/v/video-styles-v1/n01/'}));
