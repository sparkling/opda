// Each edition projects its ADR owner; the published default remains ADR-018.
import {readFileSync, existsSync} from 'node:fs';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
// Astro bundles this module into its output tree; resolve the content checkout
// from the documented repository/site CLI working directories, not the bundle URL.
export const repositoryRoot = existsSync(resolve(process.cwd(),'docs/adr')) ? process.cwd() : resolve(process.cwd(),'..');
const readable = value => value.replace(/\[([^\]]+)\](?:\[[^\]]+\]|\([^)]+\))/g, '$1').replace(/\*\*/g, '').replace(/\s+/g, ' ').trim();

export function notebookInventory(root = repositoryRoot, edition = 'adr018') {
  if (/^proposals-20261025:(RU|CA|PD|WD|IT)$/.test(edition)) return proposalInventory(root, edition);
  if (edition === 'adr025-20261021') return instructionInventory(root, edition);
  if (edition !== 'adr018') throw Error(`Unknown notebook edition: ${edition}`);
  const owner = 'docs/adr/ADR-018-notebook-artefact-sections-and-chapters.md';
  const source = readFileSync(resolve(root, owner), 'utf8');
  const categories = [
    {id:'business-architecture', prefix:'BA', title:'Business Architecture', description:'How the enterprise creates and sustains value, and how capabilities, work, information, people and responsibilities fit together.'},
    {id:'ai-strategy', prefix:'AI', title:'AI Strategy', description:'What AI enablement makes possible, the strategic choices available, and how capability can be built, adopted, operated and improved.'},
  ];
  const sections = [...source.matchAll(/^### ((BA|AI)\d{2}) — (.+)$/gm)].map(match => {
    const category = categories.find(item => item.prefix === match[2]);
    return {id:match[1], title:match[3].trim(), categoryId:category.id, path:`/${category.id}/${match[1].toLowerCase()}/`};
  });
  const chapters = [...source.matchAll(/^\| ((BA|AI)\d{2}\.\d{2}) \| ([^|]+) \| ([^|]+) \|$/gm)].map(match => {
    const section = sections.find(item => item.id === match[1].split('.')[0]);
    if (!section) throw Error(`Chapter has no section: ${match[1]}`);
    const scope = readable(match[4]);
    return {id:match[1], title:readable(match[3]), scope, question:scope.slice(0,scope.indexOf('?')+1), sectionId:section.id,
      categoryId:section.categoryId, path:`${section.path}${match[1].toLowerCase().replace('.','-')}/`};
  });
  if (sections.length !== 17 || chapters.length !== 87 || new Set(chapters.map(item=>item.id)).size !== chapters.length)
    throw Error('Commissioned ADR-018 inventory is incomplete or duplicated');
  for (const chapter of chapters) if (!chapter.question) throw Error(`Missing reader question: ${chapter.id}`);
  return {owner, sha256:createHash('sha256').update(source).digest('hex'), categories:categories.map(item=>({...item,path:`/${item.id}/`})), sections, chapters};
}

function proposalInventory(root, edition) {
  const id=edition.split(':')[1];
  const manifest=JSON.parse(readFileSync(resolve(root,'config/authoring/proposals/manifest.json'),'utf8'));
  const entry=manifest.collections.find(item=>item.id===id);
  if(!entry || entry.path!==`config/authoring/proposals/${id}.json`)throw Error('Invalid proposal collection binding');
  const source=readFileSync(resolve(root,entry.path),'utf8');
  const config=JSON.parse(source);
  if(config.schema!=='ai-ba.proposal-collection.v1'||config.id!==id||config.edition!==manifest.edition)throw Error('Invalid proposal collection');
  const subjects=config.subjects;
  if(new Set(subjects.map(s=>s.id)).size!==subjects.length)throw Error('Duplicate proposal subject');
  const sections=subjects.filter(s=>s.scopeType==='section');
  const chapters=subjects.filter(s=>s.scopeType==='chapter');
  if(chapters.some(c=>!sections.some(s=>s.id===c.sectionId)))throw Error('Missing proposal section');
  const collections=subjects.filter(s=>s.scopeType==='collection');
  if(collections.length!==1)throw Error('Invalid proposal collection overview');
  return {edition,owner:entry.path,sha256:createHash('sha256').update(source).digest('hex'),categories:[],
    sections,chapters,collection:collections[0],subjects,config,manifest};
}

function instructionInventory(root, edition) {
  const owner = 'docs/adr/ADR-024-fresh-notebook-organisation-and-artefact-regeneration.md';
  const source = readFileSync(resolve(root, owner), 'utf8');
  const sections = [], chapters = [];
  for (const match of source.matchAll(/^### (\d+)\. ([^\n]+)\n([\s\S]*?)(?=^### |$(?![\s\S]))/gm)) {
    const id = `N${match[1].padStart(2,'0')}`;
    const rows = [...match[3].matchAll(/^\| (N\d{2}\.\d{2}) \| ([^|]+) \| ([^|]+) \|$/gm)];
    if (!rows.length) continue;
    sections.push({id, title:readable(match[2]), scope:match[3].split('| Ref')[0].trim(), scopeType:'section'});
    for (const row of rows) {
      if (!row[1].startsWith(`${id}.`)) throw Error(`Chapter has wrong section: ${row[1]}`);
      chapters.push({id:row[1], title:readable(row[2]), question:readable(row[2]), scope:readable(row[3]), sectionId:id, scopeType:'chapter'});
    }
  }
  if (sections.length !== 13 || chapters.length !== 73 || new Set(chapters.map(item=>item.id)).size !== 73)
    throw Error('Commissioned ADR-024 inventory is incomplete or duplicated');
  const collection = {id:'all', title:'AI strategy and business architecture', scopeType:'collection'};
  return {edition, owner, sha256:createHash('sha256').update(source).digest('hex'), categories:[], sections, chapters,
    collection, subjects:[...chapters,...sections,collection]};
}

export function reviewedAuthoring(id, root = repositoryRoot, sourceCommit = null) {
  const fresh = /^(N\d{2}(?:\.\d{2})?|all)$/.test(id);
  if (!fresh && !/^(BA|AI)\d{2}\.\d{2}$/.test(id)) throw Error('Invalid chapter identity');
  const scopeType = id === 'all' ? 'collection' : id.includes('.') ? 'chapter' : 'section';
  const directory = scopeType === 'collection' ? 'collections' : `${scopeType}s`;
  const relative = `config/authoring/${directory}/${id}.json`;
  const path = resolve(root, relative);
  if (sourceCommit !== null && !/^[a-f0-9]{40}$/.test(sourceCommit)) throw Error('Invalid authoring source commit');
  if (sourceCommit === null && !existsSync(path)) return null;
  const record = JSON.parse(sourceCommit === null ? readFileSync(path,'utf8')
    : execFileSync('git',['show',`${sourceCommit}:${relative}`],{cwd:root,encoding:'utf8'}));
  if (record.id !== id || record.schema !== (fresh ? 'ai-ba.subject-authoring.v2' : 'ai-ba.chapter-authoring.v1')
      || (fresh && (record.scopeType !== scopeType || record.edition !== 'adr025-20261021')))
    throw Error(`Authoring identity/schema mismatch: ${id}`);
  const revision=record.review?.instructionRevision;
  const reviewedSuccessor=fresh && record.review?.status==='owner-directed-reviewed'
    && record.review?.readiness?.instructions==='owner-directed-reviewed'
    && revision?.status==='independent-review-passed' && revision.independentReview?.disposition==='pass';
  if (!['reviewed','repaired'].includes(record.review?.status) && !reviewedSuccessor
      && !(fresh && record.review?.status==='creative-reviewed' && record.review?.readiness?.instructions==='fresh-final-reviewed')) return null;
  if (!record.basePrompt?.trim() || !(fresh ? record.synthesis?.body : record.editorial)?.trim() || !record.sourceBindings?.length)
    throw Error(`Reviewed authoring lacks substantive content: ${id}`);
  if (fresh && (record.treatments?.length !== 17 || record.treatments.some(item=>!item.prompt?.trim())))
    throw Error(`Reviewed authoring lacks treatment commissions: ${id}`);
  for (const binding of record.sourceBindings)
    if (!['originalId','title','owner','locator','role','contribution','passage','use','limits'].every(key=>typeof binding[key]==='string' && binding[key].trim()))
      throw Error(`Incomplete source binding: ${id}`);
  return record;
}
