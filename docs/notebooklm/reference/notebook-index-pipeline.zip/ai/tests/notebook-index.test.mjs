import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,mkdtempSync,mkdirSync,writeFileSync,rmSync,existsSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {notebookInventory,reviewedAuthoring} from '../scripts/notebooks/inventory.mjs';
import {inventory} from '../site/notebooks/data/programme.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const dist=resolve(root,process.env.AI_BA_NOTEBOOK_TEST_DIST??'site/dist-notebooks');
const legacy=notebookInventory(root);
const releaseFile=join(root,'docs/generation/releases/notebook-release.json');
const release=existsSync(releaseFile)?JSON.parse(readFileSync(releaseFile,'utf8')):null;
const media=release?Object.values(release.subjects).flatMap(chapter=>[...chapter.decks,...chapter.multimedia]):[];
const items=[{path:'/'},...inventory.sections,inventory.collection];
const html=new Map(items.map(item=>[item.path,readFileSync(join(dist,item.path,'index.html'),'utf8')]));

test('the published successor projects thirteen sections,73chapters and one collection while preserving legacy inventory',()=>{
  assert.equal(inventory.sections.length,13);assert.equal(inventory.chapters.length,73);assert.equal(inventory.subjects.length,87);
  assert.equal(new Set(inventory.subjects.map(subject=>subject.id)).size,87);
  assert.equal(legacy.sections.length,17);assert.equal(legacy.chapters.length,87);
  assert.equal(inventory.edition,'adr025-20261021');
});

test('the source inventory and published successor routes retain exact subject identities',()=>{
  const fresh=notebookInventory(root,'adr025-20261021');
  assert.equal(fresh.sections.length,13);assert.equal(fresh.chapters.length,73);assert.equal(fresh.subjects.length,87);
  assert.equal(new Set(fresh.subjects.map(subject=>subject.id)).size,87);
  assert.equal(fresh.chapters.find(chapter=>chapter.id==='N02.08').sectionId,'N02');
  assert.equal(fresh.subjects.filter(subject=>subject.scopeType==='collection').length,1);
  assert.ok(fresh.subjects.every(subject=>subject.path===undefined));
  assert.equal(notebookInventory(root).chapters[0].id,legacy.chapters[0].id);
  assert.throws(()=>notebookInventory(root,'uncommissioned'),/Unknown notebook edition/);
});

test('all 15 pages have a single main heading, correct canonical URL and working internal links',()=>{
  assert.equal(html.size,15);
  for(const [route,body] of html){
    // Match the shared SA/EA consumer checks: reading documents inside templates
    // are inert until opened, and retain their own headings in the reading dialog.
    const activeHtml=body.replace(/(<template\b[^>]*>)[\s\S]*?<\/template>/g,'$1</template>');
    assert.doesNotMatch(activeHtml,/<body[^>]*class="[^"]*index-expanded-default/,route);
    assert.equal((activeHtml.match(/<h1\b/g)||[]).length,1,route);
    assert.equal((activeHtml.match(/<main\b/g)||[]).length,1,route);
    const ids=[...activeHtml.matchAll(/\sid="([^"]+)"/g)].map(match=>match[1]);
    assert.equal(new Set(ids).size,ids.length,`${route} duplicate active document IDs`);
    for(const [,target] of activeHtml.matchAll(/data-editorial-open="([^"]+)"/g))
      assert.ok(body.includes(`<template id="${target}"`),`${route} missing authoring document ${target}`);
    assert.ok(body.includes(`rel="canonical" href="https://ba.ai.hm.sparklingideas.co.uk${route}"`),route);
    for(const [,href] of body.matchAll(/href="([^"]+)"/g)){
      if(/^(https?:|mailto:|data:image\/svg\+xml,)/.test(href))continue;
      const [target,fragment]=href.startsWith('#')?[route,href.slice(1)]:href.split('#');
      if(/^\/(?:_astro|fonts)\//.test(target))continue;
      if(/^\/custody\/generation\/[a-f0-9-]{36}\/[a-f0-9-]{36}(?:-[a-f0-9]{16})?\.(png|pdf|mp4|m4a)$/.test(target)){
        assert.ok(media.some(item=>item.original.path===target&&/^[a-f0-9]{64}$/.test(item.original.sha256)),`${route} unrecorded custody original ${target}`);
        const version=target.match(/-([a-f0-9]{16})\.mp4$/)?.[1];
        if(version)assert.ok(media.some(item=>item.original.path===target&&item.original.sha256.startsWith(version)),`${route} wrong rendition hash suffix`);
        continue;
      }
      if(target.startsWith('/presentations/')){
        assert.ok(!target.includes('..')&&existsSync(join(dist,target)),`${route} missing media rendition ${target}`);
        continue;
      }
      assert.ok(html.has(target),`${route} links to ${href}`);
      if(fragment)assert.ok(html.get(target).includes(`id="${fragment}"`),`${route} missing ${href}`);
    }
  }
});

test('shared scaffold shows the complete accepted N hierarchy and no retired media',()=>{
  const home=html.get('/');
  assert.ok(home.includes(`href="${inventory.collection.path}"`));
  for(const section of inventory.sections){
    assert.ok(home.includes(`href="${section.path}"`));
    assert.match(html.get(section.path),/collapsible-index/);
    assert.ok(html.get(section.path).includes('id="system-0"'));
  }
  for(const chapter of inventory.chapters){
    const section=inventory.sections.find(item=>item.id===chapter.sectionId);
    const body=html.get(section.path);
    assert.ok(home.includes(`href="${chapter.path}"`));
    assert.ok(body.includes(`id="${chapter.path.split('#')[1]}"`));
    assert.equal(existsSync(join(dist,section.path,chapter.id.toLowerCase().replace('.','-'),'index.html')),false);

    assert.match(body,/class="cognitive-level"/);assert.match(body,/Presenter Slides/);
    assert.equal(reviewedAuthoring(chapter.id,root).review.readiness.instructions,'owner-directed-reviewed');
    const subjectCommit=release.subjects[chapter.id]?.inputSourceCommit??release.sourceCommit;
    assert.ok(reviewedAuthoring(chapter.id,root,subjectCommit));
    assert.equal((body.match(/data-editorial-open=/g)||[]).length,7*(1+inventory.chapters.filter(item=>item.sectionId===section.id).length));
    for(const treatment of reviewedAuthoring(chapter.id,root,subjectCommit).treatments)
      assert.ok(body.includes(`${treatment.type} / ${treatment.format} / ${treatment.ordinal}`),`${chapter.id} ${treatment.format}/${treatment.ordinal}`);
  }
  for(const body of html.values()){
    if(!release?.available)assert.doesNotMatch(body,/\/custody\/generation\//);
    assert.doesNotMatch(body,/\/presentations\/ai-ba-(?:ai|ba)\d/);
    assert.doesNotMatch(body,/4ebc5536-8a8d-49ab-b123-21eb4a147500/);
  }
  assert.ok(home.includes(`${release?.available??0} of 2,958`));
  assert.match(home,/Open original/);
});

test('current owner-directed instructions require their own independent review evidence',()=>{
  const temporary=mkdtempSync(join(tmpdir(),'ai-ba-successor-admission-'));
  try{
    const folder=join(temporary,'config/authoring/chapters');mkdirSync(folder,{recursive:true});
    const file=join(folder,'N01.01.json');
    const record=JSON.parse(readFileSync(join(root,'config/authoring/chapters/N01.01.json'),'utf8'));
    writeFileSync(file,JSON.stringify(record));
    assert.equal(reviewedAuthoring('N01.01',temporary).review.instructionRevision.status,'independent-review-passed');
    assert.doesNotMatch(reviewedAuthoring('N01.01',temporary).treatments[0].prompt,/self-contained|read independently/);
    record.review.instructionRevision.status='pending-independent-review';
    writeFileSync(file,JSON.stringify(record));assert.equal(reviewedAuthoring('N01.01',temporary),null);
    record.review.instructionRevision.status='independent-review-passed';
    delete record.review.instructionRevision.independentReview;
    writeFileSync(file,JSON.stringify(record));assert.equal(reviewedAuthoring('N01.01',temporary),null);
  }finally{rmSync(temporary,{recursive:true,force:true});}
});

test('draft authoring stays out of the reading interface; incomplete reviewed records fail closed',()=>{
  const temporary=mkdtempSync(join(tmpdir(),'ai-ba-chapter-admission-'));
  try{
    const folder=join(temporary,'config/authoring/chapters');mkdirSync(folder,{recursive:true});
    const file=join(folder,'BA01.01.json');
    writeFileSync(file,JSON.stringify({schema:'ai-ba.chapter-authoring.v1',id:'BA01.01',review:{status:'draft'}}));
    assert.equal(reviewedAuthoring('BA01.01',temporary),null);
    writeFileSync(file,JSON.stringify({schema:'ai-ba.chapter-authoring.v1',id:'BA01.01',review:{status:'reviewed'}}));
    assert.throws(()=>reviewedAuthoring('BA01.01',temporary),/lacks substantive content/);
    const complete={schema:'ai-ba.chapter-authoring.v1',id:'BA01.01',basePrompt:'Explain the chapter.',editorial:'A developed argument.',review:{status:'repaired'},
      sourceBindings:[{originalId:'source-1',title:'Original',owner:'ai-ba',locator:'docs/adr/ADR-018-notebook-artefact-sections-and-chapters.md',role:'primary',contribution:'Scope',passage:'Decision',use:'Explain the scope',limits:'Proposed'}]};
    writeFileSync(file,JSON.stringify(complete));
    assert.deepEqual(reviewedAuthoring('BA01.01',temporary),complete);
    assert.throws(()=>reviewedAuthoring('../../memory',temporary),/Invalid chapter identity/);
    assert.throws(()=>reviewedAuthoring('BA01.01',temporary,'main'),/Invalid authoring source commit/);
  }finally{rmSync(temporary,{recursive:true,force:true});}
});

 test('all section cards include unique artwork and chapter lists',()=>{
  const home=html.get('/');
  const cards=[...home.matchAll(/<article\b[^>]*class="collection-card"[^>]*>([\s\S]*?)<\/article>/g)].map(match=>match[1]);
  assert.equal(cards.length,13);
  const jump=home.match(/<nav[^>]*aria-labelledby="section-index-title"[^>]*>([\s\S]*?)<\/nav>/)?.[1];
  assert.ok(jump);
  for(const section of inventory.sections)assert.ok(jump.includes(`href="#${section.id.toLowerCase()}"`));
  const images=cards.map(card=>{
    const src=card.match(/<img[^>]*src="([^"]+)"/)?.[1];
    assert.ok(src,'card artwork'); assert.ok(existsSync(join(dist,src)),src); return src;
  });
  assert.equal(new Set(images).size,13);
  for(const [index,section] of inventory.sections.entries()){
    assert.match(cards[index],/>Chapters</);
    for(const chapter of inventory.chapters.filter(item=>item.sectionId===section.id))
      assert.ok(cards[index].includes(`href="${chapter.path}"`));
  }
 });

test('AI reading controls and media labels use synthesis terminology',()=>{
  for(const [route,body] of html){
    if(route==='/')continue;
    const active=body.replace(/<template\b[^>]*>[\s\S]*?<\/template>/g,'');
    for(const label of ['Shared purpose &amp; audience','Medium &amp; format guidance','Artefact treatments','Evidence &amp; source selection','Optional synthesis source','Submitted prompts &amp; settings']) assert.ok(active.includes('>'+label+'</button>'),route+' missing '+label);
    assert.doesNotMatch(active,/>Synthesis v1<\/button>/,route);
    assert.doesNotMatch(active,/>Editorial(?: v\d+)?<\/button>/,route);
    assert.doesNotMatch(active,/(?:With|Without) Editorial/,route);
    for(const [,label] of active.matchAll(/(?:data-title|aria-label)="([^"]+)"/g))assert.doesNotMatch(label,/with(?:out)?-editorial/,route);
  }
});
