#!/usr/bin/env python3
"""Run a configured project's existing NotebookLM owner; never create a new queue."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess

ACTIONS = ("dry-run", "prepare", "validate", "generate", "download", "index")
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--binding", type=Path, required=True)
parser.add_argument("--action", choices=ACTIONS, required=True)
parser.add_argument("--check", action="store_true", help="Check dependencies and show argv without executing")
args = parser.parse_args()
binding_path = args.binding.resolve(strict=True)
binding = json.loads(binding_path.read_text())
if binding.get("schema") != "notebooklm.project-workflow.v1":
    raise SystemExit("Unsupported binding schema")
root = binding.get("cwd")
if not isinstance(root, str) or not root.strip():
    raise SystemExit("Binding needs a project cwd")
cwd = (binding_path.parent / root).resolve(strict=True)
if not cwd.is_dir():
    raise SystemExit("Project cwd is not a directory")
run_id = binding.get("runId")
if not isinstance(run_id, str) or not run_id.strip():
    raise SystemExit("Binding needs an explicit runId")
commands = binding.get("commands", {})
argv = commands.get(args.action)
if not isinstance(argv, list) or not argv or any(not isinstance(x, str) or not x or "\0" in x for x in argv):
    raise SystemExit("Selected action needs a nonempty argv array")
exe = argv[0]
resolved = str(cwd / exe) if "/" in exe else shutil.which(exe)
# Preserve virtual-environment launcher symlinks; realpath can select bare Python.
if not resolved or not Path(resolved).is_file():
    raise SystemExit("Configured executable unavailable: " + exe)
dependencies = binding.get("dependencies")
if not isinstance(dependencies, list) or not dependencies:
    raise SystemExit("Declare the project's required dependency paths")
for dependency in dependencies:
    if not isinstance(dependency, dict) or not isinstance(dependency.get("path"), str) or not dependency.get("purpose"):
        raise SystemExit("Each dependency needs a path and purpose")
    if not (cwd / dependency["path"]).exists():
        raise SystemExit("Missing dependency: " + dependency["path"] + " (" + dependency["purpose"] + ")")
print(json.dumps({"action": args.action, "runId": run_id, "cwd": str(cwd), "argv": argv,
                  "mode": "check-only" if args.check else "existing-owner"}), flush=True)
if not args.check:
    # Array execution preserves literal prompt/path characters. No shell or retry.
    raise SystemExit(subprocess.run([resolved, *argv[1:]], cwd=cwd).returncode)
