# Connect the skill scripts to an existing project

The bundled `scripts/run-workflow.py` runs the project's approved generation,
download and index commands. It is an adapter, not a NotebookLM client, queue,
renderer or standalone implementation. A blank repository needs those owners
first; do not claim this skill installed them. Never substitute another provider
or copy a private project's pipeline to make the adapter appear portable.

Create a small binding JSON in the project's normal configuration location with:

- `schema`: `notebooklm.project-workflow.v1`.
- `cwd`: project directory, absolute or relative to the binding file.
- `runId`: the explicit commissioned run, shown beside the cwd and argv before
  every action. Check these against the reviewed binding; the backend owns exact
  source/request validation and registered variant selection.
- `dependencies`: objects containing `path` (absolute or relative to `cwd`) and
  `purpose`. Include the actual native SDK interpreter/package, generation owner,
  source/request configuration, delivery owner and shared renderer dependencies.
- `commands`: the actions below, each an explicit argv array, never shell text.

| Action | Bind to the existing owner |
| --- | --- |
| `dry-run` | Resolve and validate the full proposed input without provider mutation. |
| `prepare` | Import authorised sources, verify full readbacks and freeze reviewed requests. This can mutate NotebookLM; it is not an offline check. |
| `validate` | Check the frozen source/request/ledger identity. |
| `generate` | Existing finite supervisor with its quota, uncertain-create reconciliation, progress, download and streamed-index behaviour. |
| `download` | Existing acknowledged-ID delivery stage. Respect its locks and supervisor preconditions; do not spawn a competing downloader. |
| `index` | Existing standard presentation-index refresh, using its shared components and exact request/media records. |

For compatible projects using the established Python/Node owners, command arrays
have this shape (substitute the actual installed interpreter and registered run):

```json
{
  "dry-run": [".venv/bin/python", "scripts/notebooks/local-generation.py", "--variant", "reviewed-run", "--dry-run"],
  "prepare": [".venv/bin/python", "scripts/notebooks/local-generation.py", "--variant", "reviewed-run", "--prepare"],
  "validate": [".venv/bin/python", "scripts/notebooks/local-generation.py", "--variant", "reviewed-run", "--validate"],
  "generate": [".venv/bin/python", "scripts/notebooks/local-generation.py", "--variant", "reviewed-run", "--serve"],
  "download": [".venv/bin/python", "scripts/notebooks/local-generation.py", "--variant", "reviewed-run", "--delivery"],
  "index": ["node", "scripts/notebooks/local-comparison-refresh.mjs", "reviewed-run"]
}
```

These names are a compatibility example, not commands guaranteed in every
repository. This route needs `notebooklm_tools` in the selected Python environment,
the project's imported queue/native/quota/ownership modules, and Node plus the
pinned shared renderer and media tools declared by that project. The delivery
child normally runs under the supervisor; `--delivery` alone may do no work
without its live ownership record. Starting `generate` already streams downloads
and index updates. The adapter neither changes holds nor enables generation.

From the installed skill directory:

```sh
python3 scripts/run-workflow.py --binding /path/to/project/notebook-workflow.json --action generate --check
python3 scripts/run-workflow.py --binding /path/to/project/notebook-workflow.json --action dry-run
```

The first checks configured paths and prints the command; it does not prove API
authentication or all runtime dependencies. The second invokes the project's real
offline projection. Execute `prepare`, `generate` or `download` only after the
complete input review and within the user's authority. Keep receipts in the
project's existing owner. The script does not install dependencies, store secrets,
retry mutations, create another ledger or publish anything itself. `index` must
bind to a local renderer; publication remains the project's separately authorised
release operation. Verify the actual served URL before handing it over.
